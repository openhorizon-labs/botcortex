"""`botcortex arm …`: meeting the arm before trusting it.

The first time software moves a robot is the most dangerous moment it will
have, because everything is still an assumption: which port, which way each
joint turns, whether the servos are even powered. `status` reads and never
moves. `check` is the first motion, and it is built to be the gentlest one
possible: one joint at a time, eight degrees, with the simulation saying IN
WORDS what should happen before it does — "the gripper should move to the arm's
left" — so the person at the bench can tell a right move from a wrong one.

A joint that turns the wrong way is not an error to stop at: it is recorded
(`wire_signs` in settings) and corrected on the wire from then on, so the
twin, the skills and the recorded data never learn about it.
"""

from __future__ import annotations

from botcortex import settings, ui
from botcortex.doctor import serial_ports

_STEP_DEG = 8.0
_AXES = (
    ("away from the base, forward", "back toward the base"),
    ("to the arm's left", "to the arm's right"),
    ("up", "down"),
)


def direction(before, after) -> str:
    """The dominant direction of a movement, in bench words. The base frame is
    x forward, y to the arm's left, z up."""
    deltas = [a - b for a, b in zip(after, before, strict=True)]
    axis = max(range(3), key=lambda i: abs(deltas[i]))
    return _AXES[axis][0 if deltas[axis] > 0 else 1]


def status(device: str | None) -> int:
    """Read-only: which ports exist, and what the arm on one of them reports."""
    from botcortex.roarm import LinkError, RoArmLink

    ports = serial_ports()
    ui.heading("Serial ports")
    if not ports:
        ui.bad("none found", "plug in the arm's USB cable and switch on its 12 V power")
        return 1
    chosen = device or settings.get("device") or (ports[0] if len(ports) == 1 else None)
    for port in ports:
        (ui.ok if port == chosen else ui.note)(port + ("   ← the arm" if port == chosen else ""))
    if chosen is None:
        ui.warn("more than one port, and none chosen", "botcortex config set device <port>")
        return 1
    ui.heading("The arm")
    try:
        link = RoArmLink.open_serial(chosen)
        reply = link.feedback()
        link.close()
    except ImportError as e:
        ui.bad(str(e))
        return 1
    except LinkError as e:
        ui.bad(
            str(e), "check the 12 V supply is on and the USB cable is the DATA one, then try again"
        )
        return 1
    ui.ok(f"answers on {chosen}")
    ui.table(
        [
            ("joint", "radians", "load"),
            ("base", f"{reply['b']:+.3f}", reply.get("torB", "")),
            ("shoulder", f"{reply['s']:+.3f}", reply.get("torS", "")),
            ("elbow", f"{reply['e']:+.3f}", reply.get("torE", "")),
            ("hand", f"{reply['t']:+.3f}", reply.get("torH", "")),
        ],
        indent=4,
    )
    ui.note(
        f"tip at x {reply['x']:.0f}  y {reply['y']:.0f}  z {reply['z']:.0f} mm, by the arm's own reckoning"
    )
    return 0


def check(robot, ask=ui.confirm, say=print) -> dict[str, int]:
    """Move each joint a little and have the person confirm the direction.
    Returns the joints found reversed (also saved to settings)."""
    arm = robot.platform.arms[0]
    joints = [j for j in robot.platform.joint_limits[arm] if j != "gripper"]
    reversed_joints: dict[str, int] = {}

    say("  The arm goes to its home pose first, slowly. Keep clear of it.")
    robot.park(arm)
    for joint in joints:
        here = robot.get_positions(arm)
        step = _STEP_DEG
        try:
            with robot.rehearsal():
                robot.move_to(arm, {joint: here[joint] + step})
        except Exception:  # noqa: BLE001 — a collision or a limit: go the other way
            step = -_STEP_DEG
        before, _ = robot.pose_tip(arm, here)
        after, _ = robot.pose_tip(arm, {**here, joint: here[joint] + step})
        expected = direction(before, after)
        say(f"\n  {joint}: the gripper should move {expected}.")
        robot.move_to(arm, {joint: here[joint] + step})
        right = ask(f"Did it move {expected}?")
        robot.move_to(arm, {joint: here[joint]})
        if right:
            ui.ok(f"{joint} turns the right way")
        else:
            reversed_joints[joint] = -1
            ui.warn(f"{joint} is reversed on this unit — corrected from now on")

    # Flips compose with whatever was already recorded for this unit.
    known = dict(robot.signs)
    for joint in reversed_joints:
        if known.get(joint) == -1:
            del known[joint]
        else:
            known[joint] = -1
    if reversed_joints:
        settings.put("wire_signs", known)
        robot.signs = known
    return reversed_joints
