"""Finding out where the camera stands, with the arm as the ruler.

The arm knows where its own gripper is. So it points: it hovers its closed gripper
over a spot on the bench, the person slides one block underneath, the arm gets
out of the way, and the camera looks. A handful of spots later there are two
lists of the same points — where the ARM says the block was, and where the
CAMERA saw it — and the transform between them is the camera's position.

A depth camera gives 3-D points and needs three spots. A webcam gives pixels
and needs four, and the same data also measures its focal length, which no
webcam knows about itself. Six are used either way, because the person's hand
is the least accurate part of this and errors average out.

The arm never touches the block. Laying the block out by itself would save the
person a minute, and would mean a grasp had to work before anything was
calibrated — the wrong order in which to trust things.
"""

from __future__ import annotations

import numpy as np

from botcortex import vision
from botcortex.real import wait_until_still
from botcortex.safety import Collision

#: Above the block's top, in metres: clear of it, close enough to centre by eye.
_HOVER_M = 0.03
#: Bench kept free around every fixture and object, so a block slid under the
#: jaws is never leaning on a tray wall.
_CLEAR_M = 0.05
#: A calibration worse than this is refused rather than saved: a 40 mm block
#: grasped a centimetre off-centre is a missed grasp.
ACCEPTABLE_RESIDUAL_M = 0.008


def spots_for(robot, arm: str, block: dict, wanted: int = 6) -> list[tuple[float, float, float]]:
    """Hover points spread over the bench that this arm can actually reach.

    Tried, not predicted: `move_to_point` inside a rehearsal refuses a spot it
    cannot route to, and costs nothing when it does.
    """
    scene = robot.describe_scene()
    bench = scene["fixtures"]["table"]
    (bx, by, bz), (sx, sy, sz) = bench["position"], bench["size_m"]
    top = bz + sz / 2
    hover = top + float(block["size_m"][2]) + _HOVER_M
    # Footprints, not centres: a spot 7 cm from a tray's middle is on its wall.
    keep_clear = [
        (b["position"], b["size_m"])
        for b in (*scene["fixtures"].values(), *scene["objects"].values())
        if b is not bench
    ]
    found: list[tuple[float, float, float]] = []
    for fx in (0.22, 0.5, 0.78):
        for fy in (0.2, 0.4, 0.6, 0.8):
            x, y = bx - sx / 2 + fx * sx, by - sy / 2 + fy * sy
            if any(
                abs(x - p[0]) < size[0] / 2 + _CLEAR_M and abs(y - p[1]) < size[1] / 2 + _CLEAR_M
                for p, size in keep_clear
            ):
                continue
            try:
                with robot.rehearsal():
                    robot.move_to_point(arm, (x, y, hover), 0.01)
            except (ValueError, Collision):
                # Refused without moving: not a spot this arm can point at.
                continue
            found.append((x, y, hover))
    # Spread beats count: the far corners constrain the pose, neighbours do not.
    if len(found) > wanted:
        picked = [found[0]]
        while len(picked) < wanted:
            picked.append(
                max(found, key=lambda s: min(np.hypot(s[0] - p[0], s[1] - p[1]) for p in picked))
            )
        found = picked
    return found


def calibrate(robot, camera, block_name: str, ask, say=print) -> dict:
    """Run the pointing routine. Returns what to save in the camera's settings.

    `ask(prompt)` must not return until the person is done — `input` on a
    terminal. `robot` must have NO camera attached: nothing is calibrated yet,
    so the twin is all there is to believe.
    """
    arm = robot.platform.arms[0]
    block = robot.describe_scene()["objects"][block_name]
    bench = robot.describe_scene()["fixtures"]["table"]
    rest = bench["position"][2] + bench["size_m"][2] / 2 + float(block["size_m"][2]) / 2
    spots = spots_for(robot, arm, block)
    depth = camera.frame().depth is not None
    if len(spots) < (3 if depth else 4):
        raise RuntimeError("the arm can reach too few clear spots on the bench to calibrate from")

    # Closed jaws: a better pointer, and nothing hanging below the hand to
    # sweep the block away as the arm leaves. Measured — with the RoArm's clamp
    # open, the retreat knocked the block up to 4 cm in two spots of six.
    _, closed = robot.platform.joint_limits[arm]["gripper"]
    robot.gripper(arm, closed)
    in_base, in_view = [], []
    for i, spot in enumerate(spots, start=1):
        robot.move_to_point(arm, spot, 0.01)
        if robot.link is not None:
            # The ruler is the arm's MEASURED pose, not the twin's belief about
            # it: wait for the servos to arrive, then put the twin exactly there.
            wait_until_still(robot, arm)
            robot.sync()
        (x, y, _z), _ = robot.tip(arm)
        ask(
            f"  spot {i} of {len(spots)}: slide the block under the gripper tip, centred, then press Enter "
        )
        robot.park(arm)
        frame = camera.frame()
        one = {block_name: block}
        if depth:
            seen, unseen = vision.locate_in_camera(frame, one, vision.bench_up(frame))
            view = seen.get(block_name)
        else:
            seen, unseen = vision.blobs(frame, one)
            view = seen[block_name][0] if block_name in seen else None
        if view is None:
            say(f"    could not see the block there ({unseen[block_name]}) — skipping this spot")
            continue
        in_base.append([x, y, rest])
        in_view.append(view)

    in_base, in_view = np.array(in_base), np.array(in_view)
    if depth:
        pose, residual = vision.solve_pose(in_view, in_base)
        result = {"camera_to_base": pose.tolist(), "residual_m": residual}
    else:
        h, w = camera.frame().rgb.shape[:2]
        pose, focal, residual = vision.solve_pose_from_pixels(
            in_view, in_base[:, :2], rest, (w / 2, h / 2), w, size=block["size_m"]
        )
        result = {"camera_to_base": pose.tolist(), "focal_px": focal, "residual_m": residual}
    if residual > ACCEPTABLE_RESIDUAL_M:
        raise RuntimeError(
            f"the spots disagree by {residual * 1000:.0f} mm, which is too much to grasp by. "
            "Nothing was saved. Usual causes: the block was not centred under the jaws, "
            "or the camera moved during the routine."
        )
    return result
