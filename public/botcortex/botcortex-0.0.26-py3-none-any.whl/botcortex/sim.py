"""SimRobot — MuJoCo physics behind the same primitive interface as MockRobot.

The sim2real claim lives here: skills, the executor, clamping, velocity caps,
and the e-stop check are IDENTICAL to the hardware path — only the actuation
backend differs. Position targets go to MuJoCo position servos (the vendored
model converts the upstream torque motors; see platforms/openarm_v1/model/
PROVENANCE.md) and physics advances at the model timestep between control
ticks.

Requires the `sim` extra: uv sync --extra sim  (pip install "botcortex[sim]").
"""

from __future__ import annotations

import time
from contextlib import contextmanager
from pathlib import Path

from botcortex import config, kinematics, mjcompat, safety, scene
from botcortex.jointmap import JointMap
from botcortex.platform import Platform
from botcortex.posesearch import PoseSearch
from botcortex.robot import EStopTriggered, plan_move


class SimRobot(PoseSearch):
    """Bimanual sim twin. realtime=True paces wall-clock like hardware would;
    False runs as fast as the CPU allows (tests)."""

    def __init__(
        self,
        platform: Platform | None = None,
        stop_file: Path | None = None,
        realtime: bool = True,
        workcell: bool = True,
        benchmark: bool = False,
    ):
        """workcell=False loads the BARE arm — no table, no trays, no blocks.

        Only for tests of actuation itself. With furniture present a plain
        `move_to(j4=60)` swings the forearm into the table and stops at 49
        degrees, which is correct physics and useless for asserting that a
        servo converges. Anything measuring MANIPULATION wants the default.
        """
        try:
            import mujoco
        except ImportError as e:  # pragma: no cover
            raise ImportError(
                "SimRobot needs MuJoCo — install the sim extra: uv sync --extra sim"
            ) from e

        self._mujoco = mujoco
        # The one line a rehearsal needs that differs between MuJoCo builds:
        # how this one is asked for a second mjData.
        self._spare_data = lambda: mujoco.MjData(self.model)
        #: One mjData per nesting depth — see the note in wasm.py's __init__.
        self._spares: list = []
        self._depth = 0
        #: True while a rehearsal is running. Nothing real is happening, so
        #: the state feed holds its last frame rather than showing it — see
        #: the note in rehearsal().
        self.rehearsing = False
        #: The research benchmark's frozen conditions: its own workcell, the
        #: default sag allowance, and no `sim.product` tuning.
        self.benchmark = benchmark
        self.platform = platform or config.PLATFORM
        # The workcell if the platform has one, the bare arm otherwise — see
        # Platform.world_path. A robot with nothing to manipulate can still be
        # taught poses; it just cannot be measured on manipulation.
        # benchmark=True loads the workcell the research tables were measured
        # on, which a body may have frozen apart from the one its owners use —
        # see Platform.benchmark_world_path.
        world = self.platform.benchmark_world_path if benchmark else self.platform.world_path
        mjcf = world if workcell else self.platform.mjcf_path
        if mjcf is None or not mjcf.exists():
            raise ValueError(f"platform {self.platform.name!r} has no vendored sim model")

        self.stop_file = stop_file if stop_file is not None else config.STOP_FILE
        self.realtime = realtime
        self.model = mujoco.MjModel.from_xml_path(str(mjcf))
        self.data = mujoco.MjData(self.model)
        self.motion_log: list[tuple[str, str, dict[str, float]]] = []
        self.torque = {arm: True for arm in self.platform.arms}
        #: Believed-TCP calibration error, metres in the hand frame. See tip().
        self.tcp_error: tuple[float, float, float] = (0.0, 0.0, 0.0)
        #: How far short of a point a move may land and still be treated as servo
        #: sag to trim out, rather than a route that failed (kinematics.reach).
        #: The ViperX droops 32 mm at the far blocks — 2 mm past the default —
        #: so the second block of "clear the table" was refused as unroutable.
        #: The benchmark keeps the default it was measured with.
        self.trimmable_m = (
            kinematics._TRIMMABLE
            if benchmark
            else float(self.platform.sim.get("trimmable_m", kinematics._TRIMMABLE))
        )

        def joint_adr(name: str) -> int:
            jid = mujoco.mj_name2id(self.model, mujoco.mjtObj.mjOBJ_JOINT, name)
            if jid < 0:
                raise ValueError(f"joint {name!r} not in model")
            return int(self.model.jnt_qposadr[jid])

        def actuator_id(name: str) -> int:
            aid = mujoco.mj_name2id(self.model, mujoco.mjtObj.mjOBJ_ACTUATOR, name)
            if aid < 0:
                raise ValueError(f"actuator {name!r} not in model")
            return aid

        # Addressing and unit mapping live in JointMap, shared with every other
        # MuJoCo backend. These two lookups are the only part that is ours.
        self.joints = JointMap(self.platform, joint_adr, actuator_id)

        # One control tick advances 1/CONTROL_HZ of sim time.
        self._substeps = max(1, round((1 / config.CONTROL_HZ) / self.model.opt.timestep))

        #: Which bodies are the robot and which are its jaws, per the platform
        #: descriptor. Fixed at construction; used by every scene and
        #: collision query, which must not guess them from a name prefix.
        self._robot_bodies = scene.robot_bodies(mujoco, self.model, self.platform.sim)
        self._jaws = {
            body for arm in self.platform.arms for body in self.platform.finger_bodies(arm)
        }

        # Which bodies are objects, and where they start. Captured BEFORE
        # anything moves, because reset has to put the workcell back — an arm
        # that returns home over a table whose blocks are wherever the last
        # attempt left them is not a reset, and every run after the first
        # would start from a different problem.
        self._object_addr = scene.free_joints(mujoco, self.model)
        self._object_home = scene.object_poses(self.data.qpos, self._object_addr)
        #: One entry per "step" in motion_log: where every object stood at
        #: that tick. The browser plays these back in step with the arm
        #: frames — without them, playback showed the block teleporting to
        #: its destination and the arm setting off afterwards to fetch
        #: nothing. Rewound by rehearsal exactly as motion_log is.
        self.object_log: list[dict[str, list[float]]] = []
        #: botcortex.episodes.Recorder, when runs are being kept as training data.
        self.recorder = None
        #: (arm, frame) -> the frame actually sent. None everywhere except
        #: while generating training data; see dataset.Wobble.
        self.disturb = None

        #: What a structural link must never touch. Resolved on first need
        #: rather than at construction: a bare arm has no fixtures, and asking
        #: costs a full scene walk that most robots never need.
        self._fixture_names: set[str] | None = None

        self._snap_home()

    def reset(self) -> None:
        """Snap back to home with no momentum.

        Velocities and accelerations are zeroed FIRST: writing qpos while qvel
        still carries momentum leaves the arm drifting away from the pose we
        just set, and mj_forward does not clear it.

        Instantaneous by nature, so this exists only where there is no physical
        arm to fling — SimRobot and MockRobot define it; a real-hardware class
        must not, and the server only offers it when the method is present.
        """
        self._snap_home()

    def _snap_home(self) -> None:
        """The twin's own starting state. Separate from reset() so a class that
        must not offer reset (botcortex.real) can still be constructed."""
        self.data.qvel[:] = 0.0
        self.data.qacc[:] = 0.0
        scene.place_objects(self.data.qpos, self._object_addr, self._object_home)
        for arm in self.platform.arms:
            for joint, value in self.platform.home_position.items():
                self._write_target(arm, joint, value)
                self._write_qpos(arm, joint, value)
        # self._mujoco, not the local import: mujoco is imported inside
        # __init__ so the module stays optional, and methods can't see it.
        self._mujoco.mj_forward(self.model, self.data)

    # --- actuation (indices and units both come from JointMap) ---

    def _write_target(self, arm: str, joint: str, deg: float) -> None:
        for index, value in self.joints.ctrl_writes(arm, joint, deg):
            self.data.ctrl[index] = value

    def _write_qpos(self, arm: str, joint: str, deg: float) -> None:
        for index, value in self.joints.qpos_writes(arm, joint, deg):
            self.data.qpos[index] = value

    # --- the primitive interface (mirrors MockRobot exactly) ---

    def get_positions(self, arm: str) -> dict[str, float]:
        return self.joints.positions(arm, self.data.qpos)

    def move_to(self, arm: str, targets: dict[str, float], duration: float | None = None) -> None:
        # Same trajectory as every other backend — see robot.plan_move. All this
        # class adds is where the frames are written and that physics runs.
        frames = plan_move(arm, self.get_positions(arm), targets, duration, self.platform)
        tick = 1 / config.CONTROL_HZ
        t0 = time.monotonic()
        for i, frame in enumerate(frames, start=1):
            if self.stop_file.exists():
                raise EStopTriggered(f"stop file present: {self.stop_file}")
            # What the servos are TOLD may be disturbed on purpose while data
            # is being made (dataset.Wobble); what is recorded as the action is
            # still `frame`, the move that was meant. Never inside a rehearsal:
            # a rehearsal answers "is this move safe", not "what if it slips".
            sent = (
                self.disturb(arm, frame) if self.disturb is not None and self._depth == 0 else frame
            )
            for joint, deg in sent.items():
                self._write_target(arm, joint, deg)
            for _ in range(self._substeps):
                self._mujoco.mj_step(self.model, self.data)
            self.motion_log.append(("step", arm, self.get_positions(arm)))
            self.object_log.append(scene.object_poses(self.data.qpos, self._object_addr))
            # Before the collision check, so the tick that went wrong is in
            # the record: a failure episode without its failure teaches nothing.
            if self.recorder is not None:
                self.recorder.tick(self, arm, frame)
            # A link inside the furniture is a fault, and continuing to command
            # a servo that is already buried only pushes harder. Aborts like
            # the e-stop, and for the same reason.
            hits = self._collisions()
            if hits:
                raise safety.Collision(safety.describe(hits))
            # After the collision check, never before: a frame the twin just
            # buried in the furniture must not reach a servo.
            self._actuate(arm, frame)
            if self.realtime:
                remaining = t0 + i * tick - time.monotonic()
                if remaining > 0:
                    time.sleep(remaining)

    def _actuate(self, arm: str, frame: dict[str, float]) -> None:
        """Where a frame leaves for hardware. Physics is all a simulator has,
        so nothing here; botcortex.real.RealRobot sends it down the wire."""

    def gripper(self, arm: str, position: float) -> None:
        self.move_to(arm, {"gripper": position})

    def set_torque(self, arm: str, enabled: bool) -> None:
        self.torque[arm] = enabled
        self.motion_log.append(("torque", arm, {"enabled": float(enabled)}))

    def clear_errors(self) -> None:
        self.motion_log.append(("clear_errors", "both", {}))

    def replay_trajectory(self, arm: str, waypoints: list[dict[str, float]]) -> None:
        for waypoint in waypoints:
            self.move_to(arm, waypoint)

    # --- Cartesian: the bridge between what describe_scene says and what
    # move_to accepts. See botcortex/kinematics.py for why it exists.

    def tip(self, arm: str) -> tuple[tuple[float, float, float], float]:
        """Read the actual grasp centre without writing any simulator state."""
        mj = self._mujoco
        hand = mj.mj_name2id(
            self.model, mjcompat.enum_value(mj.mjtObj.mjOBJ_BODY), self.platform.hand_body(arm)
        )
        rot = mjcompat.row(self.data.xmat, hand, 9)
        base = mjcompat.row(self.data.xpos, hand, 3)
        # The CONTROLLER's idea of where the jaws close (kinematics.calibrated_offset);
        # the jaws themselves are where physics puts them.
        offset = kinematics.calibrated_offset(self.platform.grasp_offset, self.tcp_error)
        return (
            kinematics.tip_from(base, rot, offset),
            self.platform.downwardness(rot),
        )

    def pose_tip(
        self, arm: str, pose: dict[str, float]
    ) -> tuple[tuple[float, float, float], float]:
        """Where the grasp centre WOULD be at `pose`. A question, not a move —
        the arm is restored before returning."""
        with self.rehearsal():
            return self._probe(arm)(pose)

    def park(self, arm: str, observe=None) -> None:
        """Home, without sweeping through the furniture — kinematics.retreat."""
        kinematics.retreat(self, arm, dict(self.platform.home_position), observe)

    def move_to_point(
        self,
        arm: str,
        point,
        tolerance: float = 0.02,
        *,
        may_move: tuple[str, ...] = (),
        observe=None,
        pinned: dict[str, float] | None = None,
        carried: tuple[str, ...] = (),
    ) -> None:
        """Move the grasp centre to a point in metres, gripper pointing down.

        Routed, rehearsed and verified — one definition for every physics
        backend, in kinematics.reach. Refuses rather than approximating, both
        when the point is out of reach and when no transit arrives: a skill
        that closed its jaws wherever the arm happened to stop would report
        success having grasped nothing.
        """
        kinematics.reach(
            self,
            arm,
            point,
            tolerance,
            may_move=may_move,
            observe=observe,
            pinned=pinned,
            carried=carried,
        )

    def _fixtures(self) -> set[str]:
        if self._fixture_names is None:
            self._fixture_names = set(self.describe_scene()["fixtures"])
        return self._fixture_names

    def _collisions(self) -> set[tuple[str, str]]:
        """Arm links currently inside furniture. Empty is healthy.

        Cheap when nothing is touching anything, which is the overwhelmingly
        common case — no contacts means no possible collision, and the fixture
        list never has to be built.
        """
        if int(self.data.ncon) == 0:
            return set()
        return safety.link_collisions(
            self._mujoco, self.model, self.data, self._fixtures(), self._robot_bodies, self._jaws
        )

    @contextmanager
    def rehearsal(self):
        """Run motion for real, then leave no trace of it.

        Everything inside really happens — full physics, real contacts, a
        Collision raised exactly where one would be — and then the simulation
        is put back to the instant the block was entered. That is what lets the
        runtime answer "will this break something?" before the arm moves,
        rather than after.

        Exact, not approximate: see the measurements in botcortex.safety. The
        motion log is rewound too, so a rehearsal cannot pad the step count a
        real run reports.

        Pacing is off inside — a rehearsal nobody can see has nothing to pace
        against, and a 17-second skill would take 17 seconds to check. Which
        makes `rehearsing` load-bearing rather than cosmetic: the joint feed
        reads this robot live, so without it an owner watched the entire skill
        tear past at fifty times speed and snap back to the start before the
        real move began. It looked like the simulation glitching.

        Only backends with physics define this. A robot with none must NOT
        pretend, or "rehearsed clean" becomes a sentence that means nothing.
        """
        if len(self._spares) <= self._depth:
            self._spares.append(self._spare_data())
        spare = self._spares[self._depth]
        safety.hold_state(self._mujoco, self.model, spare, self.data)
        logged = len(self.motion_log)
        tracked = len(self.object_log)
        paced, self.realtime = self.realtime, False
        watched, self.rehearsing = self.rehearsing, True
        self._depth += 1
        try:
            yield
        finally:
            self._depth -= 1
            self.realtime = paced
            self.rehearsing = watched
            del self.motion_log[logged:]
            del self.object_log[tracked:]
            safety.release_state(self._mujoco, self.model, spare, self.data)

    def describe_scene(self) -> dict[str, dict]:
        """What is on the table. One definition, in botcortex.scene — writing it
        per backend is how two backends start disagreeing."""
        return scene.describe(self._mujoco, self.model, self.data, self._robot_bodies)

    def settle(self, seconds: float = 0.5) -> None:
        """Advance physics with targets held — lets servos finish converging."""
        for _ in range(max(1, round(seconds / self.model.opt.timestep))):
            self._mujoco.mj_step(self.model, self.data)
