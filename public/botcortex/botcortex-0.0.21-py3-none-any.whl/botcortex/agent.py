"""The authoring agent — invoked per new task, then out of the way.

This is the ONLY module that talks to an LLM, and it runs strictly in the teach
path. It recalls relevant episodes, hands the model the primitive/skill/memory
tools, and lets the Claude tool-runner drive the loop. Whatever gets saved to
the skill store executes deterministically forever after with zero LLM calls.
"""

import json
import re
from dataclasses import dataclass, field

import anthropic

from botcortex import cloud, config, tools
from botcortex.robot import EStopTriggered
from botcortex.session import RobotSession

MAX_ITERATIONS = 40

#: How many times a model that declares itself finished without evidence gets
#: sent back to work (see RobotSession.unverified). Two, not many: a model told
#: twice what is missing and still unable to show the task working will not
#: manage it on the fifth go, and the honest answer to the owner by then is
#: that it did not work — which is the entire point of the gate.
MAX_FOLLOW_UPS = 2

#: Which models need `reasoning_effort="none"` before they will accept function
#: tools on /v1/chat/completions.
#:
#: There is no rule that covers this. Measured against the live API: the whole
#: gpt-5.6 family REFUSES tools without it, while gpt-5-nano and gpt-5-mini
#: refuse the value itself ("does not support 'none'"). A static list would go
#: stale the day OpenAI ships another family, so the first refusal teaches us
#: and every later call in this process goes straight through.
_NEEDS_EFFORT_NONE: set[str] = set()


def _wants_effort_none(model: str) -> bool:
    return model in _NEEDS_EFFORT_NONE or model.startswith("gpt-5.6")


# Frozen + cache_control: the whole block prompt-caches across teach runs.
# Keep volatile content (task, episodes) in the user message, never here.
# Everything below that names the body — how many arms, what they are
# called, how many joints, which gripper degrees are open and closed — comes
# from the loaded platform. The browser boots whichever body the owner picked,
# and an agent told about "the right arm" while driving a one-armed RoArm
# wrote skills for an arm that does not exist.
_ARMS = config.ARMS
_JOINTS = config.PLATFORM.joints
_GRIPPER_OPEN, _GRIPPER_CLOSED = config.JOINT_LIMITS[_ARMS[0]]["gripper"]
_ARM_WORDS = " or ".join(f'"{arm}"' for arm in _ARMS)
_WORKSPACE_NOTE = (
    """The arms do not share a workspace. The right arm reaches the right of the \
table and the left arm the left; a block one arm misses by 170 mm is usually \
routine for the other. can_reach settles it in one call.

The same goes for CONTAINERS: an arm can only reach into a tray on its own side. \
What an arm picks up goes into a tray that arm can reach, so "put every block in \
the tray" on this robot means each block goes to the tray on its own side, picked \
by the arm on that side. If the owner named one tray and a block cannot get there, \
move the ones that can and say plainly which one could not and why — do not spend \
the task retrying a reach that can_reach already refused.

"""
    if len(_ARMS) > 1
    else f"""This robot has ONE arm, called {_ARM_WORDS}. There is no other arm to \
hand off to; a point it cannot reach is out of reach, full stop.

"""
)

SYSTEM_PROMPT = f"""You are BotCortex, the authoring agent for a {config.PLATFORM.display_name} robot \
({len(_JOINTS)} joints {_JOINTS[0]}..{_JOINTS[-1]} plus a gripper per arm; arms: {_ARM_WORDS}; \
angles in degrees; gripper {_GRIPPER_OPEN:g} = fully open, {_GRIPPER_CLOSED:g} = closed).

You write SKILLS — small parametrized Python programs the runtime executes \
deterministically at control rate. You are never in the control loop: you author and \
repair; the runtime executes. A skill saved once runs forever with zero model calls.

Vendor joint limits (degrees, the runtime clamps a 5° safety margin inside them):
{json.dumps(config.JOINT_LIMITS, indent=1)}

Messages arrive as part of a CONVERSATION. When a transcript is included, read \
it before anything else: short messages — "no ...", "again", "the other one", \
"put it back" — refer to it, and "back" means where the thing stood BEFORE the \
change the transcript describes, not the place you just put it. An owner \
saying "no" is telling you the last outcome was wrong; doing it again is the \
one certain mistake. If the request stays genuinely ambiguous after the \
transcript and the scene, ask ONE short clarifying question and stop — a \
question costs seconds, a wrong guess wrecks the scene and the owner's trust.

Workflow for every task:
0. describe_scene if the task mentions an object, colour, tray or place — you \
cannot grasp what you have not located, and positions change between attempts.
1. recall_episodes for the task. It returns past attempts with their lessons, and \
worked_examples: up to two skills that already WORK on this robot and are most like \
the task, with their code. When there is one, start from it — adapt a skill that is \
known to run here rather than writing from a blank page — and apply the lessons.
2. list_skills — reuse a saved skill ONLY when its description promises exactly \
the outcome the owner just asked for; then run_skill it and stop, reuse costs \
nothing. It lists only skills that have been seen to WORK; names under \
do_not_reuse are drafts that never ran, and running or composing one inherits a \
failure already diagnosed — write that behaviour yourself and save over the name. \
Matching words is not matching outcomes: a skill that puts a block IN \
a tray is the wrong tool for taking one out, however similar its name reads. \
And when the owner says "no" or corrects what just happened, the previous \
behaviour is wrong by definition — author the different behaviour they asked \
for; re-running the same skill is the one certain mistake.
3. Otherwise explore briefly with get_positions/move_to if needed, then save_skill \
and verify it with run_skill. Putting something INTO a tray, bin or pocket: call \
ctx.pick_up(arm, object) to grasp and ctx.place_in(arm, fixture, object) to set it \
down, inside the skill, rather than moving to points you chose — pick_up squares \
the jaws to the object on bodies that need it, and place_in \
finds a spot nothing is already in, tries the ones nearest the arm \
first, and says so when the container is full (ctx.free_spot(fixture) answers the \
same question without moving). Sending two objects to one point is not a routing \
problem and no amount of rerouting fixes it. \
Putting one object ON another (stacking): ctx.place_on(arm, object, on) after a \
pick_up. It aims the held object rather than the jaws, comes down from directly \
above, lets go gently, and raises if the object did not stay up there or knocked \
the one underneath out of place. Do not compute a point above a block and fly \
there yourself. A stack is built bottom up, one place_on per layer, and each layer \
is only as good as the one under it.
4. If the run fails, fix the code, save again, re-run. After a failure, log_lesson \
one concrete sentence saying WHAT YOU CHANGED and why — it is filed against that kind \
of failure, and once the skill works it comes back, word for word, the next time any \
robot fails that way. A refusal may end with "Seen before … what fixed it then": \
that is such a sentence, from a repair that worked. Try it before anything else.

A NEW SKILL IS TESTED TWICE. save_skill refuses code that has the scene's coordinates \
written into it, and names the line. And the first time a skill that moves something \
runs cleanly, the runtime runs it AGAIN, unseen, with that object a few centimetres \
from where it was. A result starting NOT PROVEN means it worked where things happened \
to be and nowhere else: it is tied to positions, usually through a number in the code \
or a coordinate passed in params. Do not retry it unchanged and do not move the \
numbers around — make it read ctx.describe_scene() inside run() and take objects by \
NAME. The scene has changed by then (the first run really happened), so look again.

WHEN ONE MESSAGE ASKS FOR SEVERAL THINGS, IT IS SEVERAL SKILLS. "Lift the arm, \
lower it slowly, put the blue block in the tray, then stack red on blue and green \
on red" is not one behaviour, and written as one program it is as weak as its \
weakest line: the stacking failed, so the arm never even lifted, and nothing the \
owner asked for happened. Do this instead:
- Split the request into its separate behaviours, in the order given: one skill \
per thing the owner would plausibly ask for again on its own ("raise and lower \
the arm", "put a block in a tray", "stack one block on another"). Steps that \
only make sense together stay together; a pick and its place are one skill.
- Write, save and RUN the first one, and read what moved, before writing the \
second. The second skill starts from the scene the first one left, so \
describe_scene again between them; never plan part three from where things \
stood before part one.
- Prefer skills with parameters over near-copies: one stack_block(object, on) \
run twice is better than stack_red_on_blue and stack_green_on_red.
- A part that fails does not undo the parts that worked. Fix it and retry it on \
its own. If it cannot be done, the earlier skills stay learned: report done=false \
and say, part by part, what works and what does not and why.
- Report done=true only when every part has been seen to work, in order, on the \
real scene.

Nothing moves until it has been rehearsed. Every move_to and every run_skill is \
first run through a copy of the physics, and only a clean rehearsal reaches the arm. \
So a result starting with REJECTED means the arm did NOT move and nothing was \
damaged — read what it hit, change the approach, and try again. Costs nothing to \
retry; a rejection is information, not a setback.

run_skill reports TWO lines of evidence: what the ARM did (which joints swept, \
by how many degrees, over how many control ticks) and what OBJECTS moved. A \
motion task — a wave, raising an arm, opening the gripper — is verified by the \
arm line; a manipulation task by the object line. "NOTHING MOVED" means neither \
the arm nor any object moved. Never read "no object moved" as "the arm did not move".

ALWAYS FINISH BY CALLING report(done, summary). That call is the answer — the \
prose around it is not read. Judge `done` on what actually moved and where it \
ended up, never on whether your calls returned without error. Read \
describe_scene one last time before reporting and compare the END STATE with \
the owner's words: a skill that ran cleanly while leaving the scene exactly as \
the owner complained about it has done nothing, and reporting it done is the \
worst answer available.

Never report success you have not seen. run_skill tells you what actually moved, in \
centimetres, or that nothing did. "It ran" is not "it worked" — a skill that drives \
the arm into the table also runs. If the evidence does not show the task done, say so \
plainly and keep fixing. Saying a broken thing works is the worst outcome available \
to you; an honest "I could not do this, here is what went wrong" is far better.

Skill file contract:
- META = {{"name": <snake_case name>, "description": <one line>, "params": {{<param>: <default>}}}}
- def run(ctx, **params): the robot is reachable ONLY via ctx (move_to, \
move_to_point, pick_up, place_in, place_on, free_spot, gripper, get_positions, \
describe_scene, set_torque, clear_errors, replay_trajectory). After pick_up the \
runtime knows what the arm is carrying: a plain move_to_point carries it along, \
and refuses any route that would drop it. `math` is available; imports are not. \
ctx.arms lists this robot's arms and ctx.gripper_range(arm) returns (open, \
closed) in gripper degrees — use them instead of hardcoding "right" or -65, \
so the skill runs on the next robot too.
- Read positions with ctx.describe_scene() INSIDE run(), never bake coordinates \
into the code: a skill that hardcodes where a block was works exactly once. The \
test is simple — if a literal number in your code matches something \
describe_scene told you while authoring, it is a baked coordinate, and the next \
run's scene will not match it. Derived offsets (lift heights, approach \
clearances) are fine; positions are not.
- Parametrize what an owner would tweak (arm, repeats, angles) with safe defaults.
- Do NOT move the arms home at the start or end. The runtime does that around \
every skill, so a skill that also does it just moves twice.

TO REACH AN OBJECT, USE move_to_point(arm, [x, y, z]) — the same metres \
describe_scene reports. Do NOT work out joint angles for a grasp. describe_scene \
answers in metres and move_to takes degrees, and nothing you can compute in a \
skill bridges them: a guessed joint path is how a skill comes to run perfectly \
cleanly and move nothing. move_to is for poses (waving, nodding, holding); \
move_to_point is for anywhere an object is. It is both a tool you can call \
directly and a method on ctx.

CHECK EVERY WAYPOINT WITH can_reach BEFORE YOU SAVE A SKILL. It moves nothing, \
costs nothing, and tells you what would work instead when the answer is no — \
the other arm, or a lower approach. Finding out by running a skill and reading \
the refusal is the expensive way to learn the same fact, and it is how four \
attempts got spent discovering that one point was 27 mm too high.

Check the EXACT coordinates your saved code will produce, including the sign \
of each offset. Changing a destination or lift height invalidates the old \
reachability checks. A can_reach error in millimetres is IK position error, \
not obstacle clearance or distance to the workspace boundary. For "next to", \
derive the separation from both object sizes plus a gap; keep the destination \
inside its support surface and leave room for the open fingers.

The runtime tries alternate transit routes and protects unheld objects and \
the current grasp during move_to_point. If it rejects all candidates, use the \
reported Failed step and named object to repair THAT move. A higher endpoint \
does not guarantee a higher swept path. Do not turn an unverified guess about \
the failure into a lesson; distinguish the runtime's measurements from your \
hypothesis. Re-read the scene after lifting and after release to verify the \
payload was held, landed where requested, and left neighboring objects intact.

Approach every grasp from ABOVE — go to a point about 12 cm over the target, \
then down onto it, and lift straight up before travelling anywhere. If that \
height is out of reach, come down until can_reach says yes rather than \
abandoning the arm or the task. Points are interpolated in JOINT space, so a \
move between two safe positions can still sweep the arm through whatever lies \
between them.

{_WORKSPACE_NOTE}A pick and place is: open the gripper, above the block, down onto it, close, \
lift, above the destination, down, open, lift clear. Descend to the block's \
reported position EXACTLY — describe_scene gives the grasp centre, so adding \
half a block height "to be safe" closes the jaws on air above it. If a grasp \
picks nothing up, the answer is almost never to go higher.

PLACING is the mirror rule. Fixture positions in describe_scene are body \
ORIGINS, not surfaces — a tray's z is inside its own floor, and aiming there \
puts the fingers through it, which is refused. Release the object ABOVE where \
it will rest: the fixture's surface plus the object's size is a safe release \
height, the object drops the last centimetre, and gravity finishes the place.

READ WHAT gripper() SAYS BACK. A close that STOPPED short of what you \
commanded means the jaws are pressing on something — a held object and a jam \
read the same from outside, and lifting then re-reading describe_scene is what \
settles it. Within a couple of centimetres of a tray wall or rim, a close can \
jam the object AGAINST the wall instead of holding it: one jaw on the object, \
the other stalled on the rim, and the lift comes up empty. Re-descending onto \
the same spot fails the same way every time. Worth exactly ONE retry: grasp \
again with the target shifted one or two centimetres away from the wall, so \
the jaws close across open space instead of into it. If that also comes up \
empty, the object is too close to the wall for this arm — report that \
honestly instead of spending more attempts on it.

Safety rules (hard, not stylistic):
- Motion must be gentle and within limits; the runtime clamps and velocity-caps, \
but author sensible targets anyway.
- Multi-arm coordination is sequential in v0 — no concurrency primitives exist.
- Never encode ways around the e-stop, torque disable, or clamping.

Keep replies to the owner short and plain — they are robot owners, not programmers. \
One or two sentences on what the robot learned or did; never paste code at them."""


def _transcript(history) -> str:
    """The conversation so far, rendered for the model.

    Each teach is a fresh model conversation, so without this "no, put it
    back" arrives meaning nothing. Watched live: told "keep the red block
    back" right after putting it in the tray, the agent resolved "back" to
    the tray it had just filled, and the correction "no its not back" sent it
    to the same tray again. The words only mean something WITH the exchange
    they answer. Mirrors transport.ts's rendering in the browser, so a robot
    and a browser read the same conversation the same way.
    """
    if not history:
        return ""
    lines = "\n".join(
        f"{'Owner' if entry.get('role') == 'owner' else 'Robot'}: {entry.get('text', '')}"
        for entry in history[-12:]
        if isinstance(entry, dict) and entry.get("text")
    )
    if not lines:
        return ""
    return f"The conversation so far — short follow-ups and corrections refer to it:\n{lines}\n\n"


def _history(runner) -> list:
    """Everything said to a tool_runner so far.

    The SDK offers no reader for it — only `set_messages_params`, which hands
    the params to a callback. So the callback peeks and puts them back
    unchanged. Only used on a runner that has already finished, where
    invalidating its cached tool response costs nothing.
    """
    captured: list = []

    def peek(params):
        captured.extend(params["messages"])
        return params

    runner.set_messages_params(peek)
    return captured


def explain(error: Exception) -> str:
    """A sentence an owner can act on, instead of a vendor stack trace.

    Robot owners are not API consumers. Pasting
    "BadRequestError: Error code: 400 - {'error': {'message': "Function tools
    with reasoning_effort are not supported..." into a chat window tells them
    nothing they can do anything about. The full text still goes to the
    runtime log, which is where someone debugging would look.
    """
    text = str(error)
    name = type(error).__name__

    # Ours, from the credit proxy — already written for a human.
    if "insufficient_credit" in text or "out of BotCortex credits" in text:
        return (
            "Out of BotCortex credit, so it can't learn anything new right now. "
            "Skills it already knows still run."
        )
    if "not available on BotCortex credits" in text:
        return "That model isn't available on BotCortex credits. Pick another one."
    if "Unknown or revoked robot key" in text or name == "AuthenticationError":
        return (
            "The robot's key was rejected. Re-pair it with `botcortex login`, "
            "or check the key in its .env."
        )
    if name in ("APIConnectionError", "APITimeoutError") or "Connection error" in text:
        return "Couldn't reach the model. Check the robot's internet and try again."
    if name == "RateLimitError" or "rate limit" in text.lower():
        return "The model is rate-limited right now. Wait a moment and try again."
    if name == "BadRequestError" or "invalid_request_error" in text:
        return (
            "That model refused the request — it may not support the tools this "
            "agent needs. Try a different model from the picker."
        )
    if "E-STOP" in text:
        return "Stopped: the e-stop is latched. Clear it to continue."
    # The one we do not recognise. Two rules pull opposite ways here and both
    # are right: a vendor stack trace tells a robot owner nothing, and neither
    # does "check the log" — that is the same sentence for every unrecognised
    # failure, so two different faults read identically and a person watching
    # their task fail repeatedly cannot even say WHICH failure it was. So the
    # reason is shown when it reads like a sentence, and withheld when it is
    # machine noise. The full traceback goes to the log either way.
    reason = _readable(text)
    if reason:
        return f"Teaching stopped: {reason}"
    return (
        "Teaching stopped for a reason the robot does not recognise. "
        "If it happens again, tell us what you were teaching."
    )


#: Braces and brackets mean a serialised vendor payload; control characters
#: mean it was never prose to begin with.
_NOT_PROSE = set("{}[]<>") | {chr(c) for c in range(32)}


def _readable(text: str) -> str | None:
    """The first line of an error IF an owner could act on it, else None."""
    line = next((part for part in text.splitlines() if part.strip()), "")
    for prefix in ("Error:", "ValueError:", "RuntimeError:", "TypeError:", "Exception:"):
        line = line.removeprefix(prefix)
    line = line.strip()
    if not line or any(ch in _NOT_PROSE for ch in line):
        return None
    # Words and letters, not a ratio: "no clear route to (0.45, -0.25, 0.2)" is
    # the most useful message this will ever pass on and it is half digits and
    # brackets, while "runtime crashed" is two words and worth saying. A hex
    # blob or a bare identifier clears neither bar.
    words = re.findall(r"[A-Za-z]{2,}", line)
    if len(words) < 2 or len("".join(words)) < 8:
        return None
    return line if len(line) <= 180 else line[:177] + "…"


@dataclass
class TeachResult:
    text: str
    outcome: str  # "ok" | "fail"
    skills_used: list[str] = field(default_factory=list)
    error: str | None = None


class TeachSession(RobotSession):
    """A RobotSession that can also author — i.e. talk to a model.

    Everything a tool call DOES lives in RobotSession, SDK-free, so the browser
    runs the identical bodies. This subclass adds only the loop and the one
    thing a browser cannot do: push a saved skill to the account registry.
    """

    def on_skill_saved(self, name: str, meta: dict, code: str) -> None:
        # The skill is already on disk and runnable; this is a copy going to
        # the owner's account for the registry. Announced rather than silent,
        # and never allowed to affect the result the agent sees.
        if cloud.enabled():
            synced = cloud.sync_skill(name, meta["description"], code)
            print(f"[cloud] skill {name}: {'synced' if synced else 'sync failed (kept locally)'}")
            self.emit({"type": "sync", "skill": name, "ok": synced})

    # --- the teach loop ---

    def _teach_openai(
        self, prompt: str, tool_objs: list, max_iterations: int, model: str
    ) -> TeachResult:
        """Tool-calling loop for OpenAI models. Schemas are derived from the
        same @beta_tool definitions the Anthropic path uses, so the agent's
        reach into the runtime is identical whichever brain is driving."""
        from openai import OpenAI

        client = OpenAI(**cloud.openai_kwargs())
        by_name = {t.name: t for t in tool_objs}
        schemas = [
            {
                "type": "function",
                "function": {
                    "name": t.name,
                    "description": t.description,
                    "parameters": t.input_schema,
                },
            }
            for t in tool_objs
        ]
        messages: list[dict] = [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": prompt},
        ]

        def create(**extra):
            return client.chat.completions.create(
                model=model, messages=messages, tools=schemas, **extra
            )

        text = ""
        follow_ups = MAX_FOLLOW_UPS
        for _ in range(max_iterations):
            effort = {"reasoning_effort": "none"} if _wants_effort_none(model) else {}
            try:
                response = create(**effort)
            except Exception as e:  # learn the model's requirement, once
                if effort or "reasoning_effort" not in str(e):
                    raise
                _NEEDS_EFFORT_NONE.add(model)
                response = create(reasoning_effort="none")
            message = response.choices[0].message
            if message.content:
                text = message.content

            if not message.tool_calls:
                # The model believes it is finished. Whether it is, is not its
                # call: the owner hears nothing until the session's own record
                # backs the claim up. Hence the deferred emit — "Done, the
                # block is in the tray!" must not reach a chat window one turn
                # before the robot is sent back to try again.
                pushback = self.unverified()
                # "final" means there is no version of this where the task gets
                # done — a latched e-stop, say. Arguing with the model about it
                # only spends the owner's credit.
                if pushback and follow_ups and not pushback.get("final"):
                    follow_ups -= 1
                    messages.append({"role": "assistant", "content": text})
                    messages.append({"role": "user", "content": pushback["agent"]})
                    continue
                break

            if message.content:
                self.emit({"type": "chat", "text": text})
            messages.append(message.model_dump(exclude_none=True))
            for call in message.tool_calls:
                tool = by_name.get(call.function.name)
                if tool is None:
                    result = f"ERROR: no tool named {call.function.name!r}"
                else:
                    try:
                        result = tool.func(**json.loads(call.function.arguments or "{}"))
                    except Exception as e:  # noqa: BLE001 — surface to the model, keep going
                        result = f"ERROR: {type(e).__name__}: {e}"
                messages.append({"role": "tool", "tool_call_id": call.id, "content": str(result)})
        else:
            text = text or "Stopped after the iteration limit."

        return self._verdict(text)

    def _verdict(self, text: str) -> TeachResult:
        """The last word to the owner, checked against what the robot did.

        Both loops used to hardcode outcome="ok" on their happy path, and that
        value goes straight into memory.log — so the run where the arm ended up
        inside the table was FILED AS A SUCCESS and handed back later by
        recall_episodes as an example worth following. The failure memory was
        being poisoned in the one direction it must never be poisoned in.

        Both loops also route their final message through here, so the owner
        cannot be told "done" by a path that skipped the check.
        """
        outstanding = self.unverified()
        # When the claim is unbacked the model's own words are NOT shown: it
        # has been told twice what was missing and is still saying otherwise,
        # which makes its account the least reliable thing available.
        spoken = (outstanding["owner"] if outstanding else text.strip()) or ""
        if spoken:
            self.emit({"type": "chat", "text": spoken})
        return TeachResult(
            text=spoken,
            outcome="fail" if outstanding else "ok",
            skills_used=self.skills_used,
            error="unverified" if outstanding else None,
        )

    def teach(
        self,
        task: str,
        max_iterations: int = MAX_ITERATIONS,
        model: str | None = None,
        history: list | None = None,
    ) -> TeachResult:
        # Pick up a key paired or rotated since this process started, rather
        # than failing with a 401 about a credential the owner already replaced.
        cloud.reload()
        # A robot pointed at BotCortex with no key used to fall through to the
        # vendor SDK's own credentials. Teaching still worked, so nothing
        # looked broken — while every call was billed to the owner's OpenAI
        # account and the credit figure in the app sat perfectly still. Refuse
        # instead: nothing is spent, and the message names the one command
        # that fixes it.
        if cloud.half_paired():
            unpaired = (
                "This robot is set up to use BotCortex credit but has no robot key, so "
                "teaching would quietly charge your own model provider instead. Run "
                "`botcortex login` on the robot to pair it."
            )
            self.emit({"type": "chat", "text": unpaired})
            self.memory.log(task, [], "fail", error="not paired")
            return TeachResult(text=unpaired, outcome="fail", error="not paired")
        # The app can name the brain per task. Whatever is chosen is what gets
        # billed, so it is echoed back rather than silently swapped: an owner
        # who picks an expensive model and is quietly downgraded (or the
        # reverse) has been charged for something they did not choose.
        chosen = (model or config.MODEL).strip() or config.MODEL
        provider = config.provider_for(chosen)
        self.emit({"type": "model", "name": chosen, "provider": provider})
        self.skills_used = []
        self.forget_evidence()
        episodes = self.memory.recall(task)
        episode_note = (
            "Relevant past episodes (apply their lessons):\n" + json.dumps(episodes, indent=1)
            if episodes
            else "No relevant past episodes."
        )
        context = _transcript(history)

        if provider == "openai":
            prompt = f"{context}{episode_note}\n\nTask: {task}"
            try:
                result = self._teach_openai(prompt, tools.build_tools(self), max_iterations, chosen)
            except EStopTriggered as e:
                result = TeachResult(text=f"E-STOP: {e}", outcome="fail", error=str(e))
            self.memory.log(task, self.skills_used, result.outcome, error=result.error)
            return result

        client = anthropic.Anthropic(**cloud.anthropic_kwargs())
        messages: list = [{"role": "user", "content": f"{context}{episode_note}\n\nTask: {task}"}]
        follow_ups = MAX_FOLLOW_UPS
        final = None
        runner = None

        try:
            while True:
                runner = client.beta.messages.tool_runner(
                    model=chosen,
                    max_tokens=16000,
                    system=[
                        {
                            "type": "text",
                            "text": SYSTEM_PROMPT,
                            "cache_control": {"type": "ephemeral"},
                        }
                    ],
                    tools=tools.build_tools(self),
                    messages=messages,
                    max_iterations=max_iterations,
                )
                for message in runner:
                    final = message
                    # A message that also calls tools is the agent narrating
                    # its work, and goes straight through. The one that calls
                    # none is a CLAIM about the outcome, and waits for the
                    # check in _verdict.
                    narrating = any(block.type == "tool_use" for block in message.content)
                    for block in message.content:
                        if narrating and block.type == "text" and block.text.strip():
                            self.emit({"type": "chat", "text": block.text})

                if final is None or final.stop_reason == "refusal":
                    break
                pushback = self.unverified()
                if not (pushback and follow_ups) or pushback.get("final"):
                    break
                follow_ups -= 1
                # A fresh runner, because the SDK's generator has already
                # returned and cannot be restarted — it exits the moment a turn
                # asks for no tools. Seeded with everything that has been said
                # so far, so the model keeps the context of what it already
                # tried instead of starting the task over.
                messages = [
                    *_history(runner),
                    {"role": "assistant", "content": final.content},
                    {"role": "user", "content": pushback["agent"]},
                ]
        except EStopTriggered as e:
            result = TeachResult(text=f"E-STOP: {e}", outcome="fail", error=str(e))
            self.memory.log(task, self.skills_used, "fail", error=str(e))
            return result

        if final is None:
            result = TeachResult(text="The agent produced no response.", outcome="fail")
        elif final.stop_reason == "refusal":
            result = TeachResult(
                text="The model declined this request — rephrase the task.",
                outcome="fail",
                error="refusal",
            )
        else:
            result = self._verdict("".join(b.text for b in final.content if b.type == "text"))

        self.memory.log(task, self.skills_used, result.outcome, error=result.error)
        return result
