"""How the agent gets better at WRITING skills, not just at this one skill.

Four mechanisms, all of them the runtime's and none of them the model's word:

1. `baked_points` — a skill that contains the coordinates of something in the
   scene is refused at save time, with the line. "Read positions inside run()"
   was a sentence in the prompt; this makes it a gate.
2. `variations` — a newly written skill that moved something is run again, in
   rehearsal, with that thing a few centimetres from where it was. A skill tied
   to where the blocks happened to be passes once and fails this. That is what
   "not hardcoded" means in practice, and only a simulator can check it.
3. `failure_kind` and the failure records in memory — a failure is filed by
   WHAT WENT WRONG (lost grasp, no route, disturbed another object…), on which
   primitive, on which robot, with what fixed it. The next time that kind of
   failure happens, on this robot or another, the fix that worked comes back
   with the refusal. Loose sentences found by keyword could not do that.
4. `similar_skills` — before writing, the agent is handed the working skills on
   this robot most like the task. Success used to teach nothing.
"""

from __future__ import annotations

import ast
import re

# --- 1. baked coordinates ----------------------------------------------------------

#: How close a literal has to be to a scene coordinate to count as that coordinate.
_SAME = 0.0015


def _number(node: ast.AST) -> float | None:
    if isinstance(node, ast.UnaryOp) and isinstance(node.op, ast.USub | ast.UAdd):
        inner = _number(node.operand)
        return None if inner is None else (-inner if isinstance(node.op, ast.USub) else inner)
    if (
        isinstance(node, ast.Constant)
        and isinstance(node.value, int | float)
        and not isinstance(node.value, bool)
    ):
        return float(node.value)
    return None


def baked_points(code: str, scene: dict) -> list[str]:
    """Places in `code` where a point from the current scene has been written down.

    A list or tuple of two or three plain numbers, at least two of which are
    the same (non-zero) coordinates of one body in the scene, in the same
    positions. Deliberately narrow: a lift height of 0.1 that happens to equal
    somebody's y is not a baked position, and refusing good skills would teach
    the agent to obfuscate its numbers rather than to read the scene. Two
    matching coordinates of the same body, in order, is not a coincidence.
    """
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return []  # the store reports syntax errors, in its own words
    bodies = {**(scene.get("fixtures") or {}), **(scene.get("objects") or {})}
    found: list[str] = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.List | ast.Tuple) or not 2 <= len(node.elts) <= 3:
            continue
        values = [_number(element) for element in node.elts]
        if any(value is None for value in values):
            continue
        for name, body in bodies.items():
            position = body.get("position") or []
            same = sum(
                1
                for index, value in enumerate(values)
                if index < len(position)
                and abs(value) > 1e-9
                and abs(value - float(position[index])) <= _SAME
            )
            if same >= 2:
                written = ast.get_source_segment(code, node) or str(values)
                found.append(f"line {node.lineno}: {written} is where {name} is right now")
                break
    return found


# --- 2. variations -----------------------------------------------------------------

#: Tried in order. Three centimetres: far enough that a baked coordinate misses a
#: 40 mm cube's grasp, near enough to stay on the bench and within reach.
SHIFTS = ((0.03, 0.03), (-0.03, 0.03), (0.03, -0.03), (-0.03, -0.03), (0.03, 0.0), (0.0, 0.03))
#: How many feasible variations are tried before a skill is called tied to
#: positions. One can fail for its own physical reasons; a hardcoded skill
#: fails them all.
VARIATIONS_TRIED = 2
_APART = 0.06


def holder_of(name: str, scene: dict, resting_in) -> str | None:
    """What `name` is sitting on: "on:<object>" for a stack, else the fixture."""
    objects = scene.get("objects") or {}
    me = objects.get(name)
    if not me:
        return None
    x, y, z = (float(v) for v in me["position"])
    for other, body in objects.items():
        if other == name:
            continue
        ox, oy, oz = (float(v) for v in body["position"])
        half = max(float(v) for v in body["size_m"][:2]) / 2
        tall = float(body["size_m"][2]) / 2 + float(me["size_m"][2]) / 2
        if abs(x - ox) <= half and abs(y - oy) <= half and abs((z - oz) - tall) <= 0.012:
            return f"on:{other}"
    return resting_in(me["position"], scene.get("fixtures") or {})


def feasible_shifts(name: str, scene: dict, resting_in, reachable) -> list[tuple[float, float]]:
    """Offsets `name` could be moved by and still be the same problem: on the
    same surface, clear of everything else, and somewhere an arm can get to."""
    objects, fixtures = scene.get("objects") or {}, scene.get("fixtures") or {}
    me = objects[name]
    x, y, z = (float(v) for v in me["position"])
    home = resting_in(me["position"], fixtures)
    if home is None or holder_of(name, scene, resting_in) != home:
        return []  # stacked, held or off the bench: not something to slide around
    half = max(float(v) for v in me["size_m"][:2]) / 2
    out = []
    for dx, dy in SHIFTS:
        nx, ny = x + dx, y + dy
        surface = fixtures[home]
        sx, sy = (float(v) for v in surface["size_m"][:2])
        cx, cy = (float(v) for v in surface["position"][:2])
        # Whole footprint still on the surface it started on, with a margin…
        if abs(nx - cx) + half + 0.015 > sx / 2 or abs(ny - cy) + half + 0.015 > sy / 2:
            continue
        # …and on no OTHER fixture (a tray or pocket it was not in)…
        if resting_in([nx, ny, z], fixtures) != home:
            continue
        near_fixture = False
        for other_name, other in fixtures.items():
            if other_name in (home, "table"):
                continue
            ox, oy = (float(v) for v in other["position"][:2])
            wx, wy = (float(v) / 2 for v in other["size_m"][:2])
            if abs(nx - ox) <= wx + half + 0.01 and abs(ny - oy) <= wy + half + 0.01:
                near_fixture = True
        if near_fixture:
            continue
        # …clear of every other object…
        if any(
            max(abs(nx - float(o["position"][0])), abs(ny - float(o["position"][1]))) < _APART
            for other_name, o in objects.items()
            if other_name != name
        ):
            continue
        # …and reachable, down at the object and up at the hover above it.
        if reachable((nx, ny, z)) and reachable((nx, ny, z + 0.12)):
            out.append((dx, dy))
        if len(out) >= VARIATIONS_TRIED:
            break
    return out


# --- 3. kinds of failure -----------------------------------------------------------

#: First match wins, so the specific sits above the general.
_KINDS: tuple[tuple[str, tuple[str, ...]], ...] = (
    ("tied_to_positions", ("NOT PROVEN",)),
    ("baked_coordinates", ("is where", "baked")),
    ("ejected", ("off the workcell", "off the table", "launches it")),
    ("stack_fell", ("did not stay there", "out of place", "onto ")),
    ("lost_grasp", ("dropped", "lost its grasp", "did not come up", "Nothing is held")),
    ("disturbed_object", ("displaced unheld",)),
    ("container_full", ("is full",)),
    ("unreachable", ("cannot reach", "out of reach", "closest is")),
    ("no_route", ("no clear route", "wedges", "nowhere this arm can reach")),
    ("collision", ("COLLISION", " hit ")),
    ("stopped", ("E-STOP",)),
    ("code_error", ("Error", "raised", "is not defined", "unexpected")),
)


def failure_kind(text: str) -> str:
    for kind, marks in _KINDS:
        if any(mark in text for mark in marks):
            return kind
    return "other"


def primitive_of(text: str) -> str | None:
    """The primitive a failure happened in: "Failed step: move_to_point arm …"."""
    match = re.search(r"Failed step: (\w+)", text)
    return match.group(1) if match else None


# --- 4. worked examples -------------------------------------------------------------

_PRIMITIVES = (
    "pick_up",
    "place_in",
    "place_on",
    "free_spot",
    "move_to_point",
    "move_to",
    "gripper",
    "replay_trajectory",
)
_STOP = frozenset(
    ["a", "an", "and", "the", "to", "of", "in", "on", "at", "it", "then", "with", "into", "up", "down", "by", "for", "from", "this", "that", "is"]
)


def _words(text: str) -> set[str]:
    return {
        w
        for w in re.findall(r"[a-z]+", text.lower().replace("_", " "))
        if w not in _STOP and len(w) > 1
    }


def similar_skills(task: str, proven: list[dict], read_code, limit: int = 2) -> list[dict]:
    """The working skills most like `task`, with their code.

    Matched on what the skill says it does (name and description) and on which
    primitives it uses, so "stack the green block" finds a stacking skill even
    if that one was taught about red. `proven` is newest-last; ties go to the
    newest, which was written under the most lessons.
    """
    wanted = _words(task)
    if not wanted:
        return []
    scored = []
    for index, meta in enumerate(proven):
        code = read_code(meta["name"]) or ""
        uses = {p.replace("_", " ") for p in _PRIMITIVES if f"ctx.{p}(" in code}
        has = _words(f"{meta['name']} {meta.get('description', '')} {' '.join(uses)}")
        score = len(wanted & has)
        if score:
            scored.append(
                (
                    score,
                    index,
                    {
                        "name": meta["name"],
                        "description": meta.get("description", ""),
                        "code": code[:3000],
                    },
                )
            )
    scored.sort(key=lambda item: (-item[0], -item[1]))
    return [example for _, _, example in scored[:limit]]
