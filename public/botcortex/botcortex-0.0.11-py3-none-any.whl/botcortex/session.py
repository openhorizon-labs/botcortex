"""One robot and the artifacts it owns — everything a tool call actually does.

Deliberately free of any model SDK. `agent.py` imports `anthropic` and `openai`
at module scope, which is right on a robot and impossible in a browser: those
SDKs are built on sockets Pyodide does not have. The browser still needs these
tool bodies, though, because they ARE the agent's reach into the robot — the
same clamped primitives, the same restricted skill executor, the same episodic
memory. Reimplementing them in TypeScript would mean the browser agent could do
subtly different things to a robot than the runtime's agent can.

So the SDK-free half lives here and `agent.TeachSession` extends it. What the
loop calls is shared; only how it talks to a vendor differs.

The one runtime-only concern is pushing a saved skill to the account registry,
which needs network access this file should not assume. It is a hook.
"""

from __future__ import annotations

import json

from botcortex import config, scene
from botcortex.memory import EpisodeMemory
from botcortex.robot import EStopTriggered
from botcortex.safety import Collision
from botcortex.skills import SkillContext, SkillError, SkillStore

#: How a tool body reports failure: in its RETURN VALUE, not by raising, so the
#: model reads what went wrong and repairs it rather than the loop dying.
#:
#: Exported in agent_contract.json, because the browser's loop has to classify
#: the same strings and had no way to know them — every failed tool call showed
#: a green "Completed" badge there while the runtime marked it an error.
FAILURE_PREFIXES = ("ERROR", "REJECTED", "E-STOP")


def failed(result: str) -> bool:
    """Whether a tool's return value reports a failure."""
    return str(result).startswith(FAILURE_PREFIXES)


class RobotSession:
    """One robot + its owned artifacts, shared by CLI, server, browser, tests.

    emit(), when set, receives protocol events (dicts) from any thread the
    teach loop happens to run on.
    """

    def __init__(
        self,
        robot,
        store: SkillStore | None = None,
        memory: EpisodeMemory | None = None,
    ):
        self.robot = robot
        self.store = store or SkillStore(config.SKILLS_DIR)
        self.memory = memory or EpisodeMemory(config.MEMORY_FILE)
        self.emit = lambda event: None
        self.skills_used: list[str] = []
        #: True while a teach or skill run owns the robot. The server checks it
        #: before honouring a reset, so a second tab can never teleport the arm
        #: out from under a running skill.
        self.busy = False
        self.forget_evidence()

    def forget_evidence(self) -> None:
        """Start a new task with no claims about it. See `unverified()`."""
        #: Skills saved during this task.
        self.authored: list[str] = []
        #: Whether any tool actually drove the arm.
        self.moved = False
        #: (skill, ok, what happened) for the last run_skill, or None.
        self.last_run: tuple[str, bool, str] | None = None
        #: The e-stop refused something during this task. Kept separately from
        #: the rest because a latched stop leaves NO other trace — nothing was
        #: authored, nothing moved, no run was recorded — which is exactly the
        #: shape of "there was nothing to verify".
        self.stopped = False
        #: (done, summary) once the agent has said, in a tool call rather than
        #: in prose, whether the task is finished.
        self.reported: tuple[bool, str] | None = None

    # --- tool bodies (plain methods so tests hit them without the SDK) ---

    def tool_get_positions(self, arm: str) -> dict[str, float]:
        return self.robot.get_positions(arm)

    def tool_move_to(self, arm: str, targets: dict[str, float], duration: float | None) -> str:
        return self._drive(
            lambda: self.robot.move_to(arm, targets, duration),
            lambda: f"moved; now at {json.dumps(self.robot.get_positions(arm))}",
        )

    #: How far off a solve may be and still count as reaching the point. Must
    #: match move_to_point's own tolerance, or advice would promise a point the
    #: primitive then refuses.
    REACH_TOLERANCE = 0.02

    def reach(self, arm: str, point) -> float | None:
        """How far the arm's grasp centre lands from `point`, or None if it
        cannot be asked. Moves nothing."""
        solve = getattr(self.robot, "solve_pose", None)
        if solve is None:
            return None
        try:
            _, error = solve(arm, list(point))
        except Exception:  # noqa: BLE001 — an unanswerable question, not a fault
            return None
        return error

    def tool_can_reach(self, arm: str, point: list[float]) -> str:
        """Ask before committing, instead of finding out by failing.

        The agent used to have exactly one way to learn whether a waypoint was
        reachable: write a whole skill, save it, run it, and read the refusal.
        Watched live, that cost four author-run cycles to discover one
        geometric fact about one point — and it was not even a stable fact
        until NEUTRAL_JOINTS was pinned, because the answer depended on where
        the arm happened to be standing.

        Now it is a question, it is free, and the answer does not move
        anything.
        """
        error = self.reach(arm, point)
        if error is None:
            return "ERROR: this robot cannot be asked about points; it has no geometry."
        if error <= self.REACH_TOLERANCE:
            return (
                f"yes — {arm} reaches {point} with {error * 1000:.0f} mm position error. "
                "(Reachable, which is not the same as a clear path there.)"
            )
        return f"no — {arm} misses {point} by {error * 1000:.0f} mm.{self._instead(arm, point)}"

    def _instead(self, arm: str, point) -> str:
        """What WOULD work, found by asking rather than by guessing.

        "cannot reach (0.32, -0.05, 0.34) — closest is 27 mm away" is true and
        leaves a model with nothing to change but its imagination. The runtime
        can answer the obvious follow-ups — the other arm, and a lower approach
        — in the time it takes to say so, and reachability is deterministic
        now, so the answer keeps.
        """
        for other in self.robot.platform.arms if hasattr(self.robot, "platform") else config.ARMS:
            if other == arm:
                continue
            error = self.reach(other, point)
            if error is not None and error <= self.REACH_TOLERANCE:
                return f" The {other} arm reaches it ({error * 1000:.0f} mm) — use that arm."

        for drop in (0.03, 0.06, 0.09):
            lower = [point[0], point[1], point[2] - drop]
            error = self.reach(arm, lower)
            if error is not None and error <= self.REACH_TOLERANCE:
                return (
                    f" {arm} does reach {[round(float(v), 3) for v in lower]}, "
                    f"{drop * 100:.0f} cm lower — approach from there instead."
                )
        return " Neither arm reaches it, and nor does a lower approach; pick a different point."

    def tool_move_to_point(self, arm: str, point: list[float]) -> str:
        """Put the grasp centre on a point in metres, gripper pointing down.

        The bridge between what describe_scene says and what the arm accepts.
        Without it the agent can see a block perfectly and has no way to act on
        what it sees, so it guesses joint angles — which is how a skill comes to
        run cleanly and move nothing.
        """
        try:
            return self._drive(
                lambda: self.robot.move_to_point(arm, point),
                lambda: f"at {point}; joints now {json.dumps(self.robot.get_positions(arm))}",
            )
        except ValueError as e:
            # "no clear route" means kinematics said yes and PHYSICS said no.
            # _instead's suggestions are kinematic — the other arm, a lower
            # point — which is exactly the kind of answer that just proved
            # wrong; appending them sent an agent to wedge the other arm on
            # the same spot. That refusal carries its own diagnosis
            # (kinematics.too_low) and stands alone.
            if str(e).startswith("no clear route"):
                return f"REJECTED: {e}"
            # Out of reach. Refused rather than approximated — an arm that
            # stopped wherever it could and closed its jaws would report a
            # grasp having grasped nothing. The refusal carries what to try
            # instead, or the model has nothing to change but its imagination.
            return f"REJECTED: {e}.{self._instead(arm, point)}"
        except NotImplementedError as e:
            # A backend with no geometry, which says so rather than pretending.
            return f"ERROR: {e}. Use move_to with joint angles on this robot."

    def tool_gripper(self, arm: str, position: float) -> str:
        """Open or close the jaws — and say when they did not get there.

        The angle alone was reported before, and it hid the one fact that
        decides a grasp: whether the jaws CONVERGED. Near a tray rim the close
        can jam the block against the wall — one finger on the cube, the other
        stalled on the rim, the gripper stuck around -43 of the commanded 0 —
        and "gripper at -42.6" reads as a normal statement. A stalled close and
        a firm hold are the same number from the outside, so the report names
        the stall and hands the agent the distinction to check.
        """

        def describe() -> str:
            actual = self.robot.get_positions(arm)["gripper"]
            if abs(actual - position) <= 3.0:
                return f"gripper at {actual:.1f}"
            return (
                f"gripper STOPPED at {actual:.1f}, short of the commanded {position:.1f} — "
                "the jaws are pressing on something. If that is the object being grasped, "
                "this is a hold. If the jaws could have caught anything else — a tray "
                "wall, the table, the object's corner — the object is probably NOT held. "
                "Verify by lifting and re-reading describe_scene."
            )

        return self._drive(lambda: self.robot.gripper(arm, position), describe)

    def _drive(self, action, describe) -> str:
        """Rehearse a motion, then make it, and REPORT failure rather than raise.

        Both halves matter. Rehearsing is what keeps the arm out of the table;
        returning the failure instead of raising is this file's standing
        convention (see FAILURE_PREFIXES), and these two tools were quietly
        breaking it. An EStopTriggered escaping a tool body reached the OpenAI
        loop's generic `except Exception` and came back as
        "ERROR: EStopTriggered: …" — which is not a prefix anything recognises,
        so the session never noticed the stop and filed the teach as a success.
        """
        safe, note = self._rehearse(action)
        if not safe:
            return note
        try:
            action()
        except EStopTriggered as e:
            self.stopped = True
            return f"E-STOP: {e}"
        except Collision as e:
            return f"ERROR: {e}"
        self.moved = True
        return describe()

    def tool_describe_scene(self) -> str:
        return json.dumps(self.robot.describe_scene())

    def tool_list_skills(self) -> str:
        """Only the skills that have been SEEN TO WORK.

        A saved skill is not a working skill. Anything the agent wrote and
        never got to run — or ran and watched fail — carries no proof, and the
        store keeps them apart (`SkillStore.has_run`). Listing them together
        invited the one mistake that costs the owner most: the agent reads a
        promising description, reuses the skill as a building block, and
        inherits a failure that was already diagnosed once.

        So the list is the proven ones. The unproven names are still reported,
        because the agent needs to know a name is taken and that re-authoring
        it is the right move — but they are reported as what they are, with
        the instruction not to call them.
        """
        proven = [m for m in self.store.list() if self.store.has_run(m["name"])]
        unproven = self.store.unproven()
        payload: dict = {"skills": proven}
        if unproven:
            payload["do_not_reuse"] = {
                "names": unproven,
                "why": (
                    "Saved but never seen to run successfully. Do not run or build on "
                    "these — write the behaviour yourself and save over the name."
                ),
            }
        return json.dumps(payload)

    def tool_save_skill(self, name: str, code: str) -> str:
        try:
            meta = self.store.save(name, code)
        except SkillError as e:
            return f"REJECTED: {e}"
        self._announce_skills()
        self.on_skill_saved(name, meta, code)
        if name not in self.authored:
            self.authored.append(name)
        return f"saved {name}: {meta['description']}"

    def _announce_skills(self) -> None:
        """The skill list, and which of it has never been seen to work."""
        self.emit(
            {
                "type": "skills",
                "skills": self.store.names(),
                "unproven": self.store.unproven(),
            }
        )

    def on_skill_saved(self, name: str, meta: dict, code: str) -> None:
        """Somewhere to send a copy of the skill. Nothing by default.

        The runtime overrides this to push to the account registry. It is a
        hook rather than a call because reaching the network is exactly what
        this module must not assume — and because a failure to sync must never
        change what the agent sees: the skill is already on disk and runnable.
        """

    def tool_run_skill(self, name: str, params: dict, *, as_agent: bool = False) -> str:
        """Run a skill and report WHAT HAPPENED, not that it ran.

        The old answer was "<name> finished: N primitive calls, all clamped and
        e-stop-checked". Every word of that is true and none of it is evidence:
        it says the calls were MADE, not that anything was achieved. An agent
        reads "finished" as "done", declares success, and stops — which is
        exactly what it did while driving the arm into the table.

        So the result now carries the scene before and after. The agent has to
        look at what moved to decide whether it worked, and when nothing moved
        it is told so plainly.
        """
        # A skill with no proof is only runnable by the agent that just wrote
        # it — which is how a skill EARNS its proof. Reusing someone else's
        # unproven skill is the failure this guards: the code is there, it
        # reads plausibly, and it has already been watched to fail.
        if (
            as_agent
            and name not in self.authored
            and name in self.store.names()
            and not self.store.has_run(name)
        ):
            return (
                f"REFUSED: {name} has never run successfully, so it is not a skill this "
                "robot knows — it is a draft someone left behind. Write the behaviour "
                "yourself and save over that name, then run it."
            )
        self.skills_used.append(name)
        steps: list[str] = []

        def on_step(label: str) -> None:
            steps.append(label)
            self.emit({"type": "step", "id": str(len(steps)), "state": "ok"})

        before = self._object_positions()

        # Rehearsed first, with the plan view left alone: what the owner
        # watches should be the run that happened, not a dry run of it.
        rehearsal_ctx = SkillContext(self.robot)
        safe, note = self._rehearse(
            lambda: self.store.run(name, rehearsal_ctx, **params),
            watch=before,
        )
        if not safe:
            phase = f" Failed step: {rehearsal_ctx.last_step}." if rehearsal_ctx.last_step else ""
            return self._ran(name, False, note + phase)

        ctx = SkillContext(self.robot, on_step=on_step)
        # Where the motion log stands as the REAL run starts (the rehearsal
        # above rewound its own frames), so what the arm did can be read
        # back afterwards — see _arm_motion.
        logged = len(getattr(self.robot, "motion_log", ()))
        try:
            self.store.run(name, ctx, **params)
        except EStopTriggered as e:
            self.stopped = True
            return self._ran(name, False, f"E-STOP mid-skill: {e}")
        except Collision as e:
            # Its own branch, and its own prefix: this is the failure mode the
            # agent used to be blind to, and it is repairable — it says which
            # part hit what, which is what tells a model which way to move.
            #
            # Reaching here after a clean rehearsal would mean the rehearsal is
            # not predictive, which is measured not to happen (see
            # botcortex.safety) — but the check stays, because a backstop that
            # only runs when the world has already gone wrong is the one you
            # cannot afford to have removed.
            return self._ran(name, False, f"ERROR: {e}")
        except SkillError as e:
            return self._ran(name, False, f"ERROR: {e}")
        except Exception as e:  # noqa: BLE001 — agent-authored code can raise anything
            return self._ran(name, False, f"ERROR while running {name}: {type(e).__name__}: {e}")

        self.moved = True
        # It ran to completion. That is what the sidebar's "your robot knows
        # this" is allowed to rest on — not that it was written.
        self.store.mark_ran(name)
        self._announce_skills()
        moved = self._what_moved(before)
        arm = self._arm_motion(logged)
        # _what_moved answers "moved: …", None, or a note that the workcell has
        # no objects at all; only the first is object motion.
        objects_changed = bool(moved and moved.startswith("moved"))
        if not objects_changed and not arm:
            evidence = self._nothing_moved()
        else:
            # Two lines of evidence, always both: what the ARM did and what the
            # OBJECTS did. A wave moves no object and is still a task done; a
            # pick that moved the arm and no block is a task failed. Reporting
            # only objects told an agent that had just waved the arm through
            # thirty degrees that NOTHING MOVED, and it believed it.
            evidence = f"{arm or 'The arm did not move'}. {moved.capitalize() if moved else 'No object on the table moved.'}"
        return self._ran(
            name,
            True,
            f"Rehearsed clean, then {name} ran ({len(steps)} primitive calls). {evidence}",
        )

    def _ran(self, name: str, ok: bool, note: str) -> str:
        """Record how a run went, then hand the same words to the model.

        `ok` means the run COMPLETED — no crash, no collision, no refusal. It
        deliberately does not mean the task was achieved: only the model knows
        what was asked for, so the runtime hands it the evidence (what moved,
        or that nothing did) and lets it judge. A runtime that graded the task
        itself would fail every skill whose job is a wave.

        The record is what `unverified()` reads. Writing it here rather than at
        each call site is deliberate: every path out of tool_run_skill goes
        through this, so there is no way to return from a run without the
        session having noticed how it went.
        """
        self.last_run = (name, ok, note)
        return note

    def _rehearse(self, action, watch: dict[str, list[float]] | None = None) -> tuple[bool, str]:
        """Run `action` where it cannot break anything, and say what it did.

        This is the answer to the arm ending up inside the table: not a better
        apology afterwards, but never doing it. The whole motion runs first in
        a copy of the present moment — real physics, real contacts — and only a
        clean rehearsal is allowed to reach the arm. When it is not clean,
        NOTHING has moved and the failure says why.

        (False, why) means refuse. (True, note) means go ahead.

        A backend with no physics cannot rehearse and must not claim to: the
        note says so in as many words, so "rehearsed clean" never quietly means
        "not checked".
        """
        rehearsal = getattr(self.robot, "rehearsal", None)
        if rehearsal is None:
            return True, "Not rehearsed — this robot has no physics to rehearse in."

        try:
            with rehearsal():
                action()
                predicted = self._what_moved(watch) if watch is not None else None
                lost = self._ejected()
        except EStopTriggered as e:
            self.stopped = True
            return False, f"E-STOP: {e} — nothing was moved."
        except Collision as e:
            return False, (
                f"REJECTED, and the arm has not moved. Rehearsed first, and it crashed: {e}"
            )
        except SkillError as e:
            return False, f"REJECTED, and the arm has not moved. The rehearsal failed: {e}"
        except Exception as e:  # noqa: BLE001 — agent-authored code can raise anything
            return False, (
                f"REJECTED, and the arm has not moved. The rehearsal raised {type(e).__name__}: {e}"
            )

        if lost:
            # The whole point of rehearsing: this happened somewhere nothing
            # can be damaged, and the arm has not moved.
            return False, (
                f"REJECTED, and the arm has not moved. The rehearsal threw "
                f"{', '.join(lost)} off the workcell — the arm catches it in passing "
                "and launches it. Keep the path clear of everything you are not "
                "carrying: lift straight up, travel high, and come down only over "
                "the destination."
            )

        if watch is None:
            return True, "Rehearsed clean."
        if predicted is None:
            return True, (
                "Rehearsed clean — it hits nothing, but it also moves nothing. "
                "If the task is supposed to move an object, this skill will not "
                "do it, so fix it before claiming it works."
            )
        return True, f"Rehearsed clean; predicted {predicted.lower()}"

    def _ejected(self) -> list[str]:
        """Objects that are no longer anywhere in the workcell.

        A skill caught the red block on its way past and launched it to
        [18.6, 3.7, -1761] — 176 kilometres. The rehearsal called that clean,
        because the check it runs asks whether a structural LINK is inside a
        FIXTURE, and this was the arm touching payload, which is manipulation
        working. Correct rule, and blind to this.

        Whether an object is still on the table is a different question with an
        objective answer, so it gets asked separately.
        """
        described = self.robot.describe_scene()
        fixtures = described["fixtures"]
        if not fixtures:
            return []
        return [
            name
            for name, body in described["objects"].items()
            if scene.resting_in(body["position"], fixtures) is None
        ]

    def _object_positions(self) -> dict[str, list[float]]:
        return {
            name: list(body["position"])
            for name, body in self.robot.describe_scene()["objects"].items()
        }

    def _nothing_moved(self) -> str:
        return (
            "NOTHING MOVED — not the arm, not any object. If the task was supposed to "
            "move something, it did not work — check where the object actually is "
            "with describe_scene and try again rather than reporting success."
        )

    #: A joint has to sweep this far during a run to count as having moved.
    #: Servo settling and gravity sag are a degree or two; a deliberate motion
    #: is tens.
    ARM_MOTION_DEG = 3.0

    def _arm_motion(self, since: int) -> str | None:
        """What each arm did during the run, from the motion log — the same
        frames the owner watched. Joint sweeps in degrees, largest first, and
        how many control ticks it took. None when no arm moved."""
        log = getattr(self.robot, "motion_log", None)
        if log is None:
            return None
        frames = [entry for entry in log[since:] if entry[0] == "step"]
        if not frames:
            return None
        arms = getattr(self.robot, "platform", config.PLATFORM).arms
        lines = []
        for arm in arms:
            mine = [positions for kind, who, positions in frames if who == arm]
            if not mine:
                continue
            sweeps = {}
            for joint in mine[0]:
                values = [p[joint] for p in mine if joint in p]
                sweep = max(values) - min(values)
                if sweep >= self.ARM_MOTION_DEG:
                    sweeps[joint] = sweep
            if not sweeps:
                continue
            top = sorted(sweeps.items(), key=lambda kv: -kv[1])[:3]
            listed = ", ".join(f"{joint} {sweep:.0f}°" for joint, sweep in top)
            label = "the arm" if len(arms) == 1 else f"the {arm} arm"
            lines.append(f"{label} swept {listed} over {len(mine)} control ticks")
        if not lines:
            return None
        text = "; ".join(lines)
        return text[:1].upper() + text[1:]

    def _what_moved(self, before: dict[str, list[float]], threshold: float = 0.01) -> str | None:
        """What changed in the world, in centimetres an agent can reason about.

        None means nothing did — which callers must say out loud, because
        silence about the world is exactly what let "finished" mean "succeeded".
        """
        after = self._object_positions()
        if not after:
            return "no objects in this workcell, so there is nothing to verify"

        fixtures = self.robot.describe_scene()["fixtures"]
        moved = []
        for name, end in after.items():
            start = before.get(name)
            if not start:
                continue
            shift = sum((a - b) ** 2 for a, b in zip(end, start, strict=True)) ** 0.5
            if shift > threshold:
                # WHERE it ended up, not just how far it went. See
                # scene.resting_in: "moved 32 cm to [0.315, -0.461, 0.22]" is
                # true and was read as "placed" for a block lying on the table.
                holder = scene.resting_in(end, fixtures)
                landed = f"on {holder}" if holder else "off the workcell entirely"
                moved.append(
                    f"{name} moved {shift * 100:.0f} cm and is now {landed}, "
                    f"at {[round(v, 3) for v in end]}"
                )

        return "moved: " + "; ".join(moved) + "." if moved else None

    # --- the gate on saying "done" ---

    def unverified(self) -> dict | None:
        """Why the agent may not call this task finished — or None if it may.

        The complaint this exists for: the agent drove the arm into the table,
        wrote a skill, and said the work was done. Nothing checked. The loop
        accepted whatever the model's last message claimed and logged the whole
        run as a success, which then came back out of `recall_episodes` as a
        worked example — the failure memory was being taught the wrong lesson.

        So a claim of success is now checked against what the session actually
        saw. The rules are deliberately about EVIDENCE, never about the task:
        the runtime does not know what was asked for, so it cannot grade the
        outcome. It can tell whether anything was demonstrated.

        Returns {"agent": <what to tell the model>, "owner": <what to tell the
        person>} — a dict rather than a string because the browser's loop
        crosses a worker boundary and needs it as JSON.
        """
        if self.reported is not None and not self.reported[0]:
            # It said so itself. Nothing here should second-guess that upward.
            said = self.reported[1]
            return {
                "agent": (
                    "You reported this as not done, which is the right call if the "
                    "evidence does not show it working. If you can still fix it, do "
                    "that and report again; otherwise stop here."
                ),
                "owner": said or "That didn't work.",
                "final": True,
            }

        lost = self._ejected()
        if lost:
            # Objective, and nothing else in the gate would catch it: the skill
            # ran, something moved, and the workcell is wrecked.
            return {
                "agent": (
                    f"Do not stop here. {', '.join(lost)} is no longer anywhere in the "
                    "workcell — something threw it off the table. Whatever else "
                    "happened, this attempt failed. Say so."
                ),
                "owner": f"That didn't work — {', '.join(lost)} ended up off the table.",
            }

        if self.stopped:
            # First, and final: the e-stop is latched, so nothing can move
            # however many times the model is sent back, and there is no
            # version of this where the task is done. Sending it back anyway
            # would just spend the owner's credit insisting.
            return {
                "agent": (
                    "The e-stop is latched, so nothing moved and nothing can move "
                    "until the owner clears it. Stop here and say that — do not "
                    "report the task done."
                ),
                "owner": "Stopped: the e-stop is latched. Clear it to continue.",
                "final": True,
            }

        if self.last_run and not self.last_run[1]:
            # Checked before the escape below, not after: a run REFUSED in
            # rehearsal leaves nothing authored and nothing moved — which is
            # precisely the shape of "there was nothing to verify", and would
            # otherwise let the one case this gate exists for walk straight
            # through it.
            name, _, why = self.last_run
            return {
                "agent": (
                    f"Do not stop here. The last run of {name} did not succeed:\n{why}\n"
                    "Fix the skill, save it again and run it again. If you have tried "
                    "and cannot make it work, say plainly that it did not work and what "
                    "went wrong — do not report success."
                ),
                "owner": f"That didn't work — {name} failed and the robot hasn't learned it.",
            }

        if not self.authored and not self.moved:
            # A question, not a job. "Where is the red block?" answers itself,
            # and a gate that demanded a skill for it would push back until the
            # budget ran out and then report a failure on a task that worked.
            return None

        if self.authored and self.last_run is None:
            names = ", ".join(self.authored)
            return {
                "agent": (
                    f"Do not stop here. You saved {names} but never ran it, so nothing "
                    "shows it works. Run it and read what actually moved before saying "
                    "anything is done."
                ),
                "owner": "The robot wrote that skill but never tried it, so I can't say it works.",
            }

        if not self.authored and self.last_run is None:
            return {
                "agent": (
                    "Do not stop here. You moved the arm but saved no skill and ran "
                    "none, so the robot cannot repeat any of this. Save what you did as "
                    "a skill and run it to prove it works."
                ),
                "owner": "The robot did that once but didn't learn it, so it can't repeat it.",
            }

        if self.reported is None:
            # Last, because every rule above has something more specific to say.
            # Finishing without a verdict at all is how "it ran" came to stand
            # in for "it worked".
            return {
                "agent": (
                    "Do not stop here. Call report(done, summary) to say whether the "
                    "task is actually finished — judge it on what moved and where it "
                    "ended up, not on whether your calls succeeded."
                ),
                "owner": "The robot didn't say whether that worked.",
            }

        return None

    def tool_report(self, done: bool, summary: str) -> str:
        """The agent's own verdict, as data rather than as prose.

        It said "I could not verify the requested placement, so this needs
        another correction" and the run was filed as a SUCCESS — because every
        rule the gate had was about activity (was a skill authored, did it run,
        is the workcell intact) and every one of them passed. The one signal
        nobody was reading was the agent's own admission.

        Prose cannot be trusted to carry that: "the placement failed" and
        "placed successfully" differ by a word a keyword check will get wrong
        eventually. So the claim is a tool call, and the evidence rules still
        get to veto a `done=True` that the session can see is false. The gate
        works in both directions now: it will not accept success without
        evidence, and it will not manufacture success the agent never claimed.
        """
        self.reported = (bool(done), summary.strip())
        return "noted" if done else "noted — reported as not done"

    def tool_recall_episodes(self, query: str) -> str:
        return json.dumps(self.memory.recall(query))

    def tool_log_lesson(self, lesson: str) -> str:
        self.memory.log(task="(lesson)", skills_used=[], outcome="fail", lesson=lesson)
        return "lesson recorded"

    # --- the seam the browser calls through ---

    def call_tool(self, name: str, args: dict) -> str:
        """Dispatch one tool by name, as the model asked for it.

        The runtime routes through tools.py's @beta_tool wrappers, which the
        vendor SDKs generate schemas from. The browser has no SDK, so it needs
        a plain entry point — but it must be the SAME bodies underneath, or the
        two agents diverge in what they can actually do.

        Argument shapes match agent_contract.json, which is exported from those
        same wrappers: JSON-encoded strings for the nested arguments, because
        that is what the schemas declare.
        """
        if name == "get_positions":
            return json.dumps(self.tool_get_positions(args["arm"]))
        if name == "move_to":
            return self.tool_move_to(
                args["arm"],
                json.loads(args.get("targets_json") or "{}"),
                args.get("duration"),
            )
        if name == "report":
            return self.tool_report(bool(args["done"]), str(args.get("summary") or ""))
        if name == "can_reach":
            return self.tool_can_reach(args["arm"], json.loads(args["point_json"]))
        if name == "move_to_point":
            return self.tool_move_to_point(arm=args["arm"], point=json.loads(args["point_json"]))
        if name == "gripper":
            return self.tool_gripper(args["arm"], float(args["position"]))
        if name == "describe_scene":
            return self.tool_describe_scene()
        if name == "list_skills":
            return self.tool_list_skills()
        if name == "save_skill":
            return self.tool_save_skill(args["name"], args["code"])
        if name == "run_skill":
            return self.tool_run_skill(
                args["name"],
                json.loads(args.get("params_json") or "{}"),
                # Opt IN, not opt out. The guard below is about the MODEL
                # reusing a draft; every other caller — the Run button, the
                # websocket server, a test — is an owner running their own
                # skill, which is how a draft earns its proof. Defaulting to
                # guarded blocked fourteen legitimate paths, and the failure
                # mode was the expensive direction: an owner told their own
                # skill is not a skill. So a missed call site now fails open.
                # Not in agent_contract.json, so the model cannot clear it.
                as_agent=bool(args.get("as_agent")),
            )
        if name == "recall_episodes":
            return self.tool_recall_episodes(args["query"])
        if name == "log_lesson":
            return self.tool_log_lesson(args["lesson"])
        raise ValueError(f"unknown tool: {name}")


def for_owner(result: str) -> str:
    """A tool result rewritten for the person watching rather than the model.

    The sidebar's Run button is a first-class path, not a debug affordance, and
    the strings run_skill returns are written for a model that has to repair
    something: "REJECTED, and the arm has not moved. Rehearsed first, and it
    crashed: COLLISION: openarm_right_link7 hit table. Move to a clear height
    above the obstacle first…". True, useful, and not addressed to a robot
    owner.

    One rule, used by the runtime's server and the browser's transport alike —
    two summaries of the same event would eventually summarise it differently.
    """
    if result.startswith("E-STOP"):
        return "Stopped: the e-stop is latched. Clear it to continue."

    if "COLLISION" in result:
        # "openarm_right_link7 hit table" — the owner cares about the table,
        # not about which link. The agent still gets the full version.
        _, _, hit = result.partition("COLLISION: ")
        _, _, obstacle = hit.partition(" hit ")
        thing, _, _ = obstacle.partition(".")
        return f"It didn't run — it would have hit the {thing or 'workcell'}."

    if failed(result):
        # Whatever went wrong, once — without the prefix, and without the
        # sentence of coaching that is aimed at the model.
        said = result.replace("REJECTED, and the arm has not moved. ", "It didn't run — ")
        for prefix in FAILURE_PREFIXES:
            said = said.removeprefix(f"{prefix}: ")
        said = said.replace("Rehearsed first, and it crashed: ", "")
        said, _, _ = said.partition(". ")
        said = said[:1].upper() + said[1:]
        return said if said.endswith(".") else f"{said}."

    # "Rehearsed clean, then X ran (5 primitive calls). The arm swept … Moved: …"
    # — the count is bookkeeping the owner did not ask for.
    _, _, said = result.partition("). ")
    if said.startswith("NOTHING MOVED"):
        return "It ran, but nothing moved — not the arm, not anything on the table."
    if said.endswith("No object on the table moved."):
        # An arm-only task: say the arm moved, and that the table is untouched.
        arm = said[: -len(" No object on the table moved.")]
        return f"It ran: {arm[:1].lower() + arm[1:]}. Nothing on the table moved."
    return said or result
