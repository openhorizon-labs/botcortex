"""BotCortex CLI — `botcortex "task"` (alias `bx`).

Dry-run is the default; real motion requires --execute AND an operator present.
The hardware path lands at milestone 3 — v0 is mock-first by design.
"""

import argparse
import os
import socket
import sys
from pathlib import Path

from botcortex import __version__, config, routines
from botcortex.robot import EStopTriggered, MockRobot


def _robot_identity(name: str | None = None) -> tuple[str, str, int]:
    """What this robot calls itself on the approval screen and in the app.

    The hostname is only a default. Two arms plugged into one machine would
    otherwise pair under the same name and collide on the account's
    (owner, name) index — the second registration silently updating the
    first's row instead of creating its own. --name, or BOTCORTEX_ROBOT_NAME
    in .env for something that survives reboots, settles it.
    """
    chosen = (name or os.environ.get("BOTCORTEX_ROBOT_NAME") or "").strip()
    if not chosen:
        chosen = socket.gethostname().split(".")[0].lower() or "robot"
    return chosen, config.PLATFORM.name, len(config.ARMS)


def _login(port: int, key: str | None = None, name: str | None = None) -> None:
    """Pair this robot with a BotCortex account (RFC 8628 device flow).

    The human never types a secret and the robot never handles a password:
    they approve a short code in a browser where their session already lives,
    and the durable key travels back over TLS.
    """
    from botcortex import cloud

    name, platform, arms = _robot_identity(name)

    # Escape hatch for machines with no browser anywhere near them.
    if key:
        path = cloud.save_key(key)
        print(f"✓ Key saved to {path}")
        return

    try:
        pairing = cloud.start_pairing()
    except (OSError, RuntimeError) as e:
        sys.exit(f"Could not reach BotCortex at {config.API_URL}: {e}")

    cloud.describe(pairing["device_code"], name, platform, arms)

    print()
    print(f"  Open  {pairing['verification_uri']}")
    print(f"  Code  {pairing['user_code']}")
    print()
    print(f'  Approving as "{name}" ({platform}, {arms} arms)')
    print("  Waiting for approval…", flush=True)

    try:
        token = cloud.poll_for_approval(
            pairing["device_code"], pairing["interval"], pairing["expires_in"]
        )
        minted = cloud.exchange_for_key(token, name)
    except (OSError, RuntimeError) as e:
        sys.exit(f"\n✗ {e}")
    except KeyboardInterrupt:
        sys.exit("\n  Cancelled.")

    address = cloud.lan_address(port)
    cloud.register(minted["key"], pairing["device_code"], name, platform, arms, address)
    path = cloud.save_key(minted["key"])

    # Read back through the key itself — proves it works before we claim it does.
    config.API_KEY = minted["key"]
    who = cloud.whoami()
    owner = (who or {}).get("user", {}).get("email", "your account")
    credit = (who or {}).get("credit", {}).get("display", "")

    print(f"\n  ✓ Paired with {owner}" + (f" · {credit} credit" if credit else ""))
    print(f"    Key saved to {path}")
    print(f"    Reachable at {address} — it will appear in the app's robot list.")


def _forget(name: str | None) -> None:
    """Delete a skill from this robot and from the account registry, saying
    plainly what happened to each copy — a human asked, so neither half may
    fail silent the way best-effort sync is allowed to."""
    if not name:
        sys.exit("Which skill? Usage: botcortex forget <name>")

    from botcortex import cloud
    from botcortex.skills import SkillStore

    store = SkillStore(config.SKILLS_DIR)
    known = store.names()
    if store.delete(name):
        print(f"✓ Deleted {name} from this robot")
    else:
        listed = f" Known: {', '.join(known)}." if known else " No skills saved yet."
        print(f"  No local skill named {name!r}.{listed}")

    if not cloud.paired():
        return  # BYO robots have no registry copy to chase.
    print(
        {
            "deleted": "✓ Removed the account registry copy",
            "absent": "  The account registry had no copy",
            "refused": "  ! BotCortex rejected this robot's key — run `botcortex login`, "
            "then `botcortex forget` again to clear the registry copy.",
            "unreachable": "  ! Could not reach BotCortex — the registry copy, if any, "
            "is still there. Re-run this when the robot is back online.",
        }[cloud.forget(name)]
    )


def _camera(args) -> None:
    """`botcortex camera list | use | show | calibrate | check` — everything a
    camera needs, from the terminal, for whichever body BOTCORTEX_PLATFORM names."""
    from botcortex import camera as cameras
    from botcortex import config

    path = cameras.settings_path(config.DATA_DIR, config.PLATFORM.name)
    action = args.extra or "help"
    try:
        if action == "list":
            found = cameras.list_cameras()
            for c in found:
                if c["kind"] == "opencv":
                    print(
                        f"  webcam {c['source']}  {c['size'][1]}x{c['size'][0]}   ->  botcortex camera use webcam {c['source']}"
                    )
                else:
                    print(f"  {c['name']} (depth)   ->  botcortex camera use realsense")
            if not found:
                print(
                    "  no camera found. Plug one in, or name a stream: botcortex camera use http://…"
                )
        elif action == "use":
            kind = args.more[0] if args.more else ""
            if kind == "realsense":
                chosen = {"kind": "realsense"}
            elif kind == "webcam" or kind.startswith(("http", "rtsp")):
                source = (args.more[1] if len(args.more) > 1 else "0") if kind == "webcam" else kind
                chosen = {"kind": "opencv", "source": int(source) if source.isdigit() else source}
            else:
                sys.exit("usage: botcortex camera use webcam [index] | realsense | <stream url>")
            cameras.open_camera(chosen).close()  # fail now, not at the first task
            # A different camera stands somewhere else: the old calibration goes.
            path.unlink(missing_ok=True)
            cameras.save_settings(path, **chosen)
            print(
                f"  using {chosen}. Next: botcortex camera show, then botcortex camera calibrate --execute"
            )
        elif action == "show":
            eye = cameras.open_camera(cameras.load_settings(path))
            out = config.DATA_DIR / "camera_view.png"
            cameras.write_png(out, eye.frame().rgb)
            eye.close()
            print(f"  wrote {out} — the whole bench and all the blocks should be in it")
        elif action == "calibrate":
            _calibrate_camera(args, path)
        elif action in ("colours", "colors"):
            _teach_colours(args, path)
        elif action == "check":
            from botcortex.real import open_real

            robot, _ = open_real(config.PLATFORM, execute=False, loopback=args.loopback)
            scene = robot.describe_scene()["objects"]
            for name, body in scene.items():
                why = robot.unseen.get(name)
                where = ", ".join(f"{v:.3f}" for v in body["position"])
                print(f"  {name:<14} " + (f"NOT SEEN — {why}" if why else f"at ({where}) m"))
            robot.close()
        else:
            print(
                "botcortex camera list | use <webcam [n] | realsense | url> | show | calibrate --execute | colours | check"
            )
    except (ValueError, ImportError, RuntimeError) as e:
        sys.exit(str(e))


def _dataset(args) -> None:
    """`botcortex dataset summary | generate | repair | render | export` — see docs/DATASETS.md.

    Runs are kept as episodes when BOTCORTEX_RECORD=1; `generate` makes them by
    the hundred from one saved skill, in simulation, for whichever body
    BOTCORTEX_PLATFORM names.
    """
    from botcortex import config, episodes

    root, action = config.EPISODES_DIR, args.extra or "help"

    def simulator():
        from botcortex.sim import SimRobot

        return SimRobot(config.PLATFORM, realtime=False)

    try:
        if action == "summary":
            for key, value in episodes.summary(root).items():
                print(f"  {key:<14} {value}")
            print(
                f"  in {root}"
                + ("" if config.RECORD else "   (recording is OFF: set BOTCORTEX_RECORD=1)")
            )
        elif action == "generate":
            from botcortex import dataset
            from botcortex.skills import SkillStore

            if not args.more:
                sys.exit("usage: botcortex dataset generate <skill> [count] [wobble_degrees]")
            skill = args.more[0]
            count = int(args.more[1]) if len(args.more) > 1 else 50
            wobble = float(args.more[2]) if len(args.more) > 2 else 0.0
            store = SkillStore(config.SKILLS_DIR)
            if skill not in store.names():
                sys.exit(
                    f"no skill called {skill!r}; this robot knows: {', '.join(store.names()) or 'none'}"
                )
            described = next((s["description"] for s in store.list() if s["name"] == skill), skill)
            print(
                f"  {count} runs of {skill} on {config.PLATFORM.display_name}, blocks scattered each time …"
            )
            made = dataset.generate(
                simulator,
                store,
                skill,
                root,
                count,
                instruction=described,
                wobble_deg=wobble,
                say=print,
            )
            print(
                f"  done: {made['ok']} worked, {made['failed']} failed (kept, with why). botcortex dataset summary"
            )
        elif action == "repair":
            from botcortex import dataset
            from botcortex.skills import SkillStore

            if not args.more:
                sys.exit("usage: botcortex dataset repair <skill>")
            made = dataset.replay_failures(
                simulator, SkillStore(config.SKILLS_DIR), root, args.more[0], say=print
            )
            print(
                f"  {made['replayed']} old failures replayed with the skill as it is now; {made['repaired']} repaired and linked"
            )
        elif action == "render":
            from botcortex import dataset

            blind = [
                r
                for r in episodes.index(root)
                if not r.get("images") and r["platform"] == config.PLATFORM.name
            ]
            for record in blind:
                dataset.render(root, record["id"], simulator)
            print(f"  filmed {len(blind)} episodes that were recorded without a camera")
        elif action == "export":
            from botcortex import dataset

            if not args.more:
                sys.exit("usage: botcortex dataset export <dir> [repo_id]")
            repo_id = (
                args.more[1] if len(args.more) > 1 else f"local/botcortex_{config.PLATFORM.name}"
            )
            out = dataset.to_lerobot(
                root, Path(args.more[0]).expanduser(), repo_id, config.PLATFORM.name
            )
            print(
                f"  wrote {out['episodes']} episodes, {out['frames']} frames"
                + ("" if out["filmed"] else " (no images: run `botcortex dataset render` first)")
            )
        else:
            print(
                "botcortex dataset summary | generate <skill> [count] | render | export <dir> [repo_id]"
            )
    except (ValueError, ImportError, RuntimeError) as e:
        sys.exit(str(e))


def _teach_colours(args, path) -> None:
    """Show the camera each object, alone, so it learns what YOUR blocks look
    like under YOUR light. The simulator's red is a number somebody typed."""
    from botcortex import camera as cameras
    from botcortex import ui, vision
    from botcortex.sim import SimRobot

    found = cameras.load_settings(path)
    eye = cameras.open_camera(found)
    names = args.more or sorted(
        SimRobot(config.PLATFORM, realtime=False).describe_scene()["objects"]
    )
    hues = dict(found.get("hues") or {})
    ui.note("One object at a time. Clear the bench of anything else colourful — the arm is fine.")
    try:
        for name in names:
            ui.ask(f"Put ONLY the {name.replace('_', ' ')} in view, then press Enter")
            seen = vision.dominant_hue(eye.frame())
            if seen is None:
                ui.warn(
                    f"nothing colourful in view — {name} skipped",
                    "more light, or move it nearer the middle of the picture",
                )
                continue
            hue, pixels = seen
            clash = [
                o for o, h in hues.items() if o != name and abs((h - hue + 180) % 360 - 180) < 30
            ]
            hues[name] = hue
            ui.ok(f"{name}: hue {hue:.0f}° ({pixels} pixels)")
            if clash:
                ui.warn(
                    f"that is nearly the colour of {', '.join(clash)} — the camera will not tell them apart",
                    "use objects of clearly different colours",
                )
    finally:
        eye.close()
    cameras.save_settings(path, hues=hues)
    ui.ok(f"saved {len(hues)} colours. Check them: botcortex camera check")


def _calibrate_camera(args, path) -> None:
    from botcortex import calibrate, config
    from botcortex import camera as cameras
    from botcortex.real import open_real

    if not args.execute and not args.loopback:
        sys.exit(
            "calibration moves the arm to six spots over the bench. Clear the bench except ONE block,\n"
            "be within reach of the power switch, then: botcortex camera calibrate --execute"
        )
    robot, label = open_real(
        config.PLATFORM, execute=True, device=args.device, loopback=args.loopback, camera=False
    )
    eye = cameras.open_camera(cameras.load_settings(path)) if not args.loopback else None
    if eye is None:
        sys.exit("--loopback has no camera to calibrate: its simulated one is already exact.")
    blocks = robot.describe_scene()["objects"]
    block = args.more[0] if args.more else min(blocks)
    print(f"  {label}. Calibrating on {block}: keep only that block on the bench.")
    found = calibrate.calibrate(robot, eye, block, ask=input)
    cameras.save_settings(path, **found)
    robot.close()
    print(
        f"  saved. The spots agree to {found['residual_m'] * 1000:.1f} mm. Check it: botcortex camera check"
    )


GUIDE = """
  BotCortex — teach your robot new tasks by typing.

  First time
    botcortex setup                     guided: body, software, arm, camera, account
    botcortex doctor                    check everything, with the fix beside each problem

  Every day
    botcortex serve --sim               the robot in simulation, for the app to connect to
    botcortex serve --real              the real arm, DRY RUN (camera on, nothing moves)
    botcortex serve --real --execute    the real arm, live. Be at the bench.
    botcortex skills                    what this robot knows
    botcortex forget <skill>            delete a skill here and from your account

  The arm
    botcortex arm status                which port, and what the arm reports (reads only)
    botcortex arm check --execute       first motion: each joint a little, you confirm the direction
    botcortex arm home --execute        go to the home pose, slowly
    botcortex arm hold | arm limp       servos on | servos OFF (the arm will drop)

  The camera
    botcortex camera list | use <webcam N | realsense | url> | show
    botcortex camera calibrate --execute     the arm points, you slide one block under it
    botcortex camera colours                 teach it what YOUR blocks look like
    botcortex camera check                   where it sees each object, or why it cannot

  Your account and your data
    botcortex login                     pair this robot with your BotCortex account
    botcortex config [set <name> <value> | unset <name>]
    botcortex sync                      deliver runs that are waiting to be uploaded
    botcortex dataset summary | generate | repair | render | export

  Anything else in quotes is a task:   botcortex --mock "wave right arm"
  Stuck? `botcortex doctor` first. It knows most of the ways this goes wrong.
"""


def _doctor(args) -> int:
    from botcortex import doctor, ui

    print()
    print(ui.paint("  BotCortex doctor", "bold") + ui.paint(f"   botcortex {__version__}", "dim"))
    worst = 0
    for title, findings in doctor.examine(
        probe_arm="arm" in args.more or args.extra == "arm", online=not args.offline
    ):
        ui.heading(title)
        for f in findings:
            if f.level == "ok":
                ui.ok(f.text)
            elif f.level == "warn":
                ui.warn(f.text, f.fix)
                worst = max(worst, 1)
            elif f.level == "bad":
                ui.bad(f.text, f.fix)
                worst = 2
            else:
                ui.note(f.text + (f"   → {f.fix}" if f.fix else ""))
    print()
    if worst == 2:
        ui.bad("something above will stop this robot working. Each ✗ says what to run.")
    elif worst == 1:
        ui.warn("it will work. The ! lines are worth a look before a real session.")
    else:
        ui.ok("everything checks out.")
    return 1 if worst == 2 else 0


def _config(args) -> None:
    from botcortex import settings, ui

    action = args.extra or "show"
    try:
        if action == "set" and len(args.more) >= 2:
            settings.put(args.more[0], " ".join(args.more[1:]))
            ui.ok(
                f"{args.more[0]} = {settings.load()[args.more[0]]}   (takes effect the next time botcortex starts)"
            )
        elif action == "unset" and args.more:
            ui.ok(f"{args.more[0]} is back to its default") if settings.drop(
                args.more[0]
            ) else ui.note(f"{args.more[0]} was not set")
        elif action == "show":
            ui.heading(f"Settings   {settings.path()}")
            ui.table(
                [
                    (name, str(settings.get(name, "—")), settings.source(name), what)
                    for name, (_, what) in settings.KNOWN.items()
                ]
            )
            print()
            ui.note("botcortex config set <name> <value>    botcortex config unset <name>")
        else:
            sys.exit("usage: botcortex config | config set <name> <value> | config unset <name>")
    except (KeyError, ValueError) as e:
        sys.exit(str(e.args[0] if e.args else e))


def _sync(args) -> None:
    from botcortex import cloud, ui
    from botcortex.outbox import Outbox

    box = Outbox(config.OUTBOX_DIR)
    waiting = len(box.pending())
    if not waiting:
        ui.ok("nothing is waiting: every recorded run has been delivered.")
    elif not cloud.paired():
        ui.bad(f"{waiting} run events are waiting, and this robot is not paired", "botcortex login")
        sys.exit(1)
    else:
        carrier = cloud.courier()
        tally = carrier.deliver(progress=ui.Progress("delivering", waiting))
        ui.ok(f"{tally['delivered']} delivered") if tally["delivered"] else None
        if tally["refused"]:
            ui.warn(f"{tally['refused']} refused by the API; the reasons are in {box.rejected}")
        if tally["waiting"]:
            ui.bad(
                f"{tally['waiting']} still waiting — {carrier.last_error}",
                "try again when the network is back: botcortex sync",
            )
            sys.exit(1)
    if box.refused():
        ui.note(f"{len(box.refused())} earlier events were refused for good; see {box.rejected}")


def _skills() -> None:
    from botcortex import ui
    from botcortex.skills import SkillStore

    store = SkillStore(config.SKILLS_DIR)
    known = store.list()
    if not known:
        ui.note("this robot knows no skills yet. Teach it one from the app: botcortex serve --sim")
        return
    unproven = set(store.unproven())
    ui.heading(f"{len(known)} skills on this robot")
    ui.table(
        [
            (
                s["name"],
                "never seen to work" if s["name"] in unproven else "proven",
                s.get("description", ""),
            )
            for s in known
        ]
    )


def _arm(args) -> None:
    from botcortex import armtools, ui
    from botcortex.real import open_real
    from botcortex.roarm import LinkError

    action = args.extra or "status"
    if action == "status":
        sys.exit(armtools.status(args.device))
    if action not in ("check", "home", "hold", "limp"):
        sys.exit("usage: botcortex arm status | check --execute | home --execute | hold | limp")
    if action in ("check", "home") and not (args.execute or args.loopback):
        sys.exit(
            f"`arm {action}` MOVES the arm. Clear the bench, be within reach of its power switch, then:\n"
            f"  botcortex arm {action} --execute"
        )
    try:
        robot, label = open_real(
            config.PLATFORM, execute=True, device=args.device, loopback=args.loopback, camera=False
        )
    except (ValueError, ImportError, LinkError) as e:
        sys.exit(str(e))
    print(f"  {label}")
    try:
        if action == "check":
            found = armtools.check(robot)
            print()
            if found:
                ui.warn(
                    f"reversed on this unit and now corrected: {', '.join(found)}. Run `arm check` once more to confirm."
                )
            else:
                ui.ok(
                    "every joint turns the way the simulation expects. Next: botcortex camera calibrate --execute"
                )
        elif action == "home":
            robot.park(robot.platform.arms[0])
            ui.ok("home")
        elif action == "hold":
            robot.link.torque(True)
            ui.ok("servos are holding")
        elif action == "limp":
            if ui.confirm(
                "The arm will DROP. Is it resting on something, or is a hand under it?",
                default=False,
            ):
                robot.link.limp()
                ui.ok("servos released. `botcortex arm hold` turns them back on.")
    except LinkError as e:
        sys.exit(str(e))
    finally:
        robot.close()


def main() -> None:
    """Every way out of here is a sentence, never a traceback: the person
    running this is setting up a robot, not debugging Python."""
    try:
        _main()
    except KeyboardInterrupt:
        sys.exit("\n  Stopped. If the arm was moving, it is holding its last pose.")
    except EStopTriggered as e:
        sys.exit(f"  E-STOP: {e}")
    except ImportError as e:
        sys.exit(
            f"  {e}\n  → botcortex doctor   shows everything that is missing and how to install it"
        )
    except Exception as e:  # noqa: BLE001
        import traceback

        log = config.DATA_DIR / "last-error.log"
        try:
            log.parent.mkdir(parents=True, exist_ok=True)
            log.write_text(traceback.format_exc())
            where = f"\n  The full error is in {log}."
        except OSError:
            where = ""
        sys.exit(
            f"  Something went wrong: {type(e).__name__}: {e}{where}\n  → botcortex doctor   often says why"
        )


def _main() -> None:
    parser = argparse.ArgumentParser(
        prog="botcortex",
        description=GUIDE,
        formatter_class=argparse.RawDescriptionHelpFormatter,
        usage="botcortex <command> [options]   (botcortex help)",
    )
    parser.add_argument(
        "task",
        nargs="?",
        help='what to do, e.g. "wave right arm" — or "login" / "serve" / "forget <skill>"',
    )
    parser.add_argument(
        "extra",
        nargs="?",
        help="argument for the command before it, e.g. the skill name for forget",
    )
    parser.add_argument("more", nargs="*", help="further arguments, e.g. `camera use webcam 1`")
    parser.add_argument("--mock", action="store_true", help="run against the in-memory mock robot")
    parser.add_argument(
        "--execute",
        action="store_true",
        help="allow REAL motion, with `serve --real` and `camera calibrate`. Be at the arm.",
    )
    parser.add_argument(
        "--real", action="store_true", help="serve the physical arm (dry run without --execute)"
    )
    parser.add_argument("--device", help="the arm's serial port, e.g. /dev/cu.usbserial-110")
    parser.add_argument(
        "--no-camera",
        action="store_true",
        help="with --real: serve before the camera is calibrated. The arm then believes the twin about where things are, so keep it to dry runs and arm-only skills.",
    )
    parser.add_argument(
        "--loopback",
        action="store_true",
        help="with --real: a simulated arm and camera behind the real wire protocol — no hardware needed",
    )
    parser.add_argument("--port", type=int, default=9090, help="port for `botcortex serve`")
    parser.add_argument(
        "--sim",
        action="store_true",
        help="serve MuJoCo physics instead of the mock (needs [sim] extra)",
    )
    parser.add_argument("--version", action="store_true", help="print version and exit")
    parser.add_argument(
        "--offline", action="store_true", help="doctor: skip the checks that need the network"
    )
    parser.add_argument(
        "--key",
        help="paste an existing bx_live_ key instead of pairing (headless installs, CI, fleets)",
    )
    parser.add_argument(
        "--name",
        help="what to call this robot in the app (default: hostname, or $BOTCORTEX_ROBOT_NAME)",
    )
    args = parser.parse_args()

    if args.version:
        print(f"botcortex {__version__}")
        return
    if args.execute and not (args.real or args.task in ("camera", "arm")):
        sys.exit(
            "--execute moves a physical arm: use it with `serve --real`, `arm check`, `arm home` "
            "or `camera calibrate`."
        )
    if not args.task or args.task == "help":
        print(GUIDE)
        return

    if args.task == "setup":
        from botcortex import wizard

        sys.exit(wizard.run())
    if args.task == "doctor":
        sys.exit(_doctor(args))
    if args.task == "config":
        _config(args)
        return
    if args.task == "sync":
        _sync(args)
        return
    if args.task == "skills":
        _skills()
        return
    if args.task == "arm":
        _arm(args)
        return

    if args.task == "login":
        _login(port=args.port, key=args.key, name=args.name)
        return

    if args.task == "forget":
        _forget(args.extra)
        return

    if args.task == "camera":
        _camera(args)
        return

    if args.task == "dataset":
        _dataset(args)
        return

    if args.task == "serve":
        from botcortex import cloud, server

        robot, label = None, ""
        if args.real:
            from botcortex import config
            from botcortex.real import open_real

            try:
                robot, label = open_real(
                    config.PLATFORM,
                    execute=args.execute,
                    device=args.device,
                    loopback=args.loopback,
                    camera=not args.no_camera,
                    view=True,
                )
                if args.no_camera:
                    label += " — NO CAMERA: the arm believes the twin about where things are"
            except (ValueError, ImportError, RuntimeError) as e:
                sys.exit(str(e))
        backend = label if robot is not None else "MuJoCo sim" if args.sim else "mock robot"
        # flush: uvicorn logs to stderr while this goes to a block-buffered
        # stdout, so under nohup/systemd the banner sat in the buffer and the
        # NOT PAIRED warning never reached the one place someone would look.
        print(
            f"botcortex serving on http://localhost:{args.port} ({backend}, ws at /ws)",
            flush=True,
        )
        # Say which wallet teaching spends from, every time. The half-paired
        # case is the one that used to be invisible, so it gets a warning and
        # the command that fixes it rather than a quiet status line.
        if cloud.half_paired():
            print(
                "  ! NOT PAIRED — points at BotCortex but has no robot key.\n"
                "    Teaching is refused rather than billed to your own model provider.\n"
                "    Run `botcortex login` to pair it.",
                flush=True,
            )
        elif cloud.paired():
            print("  · paired — teaching spends BotCortex credit", flush=True)
        else:
            print(
                "  · bring-your-own-key — teaching spends your model provider directly",
                flush=True,
            )
        server.serve(port=args.port, sim=args.sim, robot=robot, label=label.split(" ")[0].lower())
        return

    if not args.mock:
        # Anything that is not a command is read as a task, so a typo lands
        # here. Say both things it could have been.
        sys.exit(
            f"  `{args.task}` is not a botcortex command. See them all: botcortex help\n"
            "  To teach a task, start the robot and use the app:  botcortex serve --sim\n"
            '  (The terminal only runs the built-in check:  botcortex --mock "wave right arm")'
        )

    task = args.task.lower()
    if task.startswith("wave"):
        # Deterministic built-in — the zero-API smoke test.
        robot = MockRobot()
        named = next((a for a in robot.platform.arms if a in task), None)
        arm = named or robot.platform.arms[-1 if "right" in robot.platform.arms else 0]
        try:
            steps = routines.wave(robot, arm=arm)
        except EStopTriggered as e:
            sys.exit(f"E-STOP: {e}")
        print(
            f"[mock] waved the {arm if arm == 'arm' else arm + ' arm'}: {steps} interpolation steps at 20 Hz, "
            "velocity-capped, e-stop checked every step. Final pose: home."
        )
        return

    # Anything else goes through the authoring agent (needs Anthropic credentials).
    import anthropic

    from botcortex.agent import TeachSession

    session = TeachSession(MockRobot())
    print(f"[mock] teaching: {args.task!r} (model {config.MODEL})")
    try:
        result = session.teach(args.task)
    except anthropic.AuthenticationError:
        sys.exit(
            "No Anthropic credentials. Set ANTHROPIC_API_KEY (or `ant auth login`) — "
            "BotCortex is BYO-key and never resells inference."
        )
    except anthropic.APIConnectionError as e:
        sys.exit(f"Could not reach the model API: {e}")

    print(result.text or "(no reply)")
    marker = "✓" if result.outcome == "ok" else "✗"
    print(
        f"[{marker}] outcome={result.outcome} skills_used={result.skills_used or '[]'} "
        f"— episode logged to {config.MEMORY_FILE}"
    )
