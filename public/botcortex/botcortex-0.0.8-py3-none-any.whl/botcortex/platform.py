"""Platform descriptors — the robot catalog's unit.

A platform is data, not code: vendor joint limits, joint naming, home pose,
capabilities, the tasks it can bind, and (optionally) a sim model. Adding a
robot means adding a platforms/<name>/ directory. OpenArm v1 is entry one;
the Waveshare RoArm-M2 and two MuJoCo Menagerie arms are the research
embodiments.

That sentence — "adding a robot is a directory" — used to be true only of the
joint limits. `jointmap` fixed seven joints per arm, `kinematics` chose which
four to search, `safety` and `scene` recognised the robot by the `openarm`
name prefix, and every one of those was a place where a second robot needed
code. They now read the fields below. Anything a backend needs to know about
a body's naming, gripper mechanism, or reach solver is in `sim`; anything the
research needs to know about what the body can DO is in `capabilities` and
`tasks`.

The `tasks` block is the supported-task matrix. A task family is bound to a
platform only when the platform says it supports it; "conditional" means
supported for a stated subset (the RoArm can pick a cube it cannot orient
around), and "unsupported" is a first-class answer with a reason, not an
exception raised three primitives later.
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from pathlib import Path

PLATFORMS_DIR = Path(__file__).parent / "platforms"

#: Where models too large to ship in the wheel live — MuJoCo Menagerie arms
#: with their meshes. Filled by scripts/fetch_models.py, pinned to a commit.
MODELS_DIR = Path(os.environ.get("BOTCORTEX_MODELS", Path.home() / ".openhorizon" / "models"))

#: The task families the research binds. A platform's `tasks` block may name
#: any of these; anything it leaves out is "unsupported: not declared".
TASK_FAMILIES = (
    "pick_and_place",
    "transport_around_bystanders",
    "push",
    "insertion",
)

SUPPORT_LEVELS = ("supported", "conditional", "unsupported")


@dataclass(frozen=True)
class TaskBinding:
    """The answer to "can this platform run this task family".

    `support` is one of SUPPORT_LEVELS. `reason` is for a person or an agent —
    why the binding is conditional or refused — and is required whenever the
    answer is not a plain "supported".
    """

    task: str
    platform: str
    support: str
    reason: str = ""

    @property
    def bindable(self) -> bool:
        return self.support != "unsupported"


@dataclass(frozen=True)
class GripperSpec:
    """How the runtime's gripper degrees reach the actuators of one model.

    The runtime speaks one language for every gripper: degrees, with the
    platform's `gripper` joint limit (lo, hi) meaning lo = fully OPEN and
    hi = fully CLOSED. OpenArm's vendor range is -65..0, negative-open, which
    is where the convention came from; every other platform declares its own
    limits in that same orientation.

    kind == "fingers_m": N finger position actuators in metres of travel, 0 m
        closed, `meters_open` open (OpenArm). Needs finger_joint_fmt,
        finger_actuator_fmt, fingers, meters_open.
    kind == "linear": one actuator whose ctrl runs from `ctrl_closed` to
        `ctrl_open` (either order), read back from one joint whose qpos runs
        from `qpos_closed` to `qpos_open`. Covers a Menagerie tendon gripper
        driven 0..255, and a single-jaw hinge driven in radians.
    """

    kind: str
    fingers: int = 2
    meters_open: float = 0.044
    finger_joint_fmt: str = ""
    finger_actuator_fmt: str = ""
    actuator: str = ""
    joint: str = ""
    #: A second, passive joint written alongside `joint` whenever the state
    #: is set directly (reset, rehearsal probes). The ViperX's right finger
    #: is tied to the left by an equality; writing only one side left the
    #: constraint solver pulling both to the midpoint — a gripper jammed
    #: half-open that no command could move. `mirror_sign` is its direction
    #: relative to `joint`. Under physics the equality drives it.
    mirror_joint: str = ""
    mirror_sign: float = -1.0
    ctrl_open: float = 0.0
    ctrl_closed: float = 0.0
    qpos_open: float = 0.0
    qpos_closed: float = 0.0


@dataclass(frozen=True)
class Platform:
    name: str
    display_name: str
    arms: tuple[str, ...]
    joint_limits: dict[str, dict[str, tuple[float, float]]]
    home_position: dict[str, float]
    sim: dict
    directory: Path
    capabilities: dict = field(default_factory=dict)
    tasks: dict[str, dict] = field(default_factory=dict)

    # --- joints ---------------------------------------------------------

    @property
    def joints(self) -> tuple[str, ...]:
        """The positioning joints, in order, gripper excluded. Every arm of a
        platform has the same joint set; the limits may mirror."""
        reference = self.joint_limits[self.arms[0]]
        return tuple(j for j in reference if j != "gripper")

    @property
    def ik_joints(self) -> tuple[str, ...]:
        """The joints the reach solver searches. Declared, because which
        joints place a top-down gripper is a property of the kinematic
        chain, not of the runtime."""
        return tuple(self.sim.get("ik_joints", self.joints))

    @property
    def neutral_joints(self) -> tuple[str, ...]:
        """The joints the solver pins to home instead of searching."""
        declared = self.sim.get("neutral_joints")
        if declared is not None:
            return tuple(declared)
        return tuple(j for j in self.joints if j not in self.ik_joints)

    # --- gripper and hand ------------------------------------------------

    @property
    def gripper(self) -> GripperSpec:
        spec = self.sim.get("gripper")
        if spec is None:
            # OpenArm's original flat keys, kept so its descriptor is untouched.
            return GripperSpec(
                kind="fingers_m",
                fingers=int(self.sim.get("fingers", 2)),
                meters_open=float(self.sim.get("gripper_meters_open", 0.044)),
                finger_joint_fmt=self.sim.get("finger_joint_fmt", ""),
                finger_actuator_fmt=self.sim.get("finger_actuator_fmt", ""),
            )
        return GripperSpec(**spec)

    @property
    def grasp_offset(self) -> tuple[float, float, float]:
        """Where the jaws close, in the hand body's frame."""
        return tuple(float(v) for v in self.sim.get("grasp_offset", (0.0, 0.0, 0.0)))

    @property
    def approach_axis(self) -> int:
        """Which axis of the hand body points along the approach (out of the
        fingers): 0, 1 or 2. Straight down means that axis's world z is -1."""
        return int(self.sim.get("approach_axis", 2))

    @property
    def approach_sign(self) -> float:
        """+1 when the fingers run out along the POSITIVE approach axis, -1
        when along the negative one. The SO-101's Menagerie `gripper` body
        has its jaws along -z and no fixed child frame points the other way,
        so the downwardness the solver scores is flipped for it rather than
        the model re-vendored with a hand frame of our own."""
        return float(self.sim.get("approach_sign", 1.0))

    def downwardness(self, rot) -> float:
        """World z of the direction the fingers point, from the hand body's
        3x3 rotation flattened row-major: -1 is straight down. The sign
        applies here, once, so neither backend carries arithmetic."""
        return self.approach_sign * rot[6 + self.approach_axis]

    def hand_body(self, arm: str) -> str:
        return self.sim["hand_body_fmt"].format(side=arm)

    def finger_bodies(self, arm: str) -> tuple[str, ...]:
        return tuple(fmt.format(side=arm) for fmt in self.sim.get("finger_body_fmt", ()))

    @property
    def browser_capable(self) -> bool:
        """Whether the model ships in the wheel and parses in MuJoCo WASM.
        Menagerie arms live in a mesh cache and stay native-only."""
        return bool(self.sim.get("browser", True))

    # --- files -----------------------------------------------------------

    @property
    def model_dir(self) -> Path:
        """Where the model files are: the platform directory for a vendored
        model, the models cache for a fetched one."""
        cached = self.sim.get("model_dir")
        return MODELS_DIR / cached if cached else self.directory

    @property
    def mjcf_path(self) -> Path | None:
        """The BARE arm. Vendored or fetched, and regenerated wholesale on
        every upstream update — so nothing may be added to it by hand."""
        if not self.sim.get("mjcf"):
            return None
        return self.model_dir / self.sim["mjcf"]

    @property
    def scene_path(self) -> Path | None:
        """The arm plus the things it manipulates — a table, trays, blocks.

        Its own file, which `<include>`s the model, precisely because
        re-vendoring overwrites that file and would erase a workcell built
        inside it. For a fetched model the scene template lives in the
        platform directory and is materialised beside the model on demand,
        because MuJoCo resolves includes and mesh directories relative to the
        top-level file it was asked to load.
        """
        if not self.sim.get("scene"):
            return None
        if not self.sim.get("model_dir"):
            return self.directory / self.sim["scene"]
        return self._materialised_scene()

    def _materialised_scene(self) -> Path:
        template = self.directory / self.sim["scene"]
        target = self.model_dir / f"botcortex_{template.name}"
        if self.model_dir.exists():
            text = template.read_text()
            if not target.exists() or target.read_text() != text:
                target.write_text(text)
        return target

    @property
    def world_path(self) -> Path | None:
        """What a sim should actually load: the workcell if there is one, the
        bare arm otherwise. A platform with no scene yet still runs."""
        return self.scene_path or self.mjcf_path

    @property
    def model_available(self) -> bool:
        path = self.mjcf_path
        return path is not None and path.exists()

    # --- the supported-task matrix -------------------------------------

    def binding(self, task: str) -> TaskBinding:
        """Whether this platform can run `task`, and why not if not.

        Undeclared families are unsupported. A declared family must carry a
        reason unless it is plainly supported — the reason is what an agent
        or a person reads before deciding what to do instead.
        """
        entry = self.tasks.get(task)
        if entry is None:
            known = task in TASK_FAMILIES
            return TaskBinding(
                task,
                self.name,
                "unsupported",
                f"{self.display_name} does not declare {task!r}"
                + ("" if known else f" (not a known task family: {TASK_FAMILIES})"),
            )
        support = entry.get("support", "unsupported")
        if support not in SUPPORT_LEVELS:
            raise ValueError(f"{self.name}: task {task!r} has support {support!r}")
        reason = entry.get("reason", "")
        if support != "supported" and not reason:
            raise ValueError(f"{self.name}: task {task!r} is {support} but gives no reason")
        return TaskBinding(task, self.name, support, reason)

    def supported_tasks(self) -> dict[str, TaskBinding]:
        return {task: self.binding(task) for task in TASK_FAMILIES}


def available_platforms() -> list[str]:
    return sorted(p.name for p in PLATFORMS_DIR.iterdir() if (p / "platform.json").exists())


def load_platform(name: str = "openarm_v1") -> Platform:
    directory = PLATFORMS_DIR / name
    spec_path = directory / "platform.json"
    if not spec_path.exists():
        raise ValueError(f"unknown platform {name!r}; available: {available_platforms()}")
    spec = json.loads(spec_path.read_text())

    joint_limits = {
        arm: {joint: (float(lo), float(hi)) for joint, (lo, hi) in limits.items()}
        for arm, limits in spec["joint_limits"].items()
    }
    for arm, limits in joint_limits.items():
        if "gripper" not in limits:
            raise ValueError(f"{name}: arm {arm!r} declares no gripper limit")
    reference_arm = spec["arms"][0]
    home = {joint: 0.0 for joint in joint_limits[reference_arm]}
    home.update({j: float(v) for j, v in spec.get("home_overrides", {}).items()})

    return Platform(
        name=spec["name"],
        display_name=spec["display_name"],
        arms=tuple(spec["arms"]),
        joint_limits=joint_limits,
        home_position=home,
        sim=spec.get("sim", {}),
        directory=directory,
        capabilities=spec.get("capabilities", {}),
        tasks=spec.get("tasks", {}),
    )
