"""What is on the table, as the agent and its skills are told it.

One definition, called by every MuJoCo backend. Writing it twice was caught
immediately by `test_it_contains_no_arithmetic` — the half-extent-to-full-size
conversion is arithmetic, and arithmetic living in two backends is how they
start disagreeing. The same lesson `plan_move` and `JointMap` already carry.

PRIVILEGED perception, deliberately. The blueprint's position is that the LLM
is the authoring brain and not the perception system, so the agent is handed
geometry rather than made to infer it from pixels. On hardware the same call is
answered by a camera and a pose estimator; the SHAPE below is the contract, so
a skill written against it keeps working when the answer stops coming from a
simulator.
"""

from __future__ import annotations

from botcortex.mjcompat import enum_value, row

#: Bodies that are part of the robot rather than its work.
_ROBOT_PARTS = ("openarm", "world")


def describe(mujoco, model, data) -> dict[str, dict]:
    """Manipulable objects and immovable fixtures, keyed by name.

    Objects are bodies with a free joint — the things that can be picked up.
    Fixtures are everything else in the world: the table, the trays. Keeping
    them apart matters, because an agent told the table is an "object" will
    eventually try to pick it up.

    `mujoco` is the module (native) or the WASM module (browser). Both expose
    the same names, which is the whole reason this can be shared.
    """
    objects: dict[str, dict] = {}
    fixtures: dict[str, dict] = {}

    movable_bodies = {
        int(model.jnt_bodyid[j])
        for j in range(model.njnt)
        if int(model.jnt_type[j]) == enum_value(mujoco.mjtJoint.mjJNT_FREE)
    }

    for body in range(model.nbody):
        name = mujoco.mj_id2name(model, enum_value(mujoco.mjtObj.mjOBJ_BODY), body)
        if not name or any(part in name for part in _ROBOT_PARTS):
            continue
        entry = {
            "position": [round(v, 4) for v in row(data.xpos, body, 3)],
            # Blocks tumble. Without orientation the viewer draws every one
            # axis-aligned, so a block knocked on its corner still looks
            # perfectly square — the one visual cue that something went wrong.
            "orientation": [round(v, 4) for v in row(data.xquat, body, 4)],
            "size_m": _size_of(model, body),
            "colour": _colour_of(model, body),
        }
        (objects if body in movable_bodies else fixtures)[name] = entry

    return {"objects": objects, "fixtures": fixtures}


def _size_of(model, body: int) -> list[float]:
    """Full extents of a body's first geom, in metres.

    MuJoCo stores HALF-extents; an agent asked to grasp a "0.02 m" block when
    it is really 40 mm across would plan a grip narrower than the object.
    """
    for geom in range(model.ngeom):
        if int(model.geom_bodyid[geom]) == body:
            return [round(v * 2, 4) for v in row(model.geom_size, geom, 3)]
    return [0.0, 0.0, 0.0]


def _colour_of(model, body: int) -> list[float]:
    """The body's first geom rgba, so the viewer draws a red block red.

    Taken from the model rather than named in the client: the scene already
    says what colour a thing is, and a second list of names-to-colours in
    TypeScript would be one more thing to keep in step.
    """
    for geom in range(model.ngeom):
        if int(model.geom_bodyid[geom]) == body:
            material = int(model.geom_matid[geom])
            source = (
                row(model.mat_rgba, material, 4)
                if material >= 0
                else row(model.geom_rgba, geom, 4)
            )
            return [round(v, 3) for v in source]
    return [0.6, 0.6, 0.6, 1.0]
