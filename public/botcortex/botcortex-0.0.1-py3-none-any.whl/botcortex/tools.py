"""@beta_tool wrappers — the authoring agent's entire reach into the runtime.

The agent sees: primitives (bounded motion), the skill store, and episodic
memory. Nothing else. Tool bodies live on TeachSession (plain methods, unit
testable); this module only adapts them to the Claude tool-runner.

Motion here is TEACH-path motion: it runs on whatever robot the session holds
(mock in v0, dry-run twin on hardware). Deterministic replay of a saved skill —
the run path — never involves these tools.
"""

import json
from uuid import uuid4

from anthropic import beta_tool

from botcortex import session as session_mod

#: Results can be long — a joint dump, a whole skill listing. The wire carries
#: a preview for the operator to read; the robot keeps the real thing.
MAX_RESULT_CHARS = 500


def _traced(session, name: str, inputs: dict, run):
    """Run a tool, announcing what it is doing on the way in and out.

    Wrapped HERE, inside the closure, rather than around the BetaFunctionTool
    objects: those expose a writable `.func`, but `.call` — which the Anthropic
    tool runner uses — captures the original at decoration time and ignores it.
    Patching `.func` would have traced the OpenAI path and silently missed the
    other one.

    Inputs go out in full. `save_skill`'s code is the whole point of watching:
    seeing the program the agent wrote is what makes this legible.
    """
    call_id = uuid4().hex[:8]
    session.emit({"type": "tool", "id": call_id, "name": name, "input": inputs})
    try:
        result = run()
    except Exception as e:  # reported to the operator, then re-raised untouched
        session.emit(
            {
                "type": "tool_result",
                "id": call_id,
                "ok": False,
                "result": f"{type(e).__name__}: {e}",
            }
        )
        raise
    text = str(result)
    session.emit(
        {
            "type": "tool_result",
            "id": call_id,
            # The tool bodies report failure in the return value, not by
            # raising — session.failed owns that convention, and the contract
            # carries it so the browser classifies identically.
            "ok": not session_mod.failed(text),
            "result": text[:MAX_RESULT_CHARS],
        }
    )
    return result


def build_tools(session):
    """Return the tool list for one teach conversation, closed over `session`."""

    @beta_tool
    def get_positions(arm: str) -> str:
        """Read the robot's current joint positions in degrees.

        Args:
            arm: Which arm to read, "left" or "right".
        """
        return _traced(
            session,
            "get_positions",
            {"arm": arm},
            lambda: json.dumps(session.tool_get_positions(arm)),
        )

    @beta_tool
    def move_to(arm: str, targets_json: str, duration: float | None = None) -> str:
        """Move one arm's joints to target angles (degrees). The runtime clamps
        targets inside vendor limits, interpolates at 20 Hz with a velocity cap,
        and aborts between steps if the e-stop fires. Prefer saving a skill and
        running it over long chains of raw moves.

        Args:
            arm: "left" or "right".
            targets_json: JSON object of joint name to degrees, e.g. '{"j4": 60.0}'.
                Joints are j1..j7 and "gripper".
            duration: Optional seconds for the move; extended if the velocity cap needs more.
        """
        targets = json.loads(targets_json)
        return _traced(
            session,
            "move_to",
            {"arm": arm, "targets": targets, "duration": duration},
            lambda: session.tool_move_to(arm, targets, duration),
        )

    @beta_tool
    def report(done: bool, summary: str) -> str:
        """Say whether the task is actually finished. Call this LAST, always.

        Judge it on what moved and where it ended up — run_skill tells you, in
        centimetres and by name. Not on whether your calls returned without
        error: a skill that runs perfectly and moves nothing has still failed.

        done=False is a good answer when it is the true one. An honest "I could
        not do this, and here is what went wrong" is worth far more than a
        claim that does not hold, and the runtime will not overrule it.

        Args:
            done: True only if the evidence shows the task achieved.
            summary: One or two plain sentences for the robot's owner.
        """
        return _traced(
            session,
            "report",
            {"done": done, "summary": summary},
            lambda: session.tool_report(done, summary),
        )

    @beta_tool
    def can_reach(arm: str, point_json: str) -> str:
        """Ask whether an arm can put its gripper on a point, WITHOUT moving.

        Free, instant, and it changes nothing. Use it on every waypoint you
        intend to use before you save a skill: a point out of reach is far
        cheaper to discover here than inside a run.

        It answers REACHABILITY only — whether the arm can put its gripper
        there at all. It does not promise the way there is clear; a move
        between two reachable points can still sweep through the table, and the
        rehearsal is what catches that. Two different questions, both worth
        asking.

        When the answer is no it says what would work instead: the other arm,
        or a lower approach.

        Args:
            arm: "left" or "right".
            point_json: JSON array [x, y, z] in metres, e.g. '[0.32, -0.05, 0.34]'.
        """
        return _traced(
            session,
            "can_reach",
            {"arm": arm, "point": json.loads(point_json)},
            lambda: session.tool_can_reach(arm, json.loads(point_json)),
        )

    @beta_tool
    def move_to_point(arm: str, point_json: str) -> str:
        """Put the gripper on a point in space, in the SAME metres describe_scene
        reports, with the jaws pointing down. Solved and clamped by the runtime.

        This is how you reach an object. describe_scene answers in metres and
        move_to takes degrees; nothing you can compute in a skill bridges the
        two, so guessing joint angles for a grasp does not work — it runs
        cleanly and moves nothing.

        Approach from ABOVE: go to a point ~12 cm over the target first, then
        down onto it. A move between two safe points is interpolated in JOINT
        space and can still sweep the arm through whatever lies between them.

        Refused, not approximated, when the point is out of reach.

        Args:
            arm: "left" or "right".
            point_json: JSON array [x, y, z] in metres, e.g. '[0.22, -0.16, 0.34]'.
        """
        point = json.loads(point_json)
        return _traced(
            session,
            "move_to_point",
            {"arm": arm, "point": point},
            lambda: session.tool_move_to_point(arm, point),
        )

    @beta_tool
    def gripper(arm: str, position: float) -> str:
        """Set a gripper position in degrees (0 = closed/rest, -65 = fully open).

        Args:
            arm: "left" or "right".
            position: Target angle in degrees within [-65, 0].
        """
        return _traced(
            session,
            "gripper",
            {"arm": arm, "position": position},
            lambda: session.tool_gripper(arm, position),
        )

    @beta_tool
    def describe_scene() -> str:
        """Look at the workspace: every object you can pick up, plus the fixtures
        around them, with positions in metres and full sizes.

        Call this FIRST for any task that mentions an object, a colour, a tray or
        a place. Positions move between attempts — a skill that hardcodes them
        works exactly once, so read the scene inside the skill rather than baking
        the numbers into it.
        """
        return _traced(session, "describe_scene", {}, session.tool_describe_scene)

    @beta_tool
    def list_skills() -> str:
        """List the skills this robot already knows (name, description, params).
        Always check here before writing new code — reusing a skill costs nothing."""
        return _traced(
            session, "list_skills", {}, lambda: json.dumps(session.store.list())
        )

    @beta_tool
    def save_skill(name: str, code: str) -> str:
        """Save a new skill as a Python file the runtime executes deterministically.

        The file must define META = {"name": <name>, "description": str,
        "params": {<param>: <default>}} and run(ctx, **params). Inside run, the
        robot is reachable ONLY through ctx: ctx.move_to(arm, targets, duration),
        ctx.gripper(arm, position), ctx.get_positions(arm), ctx.set_torque,
        ctx.replay_trajectory. No imports (math is available as `math`), no
        filesystem, no network.

        Args:
            name: snake_case skill name, e.g. "wave_right_arm".
            code: The complete Python source of the skill file.
        """
        return _traced(
            session,
            "save_skill",
            {"name": name, "code": code},
            lambda: session.tool_save_skill(name, code),
        )

    @beta_tool
    def run_skill(name: str, params_json: str = "{}") -> str:
        """Execute a saved skill on the robot and report the outcome. This is the
        same deterministic path the Run button uses — test your skill with it.

        Args:
            name: The skill to run.
            params_json: JSON object of parameter overrides, e.g. '{"repeats": 2}'.
        """
        params = json.loads(params_json)
        return _traced(
            session,
            "run_skill",
            {"name": name, "params": params},
            lambda: session.tool_run_skill(name, params),
        )

    @beta_tool
    def recall_episodes(query: str) -> str:
        """Search episodic memory for past attempts relevant to a task — failures
        carry lessons about what to do differently. Check before authoring.

        Args:
            query: Free-text description of the task, e.g. "fold towel both arms".
        """
        return _traced(
            session,
            "recall_episodes",
            {"query": query},
            lambda: json.dumps(session.memory.recall(query)),
        )

    @beta_tool
    def log_lesson(lesson: str) -> str:
        """Record what this attempt taught you, so the next authoring run recalls
        it. Call after failures especially — one concrete sentence.

        Args:
            lesson: The lesson, e.g. "j4 near 135 collides with the table; keep under 100".
        """
        return _traced(
            session,
            "log_lesson",
            {"lesson": lesson},
            lambda: session.tool_log_lesson(lesson),
        )

    # This list IS the registry — defining a @beta_tool above and forgetting it
    # here leaves a tool the agent can never call, and the contract test cannot
    # see the omission because it compares the contract against THIS list.
    # test_every_defined_tool_is_offered closes that.
    return [
        get_positions,
        move_to,
        can_reach,
        move_to_point,
        report,
        gripper,
        describe_scene,
        list_skills,
        save_skill,
        run_skill,
        recall_episodes,
        log_lesson,
    ]
