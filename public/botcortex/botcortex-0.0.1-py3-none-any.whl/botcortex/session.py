"""One robot and the artifacts it owns — everything a tool call actually does.

Deliberately free of any model SDK. `agent.py` imports `anthropic` and `openai`
at module scope, which is right on a robot and impossible in a browser: those
SDKs are built on sockets Pyodide does not have. The browser still needs these
tool bodies, though, because they ARE the agent's reach into the robot — the
same clamped primitives, the same restricted skill executor, the same episodic
memory. Reimplementing them in TypeScript would mean the browser agent could do
subtly different things to a robot than the runtime's agent can.

So the SDK-free half lives here and `agent.TeachSession` extends it. What the
loop calls is shared; only how it talks to a vendor differs.

The one runtime-only concern is pushing a saved skill to the account registry,
which needs network access this file should not assume. It is a hook.
"""

from __future__ import annotations

import json

from botcortex import config
from botcortex.memory import EpisodeMemory
from botcortex.robot import EStopTriggered
from botcortex.skills import SkillContext, SkillError, SkillStore


class RobotSession:
    """One robot + its owned artifacts, shared by CLI, server, browser, tests.

    emit(), when set, receives protocol events (dicts) from any thread the
    teach loop happens to run on.
    """

    def __init__(
        self,
        robot,
        store: SkillStore | None = None,
        memory: EpisodeMemory | None = None,
    ):
        self.robot = robot
        self.store = store or SkillStore(config.SKILLS_DIR)
        self.memory = memory or EpisodeMemory(config.MEMORY_FILE)
        self.emit = lambda event: None
        self.skills_used: list[str] = []
        #: True while a teach or skill run owns the robot. The server checks it
        #: before honouring a reset, so a second tab can never teleport the arm
        #: out from under a running skill.
        self.busy = False

    # --- tool bodies (plain methods so tests hit them without the SDK) ---

    def tool_get_positions(self, arm: str) -> dict[str, float]:
        return self.robot.get_positions(arm)

    def tool_move_to(self, arm: str, targets: dict[str, float], duration: float | None) -> str:
        self.robot.move_to(arm, targets, duration)
        return f"moved; now at {json.dumps(self.robot.get_positions(arm))}"

    def tool_gripper(self, arm: str, position: float) -> str:
        self.robot.gripper(arm, position)
        return f"gripper at {self.robot.get_positions(arm)['gripper']:.1f}"

    def tool_list_skills(self) -> str:
        return json.dumps(self.store.list())

    def tool_save_skill(self, name: str, code: str) -> str:
        try:
            meta = self.store.save(name, code)
        except SkillError as e:
            return f"REJECTED: {e}"
        self.emit({"type": "skills", "skills": self.store.names()})
        self.on_skill_saved(name, meta, code)
        return f"saved {name}: {meta['description']}"

    def on_skill_saved(self, name: str, meta: dict, code: str) -> None:
        """Somewhere to send a copy of the skill. Nothing by default.

        The runtime overrides this to push to the account registry. It is a
        hook rather than a call because reaching the network is exactly what
        this module must not assume — and because a failure to sync must never
        change what the agent sees: the skill is already on disk and runnable.
        """

    def tool_run_skill(self, name: str, params: dict) -> str:
        self.skills_used.append(name)
        steps: list[str] = []

        def on_step(label: str) -> None:
            steps.append(label)
            self.emit({"type": "step", "id": str(len(steps)), "state": "ok"})

        ctx = SkillContext(self.robot, on_step=on_step)
        try:
            self.store.run(name, ctx, **params)
        except EStopTriggered as e:
            return f"E-STOP mid-skill: {e}"
        except SkillError as e:
            return f"ERROR: {e}"
        except Exception as e:  # noqa: BLE001 — agent-authored code can raise anything
            return f"ERROR while running {name}: {type(e).__name__}: {e}"
        return f"{name} finished: {len(steps)} primitive calls, all clamped and e-stop-checked"

    def tool_recall_episodes(self, query: str) -> str:
        return json.dumps(self.memory.recall(query))

    def tool_log_lesson(self, lesson: str) -> str:
        self.memory.log(task="(lesson)", skills_used=[], outcome="fail", lesson=lesson)
        return "lesson recorded"

    # --- the seam the browser calls through ---

    def call_tool(self, name: str, args: dict) -> str:
        """Dispatch one tool by name, as the model asked for it.

        The runtime routes through tools.py's @beta_tool wrappers, which the
        vendor SDKs generate schemas from. The browser has no SDK, so it needs
        a plain entry point — but it must be the SAME bodies underneath, or the
        two agents diverge in what they can actually do.

        Argument shapes match agent_contract.json, which is exported from those
        same wrappers: JSON-encoded strings for the nested arguments, because
        that is what the schemas declare.
        """
        if name == "get_positions":
            return json.dumps(self.tool_get_positions(args["arm"]))
        if name == "move_to":
            return self.tool_move_to(
                args["arm"],
                json.loads(args.get("targets_json") or "{}"),
                args.get("duration"),
            )
        if name == "gripper":
            return self.tool_gripper(args["arm"], float(args["position"]))
        if name == "list_skills":
            return self.tool_list_skills()
        if name == "save_skill":
            return self.tool_save_skill(args["name"], args["code"])
        if name == "run_skill":
            return self.tool_run_skill(args["name"], json.loads(args.get("params_json") or "{}"))
        if name == "recall_episodes":
            return self.tool_recall_episodes(args["query"])
        if name == "log_lesson":
            return self.tool_log_lesson(args["lesson"])
        raise ValueError(f"unknown tool: {name}")
