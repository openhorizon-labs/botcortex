"""One robot and the artifacts it owns — everything a tool call actually does.

Deliberately free of any model SDK. `agent.py` imports `anthropic` and `openai`
at module scope, which is right on a robot and impossible in a browser: those
SDKs are built on sockets Pyodide does not have. The browser still needs these
tool bodies, though, because they ARE the agent's reach into the robot — the
same clamped primitives, the same restricted skill executor, the same episodic
memory. Reimplementing them in TypeScript would mean the browser agent could do
subtly different things to a robot than the runtime's agent can.

So the SDK-free half lives here and `agent.TeachSession` extends it. What the
loop calls is shared; only how it talks to a vendor differs.

The one runtime-only concern is pushing a saved skill to the account registry,
which needs network access this file should not assume. It is a hook.
"""

from __future__ import annotations

import json

from botcortex import config
from botcortex.memory import EpisodeMemory
from botcortex.robot import EStopTriggered
from botcortex.safety import Collision
from botcortex.skills import SkillContext, SkillError, SkillStore

#: How a tool body reports failure: in its RETURN VALUE, not by raising, so the
#: model reads what went wrong and repairs it rather than the loop dying.
#:
#: Exported in agent_contract.json, because the browser's loop has to classify
#: the same strings and had no way to know them — every failed tool call showed
#: a green "Completed" badge there while the runtime marked it an error.
FAILURE_PREFIXES = ("ERROR", "REJECTED", "E-STOP")


def failed(result: str) -> bool:
    """Whether a tool's return value reports a failure."""
    return str(result).startswith(FAILURE_PREFIXES)


class RobotSession:
    """One robot + its owned artifacts, shared by CLI, server, browser, tests.

    emit(), when set, receives protocol events (dicts) from any thread the
    teach loop happens to run on.
    """

    def __init__(
        self,
        robot,
        store: SkillStore | None = None,
        memory: EpisodeMemory | None = None,
    ):
        self.robot = robot
        self.store = store or SkillStore(config.SKILLS_DIR)
        self.memory = memory or EpisodeMemory(config.MEMORY_FILE)
        self.emit = lambda event: None
        self.skills_used: list[str] = []
        #: True while a teach or skill run owns the robot. The server checks it
        #: before honouring a reset, so a second tab can never teleport the arm
        #: out from under a running skill.
        self.busy = False
        self.forget_evidence()

    def forget_evidence(self) -> None:
        """Start a new task with no claims about it. See `unverified()`."""
        #: Skills saved during this task.
        self.authored: list[str] = []
        #: Whether any tool actually drove the arm.
        self.moved = False
        #: (skill, ok, what happened) for the last run_skill, or None.
        self.last_run: tuple[str, bool, str] | None = None
        #: The e-stop refused something during this task. Kept separately from
        #: the rest because a latched stop leaves NO other trace — nothing was
        #: authored, nothing moved, no run was recorded — which is exactly the
        #: shape of "there was nothing to verify".
        self.stopped = False

    # --- tool bodies (plain methods so tests hit them without the SDK) ---

    def tool_get_positions(self, arm: str) -> dict[str, float]:
        return self.robot.get_positions(arm)

    def tool_move_to(self, arm: str, targets: dict[str, float], duration: float | None) -> str:
        return self._drive(
            lambda: self.robot.move_to(arm, targets, duration),
            lambda: f"moved; now at {json.dumps(self.robot.get_positions(arm))}",
        )

    def tool_move_to_point(self, arm: str, point: list[float]) -> str:
        """Put the grasp centre on a point in metres, gripper pointing down.

        The bridge between what describe_scene says and what the arm accepts.
        Without it the agent can see a block perfectly and has no way to act on
        what it sees, so it guesses joint angles — which is how a skill comes to
        run cleanly and move nothing.
        """
        try:
            return self._drive(
                lambda: self.robot.move_to_point(arm, point),
                lambda: f"at {point}; joints now {json.dumps(self.robot.get_positions(arm))}",
            )
        except ValueError as e:
            # Out of reach. Refused rather than approximated — an arm that
            # stopped wherever it could and closed its jaws would report a
            # grasp having grasped nothing.
            return f"REJECTED: {e}"
        except NotImplementedError as e:
            # A backend with no geometry, which says so rather than pretending.
            return f"ERROR: {e}. Use move_to with joint angles on this robot."

    def tool_gripper(self, arm: str, position: float) -> str:
        return self._drive(
            lambda: self.robot.gripper(arm, position),
            lambda: f"gripper at {self.robot.get_positions(arm)['gripper']:.1f}",
        )

    def _drive(self, action, describe) -> str:
        """Rehearse a motion, then make it, and REPORT failure rather than raise.

        Both halves matter. Rehearsing is what keeps the arm out of the table;
        returning the failure instead of raising is this file's standing
        convention (see FAILURE_PREFIXES), and these two tools were quietly
        breaking it. An EStopTriggered escaping a tool body reached the OpenAI
        loop's generic `except Exception` and came back as
        "ERROR: EStopTriggered: …" — which is not a prefix anything recognises,
        so the session never noticed the stop and filed the teach as a success.
        """
        safe, note = self._rehearse(action)
        if not safe:
            return note
        try:
            action()
        except EStopTriggered as e:
            self.stopped = True
            return f"E-STOP: {e}"
        except Collision as e:
            return f"ERROR: {e}"
        self.moved = True
        return describe()

    def tool_describe_scene(self) -> str:
        return json.dumps(self.robot.describe_scene())

    def tool_list_skills(self) -> str:
        return json.dumps(self.store.list())

    def tool_save_skill(self, name: str, code: str) -> str:
        try:
            meta = self.store.save(name, code)
        except SkillError as e:
            return f"REJECTED: {e}"
        self._announce_skills()
        self.on_skill_saved(name, meta, code)
        if name not in self.authored:
            self.authored.append(name)
        return f"saved {name}: {meta['description']}"

    def _announce_skills(self) -> None:
        """The skill list, and which of it has never been seen to work."""
        self.emit(
            {
                "type": "skills",
                "skills": self.store.names(),
                "unproven": self.store.unproven(),
            }
        )

    def on_skill_saved(self, name: str, meta: dict, code: str) -> None:
        """Somewhere to send a copy of the skill. Nothing by default.

        The runtime overrides this to push to the account registry. It is a
        hook rather than a call because reaching the network is exactly what
        this module must not assume — and because a failure to sync must never
        change what the agent sees: the skill is already on disk and runnable.
        """

    def tool_run_skill(self, name: str, params: dict) -> str:
        """Run a skill and report WHAT HAPPENED, not that it ran.

        The old answer was "<name> finished: N primitive calls, all clamped and
        e-stop-checked". Every word of that is true and none of it is evidence:
        it says the calls were MADE, not that anything was achieved. An agent
        reads "finished" as "done", declares success, and stops — which is
        exactly what it did while driving the arm into the table.

        So the result now carries the scene before and after. The agent has to
        look at what moved to decide whether it worked, and when nothing moved
        it is told so plainly.
        """
        self.skills_used.append(name)
        steps: list[str] = []

        def on_step(label: str) -> None:
            steps.append(label)
            self.emit({"type": "step", "id": str(len(steps)), "state": "ok"})

        before = self._object_positions()

        # Rehearsed first, with the plan view left alone: what the owner
        # watches should be the run that happened, not a dry run of it.
        safe, note = self._rehearse(
            lambda: self.store.run(name, SkillContext(self.robot), **params),
            watch=before,
        )
        if not safe:
            return self._ran(name, False, note)

        ctx = SkillContext(self.robot, on_step=on_step)
        try:
            self.store.run(name, ctx, **params)
        except EStopTriggered as e:
            self.stopped = True
            return self._ran(name, False, f"E-STOP mid-skill: {e}")
        except Collision as e:
            # Its own branch, and its own prefix: this is the failure mode the
            # agent used to be blind to, and it is repairable — it says which
            # part hit what, which is what tells a model which way to move.
            #
            # Reaching here after a clean rehearsal would mean the rehearsal is
            # not predictive, which is measured not to happen (see
            # botcortex.safety) — but the check stays, because a backstop that
            # only runs when the world has already gone wrong is the one you
            # cannot afford to have removed.
            return self._ran(name, False, f"ERROR: {e}")
        except SkillError as e:
            return self._ran(name, False, f"ERROR: {e}")
        except Exception as e:  # noqa: BLE001 — agent-authored code can raise anything
            return self._ran(name, False, f"ERROR while running {name}: {type(e).__name__}: {e}")

        self.moved = True
        # It ran to completion. That is what the sidebar's "your robot knows
        # this" is allowed to rest on — not that it was written.
        self.store.mark_ran(name)
        self._announce_skills()
        moved = self._what_moved(before)
        return self._ran(
            name,
            True,
            f"Rehearsed clean, then {name} ran ({len(steps)} primitive calls). "
            + (moved.capitalize() if moved else self._nothing_moved()),
        )

    def _ran(self, name: str, ok: bool, note: str) -> str:
        """Record how a run went, then hand the same words to the model.

        `ok` means the run COMPLETED — no crash, no collision, no refusal. It
        deliberately does not mean the task was achieved: only the model knows
        what was asked for, so the runtime hands it the evidence (what moved,
        or that nothing did) and lets it judge. A runtime that graded the task
        itself would fail every skill whose job is a wave.

        The record is what `unverified()` reads. Writing it here rather than at
        each call site is deliberate: every path out of tool_run_skill goes
        through this, so there is no way to return from a run without the
        session having noticed how it went.
        """
        self.last_run = (name, ok, note)
        return note

    def _rehearse(self, action, watch: dict[str, list[float]] | None = None) -> tuple[bool, str]:
        """Run `action` where it cannot break anything, and say what it did.

        This is the answer to the arm ending up inside the table: not a better
        apology afterwards, but never doing it. The whole motion runs first in
        a copy of the present moment — real physics, real contacts — and only a
        clean rehearsal is allowed to reach the arm. When it is not clean,
        NOTHING has moved and the failure says why.

        (False, why) means refuse. (True, note) means go ahead.

        A backend with no physics cannot rehearse and must not claim to: the
        note says so in as many words, so "rehearsed clean" never quietly means
        "not checked".
        """
        rehearsal = getattr(self.robot, "rehearsal", None)
        if rehearsal is None:
            return True, "Not rehearsed — this robot has no physics to rehearse in."

        try:
            with rehearsal():
                action()
                predicted = self._what_moved(watch) if watch is not None else None
        except EStopTriggered as e:
            self.stopped = True
            return False, f"E-STOP: {e} — nothing was moved."
        except Collision as e:
            return False, (
                f"REJECTED, and the arm has not moved. Rehearsed first, and it "
                f"crashed: {e}"
            )
        except SkillError as e:
            return False, f"REJECTED, and the arm has not moved. The rehearsal failed: {e}"
        except Exception as e:  # noqa: BLE001 — agent-authored code can raise anything
            return False, (
                f"REJECTED, and the arm has not moved. The rehearsal raised "
                f"{type(e).__name__}: {e}"
            )

        if watch is None:
            return True, "Rehearsed clean."
        if predicted is None:
            return True, (
                "Rehearsed clean — it hits nothing, but it also moves nothing. "
                "If the task is supposed to move an object, this skill will not "
                "do it, so fix it before claiming it works."
            )
        return True, f"Rehearsed clean; predicted {predicted.lower()}"

    def _object_positions(self) -> dict[str, list[float]]:
        return {
            name: list(body["position"])
            for name, body in self.robot.describe_scene()["objects"].items()
        }

    def _nothing_moved(self) -> str:
        return (
            "NOTHING MOVED. If the task was supposed to move something, it did not "
            "work — check where the object actually is with describe_scene and try "
            "again rather than reporting success."
        )

    def _what_moved(
        self, before: dict[str, list[float]], threshold: float = 0.01
    ) -> str | None:
        """What changed in the world, in centimetres an agent can reason about.

        None means nothing did — which callers must say out loud, because
        silence about the world is exactly what let "finished" mean "succeeded".
        """
        after = self._object_positions()
        if not after:
            return "no objects in this workcell, so there is nothing to verify"

        moved = []
        for name, end in after.items():
            start = before.get(name)
            if not start:
                continue
            shift = sum((a - b) ** 2 for a, b in zip(end, start, strict=True)) ** 0.5
            if shift > threshold:
                moved.append(f"{name} moved {shift * 100:.0f} cm to {[round(v, 3) for v in end]}")

        return "moved: " + "; ".join(moved) + "." if moved else None

    # --- the gate on saying "done" ---

    def unverified(self) -> dict | None:
        """Why the agent may not call this task finished — or None if it may.

        The complaint this exists for: the agent drove the arm into the table,
        wrote a skill, and said the work was done. Nothing checked. The loop
        accepted whatever the model's last message claimed and logged the whole
        run as a success, which then came back out of `recall_episodes` as a
        worked example — the failure memory was being taught the wrong lesson.

        So a claim of success is now checked against what the session actually
        saw. The rules are deliberately about EVIDENCE, never about the task:
        the runtime does not know what was asked for, so it cannot grade the
        outcome. It can tell whether anything was demonstrated.

        Returns {"agent": <what to tell the model>, "owner": <what to tell the
        person>} — a dict rather than a string because the browser's loop
        crosses a worker boundary and needs it as JSON.
        """
        if self.stopped:
            # First, and final: the e-stop is latched, so nothing can move
            # however many times the model is sent back, and there is no
            # version of this where the task is done. Sending it back anyway
            # would just spend the owner's credit insisting.
            return {
                "agent": (
                    "The e-stop is latched, so nothing moved and nothing can move "
                    "until the owner clears it. Stop here and say that — do not "
                    "report the task done."
                ),
                "owner": "Stopped: the e-stop is latched. Clear it to continue.",
                "final": True,
            }

        if self.last_run and not self.last_run[1]:
            # Checked before the escape below, not after: a run REFUSED in
            # rehearsal leaves nothing authored and nothing moved — which is
            # precisely the shape of "there was nothing to verify", and would
            # otherwise let the one case this gate exists for walk straight
            # through it.
            name, _, why = self.last_run
            return {
                "agent": (
                    f"Do not stop here. The last run of {name} did not succeed:\n{why}\n"
                    "Fix the skill, save it again and run it again. If you have tried "
                    "and cannot make it work, say plainly that it did not work and what "
                    "went wrong — do not report success."
                ),
                "owner": f"That didn't work — {name} failed and the robot hasn't learned it.",
            }

        if not self.authored and not self.moved:
            # A question, not a job. "Where is the red block?" answers itself,
            # and a gate that demanded a skill for it would push back until the
            # budget ran out and then report a failure on a task that worked.
            return None

        if self.authored and self.last_run is None:
            names = ", ".join(self.authored)
            return {
                "agent": (
                    f"Do not stop here. You saved {names} but never ran it, so nothing "
                    "shows it works. Run it and read what actually moved before saying "
                    "anything is done."
                ),
                "owner": "The robot wrote that skill but never tried it, so I can't say it works.",
            }

        if not self.authored and self.last_run is None:
            return {
                "agent": (
                    "Do not stop here. You moved the arm but saved no skill and ran "
                    "none, so the robot cannot repeat any of this. Save what you did as "
                    "a skill and run it to prove it works."
                ),
                "owner": "The robot did that once but didn't learn it, so it can't repeat it.",
            }

        return None

    def tool_recall_episodes(self, query: str) -> str:
        return json.dumps(self.memory.recall(query))

    def tool_log_lesson(self, lesson: str) -> str:
        self.memory.log(task="(lesson)", skills_used=[], outcome="fail", lesson=lesson)
        return "lesson recorded"

    # --- the seam the browser calls through ---

    def call_tool(self, name: str, args: dict) -> str:
        """Dispatch one tool by name, as the model asked for it.

        The runtime routes through tools.py's @beta_tool wrappers, which the
        vendor SDKs generate schemas from. The browser has no SDK, so it needs
        a plain entry point — but it must be the SAME bodies underneath, or the
        two agents diverge in what they can actually do.

        Argument shapes match agent_contract.json, which is exported from those
        same wrappers: JSON-encoded strings for the nested arguments, because
        that is what the schemas declare.
        """
        if name == "get_positions":
            return json.dumps(self.tool_get_positions(args["arm"]))
        if name == "move_to":
            return self.tool_move_to(
                args["arm"],
                json.loads(args.get("targets_json") or "{}"),
                args.get("duration"),
            )
        if name == "move_to_point":
            return self.tool_move_to_point(arm=args["arm"], point=json.loads(args["point_json"]))
        if name == "gripper":
            return self.tool_gripper(args["arm"], float(args["position"]))
        if name == "describe_scene":
            return self.tool_describe_scene()
        if name == "list_skills":
            return self.tool_list_skills()
        if name == "save_skill":
            return self.tool_save_skill(args["name"], args["code"])
        if name == "run_skill":
            return self.tool_run_skill(args["name"], json.loads(args.get("params_json") or "{}"))
        if name == "recall_episodes":
            return self.tool_recall_episodes(args["query"])
        if name == "log_lesson":
            return self.tool_log_lesson(args["lesson"])
        raise ValueError(f"unknown tool: {name}")


def for_owner(result: str) -> str:
    """A tool result rewritten for the person watching rather than the model.

    The sidebar's Run button is a first-class path, not a debug affordance, and
    the strings run_skill returns are written for a model that has to repair
    something: "REJECTED, and the arm has not moved. Rehearsed first, and it
    crashed: COLLISION: openarm_right_link7 hit table. Move to a clear height
    above the obstacle first…". True, useful, and not addressed to a robot
    owner.

    One rule, used by the runtime's server and the browser's transport alike —
    two summaries of the same event would eventually summarise it differently.
    """
    if result.startswith("E-STOP"):
        return "Stopped: the e-stop is latched. Clear it to continue."

    if "COLLISION" in result:
        # "openarm_right_link7 hit table" — the owner cares about the table,
        # not about which link. The agent still gets the full version.
        _, _, hit = result.partition("COLLISION: ")
        _, _, obstacle = hit.partition(" hit ")
        thing, _, _ = obstacle.partition(".")
        return f"It didn't run — it would have hit the {thing or 'workcell'}."

    if failed(result):
        # Whatever went wrong, once — without the prefix, and without the
        # sentence of coaching that is aimed at the model.
        said = result.replace("REJECTED, and the arm has not moved. ", "It didn't run — ")
        for prefix in FAILURE_PREFIXES:
            said = said.removeprefix(f"{prefix}: ")
        said = said.replace("Rehearsed first, and it crashed: ", "")
        said, _, _ = said.partition(". ")
        said = said[:1].upper() + said[1:]
        return said if said.endswith(".") else f"{said}."

    # "Rehearsed clean, then X ran (5 primitive calls). Moved: …" — the count
    # is bookkeeping the owner did not ask for.
    _, _, said = result.partition("). ")
    if said.startswith("NOTHING MOVED"):
        return "It ran, but nothing on the table moved."
    return said or result
