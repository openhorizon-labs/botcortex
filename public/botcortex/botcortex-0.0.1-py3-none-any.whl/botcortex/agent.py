"""The authoring agent — invoked per new task, then out of the way.

This is the ONLY module that talks to an LLM, and it runs strictly in the teach
path. It recalls relevant episodes, hands the model the primitive/skill/memory
tools, and lets the Claude tool-runner drive the loop. Whatever gets saved to
the skill store executes deterministically forever after with zero LLM calls.
"""

import json
from dataclasses import dataclass, field

import anthropic

from botcortex import cloud, config, tools
from botcortex.robot import EStopTriggered
from botcortex.session import RobotSession

MAX_ITERATIONS = 25

#: How many times a model that declares itself finished without evidence gets
#: sent back to work (see RobotSession.unverified). Two, not many: a model told
#: twice what is missing and still unable to show the task working will not
#: manage it on the fifth go, and the honest answer to the owner by then is
#: that it did not work — which is the entire point of the gate.
MAX_FOLLOW_UPS = 2

#: Which models need `reasoning_effort="none"` before they will accept function
#: tools on /v1/chat/completions.
#:
#: There is no rule that covers this. Measured against the live API: the whole
#: gpt-5.6 family REFUSES tools without it, while gpt-5-nano and gpt-5-mini
#: refuse the value itself ("does not support 'none'"). A static list would go
#: stale the day OpenAI ships another family, so the first refusal teaches us
#: and every later call in this process goes straight through.
_NEEDS_EFFORT_NONE: set[str] = set()


def _wants_effort_none(model: str) -> bool:
    return model in _NEEDS_EFFORT_NONE or model.startswith("gpt-5.6")

# Frozen + cache_control: the whole block prompt-caches across teach runs.
# Keep volatile content (task, episodes) in the user message, never here.
SYSTEM_PROMPT = f"""You are BotCortex, the authoring agent for a bimanual OpenArm v1 robot \
(7 joints j1..j7 plus a gripper per arm, angles in degrees).

You write SKILLS — small parametrized Python programs the runtime executes \
deterministically at control rate. You are never in the control loop: you author and \
repair; the runtime executes. A skill saved once runs forever with zero model calls.

Vendor joint limits (degrees, the runtime clamps a 5° safety margin inside them):
{json.dumps(config.JOINT_LIMITS, indent=1)}

Workflow for every task:
0. describe_scene if the task mentions an object, colour, tray or place — you \
cannot grasp what you have not located, and positions change between attempts.
1. recall_episodes for the task — past failures carry lessons; apply them.
2. list_skills — if a saved skill already does the job, run_skill it and stop. \
Reuse costs nothing.
3. Otherwise explore briefly with get_positions/move_to if needed, then save_skill \
and verify it with run_skill.
4. If the run fails, fix the code, save again, re-run. After a failure, log_lesson \
one concrete sentence.

Nothing moves until it has been rehearsed. Every move_to and every run_skill is \
first run through a copy of the physics, and only a clean rehearsal reaches the arm. \
So a result starting with REJECTED means the arm did NOT move and nothing was \
damaged — read what it hit, change the approach, and try again. Costs nothing to \
retry; a rejection is information, not a setback.

Never report success you have not seen. run_skill tells you what actually moved, in \
centimetres, or that nothing did. "It ran" is not "it worked" — a skill that drives \
the arm into the table also runs. If the evidence does not show the task done, say so \
plainly and keep fixing. Saying a broken thing works is the worst outcome available \
to you; an honest "I could not do this, here is what went wrong" is far better.

Skill file contract:
- META = {{"name": <snake_case name>, "description": <one line>, "params": {{<param>: <default>}}}}
- def run(ctx, **params): the robot is reachable ONLY via ctx (move_to, gripper, \
get_positions, describe_scene, set_torque, replay_trajectory). `math` is \
available; imports are not.
- Read positions with ctx.describe_scene() INSIDE run(), never bake coordinates \
into the code: a skill that hardcodes where a block was works exactly once.
- Parametrize what an owner would tweak (arm, repeats, angles) with safe defaults.
- Do NOT move the arms home at the start or end. The runtime does that around \
every skill, so a skill that also does it just moves twice.

Safety rules (hard, not stylistic):
- Motion must be gentle and within limits; the runtime clamps and velocity-caps, \
but author sensible targets anyway.
- Two-arm coordination is sequential in v0 — no concurrency primitives exist.
- Never encode ways around the e-stop, torque disable, or clamping.

Keep replies to the owner short and plain — they are robot owners, not programmers. \
One or two sentences on what the robot learned or did; never paste code at them."""


def _history(runner) -> list:
    """Everything said to a tool_runner so far.

    The SDK offers no reader for it — only `set_messages_params`, which hands
    the params to a callback. So the callback peeks and puts them back
    unchanged. Only used on a runner that has already finished, where
    invalidating its cached tool response costs nothing.
    """
    captured: list = []

    def peek(params):
        captured.extend(params["messages"])
        return params

    runner.set_messages_params(peek)
    return captured


def explain(error: Exception) -> str:
    """A sentence an owner can act on, instead of a vendor stack trace.

    Robot owners are not API consumers. Pasting
    "BadRequestError: Error code: 400 - {'error': {'message': "Function tools
    with reasoning_effort are not supported..." into a chat window tells them
    nothing they can do anything about. The full text still goes to the
    runtime log, which is where someone debugging would look.
    """
    text = str(error)
    name = type(error).__name__

    # Ours, from the credit proxy — already written for a human.
    if "insufficient_credit" in text or "out of BotCortex credits" in text:
        return (
            "Out of BotCortex credit, so it can't learn anything new right now. "
            "Skills it already knows still run."
        )
    if "not available on BotCortex credits" in text:
        return "That model isn't available on BotCortex credits. Pick another one."
    if "Unknown or revoked robot key" in text or name == "AuthenticationError":
        return (
            "The robot's key was rejected. Re-pair it with `botcortex login`, "
            "or check the key in its .env."
        )
    if name in ("APIConnectionError", "APITimeoutError") or "Connection error" in text:
        return "Couldn't reach the model. Check the robot's internet and try again."
    if name == "RateLimitError" or "rate limit" in text.lower():
        return "The model is rate-limited right now. Wait a moment and try again."
    if name == "BadRequestError" or "invalid_request_error" in text:
        return (
            "That model refused the request — it may not support the tools this "
            "agent needs. Try a different model from the picker."
        )
    if "E-STOP" in text:
        return "Stopped: the e-stop is latched. Clear it to continue."
    return "Teaching failed. The robot's log has the details."


@dataclass
class TeachResult:
    text: str
    outcome: str  # "ok" | "fail"
    skills_used: list[str] = field(default_factory=list)
    error: str | None = None


class TeachSession(RobotSession):
    """A RobotSession that can also author — i.e. talk to a model.

    Everything a tool call DOES lives in RobotSession, SDK-free, so the browser
    runs the identical bodies. This subclass adds only the loop and the one
    thing a browser cannot do: push a saved skill to the account registry.
    """

    def on_skill_saved(self, name: str, meta: dict, code: str) -> None:
        # The skill is already on disk and runnable; this is a copy going to
        # the owner's account for the registry. Announced rather than silent,
        # and never allowed to affect the result the agent sees.
        if cloud.enabled():
            synced = cloud.sync_skill(name, meta["description"], code)
            print(f"[cloud] skill {name}: {'synced' if synced else 'sync failed (kept locally)'}")
            self.emit({"type": "sync", "skill": name, "ok": synced})

    # --- the teach loop ---

    def _teach_openai(
        self, prompt: str, tool_objs: list, max_iterations: int, model: str
    ) -> TeachResult:
        """Tool-calling loop for OpenAI models. Schemas are derived from the
        same @beta_tool definitions the Anthropic path uses, so the agent's
        reach into the runtime is identical whichever brain is driving."""
        from openai import OpenAI

        client = OpenAI(**cloud.openai_kwargs())
        by_name = {t.name: t for t in tool_objs}
        schemas = [
            {
                "type": "function",
                "function": {
                    "name": t.name,
                    "description": t.description,
                    "parameters": t.input_schema,
                },
            }
            for t in tool_objs
        ]
        messages: list[dict] = [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": prompt},
        ]

        def create(**extra):
            return client.chat.completions.create(
                model=model, messages=messages, tools=schemas, **extra
            )

        text = ""
        follow_ups = MAX_FOLLOW_UPS
        for _ in range(max_iterations):
            effort = {"reasoning_effort": "none"} if _wants_effort_none(model) else {}
            try:
                response = create(**effort)
            except Exception as e:  # learn the model's requirement, once
                if effort or "reasoning_effort" not in str(e):
                    raise
                _NEEDS_EFFORT_NONE.add(model)
                response = create(reasoning_effort="none")
            message = response.choices[0].message
            if message.content:
                text = message.content

            if not message.tool_calls:
                # The model believes it is finished. Whether it is, is not its
                # call: the owner hears nothing until the session's own record
                # backs the claim up. Hence the deferred emit — "Done, the
                # block is in the tray!" must not reach a chat window one turn
                # before the robot is sent back to try again.
                pushback = self.unverified()
                # "final" means there is no version of this where the task gets
                # done — a latched e-stop, say. Arguing with the model about it
                # only spends the owner's credit.
                if pushback and follow_ups and not pushback.get("final"):
                    follow_ups -= 1
                    messages.append({"role": "assistant", "content": text})
                    messages.append({"role": "user", "content": pushback["agent"]})
                    continue
                break

            if message.content:
                self.emit({"type": "chat", "text": text})
            messages.append(message.model_dump(exclude_none=True))
            for call in message.tool_calls:
                tool = by_name.get(call.function.name)
                if tool is None:
                    result = f"ERROR: no tool named {call.function.name!r}"
                else:
                    try:
                        result = tool.func(**json.loads(call.function.arguments or "{}"))
                    except Exception as e:  # noqa: BLE001 — surface to the model, keep going
                        result = f"ERROR: {type(e).__name__}: {e}"
                messages.append(
                    {"role": "tool", "tool_call_id": call.id, "content": str(result)}
                )
        else:
            text = text or "Stopped after the iteration limit."

        return self._verdict(text)

    def _verdict(self, text: str) -> TeachResult:
        """The last word to the owner, checked against what the robot did.

        Both loops used to hardcode outcome="ok" on their happy path, and that
        value goes straight into memory.log — so the run where the arm ended up
        inside the table was FILED AS A SUCCESS and handed back later by
        recall_episodes as an example worth following. The failure memory was
        being poisoned in the one direction it must never be poisoned in.

        Both loops also route their final message through here, so the owner
        cannot be told "done" by a path that skipped the check.
        """
        outstanding = self.unverified()
        # When the claim is unbacked the model's own words are NOT shown: it
        # has been told twice what was missing and is still saying otherwise,
        # which makes its account the least reliable thing available.
        spoken = (outstanding["owner"] if outstanding else text.strip()) or ""
        if spoken:
            self.emit({"type": "chat", "text": spoken})
        return TeachResult(
            text=spoken,
            outcome="fail" if outstanding else "ok",
            skills_used=self.skills_used,
            error="unverified" if outstanding else None,
        )

    def teach(
        self,
        task: str,
        max_iterations: int = MAX_ITERATIONS,
        model: str | None = None,
    ) -> TeachResult:
        # Pick up a key paired or rotated since this process started, rather
        # than failing with a 401 about a credential the owner already replaced.
        cloud.reload()
        # A robot pointed at BotCortex with no key used to fall through to the
        # vendor SDK's own credentials. Teaching still worked, so nothing
        # looked broken — while every call was billed to the owner's OpenAI
        # account and the credit figure in the app sat perfectly still. Refuse
        # instead: nothing is spent, and the message names the one command
        # that fixes it.
        if cloud.half_paired():
            unpaired = (
                "This robot is set up to use BotCortex credit but has no robot key, so "
                "teaching would quietly charge your own model provider instead. Run "
                "`botcortex login` on the robot to pair it."
            )
            self.emit({"type": "chat", "text": unpaired})
            self.memory.log(task, [], "fail", error="not paired")
            return TeachResult(text=unpaired, outcome="fail", error="not paired")
        # The app can name the brain per task. Whatever is chosen is what gets
        # billed, so it is echoed back rather than silently swapped: an owner
        # who picks an expensive model and is quietly downgraded (or the
        # reverse) has been charged for something they did not choose.
        chosen = (model or config.MODEL).strip() or config.MODEL
        provider = config.provider_for(chosen)
        self.emit({"type": "model", "name": chosen, "provider": provider})
        self.skills_used = []
        self.forget_evidence()
        episodes = self.memory.recall(task)
        episode_note = (
            "Relevant past episodes (apply their lessons):\n" + json.dumps(episodes, indent=1)
            if episodes
            else "No relevant past episodes."
        )

        if provider == "openai":
            prompt = f"{episode_note}\n\nTask: {task}"
            try:
                result = self._teach_openai(
                    prompt, tools.build_tools(self), max_iterations, chosen
                )
            except EStopTriggered as e:
                result = TeachResult(text=f"E-STOP: {e}", outcome="fail", error=str(e))
            self.memory.log(task, self.skills_used, result.outcome, error=result.error)
            return result

        client = anthropic.Anthropic(**cloud.anthropic_kwargs())
        messages: list = [{"role": "user", "content": f"{episode_note}\n\nTask: {task}"}]
        follow_ups = MAX_FOLLOW_UPS
        final = None
        runner = None

        try:
            while True:
                runner = client.beta.messages.tool_runner(
                    model=chosen,
                    max_tokens=16000,
                    system=[
                        {
                            "type": "text",
                            "text": SYSTEM_PROMPT,
                            "cache_control": {"type": "ephemeral"},
                        }
                    ],
                    tools=tools.build_tools(self),
                    messages=messages,
                    max_iterations=max_iterations,
                )
                for message in runner:
                    final = message
                    # A message that also calls tools is the agent narrating
                    # its work, and goes straight through. The one that calls
                    # none is a CLAIM about the outcome, and waits for the
                    # check in _verdict.
                    narrating = any(block.type == "tool_use" for block in message.content)
                    for block in message.content:
                        if narrating and block.type == "text" and block.text.strip():
                            self.emit({"type": "chat", "text": block.text})

                if final is None or final.stop_reason == "refusal":
                    break
                pushback = self.unverified()
                if not (pushback and follow_ups) or pushback.get("final"):
                    break
                follow_ups -= 1
                # A fresh runner, because the SDK's generator has already
                # returned and cannot be restarted — it exits the moment a turn
                # asks for no tools. Seeded with everything that has been said
                # so far, so the model keeps the context of what it already
                # tried instead of starting the task over.
                messages = [
                    *_history(runner),
                    {"role": "assistant", "content": final.content},
                    {"role": "user", "content": pushback["agent"]},
                ]
        except EStopTriggered as e:
            result = TeachResult(text=f"E-STOP: {e}", outcome="fail", error=str(e))
            self.memory.log(task, self.skills_used, "fail", error=str(e))
            return result

        if final is None:
            result = TeachResult(text="The agent produced no response.", outcome="fail")
        elif final.stop_reason == "refusal":
            result = TeachResult(
                text="The model declined this request — rephrase the task.",
                outcome="fail",
                error="refusal",
            )
        else:
            result = self._verdict(
                "".join(b.text for b in final.content if b.type == "text")
            )

        self.memory.log(task, self.skills_used, result.outcome, error=result.error)
        return result
