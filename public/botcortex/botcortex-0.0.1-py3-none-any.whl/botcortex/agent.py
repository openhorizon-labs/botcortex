"""The authoring agent — invoked per new task, then out of the way.

This is the ONLY module that talks to an LLM, and it runs strictly in the teach
path. It recalls relevant episodes, hands the model the primitive/skill/memory
tools, and lets the Claude tool-runner drive the loop. Whatever gets saved to
the skill store executes deterministically forever after with zero LLM calls.
"""

import json
from dataclasses import dataclass, field

import anthropic

from botcortex import cloud, config, tools
from botcortex.robot import EStopTriggered
from botcortex.session import RobotSession

MAX_ITERATIONS = 25

#: Which models need `reasoning_effort="none"` before they will accept function
#: tools on /v1/chat/completions.
#:
#: There is no rule that covers this. Measured against the live API: the whole
#: gpt-5.6 family REFUSES tools without it, while gpt-5-nano and gpt-5-mini
#: refuse the value itself ("does not support 'none'"). A static list would go
#: stale the day OpenAI ships another family, so the first refusal teaches us
#: and every later call in this process goes straight through.
_NEEDS_EFFORT_NONE: set[str] = set()


def _wants_effort_none(model: str) -> bool:
    return model in _NEEDS_EFFORT_NONE or model.startswith("gpt-5.6")

# Frozen + cache_control: the whole block prompt-caches across teach runs.
# Keep volatile content (task, episodes) in the user message, never here.
SYSTEM_PROMPT = f"""You are BotCortex, the authoring agent for a bimanual OpenArm v1 robot \
(7 joints j1..j7 plus a gripper per arm, angles in degrees).

You write SKILLS — small parametrized Python programs the runtime executes \
deterministically at control rate. You are never in the control loop: you author and \
repair; the runtime executes. A skill saved once runs forever with zero model calls.

Vendor joint limits (degrees, the runtime clamps a 5° safety margin inside them):
{json.dumps(config.JOINT_LIMITS, indent=1)}

Workflow for every task:
0. describe_scene if the task mentions an object, colour, tray or place — you \
cannot grasp what you have not located, and positions change between attempts.
1. recall_episodes for the task — past failures carry lessons; apply them.
2. list_skills — if a saved skill already does the job, run_skill it and stop. \
Reuse costs nothing.
3. Otherwise explore briefly with get_positions/move_to if needed, then save_skill \
and verify it with run_skill.
4. If the run fails, fix the code, save again, re-run. After a failure, log_lesson \
one concrete sentence.

Skill file contract:
- META = {{"name": <snake_case name>, "description": <one line>, "params": {{<param>: <default>}}}}
- def run(ctx, **params): the robot is reachable ONLY via ctx (move_to, gripper, \
get_positions, describe_scene, set_torque, replay_trajectory). `math` is \
available; imports are not.
- Read positions with ctx.describe_scene() INSIDE run(), never bake coordinates \
into the code: a skill that hardcodes where a block was works exactly once.
- Parametrize what an owner would tweak (arm, repeats, angles) with safe defaults.
- Do NOT move the arms home at the start or end. The runtime does that around \
every skill, so a skill that also does it just moves twice.

Safety rules (hard, not stylistic):
- Motion must be gentle and within limits; the runtime clamps and velocity-caps, \
but author sensible targets anyway.
- Two-arm coordination is sequential in v0 — no concurrency primitives exist.
- Never encode ways around the e-stop, torque disable, or clamping.

Keep replies to the owner short and plain — they are robot owners, not programmers. \
One or two sentences on what the robot learned or did; never paste code at them."""


def explain(error: Exception) -> str:
    """A sentence an owner can act on, instead of a vendor stack trace.

    Robot owners are not API consumers. Pasting
    "BadRequestError: Error code: 400 - {'error': {'message': "Function tools
    with reasoning_effort are not supported..." into a chat window tells them
    nothing they can do anything about. The full text still goes to the
    runtime log, which is where someone debugging would look.
    """
    text = str(error)
    name = type(error).__name__

    # Ours, from the credit proxy — already written for a human.
    if "insufficient_credit" in text or "out of BotCortex credits" in text:
        return (
            "Out of BotCortex credit, so it can't learn anything new right now. "
            "Skills it already knows still run."
        )
    if "not available on BotCortex credits" in text:
        return "That model isn't available on BotCortex credits. Pick another one."
    if "Unknown or revoked robot key" in text or name == "AuthenticationError":
        return (
            "The robot's key was rejected. Re-pair it with `botcortex login`, "
            "or check the key in its .env."
        )
    if name in ("APIConnectionError", "APITimeoutError") or "Connection error" in text:
        return "Couldn't reach the model. Check the robot's internet and try again."
    if name == "RateLimitError" or "rate limit" in text.lower():
        return "The model is rate-limited right now. Wait a moment and try again."
    if name == "BadRequestError" or "invalid_request_error" in text:
        return (
            "That model refused the request — it may not support the tools this "
            "agent needs. Try a different model from the picker."
        )
    if "E-STOP" in text:
        return "Stopped: the e-stop is latched. Clear it to continue."
    return "Teaching failed. The robot's log has the details."


@dataclass
class TeachResult:
    text: str
    outcome: str  # "ok" | "fail"
    skills_used: list[str] = field(default_factory=list)
    error: str | None = None


class TeachSession(RobotSession):
    """A RobotSession that can also author — i.e. talk to a model.

    Everything a tool call DOES lives in RobotSession, SDK-free, so the browser
    runs the identical bodies. This subclass adds only the loop and the one
    thing a browser cannot do: push a saved skill to the account registry.
    """

    def on_skill_saved(self, name: str, meta: dict, code: str) -> None:
        # The skill is already on disk and runnable; this is a copy going to
        # the owner's account for the registry. Announced rather than silent,
        # and never allowed to affect the result the agent sees.
        if cloud.enabled():
            synced = cloud.sync_skill(name, meta["description"], code)
            print(f"[cloud] skill {name}: {'synced' if synced else 'sync failed (kept locally)'}")
            self.emit({"type": "sync", "skill": name, "ok": synced})

    # --- the teach loop ---

    def _teach_openai(
        self, prompt: str, tool_objs: list, max_iterations: int, model: str
    ) -> TeachResult:
        """Tool-calling loop for OpenAI models. Schemas are derived from the
        same @beta_tool definitions the Anthropic path uses, so the agent's
        reach into the runtime is identical whichever brain is driving."""
        from openai import OpenAI

        client = OpenAI(**cloud.openai_kwargs())
        by_name = {t.name: t for t in tool_objs}
        schemas = [
            {
                "type": "function",
                "function": {
                    "name": t.name,
                    "description": t.description,
                    "parameters": t.input_schema,
                },
            }
            for t in tool_objs
        ]
        messages: list[dict] = [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": prompt},
        ]

        def create(**extra):
            return client.chat.completions.create(
                model=model, messages=messages, tools=schemas, **extra
            )

        text = ""
        for _ in range(max_iterations):
            effort = {"reasoning_effort": "none"} if _wants_effort_none(model) else {}
            try:
                response = create(**effort)
            except Exception as e:  # learn the model's requirement, once
                if effort or "reasoning_effort" not in str(e):
                    raise
                _NEEDS_EFFORT_NONE.add(model)
                response = create(reasoning_effort="none")
            message = response.choices[0].message
            if message.content:
                text = message.content
                self.emit({"type": "chat", "text": text})
            if not message.tool_calls:
                break

            messages.append(message.model_dump(exclude_none=True))
            for call in message.tool_calls:
                tool = by_name.get(call.function.name)
                if tool is None:
                    result = f"ERROR: no tool named {call.function.name!r}"
                else:
                    try:
                        result = tool.func(**json.loads(call.function.arguments or "{}"))
                    except Exception as e:  # noqa: BLE001 — surface to the model, keep going
                        result = f"ERROR: {type(e).__name__}: {e}"
                messages.append(
                    {"role": "tool", "tool_call_id": call.id, "content": str(result)}
                )
        else:
            text = text or "Stopped after the iteration limit."

        return TeachResult(text=text.strip(), outcome="ok", skills_used=self.skills_used)

    def teach(
        self,
        task: str,
        max_iterations: int = MAX_ITERATIONS,
        model: str | None = None,
    ) -> TeachResult:
        # Pick up a key paired or rotated since this process started, rather
        # than failing with a 401 about a credential the owner already replaced.
        cloud.reload()
        # A robot pointed at BotCortex with no key used to fall through to the
        # vendor SDK's own credentials. Teaching still worked, so nothing
        # looked broken — while every call was billed to the owner's OpenAI
        # account and the credit figure in the app sat perfectly still. Refuse
        # instead: nothing is spent, and the message names the one command
        # that fixes it.
        if cloud.half_paired():
            unpaired = (
                "This robot is set up to use BotCortex credit but has no robot key, so "
                "teaching would quietly charge your own model provider instead. Run "
                "`botcortex login` on the robot to pair it."
            )
            self.emit({"type": "chat", "text": unpaired})
            self.memory.log(task, [], "fail", error="not paired")
            return TeachResult(text=unpaired, outcome="fail", error="not paired")
        # The app can name the brain per task. Whatever is chosen is what gets
        # billed, so it is echoed back rather than silently swapped: an owner
        # who picks an expensive model and is quietly downgraded (or the
        # reverse) has been charged for something they did not choose.
        chosen = (model or config.MODEL).strip() or config.MODEL
        provider = config.provider_for(chosen)
        self.emit({"type": "model", "name": chosen, "provider": provider})
        self.skills_used = []
        episodes = self.memory.recall(task)
        episode_note = (
            "Relevant past episodes (apply their lessons):\n" + json.dumps(episodes, indent=1)
            if episodes
            else "No relevant past episodes."
        )

        if provider == "openai":
            prompt = f"{episode_note}\n\nTask: {task}"
            try:
                result = self._teach_openai(
                    prompt, tools.build_tools(self), max_iterations, chosen
                )
            except EStopTriggered as e:
                result = TeachResult(text=f"E-STOP: {e}", outcome="fail", error=str(e))
            self.memory.log(task, self.skills_used, result.outcome, error=result.error)
            return result

        client = anthropic.Anthropic(**cloud.anthropic_kwargs())
        runner = client.beta.messages.tool_runner(
            model=chosen,
            max_tokens=16000,
            system=[
                {
                    "type": "text",
                    "text": SYSTEM_PROMPT,
                    "cache_control": {"type": "ephemeral"},
                }
            ],
            tools=tools.build_tools(self),
            messages=[{"role": "user", "content": f"{episode_note}\n\nTask: {task}"}],
            max_iterations=max_iterations,
        )

        final = None
        try:
            for message in runner:
                final = message
                for block in message.content:
                    if block.type == "text" and block.text.strip():
                        self.emit({"type": "chat", "text": block.text})
        except EStopTriggered as e:
            result = TeachResult(text=f"E-STOP: {e}", outcome="fail", error=str(e))
            self.memory.log(task, self.skills_used, "fail", error=str(e))
            return result

        if final is None:
            result = TeachResult(text="The agent produced no response.", outcome="fail")
        elif final.stop_reason == "refusal":
            result = TeachResult(
                text="The model declined this request — rephrase the task.",
                outcome="fail",
                error="refusal",
            )
        else:
            text = "".join(b.text for b in final.content if b.type == "text").strip()
            result = TeachResult(text=text, outcome="ok", skills_used=self.skills_used)

        self.memory.log(task, self.skills_used, result.outcome, error=result.error)
        return result
