"""Platform descriptors — the robot catalog's unit.

A platform is data, not code: vendor joint limits, joint naming, home pose,
and (optionally) a vendored sim model. Adding a robot means adding a
platforms/<name>/ directory; nothing else in the runtime changes. OpenArm v1
is entry one; SO-101 is planned next.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path

PLATFORMS_DIR = Path(__file__).parent / "platforms"


@dataclass(frozen=True)
class Platform:
    name: str
    display_name: str
    arms: tuple[str, ...]
    joint_limits: dict[str, dict[str, tuple[float, float]]]
    home_position: dict[str, float]
    sim: dict
    directory: Path

    @property
    def mjcf_path(self) -> Path | None:
        if not self.sim.get("mjcf"):
            return None
        return self.directory / self.sim["mjcf"]


def available_platforms() -> list[str]:
    return sorted(p.name for p in PLATFORMS_DIR.iterdir() if (p / "platform.json").exists())


def load_platform(name: str = "openarm_v1") -> Platform:
    directory = PLATFORMS_DIR / name
    spec_path = directory / "platform.json"
    if not spec_path.exists():
        raise ValueError(f"unknown platform {name!r}; available: {available_platforms()}")
    spec = json.loads(spec_path.read_text())

    joint_limits = {
        arm: {joint: (float(lo), float(hi)) for joint, (lo, hi) in limits.items()}
        for arm, limits in spec["joint_limits"].items()
    }
    reference_arm = spec["arms"][0]
    home = {joint: 0.0 for joint in joint_limits[reference_arm]}
    home.update({j: float(v) for j, v in spec.get("home_overrides", {}).items()})

    return Platform(
        name=spec["name"],
        display_name=spec["display_name"],
        arms=tuple(spec["arms"]),
        joint_limits=joint_limits,
        home_position=home,
        sim=spec.get("sim", {}),
        directory=directory,
    )
