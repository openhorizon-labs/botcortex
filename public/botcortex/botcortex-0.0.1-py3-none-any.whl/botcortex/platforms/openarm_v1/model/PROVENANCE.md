Vendored from https://github.com/enactic/openarm_mujoco (master, 2026-08-03).
Apache-2.0 — LICENSE preserved. Transforms: visual geoms/meshes stripped
(collision-only physics), arm torque motors converted to position servos
(kp by motor class), left finger motors aligned with upstream right-hand
position actuators. Regenerate with scripts/vendor_openarm.py.
