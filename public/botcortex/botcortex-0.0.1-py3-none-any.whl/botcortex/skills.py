"""Agent-authored skills: parametrized Python files the runtime owns and executes.

A skill is a single .py file with `META = {"name", "description", "params"}` and
`run(ctx, **params)`. Skills can only touch the robot through the SkillContext —
the exec namespace has no imports, no filesystem, and a whitelisted builtins set.
That restriction is a guardrail against accidental misuse (an agent-written `open()`
or `os.system`), not a hardened security boundary; marketplace-grade sandboxing
comes with the hub.
"""

from __future__ import annotations

import math
import re
from pathlib import Path

NAME_RE = re.compile(r"^[a-z][a-z0-9_]{1,63}$")

# Enough for motion math; nothing that reaches the interpreter's edges.
SAFE_BUILTINS = {
    name: __builtins__[name] if isinstance(__builtins__, dict) else getattr(__builtins__, name)
    for name in (
        "abs", "all", "any", "bool", "dict", "enumerate", "float", "int", "len",
        "list", "max", "min", "range", "round", "sorted", "reversed", "str", "sum",
        "tuple", "zip", "True", "False", "None", "ValueError", "RuntimeError",
        "TypeError", "KeyError", "Exception", "isinstance",
    )
    if (isinstance(__builtins__, dict) and name in __builtins__)
    or (not isinstance(__builtins__, dict) and hasattr(__builtins__, name))
}


class SkillError(ValueError):
    """The skill code failed validation or execution."""


class SkillContext:
    """The only handle a skill gets. Wraps the primitives; nothing else exists.

    on_step, when set, receives (label,) before each primitive call — the server
    uses it to stream live progress to the plan view.
    """

    def __init__(self, robot, on_step=None):
        self._robot = robot
        self._on_step = on_step
        self.math = math

    def _step(self, label: str) -> None:
        if self._on_step:
            self._on_step(label)

    def get_positions(self, arm: str) -> dict[str, float]:
        return self._robot.get_positions(arm)

    def describe_scene(self) -> dict:
        """Where the objects are, right now.

        Skills need this as much as the agent does. Without it an authored
        skill can only hold the coordinates it was written with, so "pick up
        the red block" works exactly once — the next time the block is
        anywhere else, the arm closes on air. A skill that reads the scene at
        run time is the difference between a recording and a program.
        """
        return self._robot.describe_scene()

    def move_to(self, arm: str, targets: dict[str, float], duration: float | None = None) -> None:
        self._step(f"move_to {arm} {targets}")
        self._robot.move_to(arm, targets, duration)

    def move_to_point(self, arm: str, point, tolerance: float = 0.02) -> None:
        """Put the grasp centre at a point in metres, gripper pointing down.

        The bridge from describe_scene (metres) to the arm (degrees). Without
        it a skill can see exactly where a block is and has no way to go there,
        which is what issue #16 discovered.
        """
        self._step(f"move_to_point {arm} {[round(float(v), 3) for v in point]}")
        self._robot.move_to_point(arm, point, tolerance)

    def gripper(self, arm: str, position: float) -> None:
        self._step(f"gripper {arm} -> {position}")
        self._robot.gripper(arm, position)

    def set_torque(self, arm: str, enabled: bool) -> None:
        self._step(f"set_torque {arm} {enabled}")
        self._robot.set_torque(arm, enabled)

    def clear_errors(self) -> None:
        self._robot.clear_errors()

    def replay_trajectory(self, arm: str, waypoints: list[dict[str, float]]) -> None:
        self._step(f"replay_trajectory {arm} ({len(waypoints)} waypoints)")
        self._robot.replay_trajectory(arm, waypoints)


class SkillStore:
    """Loads, validates, saves, and runs skills from a directory of .py files."""

    def __init__(self, directory: Path):
        self.directory = Path(directory)
        self.directory.mkdir(parents=True, exist_ok=True)

    def _compile(self, name: str, code: str):
        """Exec the skill in the restricted namespace; return (meta, run)."""
        namespace = {"__builtins__": dict(SAFE_BUILTINS), "math": math}
        try:
            # exec IS the skill runtime — the restricted namespace above is the guardrail.
            exec(compile(code, f"<skill:{name}>", "exec"), namespace)  # noqa: S102
        except ImportError as e:
            raise SkillError(
                f"skills cannot import ({e}); everything a skill needs is on ctx"
            ) from e
        except SyntaxError as e:
            raise SkillError(f"syntax error in skill: {e}") from e
        meta = namespace.get("META")
        run = namespace.get("run")
        if not isinstance(meta, dict) or "name" not in meta or "description" not in meta:
            raise SkillError('skill must define META = {"name", "description", "params"}')
        if not callable(run):
            raise SkillError("skill must define run(ctx, **params)")
        meta.setdefault("params", {})
        return meta, run

    def save(self, name: str, code: str) -> dict:
        if not NAME_RE.match(name):
            raise SkillError("skill name must be snake_case ascii, e.g. wave_right_arm")
        meta, _ = self._compile(name, code)
        if meta["name"] != name:
            raise SkillError(f'META["name"] ({meta["name"]!r}) must match the save name ({name!r})')
        (self.directory / f"{name}.py").write_text(code)
        return meta

    def list(self) -> list[dict]:
        metas = []
        for path in sorted(self.directory.glob("*.py")):
            try:
                meta, _ = self._compile(path.stem, path.read_text())
                metas.append(meta)
            except SkillError:
                continue  # a broken file must not take the whole store down
        return metas

    def names(self) -> list[str]:
        return [m["name"] for m in self.list()]

    def run(self, name: str, ctx: SkillContext, **params):
        path = self.directory / f"{name}.py"
        if not path.exists():
            raise SkillError(f"no skill named {name!r}; known: {self.names()}")
        meta, run = self._compile(name, path.read_text())
        merged = {**meta.get("params", {}), **params}
        return run(ctx, **merged)
