"""Noticing when the robot has hit something it should not have.

Nothing in the runtime looked at contacts before this. The arm could be driven
bodily into the tabletop and every layer above reported success: the servos
kept pushing, `move_to` returned normally, and `run_skill` answered "finished:
9 primitive calls, all clamped and e-stop-checked" — which says the calls
HAPPENED, not that anything was achieved. An agent reads that as "done".

Measured, which is what the rule below is built on rather than intuition:

  During a SUCCESSFUL pick-and-place, the only robot geoms that ever touch
  furniture are the FINGERS, and only briefly (~93 control ticks out of
  thousands) while placing a block into a tray. No structural link touches
  anything.

  Sweeping the reachable envelope, poses that bury a LINK in the furniture do
  exist — `j1=14, j2=-4, j4=5` puts `openarm_right_hand` and
  `openarm_right_link7` inside the table. That is essentially the home pose
  with a small yaw: the arm hangs to z=0.083 and the tabletop is at 0.20, so
  swinging j1 while low drives the wrist straight into the edge.

So the rule is: **a structural link touching a fixture is a fault; fingers
touching a fixture are not.** Fingers brush trays and tabletops as a normal
part of placing something down. A link inside the furniture is the arm being
somewhere it cannot be.

Contacts with PAYLOAD are never faults — that is manipulation, and the whole
point.
"""

from __future__ import annotations

from botcortex.mjcompat import enum_value

#: Geoms belonging to the hand's fingers. They contact furniture legitimately.
_FINGER = "finger"

#: Bodies that are part of the robot.
_ROBOT = "openarm"


class Collision(RuntimeError):
    """A structural part of the arm is inside something it cannot be inside.

    Raised mid-motion, like EStopTriggered, and for the same reason: continuing
    to command a servo that is already buried only pushes harder.
    """


def link_collisions(mujoco, model, data, fixtures: set[str]) -> set[tuple[str, str]]:
    """Which arm links are currently touching which fixtures.

    Empty is the healthy case. Fingers are excluded by name — see the module
    docstring for the measurements that justify it.
    """
    body = enum_value(mujoco.mjtObj.mjOBJ_BODY)

    def body_of(geom: int) -> str:
        return mujoco.mj_id2name(model, body, int(model.geom_bodyid[geom])) or ""

    hits: set[tuple[str, str]] = set()
    for index in range(int(data.ncon)):
        contact = data.contact[index]
        first, second = body_of(int(contact.geom1)), body_of(int(contact.geom2))
        for part, other in ((first, second), (second, first)):
            if part.startswith(_ROBOT) and _FINGER not in part and other in fixtures:
                hits.add((part, other))
    return hits


def describe(hits: set[tuple[str, str]]) -> str:
    """What to tell the agent, in words it can act on.

    Names the part and the thing, because "collision" alone gives a model
    nothing to change — where it hit is what tells it which way to move.
    """
    listed = ", ".join(f"{part} hit {other}" for part, other in sorted(hits))
    return (
        f"COLLISION: {listed}. The arm was driven into the workcell and stopped. "
        "Move to a clear height above the obstacle first, then approach — a "
        "joint-space move between two safe poses can still sweep through what "
        "is between them."
    )


# --- rehearsal: running a motion where it cannot break anything -------------
#
# Detecting a collision after the arm is already in the table is better than
# not detecting it, and it is still too late. So nothing moves until it has
# been run once in a copy of the present moment and come back clean.
#
# That only means anything if the copy is exact. If a rehearsal passed and the
# real run diverged into contact, the harness would be lying in the one
# direction that matters — so this is measured, not assumed:
#
#   Rehearse pick_and_place, restore, then run it for real. Separately, run it
#   for real with no rehearsal. Every joint of both arms, every qpos and every
#   qvel agree to 0.0 — not "within tolerance", bit-identical — and both take
#   the same 348 control ticks. Skipping the restore changes the world by up to
#   62 units, so the test has teeth.
#
# mjSTATE_INTEGRATION is the right mask because it is *everything the
# integrator reads*: in MuJoCo 3.11 it is 16383, every state bit set, which
# includes qacc_warmstart — the previous solution the solver warm-starts from,
# and therefore part of what decides the convergence path. Hand-picking
# qpos/qvel/ctrl would look complete and quietly drop it.
#
# Verified 16383 in the native build AND in @mujoco/mujoco, so both backends
# save and restore exactly the same fields.
#
# The state goes into a SECOND mjData rather than a flat buffer, and that
# choice is the browser's doing. mj_getState/mj_setState work perfectly
# natively, and in the WASM build mj_getState accepts a Float64Array, returns
# no error, and does not write to it — the array is on the JS heap and the
# writes land somewhere else. The restore then put back a state of all zeros,
# which is very nearly the home pose, so the failure showed up as a single
# joint 5 degrees out and nothing else. A safety mechanism whose failure looks
# like that is not one worth keeping.
#
# mj_copyState needs no buffer at all, and its argument order was measured
# identical in both builds rather than read off a header: (model, src, dst).


def state_spec(mujoco) -> int:
    """mjSTATE_INTEGRATION, however this build spells it."""
    return enum_value(mujoco.mjtState.mjSTATE_INTEGRATION)


def hold_state(mujoco, model, spare, data) -> None:
    """Park everything the integrator reads in `spare`."""
    mujoco.mj_copyState(model, data, spare, state_spec(mujoco))


def release_state(mujoco, model, spare, data) -> None:
    """Put it back. mj_forward afterwards so derived quantities agree again."""
    mujoco.mj_copyState(model, spare, data, state_spec(mujoco))
    mujoco.mj_forward(model, data)
