"""FastAPI server — the robot end of the web app's wire protocol.

Serves three things from one origin, per the blueprint: the static web app
(when a build is present), a WebSocket at /ws for everything conversational,
and STOP as its own REST endpoint so it can never queue behind chat traffic.
The protocol mirrors lib/robot/protocol.ts in the botcortex web repo.
"""

import asyncio
import platform
import traceback
from functools import partial

import anyio.to_thread
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from botcortex import __version__, cloud, config
from botcortex import agent as agent_mod
from botcortex.agent import TeachSession

ROBOT_INFO = {
    "name": "OpenArm v1 (mock)",
    "platform": platform.machine() or "dev",
    "version": __version__,
}


def gripper_map() -> dict:
    """What the 3D viewer needs to turn a gripper angle into finger travel.

    Sent rather than assumed. The viewer hardcoded -65..0 and 0.044, which made
    it a third implementation of the mapping jointmap.py owns and that the
    no-arithmetic test guards — correct for openarm_v1, silently wrong for the
    platform after it, and wrong in the one way nothing reports: a jaw drawn at
    the wrong opening.
    """
    lo, hi = config.JOINT_LIMITS[config.ARMS[0]]["gripper"]
    return {
        "minDeg": lo,
        "maxDeg": hi,
        "travelM": float(config.PLATFORM.sim.get("gripper_meters_open", 0.044)),
    }


def create_app(session: TeachSession) -> FastAPI:
    app = FastAPI(title="botcortex", version=__version__)
    app.state.session = session

    # The hosted web app (different origin) must reach /api/status and /stop.
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_methods=["GET", "POST", "OPTIONS"],
        allow_headers=["*"],
    )

    def estop_active() -> bool:
        return config.STOP_FILE.exists()

    # Every connected operator's queue.
    #
    # Reverses "v0 is single-operator: the most recent socket owns the event
    # stream". That was survivable until the e-stop became stateful: with the
    # old design, a second tab stealing the stream left the FIRST tab showing a
    # happy idle robot that silently refused to move — the exact failure the
    # latch banner exists to prevent.
    #
    # Only SHARED events fan out — chat, skills, status, and the e-stop latch.
    # The 15 Hz joint feed, the stop-file watcher, and the per-connection
    # handshake stay on their own socket; broadcasting those would hand every
    # tab one copy per connected tab.
    #
    # Each entry pairs a queue with the loop it lives on. Stashing one shared
    # loop reference looks simpler and is wrong: it goes stale the moment that
    # socket's loop closes, and every later emit raises "Event loop is closed"
    # for everyone — which is exactly how the first version of this failed.
    subscribers: set[tuple] = set()

    def emit_all(event: dict) -> None:
        # emit is called from the worker thread the teach loop runs on, so
        # every hand-off crosses back through call_soon_threadsafe.
        for entry in list(subscribers):  # a copy: sockets vanish mid-broadcast
            loop, queue = entry
            try:
                loop.call_soon_threadsafe(queue.put_nowait, event)
            except RuntimeError:
                # That socket's loop is gone; drop it rather than let one dead
                # listener break delivery for the live ones.
                subscribers.discard(entry)

    session.emit = emit_all

    @app.get("/api/status")
    def status():
        return {"ok": True, "name": ROBOT_INFO["name"], "stopped": estop_active()}

    @app.get("/api/skills")
    def skills():
        return {"skills": session.store.list()}

    @app.post("/stop")
    def stop():
        """Touch the e-stop file. Motion aborts between interpolation steps and
        stays blocked until the file is cleared — that is the point."""
        config.STOP_FILE.touch()
        # Tell the UI at once rather than letting it wait for the watcher: the
        # operator needs to see the latch the instant it engages.
        session.emit({"type": "estop", "stopped": True})
        return {"stopped": True}

    @app.post("/stop/reset")
    def stop_reset():
        config.STOP_FILE.unlink(missing_ok=True)
        session.emit({"type": "estop", "stopped": False})
        return {"stopped": False}

    @app.websocket("/ws")
    async def ws(websocket: WebSocket):
        await websocket.accept()
        queue: asyncio.Queue = asyncio.Queue()
        entry = (asyncio.get_running_loop(), queue)
        subscribers.add(entry)

        async def pump():
            while True:
                await websocket.send_json(await queue.get())

        async def state_stream():
            """~15 Hz joint-state feed — the 3D scene poses the arm from this.
            Same message whether the backend is the mock or MuJoCo.

            Pushed to THIS socket only. Broadcasting it would give every tab a
            copy per connected tab, squaring the busiest message in the protocol.
            """
            while True:
                queue.put_nowait(
                    {
                        "type": "state",
                        "arms": {
                            arm: session.robot.get_positions(arm) for arm in config.ARMS
                        },
                    }
                )
                await asyncio.sleep(1 / 15)

        async def estop_watch():
            """The stop file can appear from outside this process — the CLI, a
            second operator, a script. Poll it slowly and only speak on change.

            Deliberately NOT folded into state_stream: that runs at 15 Hz to
            pose the arm, and a stat() syscall per frame per socket buys no
            useful latency for a latched flag.
            """
            last = estop_active()
            while True:
                await asyncio.sleep(1)
                now = estop_active()
                if now != last:
                    last = now
                    queue.put_nowait({"type": "estop", "stopped": now})

        pump_task = asyncio.create_task(pump())
        state_task = asyncio.create_task(state_stream())
        estop_task = asyncio.create_task(estop_watch())
        queue.put_nowait(
            {
                "type": "hello",
                # The gripper mapping rides with the robot's identity: it is a
                # fact about THIS arm, and the viewer needs it to render a jaw
                # opening rather than guessing at one.
                "robot": {**ROBOT_INFO, "gripper": gripper_map()},
                "skills": session.store.names(),
                "stopped": estop_active(),
                # Whether this backend can be snapped home. Absent on real
                # hardware, where an instantaneous reset would be a violent move.
                "resettable": hasattr(session.robot, "reset"),
                # Which wallet this robot teaches from. The app shows a credit
                # balance, and until it knew this it showed one for robots that
                # could never spend it — a number frozen at full while the
                # owner's own provider took the bill. Read fresh, so a robot
                # paired since launch says so on the next page load.
                "paired": cloud.paired(),
                "halfPaired": cloud.half_paired(),
            }
        )
        queue.put_nowait({"type": "status", "state": "idle"})

        try:
            while True:
                msg = await websocket.receive_json()
                kind = msg.get("type")
                if kind == "ping":
                    queue.put_nowait({"type": "pong"})
                elif kind == "reset_sim":
                    # Sent by the app on page load, so a refresh gives a clean
                    # scene. Client-initiated on purpose: resetting on every
                    # socket open would also fire on reconnects after a network
                    # blip, snapping the arm home mid-session.
                    # Never mid-teach: teleporting the arm under a running skill
                    # would corrupt what the agent is verifying.
                    reset = getattr(session.robot, "reset", None)
                    if reset is not None and not session.busy:
                        reset()
                elif kind in ("chat", "run_skill") and session.busy:
                    # One robot, one arm pair: a second job while the agent is
                    # mid-teach would interleave motion with what it is
                    # verifying, and the results it reads back would belong to
                    # neither. Refused rather than queued — the operator should
                    # know it did not happen.
                    session.emit(
                        {
                            "type": "chat",
                            "text": "The robot is still working on the last task. "
                            "Wait for it to finish, or press STOP.",
                        }
                    )
                elif kind == "chat":
                    session.busy = True
                    session.emit({"type": "status", "state": "teaching"})
                    try:
                        result = await anyio.to_thread.run_sync(
                            partial(
                                session.teach,
                                msg.get("text", ""),
                                model=msg.get("model") or None,
                            )
                        )
                        # teach() owns chat emission — it streams the agent's
                        # words as they form. Echoing result.text here would
                        # print every reply to the owner twice.
                        if not result.text:
                            session.emit(
                                {"type": "chat", "text": "(the agent had nothing to say)"}
                            )
                    except Exception as e:  # noqa: BLE001 — surface, never drop the socket
                        # Plain language to the owner; the whole thing to the
                        # log, where whoever is debugging will actually look.
                        traceback.print_exception(e)
                        session.emit({"type": "chat", "text": agent_mod.explain(e)})
                    session.busy = False
                    session.emit({"type": "skills", "skills": session.store.names()})
                    session.emit({"type": "status", "state": "idle"})
                elif kind == "run_skill":
                    name = msg.get("name", "")
                    session.busy = True
                    session.emit({"type": "status", "state": "running", "detail": name})
                    try:
                        outcome = await anyio.to_thread.run_sync(
                            partial(session.tool_run_skill, name, {})
                        )
                    finally:
                        session.busy = False
                    session.emit({"type": "chat", "text": outcome})
                    session.emit({"type": "status", "state": "idle"})
        except (WebSocketDisconnect, RuntimeError):
            # RuntimeError is what Starlette raises when the peer vanishes
            # mid-receive; a closed browser tab is not an error worth a traceback.
            pass
        finally:
            # Drop THIS socket only. The old single-owner design reset emit to a
            # no-op here, which under fan-out would mean one tab closing went
            # silent for every other tab still watching the same robot.
            subscribers.discard(entry)
            pump_task.cancel()
            state_task.cancel()
            estop_task.cancel()

    # Static app last so /api, /stop, and /ws win the route match.
    if config.WEB_DIR.is_dir():
        app.mount("/", StaticFiles(directory=config.WEB_DIR, html=True), name="web")

    return app


def serve(host: str = "0.0.0.0", port: int = 9090, sim: bool = False) -> None:
    """Run the server on a mock robot, or MuJoCo with --sim. Hardware serving
    lands at milestone 3."""
    import uvicorn

    if sim:
        from botcortex.sim import SimRobot

        robot = SimRobot(realtime=True)
        ROBOT_INFO["name"] = f"{config.PLATFORM.display_name} · sim"
    else:
        from botcortex.robot import MockRobot

        robot = MockRobot(realtime=True)
    app = create_app(TeachSession(robot))
    uvicorn.run(app, host=host, port=port)
