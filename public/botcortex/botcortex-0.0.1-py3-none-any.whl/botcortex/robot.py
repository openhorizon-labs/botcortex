"""Motion primitives — the only layer that ever touches actuators.

Every move is clamped inside vendor limits, interpolated at CONTROL_HZ with a
velocity cap, and checks the e-stop file between every step. No LLM anywhere in
this file: deterministic execution is the product's core claim.

MockRobot mirrors the full primitive interface so everything above it can be
developed and tested with no hardware. RealRobot (LeRobot-backed) lands at
milestone 3.
"""

import math
import time
from pathlib import Path

from botcortex import config


class EStopTriggered(RuntimeError):
    """The stop file appeared mid-motion; the move was aborted between steps."""


def clamp_target(arm: str, joint: str, value: float) -> float:
    lo, hi = config.JOINT_LIMITS[arm][joint]
    margin = 0.0 if joint == "gripper" else config.SAFETY_MARGIN_DEG
    return min(max(value, lo + margin), hi - margin)


def plan_move(
    arm: str,
    current: dict[str, float],
    targets: dict[str, float],
    duration: float | None = None,
) -> list[dict[str, float]]:
    """The trajectory a move_to produces: clamped, velocity-capped, sampled at
    CONTROL_HZ. Returns one frame per control tick, ending exactly on the goal.

    THE single definition of how this robot moves. It used to be copied between
    MockRobot and SimRobot, which was survivable while both were Python in one
    process and stopped being survivable the moment a third backend appeared:
    two implementations that agree today drift silently, and "the arm moves the
    same everywhere" is the product's central claim, not a nicety.

    Pure on purpose — no clock, no e-stop, no actuators. A caller decides what
    to do with each frame (write a dict, write MuJoCo ctrl), when to check the
    stop file, and whether to pace in real time. That also makes the trajectory
    a value that can be compared against a committed fixture, which is what
    keeps a future port honest.
    """
    goal = {j: clamp_target(arm, j, v) for j, v in targets.items()}
    largest_delta = max((abs(goal[j] - current[j]) for j in goal), default=0.0)
    # A move never exceeds MAX_VEL_DEG_S: asking for a faster one stretches the
    # duration rather than the velocity.
    min_duration = largest_delta / config.MAX_VEL_DEG_S
    actual_duration = max(duration or 0.0, min_duration)
    steps = max(1, math.ceil(actual_duration * config.CONTROL_HZ))
    start = dict(current)
    # The final frame is the goal itself, not the interpolation evaluated at
    # 1.0. Those are the same number in exact arithmetic and not in doubles:
    # chaining moves from a pose a previous move produced landed j2 on
    # -0.40000000000000036 instead of -0.4. Each move measures its delta from
    # wherever the last one finished, so that residue compounds across the
    # dozens of moves in a skill, and the arm ends somewhere nobody asked for.
    return [
        {
            j: g if i == steps else start[j] + (g - start[j]) * (i / steps)
            for j, g in goal.items()
        }
        for i in range(1, steps + 1)
    ]


class MockRobot:
    """In-memory twin of the bimanual OpenArm v1: same primitives, no hardware.

    realtime=False (default) skips the per-step sleep so tests run instantly;
    the interpolation math is identical either way.
    """

    def __init__(self, stop_file: Path | None = None, realtime: bool = False):
        self.stop_file = stop_file if stop_file is not None else config.STOP_FILE
        self.realtime = realtime
        self.positions = {arm: dict(config.HOME_POSITION) for arm in config.ARMS}
        self.torque = {arm: True for arm in config.ARMS}
        self.motion_log: list[tuple[str, str, dict[str, float]]] = []

    def reset(self) -> None:
        """Snap back to home. Instantaneous, so it exists only where there is
        no physical arm to fling — see SimRobot.reset for the full note."""
        self.positions = {arm: dict(config.HOME_POSITION) for arm in config.ARMS}

    def get_positions(self, arm: str) -> dict[str, float]:
        return dict(self.positions[arm])

    def move_to(self, arm: str, targets: dict[str, float], duration: float | None = None) -> None:
        # `current` is the live dict, deliberately: updating it in place is how
        # the mock's state advances.
        current = self.positions[arm]
        for frame in plan_move(arm, current, targets, duration):
            if self.stop_file.exists():
                raise EStopTriggered(f"stop file present: {self.stop_file}")
            current.update(frame)
            self.motion_log.append(("step", arm, dict(current)))
            if self.realtime:
                time.sleep(1 / config.CONTROL_HZ)

    def gripper(self, arm: str, position: float) -> None:
        self.move_to(arm, {"gripper": position})

    def set_torque(self, arm: str, enabled: bool) -> None:
        self.torque[arm] = enabled
        self.motion_log.append(("torque", arm, {"enabled": float(enabled)}))

    def clear_errors(self) -> None:
        self.motion_log.append(("clear_errors", "both", {}))

    def replay_trajectory(self, arm: str, waypoints: list[dict[str, float]]) -> None:
        for waypoint in waypoints:
            self.move_to(arm, waypoint)
