"""Where each joint lives in the MuJoCo arrays, and what its degrees mean there.

`plan_move` (robot.py) decides the trajectory in degrees. This decides what
physics actually receives: which `ctrl` and `qpos` indices to write, and the
conversion to radians — or, for the gripper, to metres of finger travel.

It exists as its own layer for the same reason plan_move does. Two MuJoCo
backends are coming — native Python and the browser's WASM build — and they
differ only in how a name resolves to an index. Everything else, especially the
gripper mapping, is arithmetic that must not be written twice: a sign error
there yields a perfectly correct trajectory and a jaw that closes when it was
told to open. A backend using this class contains no arithmetic at all.

The two resolvers are the entire seam. Native passes lookups built on
mj_name2id; the browser passes ones built on the embind accessors, whose enums
are objects rather than ints. Addresses are plain integers on both sides, so
every write below is backend-agnostic.
"""

from __future__ import annotations

import math
from collections.abc import Callable, Sequence

from botcortex.platform import Platform

#: Joints per arm, named j1..j7 by the runtime whatever the vendor calls them.
ARM_JOINTS = tuple(f"j{n}" for n in range(1, 8))


class JointMap:
    """Address resolution and unit mapping for one loaded model.

    qpos_adr(name) -> the index into data.qpos for that joint
    actuator_id(name) -> the index into data.ctrl for that actuator

    Both are resolved once, at construction, so nothing does a string lookup
    inside a control loop.
    """

    def __init__(
        self,
        platform: Platform,
        qpos_adr: Callable[[str], int],
        actuator_id: Callable[[str], int],
    ):
        self.platform = platform
        sim = platform.sim
        self.meters_open = float(sim.get("gripper_meters_open", 0.044))

        self.qpos_adr: dict[str, dict[str, int]] = {}
        self.ctrl_id: dict[str, dict[str, int]] = {}
        self.finger_qpos: dict[str, list[int]] = {}
        self.finger_ctrl: dict[str, list[int]] = {}

        fingers = sim.get("fingers", 2)
        for side in platform.arms:
            self.qpos_adr[side] = {}
            self.ctrl_id[side] = {}
            for n, joint in enumerate(ARM_JOINTS, start=1):
                self.qpos_adr[side][joint] = qpos_adr(sim["joint_fmt"].format(side=side, n=n))
                self.ctrl_id[side][joint] = actuator_id(
                    sim["actuator_fmt"].format(side=side, n=n)
                )
            self.finger_qpos[side] = [
                qpos_adr(sim["finger_joint_fmt"].format(side=side, i=i))
                for i in range(1, fingers + 1)
            ]
            self.finger_ctrl[side] = [
                actuator_id(sim["finger_actuator_fmt"].format(side=side, i=i))
                for i in range(1, fingers + 1)
            ]

    # --- gripper: degrees of jaw opening <-> metres of finger travel ---
    #
    # 0° is the rest pose and maps to 0 m — the URDF/MJCF finger zero, i.e. jaws
    # together. -65° is fully open (0.044 m of travel). The inversion is real,
    # not a mistake: the vendor range runs negative-open to zero-closed.

    def gripper_deg_to_m(self, arm: str, deg: float) -> float:
        lo, hi = self.platform.joint_limits[arm]["gripper"]  # e.g. -65..0
        return (hi - deg) / (hi - lo) * self.meters_open

    def gripper_m_to_deg(self, arm: str, meters: float) -> float:
        lo, hi = self.platform.joint_limits[arm]["gripper"]
        return hi - (meters / self.meters_open) * (hi - lo)

    # --- what to write, as (index, value) pairs ---
    #
    # Pairs rather than direct writes so a backend needs no knowledge of units
    # or addressing: it loops and assigns. One gripper command yields one pair
    # per finger, which is why these return sequences rather than scalars.

    def ctrl_writes(self, arm: str, joint: str, deg: float) -> list[tuple[int, float]]:
        """Actuator targets for one joint at one control tick."""
        if joint == "gripper":
            meters = self.gripper_deg_to_m(arm, deg)
            return [(cid, meters) for cid in self.finger_ctrl[arm]]
        return [(self.ctrl_id[arm][joint], math.radians(deg))]

    def qpos_writes(self, arm: str, joint: str, deg: float) -> list[tuple[int, float]]:
        """Direct state writes — teleporting home, never mid-motion."""
        if joint == "gripper":
            meters = self.gripper_deg_to_m(arm, deg)
            return [(adr, meters) for adr in self.finger_qpos[arm]]
        return [(self.qpos_adr[arm][joint], math.radians(deg))]

    def read_deg(self, arm: str, joint: str, qpos: Sequence[float]) -> float:
        """One joint's angle in degrees, read out of a qpos array.

        Indexable is the only requirement, which numpy arrays and the WASM
        build's Float64Array views both satisfy.
        """
        if joint == "gripper":
            return self.gripper_m_to_deg(arm, float(qpos[self.finger_qpos[arm][0]]))
        return math.degrees(float(qpos[self.qpos_adr[arm][joint]]))

    def positions(self, arm: str, qpos: Sequence[float]) -> dict[str, float]:
        return {
            joint: self.read_deg(arm, joint, qpos)
            for joint in self.platform.joint_limits[arm]
        }
