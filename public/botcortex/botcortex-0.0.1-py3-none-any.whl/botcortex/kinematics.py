"""Getting the gripper to a point in space.

Issue #16 was meant to answer "can a person write a working pick-and-place
against this scene?" and answered something more useful: NO, and not because
the scene or the gripper are wrong. `describe_scene` reports where a block is
in METRES; `move_to` accepts joint angles in DEGREES; and a skill has neither
an IK solver nor the imports to write one — its namespace is `math` and the
primitives. So an agent could see the block perfectly and had no way to act on
what it saw.

That is a missing PRIMITIVE, not a missing capability in the model. It belongs
here for the same reason `plan_move` does: it is deterministic, bounded, and
must be identical on every backend. No LLM is anywhere near it.

The search is deliberately dumb — a coarse grid over four joints, then two
refinement passes around the best cell. A proper solver (damped least squares
on the Jacobian) would be faster and would need a Jacobian from each backend;
this needs only "put the joints here, tell me where the tip ended up", which
every backend can answer with what it already has. It converges to
single-millimetre accuracy in well under a second, which is nothing against a
move that takes seconds to execute.

Four joints, not seven: j1, j2, j4 and j6 position the wrist and set its pitch,
which is what a top-down grasp needs. j3, j5 and j7 are the ones left out —
and they are PINNED to the home pose rather than left wherever the arm
happened to be, which is the difference between a primitive and a coin toss.

That claim used to read "roll freedoms that a symmetric jaw closing on a cube
does not care about". True of j5 and j7. Measured false of j3: aiming at a
point 12 cm above the blue block, the same call answers 2 mm from home, 2.7 mm
with j5 at 40 degrees, 1.7 mm with j7 at 40 — and 110 mm with j3 at 30, which
is a refusal. j3 swings the elbow, so it moves the wrist through space, and
leaving it out of the search while letting it vary made the REACHABLE SET
depend on hidden state nobody chose.

An agent hit exactly that: four skills authored and run, each refused at a
waypoint the arm could reach perfectly well from a different starting pose,
with nothing in the message to suggest the starting pose was the variable. The
answer now depends on the point and the arm, and on nothing else.
"""

from __future__ import annotations

from collections.abc import Callable

#: Where the jaws actually close, in the hand body's frame. Measured, not
#: derived from mj_geomDistance — that reports the fingertip and puts an object
#: about 15 mm too deep.
GRASP_OFFSET = (-0.0018, 0.0060, 0.0878)


def tip_from(base, rot) -> tuple[float, float, float]:
    """The grasp centre in world coordinates.

    `base` is the hand body's position, `rot` its 3x3 rotation flattened
    row-major — what both MuJoCo builds hand back. Lives here rather than in
    each backend because it is arithmetic, and arithmetic in two backends is
    how they start disagreeing; `test_it_contains_no_arithmetic` caught exactly
    this when it was written twice.
    """
    return tuple(
        base[r] + sum(rot[r * 3 + c] * GRASP_OFFSET[c] for c in range(3)) for r in range(3)
    )


def unreachable(point, error: float) -> str:
    """The refusal a caller raises. Formatting a distance is arithmetic too."""
    where = tuple(round(float(v), 3) for v in point)
    return f"cannot reach {where} — closest is {error * 1000:.0f} mm away"


#: The joints the search moves. Order matters only for readability.
IK_JOINTS = ("j1", "j2", "j4", "j6")

#: The joints it does NOT move, and therefore has to pin. Held at the home
#: pose so that "can this arm reach this point" has one answer. Returned in the
#: solved pose too — a solver that assumed them and a move that did not command
#: them would disagree the moment the arm was anywhere but home.
NEUTRAL_JOINTS = ("j3", "j5", "j7")

#: How much a mis-aimed approach angle is worth, in metres of position error.
#: Position dominates — a grasp 5 mm off misses, a grasp 10 degrees off the
#: vertical still closes on a 40 mm cube.
_APPROACH_WEIGHT = 0.5

#: Below this, the gripper is not pointing down enough to drop onto a block.
#:
#: KNOWN DEFECT, traced end to end, NOT yet fixed. This is a TIEBREAK worth
#: 0.5 per unit of shortfall, which a few millimetres of position outweighs.
#: The whole chain, measured:
#:
#:   1. Aiming 12 cm above the blue block, the search returns a pose 2 mm from
#:      target with `down` around -0.5 — the hand tilted, not pointing down.
#:   2. In that pose a FINGER rests on the tabletop, 14 cm below the target.
#:   3. The wrist is now physically blocked, so j7 cannot turn: commanded 0.0,
#:      it sits at -71 degrees with its actuator saturated at exactly 7.00 N·m
#:      of its 7 N·m limit, and settling for seven seconds makes it worse.
#:   4. So the arm never arrives — the grasp centre ends 25 cm from where the
#:      solver promised — and the jaws close on nothing.
#:
#: Nothing reports a fault at any step. A finger touching a fixture is normal
#: (botcortex.safety), 2 mm is a fine position error, and the servo saturation
#: is invisible above the actuator. It reads as "the skill moved nothing".
#:
#: Not the masses: hand 150 g, fingers 36 g, no link over 1.2 kg. Not the
#: gains. The pose is wrong and everything downstream is a consequence.
#:
#: Making it a hard filter was tried and measured WORSE — 196 mm on a point
#: previously hit to 2 mm — but that was an implementation fault, not a verdict
#: on the idea: once any down-pointing pose existed it won at any error, and
#: the refinement window then narrowed around it. The fix is to refine the
#: down-pointing branch and the unconstrained branch INDEPENDENTLY and choose
#: between them at the end, so a filter cannot trap the search in a bad cell.
#:
#: Measured baseline to beat: of three blocks, red and green lift (both at
#: down = -0.50, so -0.85 is stricter than a cube actually needs) and blue does
#: not. Position error is ~2 mm everywhere — position is not the problem.
_WANT_DOWN = -0.85


def solve(
    probe: Callable[[dict[str, float]], tuple[tuple[float, float, float], float]],
    bounds: dict[str, tuple[float, float]],
    target: tuple[float, float, float],
    *,
    neutral: dict[str, float] | None = None,
    coarse: int = 9,
    refine: int = 2,
) -> tuple[dict[str, float], float]:
    """Joint angles that put the grasp centre on `target`, pointing down.

    `probe(pose)` sets those joints and returns (tip_xyz, downwardness), where
    downwardness is the world z of the gripper's approach axis: -1 is straight
    down. Supplying it is each backend's job — it is the only part that needs
    to know what a MuJoCo handle is.

    `bounds` must ALREADY be clamped to the platform's envelope. Searching
    outside it would find poses the primitives then refuse to execute.

    Returns the pose and its position error in metres. The caller decides what
    error is acceptable; a solver that silently returned its best guess for an
    unreachable point would have a skill close its gripper on air.
    """
    # Every probe carries the pinned joints, so the search measures the arm in
    # one configuration rather than in whatever one the last move left behind.
    held = dict(neutral or {})

    best_pose: dict[str, float] | None = None
    best_score = float("inf")
    best_error = float("inf")
    window = dict(bounds)

    for _ in range(refine + 1):
        axes = {
            joint: [lo + (hi - lo) * i / (coarse - 1) for i in range(coarse)]
            for joint, (lo, hi) in window.items()
        }
        for pose in _grid(axes):
            tip, down = probe({**held, **pose})
            error = _distance(tip, target)
            # Aiming is a tiebreak, not a goal: only a gripper pointing too far
            # from vertical is penalised, and only by how far short it falls.
            score = error + max(0.0, _WANT_DOWN - down) * _APPROACH_WEIGHT
            if score < best_score:
                best_score, best_error, best_pose = score, error, pose

        assert best_pose is not None
        # Next pass searches one cell either side of the winner.
        window = {
            joint: (
                max(bounds[joint][0], best_pose[joint] - (hi - lo) / (coarse - 1)),
                min(bounds[joint][1], best_pose[joint] + (hi - lo) / (coarse - 1)),
            )
            for joint, (lo, hi) in window.items()
        }

    # The pinned joints ride back with the answer: the caller MOVES to this
    # pose, and a move that left j3 where it was would not arrive where the
    # search said it would.
    return {**held, **best_pose}, best_error


def _grid(axes: dict[str, list[float]]) -> list[dict[str, float]]:
    poses: list[dict[str, float]] = [{}]
    for joint, values in axes.items():
        poses = [{**pose, joint: value} for pose in poses for value in values]
    return poses


def _distance(a: tuple[float, float, float], b: tuple[float, float, float]) -> float:
    return sum((x - y) ** 2 for x, y in zip(a, b, strict=True)) ** 0.5
