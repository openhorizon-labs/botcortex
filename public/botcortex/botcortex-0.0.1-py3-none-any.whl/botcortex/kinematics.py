"""Getting the gripper to a point in space.

Issue #16 was meant to answer "can a person write a working pick-and-place
against this scene?" and answered something more useful: NO, and not because
the scene or the gripper are wrong. `describe_scene` reports where a block is
in METRES; `move_to` accepts joint angles in DEGREES; and a skill has neither
an IK solver nor the imports to write one — its namespace is `math` and the
primitives. So an agent could see the block perfectly and had no way to act on
what it saw.

That is a missing PRIMITIVE, not a missing capability in the model. It belongs
here for the same reason `plan_move` does: it is deterministic, bounded, and
must be identical on every backend. No LLM is anywhere near it.

The search is deliberately dumb — a coarse grid over four joints, then two
refinement passes around the best cell. A proper solver (damped least squares
on the Jacobian) would be faster and would need a Jacobian from each backend;
this needs only "put the joints here, tell me where the tip ended up", which
every backend can answer with what it already has. It converges to
single-millimetre accuracy in well under a second, which is nothing against a
move that takes seconds to execute.

Four joints, not seven: j1, j2, j4 and j6 position the wrist and set its pitch,
which is what a top-down grasp needs. j3, j5 and j7 are the ones left out —
and they are PINNED to the home pose rather than left wherever the arm
happened to be, which is the difference between a primitive and a coin toss.

That claim used to read "roll freedoms that a symmetric jaw closing on a cube
does not care about". True of j5 and j7. Measured false of j3: aiming at a
point 12 cm above the blue block, the same call answers 2 mm from home, 2.7 mm
with j5 at 40 degrees, 1.7 mm with j7 at 40 — and 110 mm with j3 at 30, which
is a refusal. j3 swings the elbow, so it moves the wrist through space, and
leaving it out of the search while letting it vary made the REACHABLE SET
depend on hidden state nobody chose.

An agent hit exactly that: four skills authored and run, each refused at a
waypoint the arm could reach perfectly well from a different starting pose,
with nothing in the message to suggest the starting pose was the variable. The
answer now depends on the point and the arm, and on nothing else.
"""

from __future__ import annotations

from collections.abc import Callable

from botcortex.safety import Collision

#: Where the jaws actually close, in the hand body's frame. Measured, not
#: derived from mj_geomDistance — that reports the fingertip and puts an object
#: about 15 mm too deep.
GRASP_OFFSET = (-0.0018, 0.0060, 0.0878)


def tip_from(base, rot) -> tuple[float, float, float]:
    """The grasp centre in world coordinates.

    `base` is the hand body's position, `rot` its 3x3 rotation flattened
    row-major — what both MuJoCo builds hand back. Lives here rather than in
    each backend because it is arithmetic, and arithmetic in two backends is
    how they start disagreeing; `test_it_contains_no_arithmetic` caught exactly
    this when it was written twice.
    """
    return tuple(
        base[r] + sum(rot[r * 3 + c] * GRASP_OFFSET[c] for c in range(3)) for r in range(3)
    )


def unreachable(point, error: float) -> str:
    """The refusal a caller raises. Formatting a distance is arithmetic too."""
    where = tuple(round(float(v), 3) for v in point)
    return f"cannot reach {where} — closest is {error * 1000:.0f} mm away"


#: The joints the search moves. Order matters only for readability.
IK_JOINTS = ("j1", "j2", "j4", "j6")

#: The joints it does NOT move, and therefore has to pin. Held at the home
#: pose so that "can this arm reach this point" has one answer. Returned in the
#: solved pose too — a solver that assumed them and a move that did not command
#: them would disagree the moment the arm was anywhere but home.
NEUTRAL_JOINTS = ("j3", "j5", "j7")

#: How much a mis-aimed approach angle is worth, in metres of position error.
#: Position dominates — a grasp 5 mm off misses, a grasp 10 degrees off the
#: vertical still closes on a 40 mm cube.
_APPROACH_WEIGHT = 0.5

#: Below this, the search starts nudging poses toward vertical. A TIEBREAK,
#: nothing more: red and green blocks lift at down = -0.50, and grid grasps
#: lift at -0.43, so a tilted hand closes on a cube perfectly well and no
#: hard orientation constraint is justified by any measurement we have.
#:
#: This constant was once suspected of causing every grasp failure, and the
#: KNOWN DEFECT note that lived here sent a session hunting orientation
#: weights (measured useless: 7/15 at every _APPROACH_WEIGHT from 0.5 to 20)
#: and a hard down filter (measured worse: 196 mm on a point previously hit
#: to 2 mm). The real fault was never the POSE — it was the PATH. From the
#: home pose the tip hangs at z = 0.075, below the 0.20 tabletop, and a
#: joint-space move from there to a pose over the table drags a finger onto
#: the tabletop on the way. The wrist wedges against it — j7 saturated at
#: exactly its 7 N·m limit — and the arm stops up to 285 mm short with no
#: fault raised anywhere, because a finger touching a fixture is legal
#: (botcortex.safety) and nothing above the actuator sees saturation.
#:
#: Measured with the same solved pose, same target, blue block: direct
#: transit arrives 285 mm off and the grasp closes on air; raising the tip to
#: transit height first arrives 12 mm off and the block lifts 11 cm. That
#: measurement is why reach() below routes and verifies instead of trusting
#: one joint-space move.
_WANT_DOWN = -0.85


def solve(
    probe: Callable[[dict[str, float]], tuple[tuple[float, float, float], float]],
    bounds: dict[str, tuple[float, float]],
    target: tuple[float, float, float],
    *,
    neutral: dict[str, float] | None = None,
    coarse: int = 9,
    refine: int = 2,
) -> tuple[dict[str, float], float]:
    """Joint angles that put the grasp centre on `target`, pointing down.

    `probe(pose)` sets those joints and returns (tip_xyz, downwardness), where
    downwardness is the world z of the gripper's approach axis: -1 is straight
    down. Supplying it is each backend's job — it is the only part that needs
    to know what a MuJoCo handle is.

    `bounds` must ALREADY be clamped to the platform's envelope. Searching
    outside it would find poses the primitives then refuse to execute.

    Returns the pose and its position error in metres. The caller decides what
    error is acceptable; a solver that silently returned its best guess for an
    unreachable point would have a skill close its gripper on air.
    """
    # Every probe carries the pinned joints, so the search measures the arm in
    # one configuration rather than in whatever one the last move left behind.
    held = dict(neutral or {})

    best_pose: dict[str, float] | None = None
    best_score = float("inf")
    best_error = float("inf")
    window = dict(bounds)

    for _ in range(refine + 1):
        axes = {
            joint: [lo + (hi - lo) * i / (coarse - 1) for i in range(coarse)]
            for joint, (lo, hi) in window.items()
        }
        for pose in _grid(axes):
            tip, down = probe({**held, **pose})
            error = _distance(tip, target)
            # Aiming is a tiebreak, not a goal: only a gripper pointing too far
            # from vertical is penalised, and only by how far short it falls.
            score = error + max(0.0, _WANT_DOWN - down) * _APPROACH_WEIGHT
            if score < best_score:
                best_score, best_error, best_pose = score, error, pose

        assert best_pose is not None
        # Next pass searches one cell either side of the winner.
        window = {
            joint: (
                max(bounds[joint][0], best_pose[joint] - (hi - lo) / (coarse - 1)),
                min(bounds[joint][1], best_pose[joint] + (hi - lo) / (coarse - 1)),
            )
            for joint, (lo, hi) in window.items()
        }

    # The pinned joints ride back with the answer: the caller MOVES to this
    # pose, and a move that left j3 where it was would not arrive where the
    # search said it would.
    return {**held, **best_pose}, best_error


def _grid(axes: dict[str, list[float]]) -> list[dict[str, float]]:
    poses: list[dict[str, float]] = [{}]
    for joint, values in axes.items():
        poses = [{**pose, joint: value} for pose in poses for value in values]
    return poses


def _distance(a: tuple[float, float, float], b: tuple[float, float, float]) -> float:
    return sum((x - y) ** 2 for x, y in zip(a, b, strict=True)) ** 0.5


# --- routing: getting there without wedging on the furniture ----------------
#
# A solved pose says where the arm CAN be, not that a joint-space move from
# here will arrive there. From the low home pose, moves to poses over the
# table drag a finger onto the tabletop mid-transit; the wrist wedges, the
# servo saturates, and the arm stops hundreds of millimetres short with no
# fault raised anywhere (see the _WANT_DOWN note for the measurements). So a
# Cartesian move is a ROUTE — tried in rehearsal, measured on arrival, and
# only a route that verifiably arrives is executed for real.
#
# KNOWN LIMIT, measured against scripts/grasp_bench.py: a block within ~2 cm
# of a tray rim, at the x positions where the arm's yaw happens to align the
# jaw closing axis with the block-to-wall direction, cannot be grasped by
# arriving and closing. The close pushes the block against the rim — one
# finger on the cube at 6 N, the other stalled on the rim, the gripper stuck
# around -43 of the commanded 0. Levers measured DEAD before spending time
# on them again: wrist roll (j7 at these tilted poses lands 126-218 mm off),
# tighter arrival (iterated trim reached 5.5 mm, better than a succeeding
# cell, still jammed), and kinematic finger-contact screens (a fatal rim
# clip reads 2.3 mm, a benign tabletop brush reads 2.5 mm, and one jamming
# cell reads clean). What does work is a STRATEGY — grasp biased away from
# the wall, or slide the block clear first — which is the authoring agent's
# layer, fed by tool_gripper reporting a stalled close instead of silence.

#: How far above the tallest fixture a transit waypoint crosses the workcell.
#: Covers the fingers hanging below the grasp centre, with margin for a tilted
#: hand. Measured: 0.18 above the tabletop clears every wedge grasp_bench
#: provokes; 0 (the old behaviour) wedges on 7 of 15.
TRANSIT_CLEARANCE = 0.18

#: Transit waypoints may be sloppy — they are flown through, not grasped at.
#: A route is only rejected when a waypoint cannot be solved to within this.
_TRANSIT_TOLERANCE = 0.05

#: Servo convergence time after the final waypoint, before arrival is
#: measured. The identical settle runs in the rehearsal and in the real
#: execution, so the rehearsed arrival is evidence about the real one.
_SETTLE_S = 0.3

#: Above this arrival error, reach() tries one trim move. Position servos sag
#: under gravity — measured 9–12 mm at the far edge of the table against a
#: solve error of 2 mm — and the jaw pad is only 14.8 mm long, so a grasp
#: that ARRIVES by the transit's standard can still clip past the block:
#: at 11 mm the jaws close beside the cube, at 7 mm they catch it. The trim
#: aims at the target mirrored through the miss (2·target − tip), which
#: cancels sag exactly when the sag is locally constant, and it is kept only
#: when a rehearsal measures it landing closer than where the arm already is.
_TRIM_ABOVE = 0.006


def transit_height(fixtures: dict[str, dict]) -> float | None:
    """Where transits cross the workcell: above everything that cannot move.

    None when there is nothing to clear — a bare arm needs no transit height,
    and inventing one would refuse points a bare arm can simply go to.
    """
    tops = [
        body["position"][2] + body["size_m"][2] / 2
        for body in fixtures.values()
        if len(body.get("position", ())) >= 3 and len(body.get("size_m", ())) >= 3
    ]
    return max(tops) + TRANSIT_CLEARANCE if tops else None


def routes(
    here: tuple[float, float, float],
    target: tuple[float, float, float],
    transit_z: float | None,
) -> list[tuple[tuple[float, float, float], ...]]:
    """Candidate waypoint chains, cheapest first.

    Direct; rise at the current column then go; rise, cross at transit
    height above the target, then descend. Duplicates collapse — over an
    empty floor all three are the same one-move route.
    """
    direct = (target,)
    if transit_z is None:
        return [direct]
    lift_here = (here[0], here[1], max(transit_z, here[2]))
    lift_there = (target[0], target[1], max(transit_z, target[2]))
    candidates = [direct, (lift_here, target), (lift_here, lift_there, target)]
    out: list[tuple] = []
    for route in candidates:
        cleaned = tuple(
            point
            for i, point in enumerate(route)
            if i == 0 or _distance(point, route[i - 1]) > 1e-9
        )
        if cleaned not in out:
            out.append(cleaned)
    return out


def no_route(point, closest: float | None) -> str:
    """The refusal when every route wedged or collided."""
    where = tuple(round(float(v), 3) for v in point)
    if closest is None:
        return f"no clear route to {where} — every path tried collided with the workcell"
    return (
        f"no clear route to {where} — the arm wedges against the workcell in "
        f"transit and ends {closest * 1000:.0f} mm away on the best path tried"
    )


def reach(robot, arm: str, point, tolerance: float = 0.02) -> None:
    """Put the grasp centre on `point` — routed, rehearsed, and verified.

    The whole Cartesian move, shared by every physics backend the way
    plan_move is: solve the target, then try routes in order, each one run
    first in a rehearsal and measured on arrival. The first route whose
    rehearsed tip lands within `tolerance` of the target is executed for
    real — and because a rehearsal restores the exact state it started from,
    the real run repeats the rehearsed one identically.

    Raises ValueError when the point is out of reach (the solver cannot get
    within `tolerance`) or when no route arrives — an arm that silently
    stopped 285 mm short and let the jaws close on air is the failure this
    function exists to end. Needs a backend with `rehearsal()`, which is
    every backend that can answer solve_pose in the first place.
    """
    target = tuple(float(v) for v in point)
    solved: dict[tuple, tuple[dict[str, float], float]] = {}

    def pose_for(waypoint: tuple, gate: float) -> dict[str, float] | None:
        if waypoint not in solved:
            solved[waypoint] = robot.solve_pose(arm, waypoint)
        pose, error = solved[waypoint]
        return pose if error <= gate else None

    if pose_for(target, tolerance) is None:
        raise ValueError(unreachable(target, solved[target][1]))

    here, _down = robot.tip(arm)
    transit = transit_height(robot.describe_scene()["fixtures"])
    closest: float | None = None
    for route in routes(here, target, transit):
        poses = [pose_for(waypoint, _TRANSIT_TOLERANCE) for waypoint in route[:-1]]
        poses.append(pose_for(target, tolerance))
        if any(pose is None for pose in poses):
            continue
        try:
            with robot.rehearsal():
                for pose in poses:
                    robot.move_to(arm, pose)
                robot.settle(_SETTLE_S)
                tip, _ = robot.tip(arm)
                arrived = _distance(tip, target)
        except Collision:
            continue
        if arrived <= tolerance:
            for pose in poses:
                robot.move_to(arm, pose)
            robot.settle(_SETTLE_S)
            _trim(robot, arm, target, tolerance)
            return
        closest = arrived if closest is None else min(closest, arrived)
    raise ValueError(no_route(target, closest))


#: A homed joint may sit this far from its commanded angle and still count as
#: home. Free-swinging servos settle well under a degree; a wedged one stalls
#: tens of degrees out, which is the case this exists to catch.
_HOME_TOLERANCE_DEG = 5.0


def retreat(robot, arm: str, home: dict[str, float]) -> None:
    """Return `arm` to the `home` pose without sweeping through the furniture.

    Going home used to be one joint-space move, and from over the tray that
    move sweeps the hand down through the table edge — the same wedge reach()
    routes around, pointed the other way. Same treatment: candidate routes,
    each one rehearsed, the first that arrives executed for real. Arrival
    here means the JOINTS land on `home` — home is a pose, not a point — and
    the gripper is exempt, because an arm carrying something home stalls its
    jaws on the payload, which is the grip working.

    When no candidate gets there, the Collision seen in rehearsal is raised:
    the arm has not moved, and the message names what would have been hit.
    """
    candidates: list[list[dict[str, float]]] = [[dict(home)]]
    lifted = _lifted_pose(robot, arm)
    if lifted is not None:
        candidates.append([lifted, dict(home)])
        # Rising is not always enough: from over the tray, the drop to the low
        # home still crosses the table edge. Cross at height to above home's
        # own column first — home's tip stands OFF the table — then drop.
        over_home = _over_home_pose(robot, arm, home)
        if over_home is not None:
            candidates.append([lifted, over_home, dict(home)])
    blocked: Exception | None = None
    for route in candidates:
        try:
            with robot.rehearsal():
                for pose in route:
                    robot.move_to(arm, pose)
                robot.settle(_SETTLE_S)
                landed = robot.get_positions(arm)
                arrived = all(
                    abs(landed[joint] - value) <= _HOME_TOLERANCE_DEG
                    for joint, value in home.items()
                    if joint != "gripper"
                )
        except Collision as e:
            blocked = e
            continue
        if arrived:
            for pose in route:
                robot.move_to(arm, pose)
            robot.settle(_SETTLE_S)
            return
    if blocked is not None:
        raise blocked
    raise Collision(
        f"{arm} cannot get home cleanly from here — every route rehearsed "
        "leaves it stalled against the workcell"
    )


def _lifted_pose(robot, arm: str) -> dict[str, float] | None:
    """The arm raised at its current column to transit height, or None."""
    transit = transit_height(robot.describe_scene()["fixtures"])
    if transit is None:
        return None
    here, _down = robot.tip(arm)
    pose, error = robot.solve_pose(arm, (here[0], here[1], max(transit, here[2])))
    return pose if error <= _TRANSIT_TOLERANCE else None


def _over_home_pose(robot, arm: str, home: dict[str, float]) -> dict[str, float] | None:
    """The arm at transit height above where home's tip stands, or None."""
    transit = transit_height(robot.describe_scene()["fixtures"])
    if transit is None:
        return None
    home_tip, _down = robot.pose_tip(arm, home)
    pose, error = robot.solve_pose(
        arm, (home_tip[0], home_tip[1], max(transit, home_tip[2]))
    )
    return pose if error <= _TRANSIT_TOLERANCE else None


def _trim(robot, arm: str, target: tuple, tolerance: float) -> None:
    """One sag-cancelling correction, kept only if a rehearsal proves it helps.

    Never raises: the arm is already within the caller's tolerance, and a trim
    that cannot be solved, collides, or measures worse is simply not taken.
    """
    tip, _down = robot.tip(arm)
    arrived = _distance(tip, target)
    if arrived <= _TRIM_ABOVE:
        return
    mirrored = tuple(g - (t - g) for g, t in zip(target, tip, strict=True))
    pose, error = robot.solve_pose(arm, mirrored)
    if error > tolerance:
        return
    try:
        with robot.rehearsal():
            robot.move_to(arm, pose)
            robot.settle(_SETTLE_S)
            trimmed, _ = robot.tip(arm)
            better = _distance(trimmed, target)
    except Collision:
        return
    if better < arrived:
        robot.move_to(arm, pose)
        robot.settle(_SETTLE_S)
