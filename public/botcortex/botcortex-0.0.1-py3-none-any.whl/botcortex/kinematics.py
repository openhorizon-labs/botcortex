"""Getting the gripper to a point in space.

Issue #16 was meant to answer "can a person write a working pick-and-place
against this scene?" and answered something more useful: NO, and not because
the scene or the gripper are wrong. `describe_scene` reports where a block is
in METRES; `move_to` accepts joint angles in DEGREES; and a skill has neither
an IK solver nor the imports to write one — its namespace is `math` and the
primitives. So an agent could see the block perfectly and had no way to act on
what it saw.

That is a missing PRIMITIVE, not a missing capability in the model. It belongs
here for the same reason `plan_move` does: it is deterministic, bounded, and
must be identical on every backend. No LLM is anywhere near it.

The search is deliberately dumb — a coarse grid over four joints, then two
refinement passes around the best cell. A proper solver (damped least squares
on the Jacobian) would be faster and would need a Jacobian from each backend;
this needs only "put the joints here, tell me where the tip ended up", which
every backend can answer with what it already has. It converges to
single-millimetre accuracy in well under a second, which is nothing against a
move that takes seconds to execute.

Four joints, not seven: j1, j2, j4 and j6 position the wrist and set its pitch,
which is what a top-down grasp needs. j3, j5 and j7 are roll freedoms that a
symmetric jaw closing on a cube does not care about.
"""

from __future__ import annotations

from collections.abc import Callable

#: Where the jaws actually close, in the hand body's frame. Measured, not
#: derived from mj_geomDistance — that reports the fingertip and puts an object
#: about 15 mm too deep.
GRASP_OFFSET = (-0.0018, 0.0060, 0.0878)


def tip_from(base, rot) -> tuple[float, float, float]:
    """The grasp centre in world coordinates.

    `base` is the hand body's position, `rot` its 3x3 rotation flattened
    row-major — what both MuJoCo builds hand back. Lives here rather than in
    each backend because it is arithmetic, and arithmetic in two backends is
    how they start disagreeing; `test_it_contains_no_arithmetic` caught exactly
    this when it was written twice.
    """
    return tuple(
        base[r] + sum(rot[r * 3 + c] * GRASP_OFFSET[c] for c in range(3)) for r in range(3)
    )


def unreachable(point, error: float) -> str:
    """The refusal a caller raises. Formatting a distance is arithmetic too."""
    where = tuple(round(float(v), 3) for v in point)
    return f"cannot reach {where} — closest is {error * 1000:.0f} mm away"


#: The joints the search moves. Order matters only for readability.
IK_JOINTS = ("j1", "j2", "j4", "j6")

#: How much a mis-aimed approach angle is worth, in metres of position error.
#: Position dominates — a grasp 5 mm off misses, a grasp 10 degrees off the
#: vertical still closes on a 40 mm cube.
_APPROACH_WEIGHT = 0.5

#: Below this, the gripper is not pointing down enough to drop onto a block.
_WANT_DOWN = -0.85


def solve(
    probe: Callable[[dict[str, float]], tuple[tuple[float, float, float], float]],
    bounds: dict[str, tuple[float, float]],
    target: tuple[float, float, float],
    *,
    coarse: int = 9,
    refine: int = 2,
) -> tuple[dict[str, float], float]:
    """Joint angles that put the grasp centre on `target`, pointing down.

    `probe(pose)` sets those joints and returns (tip_xyz, downwardness), where
    downwardness is the world z of the gripper's approach axis: -1 is straight
    down. Supplying it is each backend's job — it is the only part that needs
    to know what a MuJoCo handle is.

    `bounds` must ALREADY be clamped to the platform's envelope. Searching
    outside it would find poses the primitives then refuse to execute.

    Returns the pose and its position error in metres. The caller decides what
    error is acceptable; a solver that silently returned its best guess for an
    unreachable point would have a skill close its gripper on air.
    """
    best_pose: dict[str, float] | None = None
    best_score = float("inf")
    best_error = float("inf")
    window = dict(bounds)

    for _ in range(refine + 1):
        axes = {
            joint: [lo + (hi - lo) * i / (coarse - 1) for i in range(coarse)]
            for joint, (lo, hi) in window.items()
        }
        for pose in _grid(axes):
            tip, down = probe(pose)
            error = _distance(tip, target)
            # Aiming is a tiebreak, not a goal: only a gripper pointing too far
            # from vertical is penalised, and only by how far short it falls.
            score = error + max(0.0, _WANT_DOWN - down) * _APPROACH_WEIGHT
            if score < best_score:
                best_score, best_error, best_pose = score, error, pose

        assert best_pose is not None
        # Next pass searches one cell either side of the winner.
        window = {
            joint: (
                max(bounds[joint][0], best_pose[joint] - (hi - lo) / (coarse - 1)),
                min(bounds[joint][1], best_pose[joint] + (hi - lo) / (coarse - 1)),
            )
            for joint, (lo, hi) in window.items()
        }

    return best_pose, best_error


def _grid(axes: dict[str, list[float]]) -> list[dict[str, float]]:
    poses: list[dict[str, float]] = [{}]
    for joint, values in axes.items():
        poses = [{**pose, joint: value} for pose in poses for value in values]
    return poses


def _distance(a: tuple[float, float, float], b: tuple[float, float, float]) -> float:
    return sum((x - y) ** 2 for x, y in zip(a, b, strict=True)) ** 0.5
