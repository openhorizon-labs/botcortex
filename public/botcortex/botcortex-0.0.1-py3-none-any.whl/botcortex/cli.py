"""BotCortex CLI — `botcortex "task"` (alias `bx`).

Dry-run is the default; real motion requires --execute AND an operator present.
The hardware path lands at milestone 3 — v0 is mock-first by design.
"""

import argparse
import os
import socket
import sys

from botcortex import __version__, config, routines
from botcortex.robot import EStopTriggered, MockRobot


def _robot_identity(name: str | None = None) -> tuple[str, str, int]:
    """What this robot calls itself on the approval screen and in the app.

    The hostname is only a default. Two arms plugged into one machine would
    otherwise pair under the same name and collide on the account's
    (owner, name) index — the second registration silently updating the
    first's row instead of creating its own. --name, or BOTCORTEX_ROBOT_NAME
    in .env for something that survives reboots, settles it.
    """
    chosen = (name or os.environ.get("BOTCORTEX_ROBOT_NAME") or "").strip()
    if not chosen:
        chosen = socket.gethostname().split(".")[0].lower() or "robot"
    return chosen, config.PLATFORM.name, len(config.ARMS)


def _login(port: int, key: str | None = None, name: str | None = None) -> None:
    """Pair this robot with a BotCortex account (RFC 8628 device flow).

    The human never types a secret and the robot never handles a password:
    they approve a short code in a browser where their session already lives,
    and the durable key travels back over TLS.
    """
    from botcortex import cloud

    name, platform, arms = _robot_identity(name)

    # Escape hatch for machines with no browser anywhere near them.
    if key:
        path = cloud.save_key(key)
        print(f"✓ Key saved to {path}")
        return

    try:
        pairing = cloud.start_pairing()
    except (OSError, RuntimeError) as e:
        sys.exit(f"Could not reach BotCortex at {config.API_URL}: {e}")

    cloud.describe(pairing["device_code"], name, platform, arms)

    print()
    print(f"  Open  {pairing['verification_uri']}")
    print(f"  Code  {pairing['user_code']}")
    print()
    print(f"  Approving as \"{name}\" ({platform}, {arms} arms)")
    print("  Waiting for approval…", flush=True)

    try:
        token = cloud.poll_for_approval(
            pairing["device_code"], pairing["interval"], pairing["expires_in"]
        )
        minted = cloud.exchange_for_key(token, name)
    except (OSError, RuntimeError) as e:
        sys.exit(f"\n✗ {e}")
    except KeyboardInterrupt:
        sys.exit("\n  Cancelled.")

    address = cloud.lan_address(port)
    cloud.register(minted["key"], pairing["device_code"], name, platform, arms, address)
    path = cloud.save_key(minted["key"])

    # Read back through the key itself — proves it works before we claim it does.
    config.API_KEY = minted["key"]
    who = cloud.whoami()
    owner = (who or {}).get("user", {}).get("email", "your account")
    credit = (who or {}).get("credit", {}).get("display", "")

    print(f"\n  ✓ Paired with {owner}" + (f" · {credit} credit" if credit else ""))
    print(f"    Key saved to {path}")
    print(f"    Reachable at {address} — it will appear in the app's robot list.")


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="botcortex", description="Teach your robot new tasks by typing."
    )
    parser.add_argument(
        "task", nargs="?", help='what to do, e.g. "wave right arm" — or "login" / "serve"'
    )
    parser.add_argument("--mock", action="store_true", help="run against the in-memory mock robot")
    parser.add_argument(
        "--execute", action="store_true", help="allow real motion (not wired in v0)"
    )
    parser.add_argument("--port", type=int, default=9090, help="port for `botcortex serve`")
    parser.add_argument(
        "--sim", action="store_true", help="serve MuJoCo physics instead of the mock (needs [sim] extra)"
    )
    parser.add_argument("--version", action="store_true", help="print version and exit")
    parser.add_argument(
        "--key",
        help="paste an existing bx_live_ key instead of pairing (headless installs, CI, fleets)",
    )
    parser.add_argument(
        "--name",
        help="what to call this robot in the app (default: hostname, or $BOTCORTEX_ROBOT_NAME)",
    )
    args = parser.parse_args()

    if args.version:
        print(f"botcortex {__version__}")
        return
    if args.execute:
        sys.exit("--execute is not wired yet: real hardware lands at milestone 3.")
    if not args.task:
        parser.print_help()
        return

    if args.task == "login":
        _login(port=args.port, key=args.key, name=args.name)
        return

    if args.task == "serve":
        from botcortex import cloud, server

        backend = "MuJoCo sim" if args.sim else "mock robot"
        # flush: uvicorn logs to stderr while this goes to a block-buffered
        # stdout, so under nohup/systemd the banner sat in the buffer and the
        # NOT PAIRED warning never reached the one place someone would look.
        print(
            f"botcortex serving on http://localhost:{args.port} ({backend}, ws at /ws)",
            flush=True,
        )
        # Say which wallet teaching spends from, every time. The half-paired
        # case is the one that used to be invisible, so it gets a warning and
        # the command that fixes it rather than a quiet status line.
        if cloud.half_paired():
            print(
                "  ! NOT PAIRED — points at BotCortex but has no robot key.\n"
                "    Teaching is refused rather than billed to your own model provider.\n"
                "    Run `botcortex login` to pair it.",
                flush=True,
            )
        elif cloud.paired():
            print("  · paired — teaching spends BotCortex credit", flush=True)
        else:
            print(
                "  · bring-your-own-key — teaching spends your model provider directly",
                flush=True,
            )
        server.serve(port=args.port, sim=args.sim)
        return

    if not args.mock:
        sys.exit('v0 supports --mock only. Try: botcortex --mock "wave right arm"')

    task = args.task.lower()
    if task.startswith("wave"):
        # Deterministic built-in — the zero-API smoke test.
        arm = "left" if "left" in task else "right"
        robot = MockRobot()
        try:
            steps = routines.wave(robot, arm=arm)
        except EStopTriggered as e:
            sys.exit(f"E-STOP: {e}")
        print(
            f"[mock] waved the {arm} arm: {steps} interpolation steps at 20 Hz, "
            "velocity-capped, e-stop checked every step. Final pose: home."
        )
        return

    # Anything else goes through the authoring agent (needs Anthropic credentials).
    import anthropic

    from botcortex.agent import TeachSession

    session = TeachSession(MockRobot())
    print(f"[mock] teaching: {args.task!r} (model {config.MODEL})")
    try:
        result = session.teach(args.task)
    except anthropic.AuthenticationError:
        sys.exit(
            "No Anthropic credentials. Set ANTHROPIC_API_KEY (or `ant auth login`) — "
            "BotCortex is BYO-key and never resells inference."
        )
    except anthropic.APIConnectionError as e:
        sys.exit(f"Could not reach the model API: {e}")

    print(result.text or "(no reply)")
    marker = "✓" if result.outcome == "ok" else "✗"
    print(
        f"[{marker}] outcome={result.outcome} skills_used={result.skills_used or '[]'} "
        f"— episode logged to {config.MEMORY_FILE}"
    )
