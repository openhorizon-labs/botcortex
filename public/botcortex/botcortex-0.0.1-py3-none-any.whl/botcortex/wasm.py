"""WasmRobot — the same primitives, driving MuJoCo compiled to WebAssembly.

This is what lets someone teach a robot with nothing installed: Pyodide runs
this package in the browser, `@mujoco/mujoco` (DeepMind's own WASM build of the
same engine, same version) runs the physics, and the account's credit pays for
the authoring. No runtime on their machine, and no second definition of how the
robot moves.

Read this class looking for arithmetic. There isn't any, and that is the point.
The trajectory comes from `plan_move`, the addresses and units from `JointMap`;
all that is left here is handing MuJoCo the numbers those two produced. A
browser backend that recomputed a velocity cap or a gripper conversion would
agree with the runtime on the day it was written and drift from then on, and
"the skill you taught in the browser runs on your arm" is the promise that pays
for all of this.

Measured parity against the native build, same model and command: 0.003° over a
40-tick move. Bitwise agreement is not achievable across architectures (libm and
FMA differ) and is not what matters — position-commanded, velocity-capped
motion converges on the command.

The JS side owns the module, model and data objects and passes them in; Pyodide
hands them over as JsProxy. Nothing here imports mujoco.
"""

from __future__ import annotations

import time
from collections.abc import Callable
from contextlib import contextmanager
from pathlib import Path

from botcortex import config, kinematics, mjcompat, safety, scene
from botcortex.jointmap import JointMap
from botcortex.platform import Platform
from botcortex.robot import EStopTriggered, clamp_target, plan_move


class WasmRobot:
    """Bimanual sim twin backed by the browser's MuJoCo.

    `mujoco`, `model` and `data` are the JS objects from @mujoco/mujoco.
    `sleep` is how a control tick waits: the default blocks, which is correct
    inside a Web Worker and wrong on the main thread — see the note on
    move_to().
    """

    def __init__(
        self,
        mujoco,
        model,
        data,
        platform: Platform | None = None,
        stop_file: Path | None = None,
        realtime: bool = False,
        sleep: Callable[[float], None] | None = None,
    ):
        self._mujoco = mujoco
        self.model = model
        self.data = data
        self.platform = platform or config.PLATFORM
        # A real path, in Pyodide's in-memory filesystem. Deliberately the same
        # mechanism as every other backend rather than a JS flag: the e-stop
        # check is the one line in this system that must never differ between
        # environments, and `stop_file.exists()` is that line everywhere.
        self.stop_file = stop_file if stop_file is not None else config.STOP_FILE
        self.realtime = realtime
        self._sleep = sleep or time.sleep
        self.motion_log: list[tuple[str, str, dict[str, float]]] = []
        self.torque = {arm: True for arm in self.platform.arms}

        # The whole seam between this backend and the native one. Native
        # resolves through mj_name2id; here the embind accessors do it, because
        # the WASM build's enums are objects rather than ints and cannot be
        # passed to mj_name2id from Python.
        def qpos_adr(name: str) -> int:
            return int(model.jnt_qposadr[int(model.jnt(name).id)])

        def actuator_id(name: str) -> int:
            return int(data.actuator(name).id)

        self.joints = JointMap(self.platform, qpos_adr, actuator_id)

        # One control tick of sim time, however many physics steps that takes.
        self._substeps = max(1, round((1 / config.CONTROL_HZ) / float(model.opt.timestep)))

        #: What a structural link must never touch. Resolved on first need
        #: rather than at construction: a bare arm has no fixtures, and asking
        #: costs a full scene walk that most robots never need.
        self._fixture_names: set[str] | None = None

        #: Where rehearsals park the present moment — one mjData per nesting
        #: depth, built on first use and reused. A single shared spare would be
        #: clobbered by an inner rehearsal, and the outer restore would then put
        #: back the INNER snapshot: garbage, silently.
        self._spares: list = []
        self._depth = 0

        self.reset()

    # --- actuation (indices and units both come from JointMap) ---
    #
    # data.ctrl and data.qpos hand back a FRESH Float64Array view per property
    # access, onto the same WASM heap. Writes stick; identity does not hold, and
    # a view cached across a heap growth would detach. Fetched per tick, which
    # is both correct and cheap.

    def _write_target(self, arm: str, joint: str, deg: float) -> None:
        ctrl = self.data.ctrl
        for index, value in self.joints.ctrl_writes(arm, joint, deg):
            ctrl[index] = value

    def _write_qpos(self, arm: str, joint: str, deg: float) -> None:
        qpos = self.data.qpos
        for index, value in self.joints.qpos_writes(arm, joint, deg):
            qpos[index] = value

    def reset(self) -> None:
        """Snap back to home with no momentum.

        Velocities and accelerations are zeroed FIRST: writing qpos while qvel
        still carries momentum leaves the arm drifting away from the pose we
        just set, and mj_forward does not clear it.
        """
        qvel, qacc = self.data.qvel, self.data.qacc
        for i in range(len(qvel)):
            qvel[i] = 0.0
        for i in range(len(qacc)):
            qacc[i] = 0.0
        for arm in self.platform.arms:
            for joint, value in config.HOME_POSITION.items():
                self._write_target(arm, joint, value)
                self._write_qpos(arm, joint, value)
        self._mujoco.mj_forward(self.model, self.data)

    # --- the primitive interface (mirrors MockRobot and SimRobot exactly) ---

    def get_positions(self, arm: str) -> dict[str, float]:
        return self.joints.positions(arm, self.data.qpos)

    def move_to(self, arm: str, targets: dict[str, float], duration: float | None = None) -> None:
        """One move, at the control rate, e-stop checked before every frame.

        On pacing: the default `sleep` BLOCKS, which is right in a Web Worker
        and wrong on the browser's main thread, where it would freeze the tab
        and — worse — stop the STOP button's message from ever being delivered.
        Whoever constructs this decides; the class does not assume. Passing a
        no-op sleep runs the move as fast as the CPU allows and leaves pacing to
        the caller, which is how the frames become animation.
        """
        frames = plan_move(arm, self.get_positions(arm), targets, duration)
        tick = 1 / config.CONTROL_HZ
        for frame in frames:
            if self.stop_file.exists():
                raise EStopTriggered(f"stop file present: {self.stop_file}")
            for joint, deg in frame.items():
                self._write_target(arm, joint, deg)
            for _ in range(self._substeps):
                self._mujoco.mj_step(self.model, self.data)
            self.motion_log.append(("step", arm, self.get_positions(arm)))
            # A link inside the furniture is a fault, and continuing to command
            # a servo that is already buried only pushes harder. Aborts like
            # the e-stop, and for the same reason.
            hits = self._collisions()
            if hits:
                raise safety.Collision(safety.describe(hits))
            if self.realtime:
                self._sleep(tick)

    def gripper(self, arm: str, position: float) -> None:
        self.move_to(arm, {"gripper": position})

    def set_torque(self, arm: str, enabled: bool) -> None:
        self.torque[arm] = enabled
        self.motion_log.append(("torque", arm, {"enabled": float(enabled)}))

    def clear_errors(self) -> None:
        self.motion_log.append(("clear_errors", "both", {}))

    def replay_trajectory(self, arm: str, waypoints: list[dict[str, float]]) -> None:
        for waypoint in waypoints:
            self.move_to(arm, waypoint)

    # --- Cartesian: the bridge between what describe_scene says and what
    # move_to accepts. See botcortex/kinematics.py for why it exists.

    def _probe(self, arm: str):
        """Hands kinematics.solve a way to try a pose without knowing MuJoCo."""
        mj = self._mujoco
        hand = mj.mj_name2id(
            self.model, mjcompat.enum_value(mj.mjtObj.mjOBJ_BODY), f"openarm_{arm}_hand"
        )

        def probe(pose):
            for joint, deg in pose.items():
                self._write_qpos(arm, joint, deg)
            mj.mj_forward(self.model, self.data)
            rot = mjcompat.row(self.data.xmat, hand, 9)
            base = mjcompat.row(self.data.xpos, hand, 3)
            # rot[8] is the world z of the hand's own z axis: -1 is straight down.
            return kinematics.tip_from(base, rot), rot[8]

        return probe

    def solve_pose(self, arm: str, point) -> tuple[dict[str, float], float]:
        """Joint angles that put the grasp centre on `point`, and the error.

        Restores the arm afterwards: the search walks the joints through
        hundreds of poses, and leaving it wherever the last probe landed would
        teleport the robot as a side effect of asking a question.
        """
        held = self.get_positions(arm)
        try:
            bounds = {
                joint: (clamp_target(arm, joint, -1e6), clamp_target(arm, joint, 1e6))
                for joint in kinematics.IK_JOINTS
            }
            # The joints the search does not move are pinned to home, so the
            # answer depends on the point and the arm and nothing else. See
            # kinematics.NEUTRAL_JOINTS for the measurement that forced this.
            neutral = {
                joint: config.HOME_POSITION[joint] for joint in kinematics.NEUTRAL_JOINTS
            }
            return kinematics.solve(
                self._probe(arm), bounds, tuple(point), neutral=neutral
            )
        finally:
            for joint, deg in held.items():
                self._write_qpos(arm, joint, deg)
            self._mujoco.mj_forward(self.model, self.data)

    def move_to_point(self, arm: str, point, tolerance: float = 0.02) -> None:
        """Move the grasp centre to a point in metres, gripper pointing down.

        Refuses rather than approximating when the point is out of reach — a
        skill that closed its jaws wherever the arm happened to stop would
        report success having grasped nothing.
        """
        pose, error = self.solve_pose(arm, point)
        if error > tolerance:
            raise ValueError(kinematics.unreachable(point, error))
        self.move_to(arm, pose)

    def _collisions(self) -> set[tuple[str, str]]:
        """Arm links currently inside furniture. Empty is healthy.

        Cheap when nothing is touching anything, which is the overwhelmingly
        common case — no contacts means no possible collision, and the fixture
        list never has to be built.
        """
        if int(self.data.ncon) == 0:
            return set()
        if self._fixture_names is None:
            self._fixture_names = set(
                scene.describe(self._mujoco, self.model, self.data)["fixtures"]
            )
        return safety.link_collisions(
            self._mujoco, self.model, self.data, self._fixture_names
        )

    def _spare_data(self):
        """A second mjData, asked for the way JS asks — `new mj.MjData(model)`.

        The one line of rehearsal that differs from the native backend.
        """
        return self._mujoco.MjData.new(self.model)

    @contextmanager
    def rehearsal(self):
        """Run motion for real, then leave no trace of it.

        Identical to SimRobot.rehearsal — same MuJoCo call, same state mask
        (verified 16383 in both builds), same rewind of the motion log. The
        rationale and the measurements are in botcortex.safety.
        """
        if len(self._spares) <= self._depth:
            self._spares.append(self._spare_data())
        spare = self._spares[self._depth]
        safety.hold_state(self._mujoco, self.model, spare, self.data)
        logged = len(self.motion_log)
        paced, self.realtime = self.realtime, False
        self._depth += 1
        try:
            yield
        finally:
            self._depth -= 1
            self.realtime = paced
            del self.motion_log[logged:]
            safety.release_state(self._mujoco, self.model, spare, self.data)

    def describe_scene(self) -> dict[str, dict]:
        """What is on the table. One definition, in botcortex.scene — writing it
        per backend is how two backends start disagreeing."""
        return scene.describe(self._mujoco, self.model, self.data)

    def settle(self, seconds: float = 0.5) -> None:
        """Advance physics with targets held — lets servos finish converging."""
        for _ in range(max(1, round(seconds / float(self.model.opt.timestep)))):
            self._mujoco.mj_step(self.model, self.data)
