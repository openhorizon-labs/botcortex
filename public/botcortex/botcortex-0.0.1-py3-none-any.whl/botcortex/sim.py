"""SimRobot — MuJoCo physics behind the same primitive interface as MockRobot.

The sim2real claim lives here: skills, the executor, clamping, velocity caps,
and the e-stop check are IDENTICAL to the hardware path — only the actuation
backend differs. Position targets go to MuJoCo position servos (the vendored
model converts the upstream torque motors; see platforms/openarm_v1/model/
PROVENANCE.md) and physics advances at the model timestep between control
ticks.

Requires the `sim` extra: uv sync --extra sim  (pip install "botcortex[sim]").
"""

from __future__ import annotations

import time
from contextlib import contextmanager
from pathlib import Path

from botcortex import config, kinematics, mjcompat, safety, scene
from botcortex.jointmap import JointMap
from botcortex.platform import Platform
from botcortex.robot import EStopTriggered, clamp_target, plan_move


class SimRobot:
    """Bimanual sim twin. realtime=True paces wall-clock like hardware would;
    False runs as fast as the CPU allows (tests)."""

    def __init__(
        self,
        platform: Platform | None = None,
        stop_file: Path | None = None,
        realtime: bool = True,
        workcell: bool = True,
    ):
        """workcell=False loads the BARE arm — no table, no trays, no blocks.

        Only for tests of actuation itself. With furniture present a plain
        `move_to(j4=60)` swings the forearm into the table and stops at 49
        degrees, which is correct physics and useless for asserting that a
        servo converges. Anything measuring MANIPULATION wants the default.
        """
        try:
            import mujoco
        except ImportError as e:  # pragma: no cover
            raise ImportError(
                "SimRobot needs MuJoCo — install the sim extra: uv sync --extra sim"
            ) from e

        self._mujoco = mujoco
        # The one line a rehearsal needs that differs between MuJoCo builds:
        # how this one is asked for a second mjData.
        self._spare_data = lambda: mujoco.MjData(self.model)
        #: One mjData per nesting depth — see the note in wasm.py's __init__.
        self._spares: list = []
        self._depth = 0
        self.platform = platform or config.PLATFORM
        # The workcell if the platform has one, the bare arm otherwise — see
        # Platform.world_path. A robot with nothing to manipulate can still be
        # taught poses; it just cannot be measured on manipulation.
        mjcf = self.platform.world_path if workcell else self.platform.mjcf_path
        if mjcf is None or not mjcf.exists():
            raise ValueError(f"platform {self.platform.name!r} has no vendored sim model")

        self.stop_file = stop_file if stop_file is not None else config.STOP_FILE
        self.realtime = realtime
        self.model = mujoco.MjModel.from_xml_path(str(mjcf))
        self.data = mujoco.MjData(self.model)
        self.motion_log: list[tuple[str, str, dict[str, float]]] = []
        self.torque = {arm: True for arm in self.platform.arms}

        def joint_adr(name: str) -> int:
            jid = mujoco.mj_name2id(self.model, mujoco.mjtObj.mjOBJ_JOINT, name)
            if jid < 0:
                raise ValueError(f"joint {name!r} not in model")
            return int(self.model.jnt_qposadr[jid])

        def actuator_id(name: str) -> int:
            aid = mujoco.mj_name2id(self.model, mujoco.mjtObj.mjOBJ_ACTUATOR, name)
            if aid < 0:
                raise ValueError(f"actuator {name!r} not in model")
            return aid

        # Addressing and unit mapping live in JointMap, shared with every other
        # MuJoCo backend. These two lookups are the only part that is ours.
        self.joints = JointMap(self.platform, joint_adr, actuator_id)

        # One control tick advances 1/CONTROL_HZ of sim time.
        self._substeps = max(1, round((1 / config.CONTROL_HZ) / self.model.opt.timestep))

        # Where every free-floating object starts. Captured BEFORE anything
        # moves, because reset has to put the workcell back — an arm that
        # returns home over a table whose blocks are wherever the last attempt
        # left them is not a reset, and every run after the first would start
        # from a different problem.
        self._object_home = {
            adr: [float(v) for v in self.data.qpos[adr : adr + 7]]
            for adr in (
                int(self.model.jnt_qposadr[j])
                for j in range(self.model.njnt)
                if int(self.model.jnt_type[j])
                == mjcompat.enum_value(self._mujoco.mjtJoint.mjJNT_FREE)
            )
        }

        #: What a structural link must never touch. Resolved on first need
        #: rather than at construction: a bare arm has no fixtures, and asking
        #: costs a full scene walk that most robots never need.
        self._fixture_names: set[str] | None = None

        self.reset()

    def reset(self) -> None:
        """Snap back to home with no momentum.

        Velocities and accelerations are zeroed FIRST: writing qpos while qvel
        still carries momentum leaves the arm drifting away from the pose we
        just set, and mj_forward does not clear it.

        Instantaneous by nature, so this exists only where there is no physical
        arm to fling — SimRobot and MockRobot define it; a real-hardware class
        must not, and the server only offers it when the method is present.
        """
        self.data.qvel[:] = 0.0
        self.data.qacc[:] = 0.0
        for adr, pose in self._object_home.items():
            self.data.qpos[adr : adr + 7] = pose
        for arm in self.platform.arms:
            for joint, value in config.HOME_POSITION.items():
                self._write_target(arm, joint, value)
                self._write_qpos(arm, joint, value)
        # self._mujoco, not the local import: mujoco is imported inside
        # __init__ so the module stays optional, and methods can't see it.
        self._mujoco.mj_forward(self.model, self.data)

    # --- actuation (indices and units both come from JointMap) ---

    def _write_target(self, arm: str, joint: str, deg: float) -> None:
        for index, value in self.joints.ctrl_writes(arm, joint, deg):
            self.data.ctrl[index] = value

    def _write_qpos(self, arm: str, joint: str, deg: float) -> None:
        for index, value in self.joints.qpos_writes(arm, joint, deg):
            self.data.qpos[index] = value

    # --- the primitive interface (mirrors MockRobot exactly) ---

    def get_positions(self, arm: str) -> dict[str, float]:
        return self.joints.positions(arm, self.data.qpos)

    def move_to(self, arm: str, targets: dict[str, float], duration: float | None = None) -> None:
        # Same trajectory as every other backend — see robot.plan_move. All this
        # class adds is where the frames are written and that physics runs.
        frames = plan_move(arm, self.get_positions(arm), targets, duration)
        tick = 1 / config.CONTROL_HZ
        t0 = time.monotonic()
        for i, frame in enumerate(frames, start=1):
            if self.stop_file.exists():
                raise EStopTriggered(f"stop file present: {self.stop_file}")
            for joint, deg in frame.items():
                self._write_target(arm, joint, deg)
            for _ in range(self._substeps):
                self._mujoco.mj_step(self.model, self.data)
            self.motion_log.append(("step", arm, self.get_positions(arm)))
            # A link inside the furniture is a fault, and continuing to command
            # a servo that is already buried only pushes harder. Aborts like
            # the e-stop, and for the same reason.
            hits = self._collisions()
            if hits:
                raise safety.Collision(safety.describe(hits))
            if self.realtime:
                remaining = t0 + i * tick - time.monotonic()
                if remaining > 0:
                    time.sleep(remaining)

    def gripper(self, arm: str, position: float) -> None:
        self.move_to(arm, {"gripper": position})

    def set_torque(self, arm: str, enabled: bool) -> None:
        self.torque[arm] = enabled
        self.motion_log.append(("torque", arm, {"enabled": float(enabled)}))

    def clear_errors(self) -> None:
        self.motion_log.append(("clear_errors", "both", {}))

    def replay_trajectory(self, arm: str, waypoints: list[dict[str, float]]) -> None:
        for waypoint in waypoints:
            self.move_to(arm, waypoint)

    # --- Cartesian: the bridge between what describe_scene says and what
    # move_to accepts. See botcortex/kinematics.py for why it exists.

    def _probe(self, arm: str):
        """Hands kinematics.solve a way to try a pose without knowing MuJoCo."""
        mj = self._mujoco
        hand = mj.mj_name2id(
            self.model, mjcompat.enum_value(mj.mjtObj.mjOBJ_BODY), f"openarm_{arm}_hand"
        )

        def probe(pose):
            for joint, deg in pose.items():
                self._write_qpos(arm, joint, deg)
            mj.mj_forward(self.model, self.data)
            rot = mjcompat.row(self.data.xmat, hand, 9)
            base = mjcompat.row(self.data.xpos, hand, 3)
            # rot[8] is the world z of the hand's own z axis: -1 is straight down.
            return kinematics.tip_from(base, rot), rot[8]

        return probe

    def solve_pose(self, arm: str, point) -> tuple[dict[str, float], float]:
        """Joint angles that put the grasp centre on `point`, and the error.

        Restores the arm afterwards: the search walks the joints through
        hundreds of poses, and leaving it wherever the last probe landed would
        teleport the robot as a side effect of asking a question.
        """
        held = self.get_positions(arm)
        try:
            bounds = {
                joint: (clamp_target(arm, joint, -1e6), clamp_target(arm, joint, 1e6))
                for joint in kinematics.IK_JOINTS
            }
            return kinematics.solve(self._probe(arm), bounds, tuple(point))
        finally:
            for joint, deg in held.items():
                self._write_qpos(arm, joint, deg)
            self._mujoco.mj_forward(self.model, self.data)

    def move_to_point(self, arm: str, point, tolerance: float = 0.02) -> None:
        """Move the grasp centre to a point in metres, gripper pointing down.

        Refuses rather than approximating when the point is out of reach — a
        skill that closed its jaws wherever the arm happened to stop would
        report success having grasped nothing.
        """
        pose, error = self.solve_pose(arm, point)
        if error > tolerance:
            raise ValueError(kinematics.unreachable(point, error))
        self.move_to(arm, pose)

    def _collisions(self) -> set[tuple[str, str]]:
        """Arm links currently inside furniture. Empty is healthy.

        Cheap when nothing is touching anything, which is the overwhelmingly
        common case — no contacts means no possible collision, and the fixture
        list never has to be built.
        """
        if int(self.data.ncon) == 0:
            return set()
        if self._fixture_names is None:
            self._fixture_names = set(
                scene.describe(self._mujoco, self.model, self.data)["fixtures"]
            )
        return safety.link_collisions(
            self._mujoco, self.model, self.data, self._fixture_names
        )

    @contextmanager
    def rehearsal(self):
        """Run motion for real, then leave no trace of it.

        Everything inside really happens — full physics, real contacts, a
        Collision raised exactly where one would be — and then the simulation
        is put back to the instant the block was entered. That is what lets the
        runtime answer "will this break something?" before the arm moves,
        rather than after.

        Exact, not approximate: see the measurements in botcortex.safety. The
        motion log is rewound too, so a rehearsal cannot pad the step count a
        real run reports.

        Pacing is off inside — a rehearsal nobody can see has nothing to pace
        against, and a 17-second skill would take 17 seconds to check.

        Only backends with physics define this. A robot with none must NOT
        pretend, or "rehearsed clean" becomes a sentence that means nothing.
        """
        if len(self._spares) <= self._depth:
            self._spares.append(self._spare_data())
        spare = self._spares[self._depth]
        safety.hold_state(self._mujoco, self.model, spare, self.data)
        logged = len(self.motion_log)
        paced, self.realtime = self.realtime, False
        self._depth += 1
        try:
            yield
        finally:
            self._depth -= 1
            self.realtime = paced
            del self.motion_log[logged:]
            safety.release_state(self._mujoco, self.model, spare, self.data)

    def describe_scene(self) -> dict[str, dict]:
        """What is on the table. One definition, in botcortex.scene — writing it
        per backend is how two backends start disagreeing."""
        return scene.describe(self._mujoco, self.model, self.data)

    def settle(self, seconds: float = 0.5) -> None:
        """Advance physics with targets held — lets servos finish converging."""
        for _ in range(max(1, round(seconds / self.model.opt.timestep))):
            self._mujoco.mj_step(self.model, self.data)
