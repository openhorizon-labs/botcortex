"""Episodic failure memory — the moat.

Every task attempt appends one JSON line; at authoring time the most relevant
episodes are recalled and injected into the agent's context before it writes
code. Failure-diagnostic feedback improves manipulation success by up to +35%
(RoboInspector, arXiv 2508.21378). Traces stay on-device — syncing them is the
paid cloud feature, later.
"""

import json
import re
from datetime import UTC, datetime
from pathlib import Path

STOPWORDS = frozenset(
    [
        "a",
        "an",
        "and",
        "are",
        "as",
        "at",
        "be",
        "by",
        "for",
        "from",
        "has",
        "i",
        "in",
        "is",
        "it",
        "of",
        "on",
        "or",
        "that",
        "the",
        "this",
        "to",
        "was",
        "with",
    ]
)


def _terms(text: str) -> set[str]:
    return {w for w in re.findall(r"[a-z0-9_]+", text.lower()) if w not in STOPWORDS}


class EpisodeMemory:
    def __init__(self, path: Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def log(
        self,
        task: str,
        skills_used: list[str],
        outcome: str,
        error: str | None = None,
        lesson: str | None = None,
    ) -> dict:
        episode = {
            "ts": datetime.now(UTC).isoformat(timespec="seconds"),
            "task": task,
            "skills_used": skills_used,
            "outcome": outcome,  # "ok" | "fail"
            "error": error,
            "lesson": lesson,
        }
        with self.path.open("a") as f:
            f.write(json.dumps(episode) + "\n")
        return episode

    def all(self) -> list[dict]:
        if not self.path.exists():
            return []
        episodes = []
        for line in self.path.read_text().splitlines():
            try:
                episodes.append(json.loads(line))
            except json.JSONDecodeError:
                continue
        return episodes

    def recall(self, task: str, limit: int = 5) -> list[dict]:
        """Keyword-overlap retrieval, v0. Embeddings can replace this wholesale
        later — the interface (task in, episodes out) is the stable part."""
        query = _terms(task)
        if not query:
            return []
        scored = []
        for i, ep in enumerate(self.all()):
            hay = _terms(f"{ep.get('task', '')} {ep.get('lesson') or ''} {ep.get('error') or ''}")
            score = len(query & hay)
            if score:
                scored.append((score, i, ep))
        scored.sort(key=lambda t: (-t[0], -t[1]))  # relevance, then recency
        return [ep for _, _, ep in scored[:limit]]

    def annotate_last(self, lesson: str) -> bool:
        """Attach a lesson to the most recent episode (the agent reflects after
        the attempt, and the attempt is already on disk)."""
        episodes = self.all()
        if not episodes:
            return False
        episodes[-1]["lesson"] = lesson
        with self.path.open("w") as f:
            for ep in episodes:
                f.write(json.dumps(ep) + "\n")
        return True
