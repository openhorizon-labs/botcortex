"""Getting the gripper to a point in space.

Issue #16 was meant to answer "can a person write a working pick-and-place
against this scene?" and answered something more useful: NO, and not because
the scene or the gripper are wrong. `describe_scene` reports where a block is
in METRES; `move_to` accepts joint angles in DEGREES; and a skill has neither
an IK solver nor the imports to write one — its namespace is `math` and the
primitives. So an agent could see the block perfectly and had no way to act on
what it saw.

That is a missing PRIMITIVE, not a missing capability in the model. It belongs
here for the same reason `plan_move` does: it is deterministic, bounded, and
must be identical on every backend. No LLM is anywhere near it.

The search is deliberately dumb — a coarse grid over four joints, then two
refinement passes around the best cell. A proper solver (damped least squares
on the Jacobian) would be faster and would need a Jacobian from each backend;
this needs only "put the joints here, tell me where the tip ended up", which
every backend can answer with what it already has. It converges to
single-millimetre accuracy in well under a second, which is nothing against a
move that takes seconds to execute.

Four joints, not seven: j1, j2, j4 and j6 position the wrist and set its pitch,
which is what a top-down grasp needs. j3, j5 and j7 are the ones left out —
and they are PINNED to the home pose rather than left wherever the arm
happened to be, which is the difference between a primitive and a coin toss.

That claim used to read "roll freedoms that a symmetric jaw closing on a cube
does not care about". True of j5 and j7. Measured false of j3: aiming at a
point 12 cm above the blue block, the same call answers 2 mm from home, 2.7 mm
with j5 at 40 degrees, 1.7 mm with j7 at 40 — and 110 mm with j3 at 30, which
is a refusal. j3 swings the elbow, so it moves the wrist through space, and
leaving it out of the search while letting it vary made the REACHABLE SET
depend on hidden state nobody chose.

An agent hit exactly that: four skills authored and run, each refused at a
waypoint the arm could reach perfectly well from a different starting pose,
with nothing in the message to suggest the starting pose was the variable. The
answer now depends on the point and the arm, and on nothing else.
"""

from __future__ import annotations

from collections.abc import Callable

from botcortex import scene
from botcortex.safety import Collision, ObjectMotionGuard

#: Where OpenArm's jaws actually close, in the hand body's frame. Measured,
#: not derived from mj_geomDistance — that reports the fingertip and puts an
#: object about 15 mm too deep. Lives in platforms/openarm_v1/platform.json
#: now; kept here as the documented origin of the number.
OPENARM_GRASP_OFFSET = (-0.0018, 0.0060, 0.0878)


def tip_from(base, rot, offset=OPENARM_GRASP_OFFSET) -> tuple[float, float, float]:
    """The grasp centre in world coordinates.

    `base` is the hand body's position, `rot` its 3x3 rotation flattened
    row-major — what both MuJoCo builds hand back — and `offset` where the
    jaws close in the hand's own frame (Platform.grasp_offset). Lives here
    rather than in each backend because it is arithmetic, and arithmetic in
    two backends is how they start disagreeing; `test_it_contains_no_arithmetic`
    caught exactly this when it was written twice.
    """
    return tuple(base[r] + sum(rot[r * 3 + c] * offset[c] for c in range(3)) for r in range(3))


def calibrated_offset(offset, error) -> tuple[float, float, float]:
    """The grasp offset the CONTROLLER believes: the descriptor's plus the
    calibration error it is carrying (zero on the product path; the research
    harness injects a frame fault here). Arithmetic, so it lives here and not
    in each backend — see tip_from."""
    return tuple(float(o) + float(e) for o, e in zip(offset, error, strict=True))


def downwardness(rot, axis: int = 2) -> float:
    """World z of the hand's approach axis: -1 is pointing straight down."""
    return rot[6 + axis]


def unreachable(point, error: float) -> str:
    """The refusal a caller raises. Formatting a distance is arithmetic too."""
    where = tuple(round(float(v), 3) for v in point)
    return f"cannot reach {where} — closest is {error * 1000:.0f} mm away"


#: Which joints the search moves, and which it pins to home, are declared per
#: platform (Platform.ik_joints / neutral_joints): j1, j2, j4, j6 with j3, j5,
#: j7 pinned on a seven-joint anthropomorphic arm; all three on a RoArm. The
#: pinned joints are held at the home pose so that "can this arm reach this
#: point" has one answer, and returned in the solved pose too — a solver that
#: assumed them and a move that did not command them would disagree the
#: moment the arm was anywhere but home.

#: How much a mis-aimed approach angle is worth, in metres of position error.
#: Position dominates — a grasp 5 mm off misses, a grasp 10 degrees off the
#: vertical still closes on a 40 mm cube.
_APPROACH_WEIGHT = 0.5

#: Below this, the search starts nudging poses toward vertical. A TIEBREAK,
#: nothing more: red and green blocks lift at down = -0.50, and grid grasps
#: lift at -0.43, so a tilted hand closes on a cube perfectly well and no
#: hard orientation constraint is justified by any measurement we have.
#:
#: This constant was once suspected of causing every grasp failure, and the
#: KNOWN DEFECT note that lived here sent a session hunting orientation
#: weights (measured useless: 7/15 at every _APPROACH_WEIGHT from 0.5 to 20)
#: and a hard down filter (measured worse: 196 mm on a point previously hit
#: to 2 mm). The real fault was never the POSE — it was the PATH. From the
#: home pose the tip hangs at z = 0.075, below the 0.20 tabletop, and a
#: joint-space move from there to a pose over the table drags a finger onto
#: the tabletop on the way. The wrist wedges against it — j7 saturated at
#: exactly its 7 N·m limit — and the arm stops up to 285 mm short with no
#: fault raised anywhere, because a finger touching a fixture is legal
#: (botcortex.safety) and nothing above the actuator sees saturation.
#:
#: Measured with the same solved pose, same target, blue block: direct
#: transit arrives 285 mm off and the grasp closes on air; raising the tip to
#: transit height first arrives 12 mm off and the block lifts 11 cm. That
#: measurement is why reach() below routes and verifies instead of trusting
#: one joint-space move.
_WANT_DOWN = -0.85


def solve(
    probe: Callable[[dict[str, float]], tuple[tuple[float, float, float], float]],
    bounds: dict[str, tuple[float, float]],
    target: tuple[float, float, float],
    *,
    neutral: dict[str, float] | None = None,
    coarse: int = 9,
    refine: int = 2,
    want_down: float = _WANT_DOWN,
    approach_weight: float = _APPROACH_WEIGHT,
) -> tuple[dict[str, float], float]:
    """Joint angles that put the grasp centre on `target`, pointing down.

    `probe(pose)` sets those joints and returns (tip_xyz, downwardness), where
    downwardness is the world z of the gripper's approach axis: -1 is straight
    down. Supplying it is each backend's job — it is the only part that needs
    to know what a MuJoCo handle is.

    `bounds` must ALREADY be clamped to the platform's envelope. Searching
    outside it would find poses the primitives then refuse to execute.

    Returns the pose and its position error in metres. The caller decides what
    error is acceptable; a solver that silently returned its best guess for an
    unreachable point would have a skill close its gripper on air.
    """
    # Every probe carries the pinned joints, so the search measures the arm in
    # one configuration rather than in whatever one the last move left behind.
    held = dict(neutral or {})

    best_pose: dict[str, float] | None = None
    best_score = float("inf")
    best_error = float("inf")
    window = dict(bounds)

    for _ in range(refine + 1):
        axes = {
            joint: [lo + (hi - lo) * i / (coarse - 1) for i in range(coarse)]
            for joint, (lo, hi) in window.items()
        }
        for pose in _grid(axes):
            tip, down = probe({**held, **pose})
            error = _distance(tip, target)
            # Aiming is a tiebreak, not a goal: only a gripper pointing too far
            # from vertical is penalised, and only by how far short it falls.
            # `down` is -1 straight down, so "too far from vertical" is down
            # ABOVE want_down. The subtraction used to run the other way and
            # penalised the vertical poses instead — invisible on OpenArm,
            # whose pinned-joint search rarely reaches a vertical pose anyway,
            # and the reason a Panda solved a block with its fingers pointing
            # 30 degrees UP and drove its palm into the bench.
            score = error + max(0.0, down - want_down) * approach_weight
            if score < best_score:
                best_score, best_error, best_pose = score, error, pose

        assert best_pose is not None
        # Next pass searches one cell either side of the winner.
        window = {
            joint: (
                max(bounds[joint][0], best_pose[joint] - (hi - lo) / (coarse - 1)),
                min(bounds[joint][1], best_pose[joint] + (hi - lo) / (coarse - 1)),
            )
            for joint, (lo, hi) in window.items()
        }

    # The pinned joints ride back with the answer: the caller MOVES to this
    # pose, and a move that left j3 where it was would not arrive where the
    # search said it would.
    return {**held, **best_pose}, best_error


def _grid(axes: dict[str, list[float]]) -> list[dict[str, float]]:
    poses: list[dict[str, float]] = [{}]
    for joint, values in axes.items():
        poses = [{**pose, joint: value} for pose in poses for value in values]
    return poses


def _distance(a: tuple[float, float, float], b: tuple[float, float, float]) -> float:
    return sum((x - y) ** 2 for x, y in zip(a, b, strict=True)) ** 0.5


# --- routing: getting there without wedging on the furniture ----------------
#
# A solved pose says where the arm CAN be, not that a joint-space move from
# here will arrive there. From the low home pose, moves to poses over the
# table drag a finger onto the tabletop mid-transit; the wrist wedges, the
# servo saturates, and the arm stops hundreds of millimetres short with no
# fault raised anywhere (see the _WANT_DOWN note for the measurements). So a
# Cartesian move is a ROUTE — tried in rehearsal, measured on arrival, and
# only a route that verifiably arrives is executed for real.
#
# KNOWN LIMIT, measured against scripts/grasp_bench.py: a block within ~2 cm
# of a tray rim, at the x positions where the arm's yaw happens to align the
# jaw closing axis with the block-to-wall direction, cannot be grasped by
# arriving and closing. The close pushes the block against the rim — one
# finger on the cube at 6 N, the other stalled on the rim, the gripper stuck
# around -43 of the commanded 0. Levers measured DEAD before spending time
# on them again: wrist roll (j7 at these tilted poses lands 126-218 mm off),
# tighter arrival (iterated trim reached 5.5 mm, better than a succeeding
# cell, still jammed), and kinematic finger-contact screens (a fatal rim
# clip reads 2.3 mm, a benign tabletop brush reads 2.5 mm, and one jamming
# cell reads clean). What does work is a STRATEGY — grasp biased away from
# the wall, or slide the block clear first — which is the authoring agent's
# layer, fed by tool_gripper reporting a stalled close instead of silence.

#: How far above the tallest fixture a transit waypoint crosses the workcell.
#: Covers the fingers hanging below the grasp centre, with margin for a tilted
#: hand. Measured: 0.18 above the tabletop clears every wedge grasp_bench
#: provokes; 0 (the old behaviour) wedges on 7 of 15.
TRANSIT_CLEARANCE = 0.18

#: Transit waypoints may be sloppy — they are flown through, not grasped at.
#: A route is only rejected when a waypoint cannot be solved to within this.
_TRANSIT_TOLERANCE = 0.05

#: Servo convergence time after the final waypoint, before arrival is
#: measured. The identical settle runs in the rehearsal and in the real
#: execution, so the rehearsed arrival is evidence about the real one.
_SETTLE_S = 0.3

#: Above this arrival error, reach() tries one trim move. Position servos sag
#: under gravity — measured 9–12 mm at the far edge of the table against a
#: solve error of 2 mm — and the jaw pad is only 14.8 mm long, so a grasp
#: that ARRIVES by the transit's standard can still clip past the block:
#: at 11 mm the jaws close beside the cube, at 7 mm they catch it. The trim
#: aims at the target mirrored through the miss (2·target − tip), which
#: cancels sag exactly when the sag is locally constant, and it is kept only
#: when a rehearsal measures it landing closer than where the arm already is.
_TRIM_ABOVE = 0.006


def transit_height(fixtures: dict[str, dict]) -> float | None:
    """Where transits cross the workcell: above everything that cannot move.

    None when there is nothing to clear — a bare arm needs no transit height,
    and inventing one would refuse points a bare arm can simply go to.
    """
    tops = [
        body["position"][2] + body["size_m"][2] / 2
        for body in fixtures.values()
        if len(body.get("position", ())) >= 3 and len(body.get("size_m", ())) >= 3
    ]
    return max(tops) + TRANSIT_CLEARANCE if tops else None


#: Room left beside an object already in the container, so the jaws can come
#: down next to it rather than onto it.
NEIGHBOUR_GAP = 0.02

#: How far inside the container's floor an object is placed. Small on purpose
#: and separate from NEIGHBOUR_GAP: the walls are 5-10 mm and the jaws close
#: around the object, not outside it. One shared 25 mm margin left a 120 mm
#: tray with a single usable spot, so the second block was told the tray was
#: full while two thirds of it stood empty.
WALL_MARGIN = 0.008


def free_point(
    scene: dict,
    fixture: str,
    *,
    carrying: str | None = None,
) -> tuple[float, float, float] | None:
    """The first clear spot in `fixture`, ignoring whether the arm can get
    there. `free_spots` is the full list; see it for why that matters."""
    spots = free_spots(scene, fixture, carrying=carrying)
    return spots[0] if spots else None


def free_spots(
    scene: dict,
    fixture: str,
    *,
    carrying: str | None = None,
) -> list[tuple[float, float, float]]:
    """Where in `fixture` an object can be set down without hitting what is
    already in it. None when it is full, or there is no such fixture.

    The failure this exists to end: "put every block in the tray" put every
    block at the tray's CENTRE, so the first one landed, the second one was
    lowered onto the first, and the transit guard refused the move for
    displacing a block the arm was not holding. Nothing was wrong with the
    route — the destination was occupied, and neither the agent nor the skill
    had any way to ask where a free spot was. `can_reach` exists for exactly
    this shape of question about reachability; this is the same for space.

    Returns the point the object's CENTRE should end up at, which is what
    `research.contracts` already means by resting in a fixture, so a skill
    moves the grasp centre there and opens the jaws.
    """
    target = (scene.get("fixtures") or {}).get(fixture)
    if not target:
        return []
    size = target.get("size_m") or [0, 0, 0]
    centre = target.get("position") or [0, 0, 0]
    if len(size) < 3 or len(centre) < 3:
        return []

    held = (scene.get("objects") or {}).get(carrying) if carrying else None
    # An object's own footprint decides both how much room it needs and how
    # high its centre sits once it is resting on the floor of the fixture.
    span = max((held or {}).get("size_m", [0.04, 0.04, 0.04])[:2], default=0.04)
    tall = (held or {}).get("size_m", [0.04, 0.04, 0.04])[2]
    floor = centre[2] + size[2] / 2
    z = floor + tall / 2

    # Usable half-extent for an OFF-CENTRE spot: the floor, minus the object,
    # minus a gap for the fingers. The centre itself is always a candidate, gap
    # or no gap — the pocket is 66 mm across for a 40 mm block on purpose, a
    # deliberately tight fit that the benchmark places into, and a rule that
    # refused it would refuse the task this workcell was built for.
    reach_x = size[0] / 2 - span / 2 - WALL_MARGIN
    reach_y = size[1] / 2 - span / 2 - WALL_MARGIN

    taken = [
        body["position"]
        for name, body in (scene.get("objects") or {}).items()
        if name != carrying and len(body.get("position", ())) >= 3
    ]

    def clear(x: float, y: float) -> bool:
        # Only what is at this height matters: a block on the table beside the
        # tray is not in the way of one going into it.
        return all(
            abs(pos[2] - z) > max(tall, 0.02)
            or max(abs(pos[0] - x), abs(pos[1] - y)) >= span + NEIGHBOUR_GAP
            for pos in taken
        )

    # Two layouts, and which one applies is a question about the container,
    # not a preference. A ring of spots around the edge holds several objects;
    # the centre holds one and rules out the ring, because a 40 mm block in
    # the middle of a 170 mm tray sits within the neighbour gap of every
    # corner. So: use the ring when opposite sides of it are far enough apart
    # to hold two objects, and the centre when they are not. Getting this
    # backwards gave a tray that held exactly one block and told the second
    # delivery it was full.
    separation = span + NEIGHBOUR_GAP
    ring: list[tuple[float, float]] = []
    if reach_x > 0 and reach_y > 0 and 2 * max(reach_x, reach_y) >= separation:
        ring = [(sx * reach_x, sy * reach_y) for sx in (-1, 1) for sy in (-1, 1)]
        ring += [(sx * reach_x, 0.0) for sx in (-1, 1)]
        ring += [(0.0, sy * reach_y) for sy in (-1, 1)]
    # Nearest the arm's base first. A tray's far corner is the spot most
    # likely to be a point the arm wedges reaching into — measured: of the
    # eight spots in the OpenArm's tray one is unroutable and it is the far
    # one, and on the RoArm only the near side is routable at all.
    ring.sort(key=lambda d: (centre[0] + d[0]) ** 2 + (centre[1] + d[1]) ** 2)
    offsets = ring or [(0.0, 0.0)]
    out: list[tuple[float, float, float]] = []
    for dx, dy in offsets:
        x, y = centre[0] + dx, centre[1] + dy
        if clear(x, y) and all(max(abs(x - p[0]), abs(y - p[1])) > 1e-6 for p in out):
            out.append((round(x, 4), round(y, 4), round(z, 4)))
    return out


def routes(
    here: tuple[float, float, float],
    target: tuple[float, float, float],
    transit_z: float | None,
) -> list[tuple[tuple[float, float, float], ...]]:
    """Candidate waypoint chains, cheapest first.

    Direct; rise at the current column then go; rise, cross at transit
    height above the target, then descend. Duplicates collapse — over an
    empty floor all three are the same one-move route.
    """
    direct = (target,)
    if transit_z is None:
        return [direct]
    lift_here = (here[0], here[1], max(transit_z, here[2]))
    lift_there = (target[0], target[1], max(transit_z, target[2]))
    candidates = [direct, (lift_here, target), (lift_here, lift_there, target)]
    out: list[tuple] = []
    for route in candidates:
        cleaned = tuple(
            point
            for i, point in enumerate(route)
            if i == 0 or _distance(point, route[i - 1]) > 1e-9
        )
        if cleaned not in out:
            out.append(cleaned)
    return out


def no_route(point, closest: float | None) -> str:
    """The refusal when every route wedged or collided."""
    where = tuple(round(float(v), 3) for v in point)
    if closest is None:
        return f"no clear route to {where} — every path tried collided with the workcell"
    return (
        f"no clear route to {where} — the arm wedges against the workcell in "
        f"transit and ends {closest * 1000:.0f} mm away on the best path tried"
    )


#: Below a fixture's top plus this, the fingers cannot put the grasp centre
#: there — they hang about 15 mm below it and land on the surface first.
#: Measured: picking from inside the tray works with the grasp centre 20 mm
#: above the tray floor, and every attempt below that wedges.
_SURFACE_CLEARANCE = 0.02


def too_low(target, fixtures: dict[str, dict]) -> str:
    """Why a refused point near a surface was never going to work — or "".

    The kinematic solver happily places the grasp centre AT a tray floor,
    because probing writes qpos and ignores contacts; only the transit
    verification then discovers the fingers cannot get there. Watched live:
    an agent aimed its placement at a tray's own body z — the fixture's
    ORIGIN, inside its floor — was told "the arm wedges in transit", and
    retried by moving sideways. The message pointed at routing when the
    problem was depth, so the diagnosis now rides with the refusal.
    """
    within = scene.resting_in(target, fixtures)
    if within is None:
        return ""
    body = fixtures[within]
    top = body["position"][2] + body["size_m"][2] / 2
    if target[2] >= top + _SURFACE_CLEARANCE:
        return ""
    floor = round(top + _SURFACE_CLEARANCE, 3)
    return (
        f". That point is essentially at {within}'s surface: the fingers hang "
        f"below the grasp centre, so nothing under about z={floor} is reachable "
        f"there. To PLACE an object, release it above the surface instead — "
        "open the gripper with the object just over its resting height and let "
        "it drop the last centimetre."
    )


def reach(
    robot,
    arm: str,
    point,
    tolerance: float = 0.02,
    *,
    may_move: tuple[str, ...] = (),
    observe=None,
    pinned: dict[str, float] | None = None,
) -> None:
    """Put the grasp centre on `point` — routed, rehearsed, and verified.

    `may_move` names objects this move is allowed to displace (a push's
    target); `observe` is the scene source the guards read, the robot's own
    by default. See safety.ObjectMotionGuard for both.

    The whole Cartesian move, shared by every physics backend the way
    plan_move is: solve the target, then try routes in order, each one run
    first in a rehearsal and measured on arrival. The first route whose
    rehearsed tip lands within `tolerance` of the target is executed for
    real — and because a rehearsal restores the exact state it started from,
    the real run repeats the rehearsed one identically.

    Raises ValueError when the point is out of reach (the solver cannot get
    within `tolerance`) or when no route arrives — an arm that silently
    stopped 285 mm short and let the jaws close on air is the failure this
    function exists to end. Needs a backend with `rehearsal()`, which is
    every backend that can answer solve_pose in the first place.
    """
    target = tuple(float(v) for v in point)
    solved: dict[tuple, tuple[dict[str, float], float]] = {}

    def pose_for(waypoint: tuple, gate: float) -> dict[str, float] | None:
        if waypoint not in solved:
            # Only pass `pinned` when there is one, so a backend that predates
            # the override still answers.
            solved[waypoint] = (
                robot.solve_pose(arm, waypoint, pinned=pinned)
                if pinned
                else robot.solve_pose(arm, waypoint)
            )
        pose, error = solved[waypoint]
        return pose if error <= gate else None

    if pose_for(target, tolerance) is None:
        raise ValueError(unreachable(target, solved[target][1]))

    observe = observe or robot.describe_scene
    here, _down = robot.tip(arm)
    transit = transit_height(observe()["fixtures"])
    closest: float | None = None
    blocked: str | None = None
    #: The best route that arrived close but not close enough: executed
    #: and trimmed when nothing arrives outright. Position servos sag by a
    #: centimetre at the far edge of a bench, which is exactly what the
    #: trim cancels — refusing a tight tolerance before trimming refused
    #: every precise placement on a sagging arm.
    near: tuple[float, list[dict[str, float]]] | None = None
    guard = ObjectMotionGuard(robot, arm, may_move, observe)
    for route in routes(here, target, transit):
        poses = [pose_for(waypoint, _TRANSIT_TOLERANCE) for waypoint in route[:-1]]
        poses.append(pose_for(target, tolerance))
        if any(pose is None for pose in poses):
            continue
        try:
            with robot.rehearsal():
                for pose in poses:
                    robot.move_to(arm, pose)
                    guard.check()
                robot.settle(_SETTLE_S)
                guard.check()
                tip, _ = robot.tip(arm)
                arrived = _distance(tip, target)
        except Collision as error:
            blocked = str(error)
            continue
        if arrived <= tolerance:
            for pose in poses:
                robot.move_to(arm, pose)
                guard.check()
            robot.settle(_SETTLE_S)
            guard.check()
            _trim(robot, arm, target, tolerance, may_move, observe)
            return
        closest = arrived if closest is None else min(closest, arrived)
        if arrived <= _TRIMMABLE and (near is None or arrived < near[0]):
            near = (arrived, poses)
    if near is not None:
        for pose in near[1]:
            robot.move_to(arm, pose)
            guard.check()
        robot.settle(_SETTLE_S)
        guard.check()
        for _ in range(_TRIM_PASSES):
            _trim(robot, arm, target, _TRIMMABLE, may_move, observe)
            tip, _ = robot.tip(arm)
            if _distance(tip, target) <= tolerance:
                return
        tip, _ = robot.tip(arm)
        closest = _distance(tip, target)
    raise ValueError(
        no_route(target, closest)
        + too_low(target, observe()["fixtures"])
        + (f". Last rejected route: {blocked}" if blocked else "")
    )


#: A route that lands within this of the target is worth executing and
#: trimming when none lands within the caller's tolerance; beyond it the
#: miss is not sag, and trimming would only chase it.
_TRIMMABLE = 0.03
#: Sag-cancelling corrections after a near miss, each rehearsed first.
_TRIM_PASSES = 3


#: A homed joint may sit this far from its commanded angle and still count as
#: home. Free-swinging servos settle well under a degree; a wedged one stalls
#: tens of degrees out, which is the case this exists to catch.
_HOME_TOLERANCE_DEG = 5.0


def retreat(robot, arm: str, home: dict[str, float], observe=None) -> None:
    """Return `arm` to the `home` pose without sweeping through the furniture.

    Going home used to be one joint-space move, and from over the tray that
    move sweeps the hand down through the table edge — the same wedge reach()
    routes around, pointed the other way. Same treatment: candidate routes,
    each one rehearsed, the first that arrives executed for real. Arrival
    here means the JOINTS land on `home` — home is a pose, not a point — and
    the gripper is exempt, because an arm carrying something home stalls its
    jaws on the payload, which is the grip working.

    When no candidate gets there, the Collision seen in rehearsal is raised:
    the arm has not moved, and the message names what would have been hit.
    """
    observe = observe or robot.describe_scene
    candidates: list[list[dict[str, float]]] = [[dict(home)]]
    lifted = _lifted_pose(robot, arm, observe)
    if lifted is not None:
        candidates.append([lifted, dict(home)])
        # Rising is not always enough: from over the tray, the drop to the low
        # home still crosses the table edge. Cross at height to above home's
        # own column first — home's tip stands OFF the table — then drop.
        over_home = _over_home_pose(robot, arm, home, observe)
        if over_home is not None:
            candidates.append([lifted, over_home, dict(home)])
    blocked: Exception | None = None
    guard = ObjectMotionGuard(robot, arm, (), observe)
    for route in candidates:
        try:
            with robot.rehearsal():
                for pose in route:
                    robot.move_to(arm, pose)
                    guard.check()
                robot.settle(_SETTLE_S)
                guard.check()
                landed = robot.get_positions(arm)
                arrived = all(
                    abs(landed[joint] - value) <= _HOME_TOLERANCE_DEG
                    for joint, value in home.items()
                    if joint != "gripper"
                )
        except Collision as e:
            blocked = e
            continue
        if arrived:
            for pose in route:
                robot.move_to(arm, pose)
                guard.check()
            robot.settle(_SETTLE_S)
            guard.check()
            return
    if blocked is not None:
        raise blocked
    raise Collision(
        f"{arm} cannot get home cleanly from here — every route rehearsed "
        "leaves it stalled against the workcell"
    )


def _lifted_pose(robot, arm: str, observe=None) -> dict[str, float] | None:
    """The arm raised at its current column to transit height, or None."""
    transit = transit_height((observe or robot.describe_scene)()["fixtures"])
    if transit is None:
        return None
    here, _down = robot.tip(arm)
    pose, error = robot.solve_pose(arm, (here[0], here[1], max(transit, here[2])))
    return pose if error <= _TRANSIT_TOLERANCE else None


def _over_home_pose(
    robot, arm: str, home: dict[str, float], observe=None
) -> dict[str, float] | None:
    """The arm at transit height above where home's tip stands, or None."""
    transit = transit_height((observe or robot.describe_scene)()["fixtures"])
    if transit is None:
        return None
    home_tip, _down = robot.pose_tip(arm, home)
    pose, error = robot.solve_pose(arm, (home_tip[0], home_tip[1], max(transit, home_tip[2])))
    return pose if error <= _TRANSIT_TOLERANCE else None


def _trim(
    robot, arm: str, target: tuple, tolerance: float, may_move: tuple[str, ...] = (), observe=None
) -> None:
    """One sag-cancelling correction, kept only if a rehearsal proves it helps.

    Never raises: the arm is already within the caller's tolerance, and a trim
    that cannot be solved, collides, or measures worse is simply not taken.
    """
    tip, _down = robot.tip(arm)
    arrived = _distance(tip, target)
    if arrived <= _TRIM_ABOVE:
        return
    mirrored = tuple(g - (t - g) for g, t in zip(target, tip, strict=True))
    pose, error = robot.solve_pose(arm, mirrored)
    if error > tolerance:
        return
    guard = ObjectMotionGuard(robot, arm, may_move, observe)
    try:
        with robot.rehearsal():
            robot.move_to(arm, pose)
            robot.settle(_SETTLE_S)
            guard.check()
            trimmed, _ = robot.tip(arm)
            better = _distance(trimmed, target)
    except Collision:
        return
    if better < arrived:
        robot.move_to(arm, pose)
        robot.settle(_SETTLE_S)
        guard.check()
