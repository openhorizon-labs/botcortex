"""Agent-authored skills: parametrized Python files the runtime owns and executes.

A skill is a single .py file with `META = {"name", "description", "params"}` and
`run(ctx, **params)`. Skills can only touch the robot through the SkillContext —
the exec namespace has no imports, no filesystem, and a whitelisted builtins set.
That restriction is a guardrail against accidental misuse (an agent-written `open()`
or `os.system`), not a hardened security boundary; marketplace-grade sandboxing
comes with the hub.
"""

from __future__ import annotations

import math
import re
from pathlib import Path

from botcortex import config, kinematics
from botcortex.safety import Collision

NAME_RE = re.compile(r"^[a-z][a-z0-9_]{1,63}$")

# Enough for motion math; nothing that reaches the interpreter's edges.
SAFE_BUILTINS = {
    name: __builtins__[name] if isinstance(__builtins__, dict) else getattr(__builtins__, name)
    for name in (
        "abs",
        "all",
        "any",
        "bool",
        "dict",
        "enumerate",
        "float",
        "int",
        "len",
        "list",
        "max",
        "min",
        "range",
        "round",
        "sorted",
        "reversed",
        "str",
        "sum",
        "tuple",
        "zip",
        "True",
        "False",
        "None",
        "ValueError",
        "RuntimeError",
        "TypeError",
        "KeyError",
        "Exception",
        "isinstance",
    )
    if (isinstance(__builtins__, dict) and name in __builtins__)
    or (not isinstance(__builtins__, dict) and hasattr(__builtins__, name))
}


class SkillError(ValueError):
    """The skill code failed validation or execution."""


class SkillContext:
    """The only handle a skill gets. Wraps the primitives; nothing else exists.

    on_step, when set, receives (label,) before each primitive call — the server
    uses it to stream live progress to the plan view.
    """

    def __init__(self, robot, on_step=None, perception=None):
        self._robot = robot
        self.platform = getattr(robot, "platform", config.PLATFORM)
        self._on_step = on_step
        #: What the skill SEES, when it is not the simulator's own truth. The
        #: research harness puts its perception layer here so that faults in
        #: observation reach the program while the verifier keeps reading the
        #: world directly — see botcortex.research.perception. None means the
        #: robot's describe_scene, which is the product path.
        self._perception = perception
        self.math = math
        self.last_step: str | None = None

    def _step(self, label: str) -> None:
        self.last_step = label
        if self._on_step:
            self._on_step(label)

    def get_positions(self, arm: str) -> dict[str, float]:
        return self._robot.get_positions(arm)

    @property
    def arms(self) -> tuple[str, ...]:
        """The arms this robot has — ("right", "left") on OpenArm, ("arm",)
        on a single manipulator. A skill that hardcodes "right" is written
        for one body; one that reads this runs on the next."""
        return self.platform.arms

    def gripper_range(self, arm: str) -> tuple[float, float]:
        """(fully open, fully closed) in gripper degrees for this body.

        Every platform's gripper limit is declared open-to-closed, so a skill
        can open and close without knowing whether the jaws are two sliding
        fingers, a tendon, or one hinged clamp."""
        lo, hi = self.platform.joint_limits[arm]["gripper"]
        return (lo, hi)

    def describe_scene(self) -> dict:
        """Where the objects are, right now.

        Skills need this as much as the agent does. Without it an authored
        skill can only hold the coordinates it was written with, so "pick up
        the red block" works exactly once — the next time the block is
        anywhere else, the arm closes on air. A skill that reads the scene at
        run time is the difference between a recording and a program.
        """
        if self._perception is not None:
            return self._perception()
        return self._robot.describe_scene()

    def free_spot(self, fixture: str, carrying: str | None = None):
        """A clear place to set something down inside `fixture`, or None.

        Read at run time for the same reason describe_scene is: the free spot
        moves as the tray fills, so a skill that hardcodes one works for the
        first object and lowers the second onto the first. Returns the point
        the object's CENTRE should end up at — move the grasp centre there and
        open the jaws.
        """
        spots = kinematics.free_spots(self.describe_scene(), fixture, carrying=carrying)
        return spots[0] if spots else None

    def pick_up(self, arm: str, obj: str) -> None:
        """Grasp `obj` and lift it clear, jaws squared to it.

        Open, hover, descend, close, lift — the sequence every pick is — with
        one thing a hand-written one cannot do: on a body whose jaws point
        wherever its shoulder pans, the wrist is rolled so they meet the object
        face-on. On the SO-101 a block reached sideways (pan -37.5°) otherwise
        meets the jaws at 37.5°, one jaw lands ON the cube, the grasp centre
        stops 14 mm high, and the router reports the arm wedging against the
        workcell — a message about routes, for a grasp that was never aligned.

        Raises ValueError when there is no such object, or when the jaws close
        and the object does not come up with them. A pick that grasped nothing
        and said nothing is the failure that lets the next step carry air.
        """
        scene = self.describe_scene()
        body = (scene.get("objects") or {}).get(obj)
        if body is None:
            known = ", ".join(sorted(scene.get("objects") or {})) or "none"
            raise ValueError(f"no object called {obj!r}; the scene has: {known}")
        x, y, z = (float(v) for v in body["position"])
        opening, closed = self.gripper_range(arm)
        hover = [x, y, z + _PICK_LIFT]
        self.gripper(arm, opening)

        pinned = None
        candidates = self._squared_jaws(arm, (x, y, z), body.get("orientation"))
        rehearsal = getattr(self._robot, "rehearsal", None)
        if candidates and rehearsal is not None:
            refused = ""
            for option in candidates:
                # Rehearsed as the whole hover-then-descend, from exactly where
                # the arm stands now, so it is evidence about the real move
                # rather than a guess about a different one.
                try:
                    with rehearsal():
                        self._robot_routed(arm, hover, pinned=option)
                        self._robot_routed(arm, [x, y, z], pinned=option)
                except ValueError as e:
                    refused = str(e)
                    continue
                pinned = option
                break
            if pinned is None:
                raise ValueError(
                    f"no wrist orientation lets the jaws reach {obj} — tried "
                    f"{[round(next(iter(c.values())), 1) for c in candidates]}. Last refusal: {refused}"
                )

        self._routed(arm, hover, pinned=pinned)
        self._routed(arm, [x, y, z], pinned=pinned)
        self.gripper(arm, closed)
        self._routed(arm, hover, pinned=pinned, may_move=(obj,))

        lifted = (self.describe_scene().get("objects") or {}).get(obj, {}).get("position")
        if lifted is None or float(lifted[2]) < z + _PICK_LIFT / 2:
            raise ValueError(
                f"the jaws closed but {obj} did not come up with them — it is still at "
                f"{[round(float(v), 3) for v in (lifted or body['position'])]}. "
                "Nothing is held; do not carry on as if it were."
            )

    def _squared_jaws(self, arm: str, point, orientation) -> list[dict[str, float]] | None:
        """Every roll-joint angle that squares the jaws to an object, smallest
        turn first, or None where the body does not need one (no `sim.jaw_yaw`
        in its descriptor — every body whose picks already work).

        Every one, not the one that looks right. A cube is the same every
        quarter turn but the SO-101's clamp is not: one jaw is fixed, and
        which quarter turn keeps the fixed jaw OUTSIDE the cube depends on
        where the cube is. Measured from a hover: the green block descends only
        at +127.5° and wedges at the +37.5° that squares it most directly; the
        blue block at +108.6° or -71.4° and not +18.6°. An earlier measurement
        approached from home instead of from above and suggested one rule for
        all of them, which is the mistake this list is here to not repeat.
        """
        declared = self.platform.sim.get("jaw_yaw") if hasattr(self.platform, "sim") else None
        solve = getattr(self._robot, "solve_pose", None)
        if not declared or solve is None:
            return None
        pan, roll = declared["pan"], declared["roll"]
        pose, _error = solve(arm, tuple(point))
        home = self.platform.home_position
        turned = float(pose.get(pan, 0.0)) - float(home.get(pan, 0.0))
        base = float(home.get(roll, 0.0)) + _wrap_quarter(_yaw_degrees(orientation) - turned)
        lo, hi = self.platform.joint_limits[arm][roll]
        options = sorted(
            (base + quarter for quarter in (0.0, 90.0, -90.0, 180.0, -180.0)),
            key=lambda angle: abs(angle - float(home.get(roll, 0.0))),
        )
        return [{roll: angle} for angle in options if lo <= angle <= hi] or None

    def _robot_routed(self, arm: str, point, *, pinned=None, may_move=()) -> None:
        """The robot's move_to_point with no step recorded — for rehearsals,
        which must not appear in the plan the owner watches."""
        allowed = tuple(str(n) for n in may_move)
        if pinned:
            self._robot.move_to_point(
                arm, point, 0.02, may_move=allowed, observe=self._perception, pinned=pinned
            )
        else:
            self._robot.move_to_point(arm, point, 0.02, may_move=allowed, observe=self._perception)

    def _routed(self, arm: str, point, *, pinned=None, may_move=()) -> None:
        """move_to_point, holding a neutral joint where the caller asked."""
        allowed = tuple(str(n) for n in may_move)
        self._step(
            f"move_to_point {arm} {[round(float(v), 3) for v in point]}"
            + (f" may_move={list(allowed)}" if allowed else "")
            + (f" pinned={pinned}" if pinned else "")
        )
        if pinned:
            self._robot.move_to_point(
                arm, point, 0.02, may_move=allowed, observe=self._perception, pinned=pinned
            )
        else:
            self._robot.move_to_point(arm, point, 0.02, may_move=allowed, observe=self._perception)

    def place_in(self, arm: str, fixture: str, obj: str):
        """Put what the jaws are holding into `fixture`, and say where it went.

        The failure this ends: "clear every block into the tray" sent every
        block to the tray's CENTRE, so the first landed, the second was
        lowered onto the first, and the transit guard refused the move for
        displacing a block the arm was not holding. Correct, and reported as a
        routing problem, so four author-run cycles went into rerouting a move
        whose DESTINATION was the problem.

        Spots are tried nearest the arm first. Whether a route is clear
        depends on where the arm is standing, what is in the jaws and how the
        approach is shaped, so this does not predict it — it attempts the move,
        and `move_to_point` refuses without moving, which makes trying the next
        spot free. Measured: one of the eight spots in the OpenArm's tray is a
        point the arm wedges entering, and five of the eight in the RoArm's.

        Raises ValueError when the container is full, or when nothing in it is
        a place this arm can reach into — two different sentences, because they
        need two different things from whoever reads them.
        """
        spots = kinematics.free_spots(self.describe_scene(), fixture, carrying=obj)
        if not spots:
            raise ValueError(
                f"{fixture} is full — everything that fits is already in it. "
                "Put this somewhere else, or take something out first."
            )
        opening, _closed = self.gripper_range(arm)
        refused = ""
        for spot in spots[:_SPOTS_TRIED]:
            hover = [spot[0], spot[1], spot[2] + _PLACE_APPROACH]
            try:
                self.move_to_point(arm, hover, may_move=[obj])
                self.move_to_point(arm, list(spot), may_move=[obj])
            except ValueError as e:
                refused = str(e)
                continue
            self.gripper(arm, opening)
            # Strict first, permissive only if refused. Two-finger jaws can
            # drag a released block on the way up — measured on the ViperX,
            # where a retreat that forbade it was refused for "displacing" the
            # block it had just set down, so the arm could not leave and every
            # pick after it failed too. But ALLOWING the block to move is not
            # free: it widens which routes the guard accepts, and on the Panda
            # the router then took a cheaper route that dragged a placed block
            # into the path of the next one, turning 3 of 3 into 2 of 3. So
            # the move that never disturbs anything is tried first, and the
            # one that may nudge the block only when that is impossible.
            try:
                self.move_to_point(arm, hover)
            except ValueError:
                self.move_to_point(arm, hover, may_move=[obj])
            resting = (self.describe_scene().get("objects") or {}).get(obj, {}).get("position")
            target = (self.describe_scene().get("fixtures") or {}).get(fixture, {})
            size, centre = target.get("size_m"), target.get("position")
            if resting and size and centre and not (
                abs(float(resting[0]) - float(centre[0])) <= float(size[0]) / 2
                and abs(float(resting[1]) - float(centre[1])) <= float(size[1]) / 2
            ):
                raise ValueError(
                    f"{obj} was released over {fixture} but the jaws carried it back out on the "
                    f"way up — it is at {[round(float(v), 3) for v in resting]}, outside the "
                    f"{fixture}."
                )
            return tuple(spot)
        raise ValueError(
            f"{fixture} has room but nowhere this arm can reach into — tried "
            f"{[list(s) for s in spots[:_SPOTS_TRIED]]}. Last refusal: {refused}"
        )

    def move_to(self, arm: str, targets: dict[str, float], duration: float | None = None) -> None:
        self._step(f"move_to {arm} {targets}")
        self._robot.move_to(arm, targets, duration)

    def go_home(self) -> None:
        """Every arm to the pose the robot rests in.

        Sequential, because v0 has no concurrency primitive — the same reason
        the system prompt tells the agent two-arm coordination is sequential.

        Through park() rather than a raw move: home is LOW, so from over the
        tray a single joint-space move sweeps the hand down through the table
        edge. The backend routes and rehearses its way there — see
        kinematics.retreat.
        """
        for arm in getattr(self._robot, "platform", config.PLATFORM).arms:
            self._step(f"home {arm}")
            self._robot.park(arm, observe=self._perception)

    def move_to_point(self, arm: str, point, tolerance: float = 0.02, may_move=()) -> None:
        """Put the grasp centre at a point in metres, gripper pointing down.

        The bridge from describe_scene (metres) to the arm (degrees). Without
        it a skill can see exactly where a block is and has no way to go there,
        which is what issue #16 discovered.

        `may_move` names the objects this move is MEANT to displace — the
        block a push is pushing. The transit guard still refuses to disturb
        anything else. Without it every deliberate push read as an unsafe
        transit, which is the "task-specific allowed-effect set" the research
        plan asks for.
        """
        allowed = tuple(str(name) for name in (may_move or ()))
        self._step(
            f"move_to_point {arm} {[round(float(v), 3) for v in point]}"
            + (f" may_move={list(allowed)}" if allowed else "")
        )
        self._robot.move_to_point(arm, point, tolerance, may_move=allowed, observe=self._perception)

    def gripper(self, arm: str, position: float) -> None:
        self._step(f"gripper {arm} -> {position}")
        self._robot.gripper(arm, position)

    def set_torque(self, arm: str, enabled: bool) -> None:
        self._step(f"set_torque {arm} {enabled}")
        self._robot.set_torque(arm, enabled)

    def clear_errors(self) -> None:
        self._robot.clear_errors()

    def replay_trajectory(self, arm: str, waypoints: list[dict[str, float]]) -> None:
        self._step(f"replay_trajectory {arm} ({len(waypoints)} waypoints)")
        self._robot.replay_trajectory(arm, waypoints)


#: How many spots are tried before giving up on a container. Each attempt is
#: a real routed move that refuses without moving, so trying is cheap enough
#: and honest — unlike asking whether a route WOULD work, which depends on
#: where the arm is standing and what the approach looks like.
_SPOTS_TRIED = 4

#: How far above a placement the jaws hover before descending.
_PLACE_APPROACH = 0.10

#: How far above an object the jaws hover before descending onto it, and how
#: far it is lifted after the grasp. The same number the portable pick uses,
#: which clears a 40 mm block and the tray walls on every body.
_PICK_LIFT = 0.12


def _wrap_quarter(degrees: float) -> float:
    """An angle folded into [-45, 45]. A cube looks the same every 90°, so the
    smallest wrist turn that squares the jaws to it is always within 45°."""
    return (degrees + 45.0) % 90.0 - 45.0


def _yaw_degrees(orientation) -> float:
    """Heading of a wxyz quaternion about the vertical, in degrees."""
    if not orientation or len(orientation) < 4:
        return 0.0
    w, x, y, z = (float(v) for v in orientation[:4])
    return math.degrees(math.atan2(2.0 * (w * z + x * y), 1.0 - 2.0 * (y * y + z * z)))


class SkillStore:
    """Loads, validates, saves, and runs skills from a directory of .py files."""

    def __init__(self, directory: Path):
        self.directory = Path(directory)
        self.directory.mkdir(parents=True, exist_ok=True)

    def _compile(self, name: str, code: str):
        """Exec the skill in the restricted namespace; return (meta, run)."""
        namespace = {"__builtins__": dict(SAFE_BUILTINS), "math": math}
        try:
            # exec IS the skill runtime — the restricted namespace above is the guardrail.
            exec(compile(code, f"<skill:{name}>", "exec"), namespace)  # noqa: S102
        except ImportError as e:
            raise SkillError(
                f"skills cannot import ({e}); everything a skill needs is on ctx"
            ) from e
        except SyntaxError as e:
            raise SkillError(f"syntax error in skill: {e}") from e
        meta = namespace.get("META")
        run = namespace.get("run")
        if not isinstance(meta, dict) or "name" not in meta or "description" not in meta:
            raise SkillError('skill must define META = {"name", "description", "params"}')
        if not callable(run):
            raise SkillError("skill must define run(ctx, **params)")
        meta.setdefault("params", {})
        return meta, run

    def save(self, name: str, code: str) -> dict:
        if not NAME_RE.match(name):
            raise SkillError("skill name must be snake_case ascii, e.g. wave_right_arm")
        meta, _ = self._compile(name, code)
        if meta["name"] != name:
            raise SkillError(f'META["name"] ({meta["name"]!r}) must match the save name ({name!r})')
        (self.directory / f"{name}.py").write_text(code)
        # New code is unproven code. Saving over a skill that HAD run drops the
        # mark, because what ran was the old version — otherwise the third
        # rewrite of a broken skill inherits the first one's good name.
        self._proof(name).unlink(missing_ok=True)
        return meta

    def delete(self, name: str) -> bool:
        """Remove a skill and its proof mark. True if there was one to remove.

        The proof goes too: a `.ran` file surviving its skill would crown the
        NEXT skill saved under this name with a run it never had.
        """
        path = self.directory / f"{name}.py"
        existed = path.exists()
        path.unlink(missing_ok=True)
        self._proof(name).unlink(missing_ok=True)
        return existed

    # --- which of these has ever actually worked -----------------------------
    #
    # The sidebar's promise is "your robot knows these". A skill the agent wrote
    # and never got to run — or ran and watched fail — is not something the
    # robot knows, and listing it beside the ones that work is the same lie as
    # reporting a failed teach as done. So a run that completes leaves a mark
    # next to the file, and everything that lists skills can say which is which.
    #
    # A file rather than an in-memory flag: the claim has to survive a restart,
    # and it is worth being able to see it on disk.

    def _proof(self, name: str) -> Path:
        return self.directory / f"{name}.ran"

    def mark_ran(self, name: str) -> None:
        """This exact code ran to completion at least once."""
        self._proof(name).touch()

    def has_run(self, name: str) -> bool:
        return self._proof(name).exists()

    def unproven(self) -> list[str]:
        """Saved, but never seen to run. Named for the UI to mark."""
        return [name for name in self.names() if not self.has_run(name)]

    def list(self) -> list[dict]:
        metas = []
        for path in sorted(self.directory.glob("*.py")):
            try:
                meta, _ = self._compile(path.stem, path.read_text())
                metas.append(meta)
            except SkillError:
                continue  # a broken file must not take the whole store down
        return metas

    def names(self) -> list[str]:
        return [m["name"] for m in self.list()]

    def run(self, name: str, ctx: SkillContext, *, home: bool = True, **params):
        """Execute a skill, from home and back to home.

        Bracketing every skill with a move to HOME_POSITION is the runtime's
        job rather than the agent's, for the same reason clamping and the
        e-stop are: a rule that only holds when a model remembers to write it
        does not hold. An agent that forgot the return leaves the arm extended
        over the workcell for whatever runs next.

        It also makes a skill REPRODUCIBLE. Two runs from different starting
        poses take different paths and can reach different outcomes, which
        would put a confound straight into the success rate the eval suite
        exists to measure.

        A real move, never `robot.reset()`: reset teleports, which is why it
        exists only on backends with no physical arm to fling. This goes home
        the way any other motion does — interpolated, velocity-capped, e-stop
        checked between frames.

        On FAILURE the arm stays where it stopped. Homing afterwards would
        overwrite the evidence, and moving an arm right after an unexplained
        failure is the wrong instinct on hardware. `home=False` skips both ends
        for a caller that is composing skills and does not want the round trip.

        THE BRACKET IS NOT THE SKILL, and the failure has to say which broke.
        Measured on a real attempt: an agent wrote a correct pick-and-place,
        the body ran to completion, and the closing go_home swept the hand
        through the table on its way back from over the tray. The collision was
        reported as the skill's, so the agent concluded its grasp descent was
        too low and raised it — three times, each time breaking the grasp a
        little more, each time getting the same collision from the same
        bracket. It was debugging a sentence about someone else's move.
        """
        path = self.directory / f"{name}.py"
        if not path.exists():
            raise SkillError(f"no skill named {name!r}; known: {self.names()}")
        meta, run = self._compile(name, path.read_text())
        merged = {**meta.get("params", {}), **params}

        if home:
            self._home(ctx, opening=True)
        result = run(ctx, **merged)
        if home:
            self._home(ctx, opening=False)
        return result

    @staticmethod
    def _home(ctx: SkillContext, *, opening: bool) -> None:
        """The runtime's own move to the rest pose, owning its own failures."""
        try:
            ctx.go_home()
        except Collision as e:
            raise Collision(
                (
                    f"{e}\n\nTHIS WAS NOT YOUR SKILL. The runtime moves both arms to the "
                    "rest pose before every skill, and the arm could not get there from "
                    "where it was already standing. Reset the sim, or move the arm clear "
                    "by hand, before running anything."
                )
                if opening
                else (
                    f"{e}\n\nTHIS WAS NOT YOUR SKILL — the skill body ran all the way "
                    "through. The runtime then moves both arms back to the rest pose, "
                    "and THAT move crashed. Do not change your grasp or your waypoints "
                    "to fix this: change where the skill LEAVES the arm. Finish lower "
                    "and closer in rather than high and extended over the workcell."
                )
            ) from e
