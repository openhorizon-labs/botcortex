"""What the owner chose, kept in a file instead of in their shell.

A robot was configured by exporting environment variables: the body, the port,
whether to record. That is fine for a developer and a dead end for everyone
else — close the terminal and the robot has forgotten what it is. So choices
made through `botcortex setup` and `botcortex config` are written to
`settings.json` in the data directory, and read from there on every start.

An environment variable still wins when it is set, because a one-off override
(`BOTCORTEX_PLATFORM=panda botcortex serve --sim`) should not need a file edit
and must not be silently ignored. Order: environment, then this file, then the
built-in default.

Nothing here imports the rest of the package: `config` reads this at import,
and the browser imports `config`.
"""

from __future__ import annotations

import json
import os
from pathlib import Path

#: name -> (environment variable, what it is, for `botcortex config`)
KNOWN = {
    "platform": ("BOTCORTEX_PLATFORM", "which robot body this is, e.g. roarm_m2"),
    "device": ("BOTCORTEX_DEVICE", "the arm's serial port, e.g. /dev/cu.usbserial-110"),
    "share_runs": ("BOTCORTEX_SHARE_RUNS", "send runs to BotCortex when paired: on or off"),
    "record": ("BOTCORTEX_RECORD", "keep every run as files on this machine: on or off"),
    "model": ("BOTCORTEX_MODEL", "the model that writes skills"),
    "wire_signs": (
        "BOTCORTEX_WIRE_SIGNS",
        "joints whose direction is reversed on this unit, as JSON; written by `botcortex arm check`",
    ),
}
_ON = ("1", "true", "yes", "on")
_OFF = ("0", "false", "no", "off")


def data_dir() -> Path:
    return Path(os.environ.get("BOTCORTEX_DATA", Path.home() / ".openhorizon"))


def path() -> Path:
    return data_dir() / "settings.json"


def load() -> dict:
    try:
        found = json.loads(path().read_text())
        return found if isinstance(found, dict) else {}
    except (OSError, ValueError):
        # A missing file is a fresh install; an unreadable one must not stop
        # a robot from starting. `botcortex doctor` is where it gets said.
        return {}


def get(name: str, default=None):
    """The environment, then the file, then `default`."""
    variable = KNOWN[name][0]
    if os.environ.get(variable) not in (None, ""):
        return os.environ[variable]
    return load().get(name, default)


def flag(name: str, default: bool) -> bool:
    value = get(name)
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    text = str(value).strip().lower()
    return True if text in _ON else False if text in _OFF else default


def source(name: str) -> str:
    """Where the value in force came from — shown by `botcortex config`."""
    if os.environ.get(KNOWN[name][0]) not in (None, ""):
        return f"environment ({KNOWN[name][0]})"
    return "settings file" if name in load() else "default"


def put(name: str, value) -> None:
    if name not in KNOWN:
        raise KeyError(f"no setting called {name!r}; there are: {', '.join(KNOWN)}")
    if name in ("share_runs", "record"):
        text = str(value).strip().lower()
        if text not in _ON + _OFF:
            raise ValueError(f"{name} is on or off, not {value!r}")
        value = text in _ON
    found = load()
    found[name] = value
    _write(found)


def drop(name: str) -> bool:
    found = load()
    if name not in found:
        return False
    del found[name]
    _write(found)
    return True


def _write(found: dict) -> None:
    target = path()
    target.parent.mkdir(parents=True, exist_ok=True)
    scratch = target.with_suffix(".tmp")
    scratch.write_text(json.dumps(found, indent=2) + "\n")
    scratch.replace(target)  # never a half-written settings file
