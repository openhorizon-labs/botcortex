"""A RoArm that is not there: the firmware's side of the wire, in simulation.

`LoopbackPort` is handed to `RoArmLink` where a serial port would go. Behind it
a SECOND simulation plays the physical world: joint commands arriving as JSON
drive its servos, feedback requests are answered from its joints, and a
`SimCamera` pointed at it is the bench camera. The robot under test therefore
gets nothing it would not get on a desk — bytes and pixels — and its own twin
can be wrong about the world in every way a real one can.

It is how the whole hardware path is tested with no hardware, and it is also a
fair way to try `--real` before the arm arrives.
"""

from __future__ import annotations

import json
from collections import deque

from botcortex.roarm import from_wire, to_wire


class LoopbackPort:
    def __init__(self, world, stalled: bool = False):
        self.world = world
        #: True plays a blocked or unpowered arm: commands arrive, nothing moves.
        self.stalled = stalled
        self.sent: list[dict] = []
        self._replies: deque[bytes] = deque()
        platform = world.platform
        self._arm = platform.arms[0]
        self._jaw = float(platform.sim["gripper"]["qpos_open"])
        self._limits = tuple(platform.joint_limits[self._arm]["gripper"])

    def write(self, data: bytes) -> None:
        command = json.loads(data.decode("utf-8"))
        self.sent.append(command)
        if command["T"] == 102 and not self.stalled:
            degrees = from_wire(
                {
                    "b": command["base"],
                    "s": command["shoulder"],
                    "e": command["elbow"],
                    "t": command["hand"],
                },
                self._jaw,
                self._limits,
            )
            world = self.world
            for joint, deg in degrees.items():
                world._write_target(self._arm, joint, deg)
            for _ in range(world._substeps):
                world._mujoco.mj_step(world.model, world.data)
        elif command["T"] == 105:
            # Time passes on a real bench whether or not anyone is commanding:
            # a servo keeps closing on its target between frames. Asking where
            # the arm is, is the only clock this world has.
            if not self.stalled:
                for _ in range(self.world._substeps):
                    self.world._mujoco.mj_step(self.world.model, self.world.data)
            wire = to_wire(self.world.get_positions(self._arm), self._jaw, self._limits)
            reply = {
                "T": 1051,
                "b": wire["base"],
                "s": wire["shoulder"],
                "e": wire["elbow"],
                "t": wire["hand"],
            }
            # The firmware chatters on this port; the link must skip it.
            self._replies.append(b"not json at all\r\n")
            self._replies.append((json.dumps(reply) + "\r\n").encode("utf-8"))

    def readline(self) -> bytes:
        return self._replies.popleft() if self._replies else b""

    def close(self) -> None:
        pass
