"""Finding out where the camera stands, with the arm as the ruler.

The arm knows where its own gripper is. So it points: it hovers its closed gripper
over a spot on the bench, the person slides one block underneath, the arm gets
out of the way, and the camera looks. A handful of spots later there are two
lists of the same points — where the ARM says the block was, and where the
CAMERA saw it — and the transform between them is the camera's position.

A depth camera gives 3-D points and needs three spots. A webcam gives pixels
and needs four, and the same data also measures its focal length, which no
webcam knows about itself. Six are used either way, because the person's hand
is the least accurate part of this and errors average out.

The arm never touches the block. Laying the block out by itself would save the
person a minute, and would mean a grasp had to work before anything was
calibrated — the wrong order in which to trust things.
"""

from __future__ import annotations

import numpy as np

from botcortex import vision
from botcortex.real import wait_until_still
from botcortex.safety import Collision

#: Above the block's top, in metres: clear of it, close enough to centre by eye.
_HOVER_M = 0.03
#: Bench kept free around every fixture and object, so a block slid under the
#: jaws is never leaning on a tray wall.
_CLEAR_M = 0.05
#: A calibration worse than this is refused rather than saved: a 40 mm block
#: grasped a centimetre off-centre is a missed grasp.
ACCEPTABLE_RESIDUAL_M = 0.008


def spots_for(robot, arm: str, block: dict, wanted: int = 6) -> list[tuple[float, float, float]]:
    """Hover points spread over the bench that this arm can actually reach.

    Tried, not predicted: `move_to_point` inside a rehearsal refuses a spot it
    cannot route to, and costs nothing when it does.
    """
    scene = robot.describe_scene()
    bench = scene["fixtures"]["table"]
    (bx, by, bz), (sx, sy, sz) = bench["position"], bench["size_m"]
    top = bz + sz / 2
    hover = top + float(block["size_m"][2]) + _HOVER_M
    # Footprints, not centres: a spot 7 cm from a tray's middle is on its wall.
    keep_clear = [
        (b["position"], b["size_m"])
        for b in (*scene["fixtures"].values(), *scene["objects"].values())
        if b is not bench
    ]
    found: list[tuple[float, float, float]] = []
    for fx in (0.22, 0.5, 0.78):
        for fy in (0.2, 0.4, 0.6, 0.8):
            x, y = bx - sx / 2 + fx * sx, by - sy / 2 + fy * sy
            if any(
                abs(x - p[0]) < size[0] / 2 + _CLEAR_M and abs(y - p[1]) < size[1] / 2 + _CLEAR_M
                for p, size in keep_clear
            ):
                continue
            try:
                with robot.rehearsal():
                    robot.move_to_point(arm, (x, y, hover), 0.01)
            except (ValueError, Collision):
                # Refused without moving: not a spot this arm can point at.
                continue
            found.append((x, y, hover))
    # Spread beats count: the far corners constrain the pose, neighbours do not.
    if len(found) > wanted:
        picked = [found[0]]
        while len(picked) < wanted:
            picked.append(
                max(found, key=lambda s: min(np.hypot(s[0] - p[0], s[1] - p[1]) for p in picked))
            )
        found = picked
    return found


def calibrate(robot, camera, block_name: str, ask, say=print) -> dict:
    """Run the pointing routine. Returns what to save in the camera's settings.

    `ask(prompt)` must not return until the person is done — `input` on a
    terminal. `robot` must have NO camera attached: nothing is calibrated yet,
    so the twin is all there is to believe.
    """
    arm = robot.platform.arms[0]
    block = robot.describe_scene()["objects"][block_name]
    bench = robot.describe_scene()["fixtures"]["table"]
    rest = bench["position"][2] + bench["size_m"][2] / 2 + float(block["size_m"][2]) / 2
    spots = spots_for(robot, arm, block)
    depth = camera.frame().depth is not None
    if len(spots) < (3 if depth else 4):
        raise RuntimeError("the arm can reach too few clear spots on the bench to calibrate from")

    # Closed jaws: a better pointer, and nothing hanging below the hand to
    # sweep the block away as the arm leaves. Measured — with the RoArm's clamp
    # open, the retreat knocked the block up to 4 cm in two spots of six.
    _, closed = robot.platform.joint_limits[arm]["gripper"]
    robot.gripper(arm, closed)
    in_base, in_view = [], []
    for i, spot in enumerate(spots, start=1):
        robot.move_to_point(arm, spot, 0.01)
        if robot.link is not None:
            # The ruler is the arm's MEASURED pose, not the twin's belief about
            # it: wait for the servos to arrive, then put the twin exactly there.
            wait_until_still(robot, arm)
            robot.sync()
        (x, y, _z), _ = robot.tip(arm)
        ask(
            f"  spot {i} of {len(spots)}: slide the block under the gripper tip, centred, then press Enter "
        )
        robot.park(arm)
        frame = camera.frame()
        one = {block_name: block}
        if depth:
            seen, unseen = vision.locate_in_camera(frame, one, vision.bench_up(frame))
            view = seen.get(block_name)
        else:
            seen, unseen = vision.blobs(frame, one)
            view = seen[block_name][0] if block_name in seen else None
        if view is None:
            say(f"    could not see the block there ({unseen[block_name]}) — skipping this spot")
            continue
        in_base.append([x, y, rest])
        in_view.append(view)

    in_base, in_view = np.array(in_base), np.array(in_view)
    if depth:
        pose, residual = vision.solve_pose(in_view, in_base)
        result = {"camera_to_base": pose.tolist(), "residual_m": residual}
    else:
        h, w = camera.frame().rgb.shape[:2]
        pose, focal, residual = vision.solve_pose_from_pixels(
            in_view, in_base[:, :2], rest, (w / 2, h / 2), w, size=block["size_m"]
        )
        result = {"camera_to_base": pose.tolist(), "focal_px": focal, "residual_m": residual}
    if residual > ACCEPTABLE_RESIDUAL_M:
        raise RuntimeError(
            f"the spots disagree by {residual * 1000:.0f} mm, which is too much to grasp by. "
            "Nothing was saved. Usual causes: the block was not centred under the jaws, "
            "or the camera moved during the routine."
        )
    return result


# --- zero-shot: the arm is the target ---------------------------------------
#
# With a depth camera nobody needs to slide anything. The camera looks at the
# bench with the arm parked, then at the arm hovering over a spot with its
# jaws closed and pointing down; the pixels that changed are the arm, and the
# lowest of them along the bench's normal are the underside of the jaws. The
# twin knows where that underside is at the same pose. A handful of spots
# later there are two lists of the same points, exactly as with a block, and
# nobody's hand was involved. Measured in simulation: the spots agree to
# under 2 mm, as good as the hand routine's best.

#: How far a pixel's depth must move for it to count as the arm arriving.
_MOVED_M = 0.02
#: The slab of the arm's cloud, above its lowest point, taken as the jaws'
#: underside. A depth sensor is a millimetre or two noisy; a jaw is thicker.
_UNDERSIDE_M = 0.01
#: How many pixels the arm must show at a spot for the tip to be trusted.
_MIN_ARM_PIXELS = 200
#: How far the lowest pixels of a moved piece may sit from where the twin
#: puts the jaws' underside, for that piece to be taken as the arm. Measured
#: on a real bench: the arm's pieces agreed within 4-14 mm, a person leaning
#: in and the paper the arm's draught lifted were off by 40 mm and more.
_AGREE_M = 0.02


def jaw_surface(robot, arm: str, spacing_m: float = 0.003) -> np.ndarray:
    """Points on the outside of the closed jaws and the hand right now, in
    the base frame: every face of every box they are built from, sampled a
    few millimetres apart. What a depth camera could see of them, from any
    side; which side it does see is settled by the fit itself."""
    from botcortex import mjcompat

    mj, model, data = robot._mujoco, robot.model, robot.data
    bodies = {*robot.platform.finger_bodies(arm), robot.platform.hand_body(arm)}
    ids = {mj.mj_name2id(model, mjcompat.enum_value(mj.mjtObj.mjOBJ_BODY), b) for b in bodies}
    # The vendor's meshes when the body has them: they are what a camera sees
    # of a real arm, and what the simulated camera renders. The collision
    # boxes underneath are a stand-in that sits 15 mm off the mesh on the
    # RoArm, which is the whole calibration budget.
    box, mesh = (
        mjcompat.enum_value(mj.mjtGeom.mjGEOM_BOX),
        mjcompat.enum_value(mj.mjtGeom.mjGEOM_MESH),
    )
    surface, boxes = [], []
    for geom in range(model.ngeom):
        if int(model.geom_bodyid[geom]) not in ids:
            continue
        kind = int(model.geom_type[geom])
        if kind not in (box, mesh):
            continue
        centre = np.array(mjcompat.row(data.geom_xpos, geom, 3))
        rot = np.array(mjcompat.row(data.geom_xmat, geom, 9)).reshape(3, 3)
        if kind == mesh:
            mid = int(model.geom_dataid[geom])
            va, vn = int(model.mesh_vertadr[mid]), int(model.mesh_vertnum[mid])
            verts = np.asarray(model.mesh_vert[va : va + vn], dtype=float).reshape(-1, 3)
            surface.append(centre + verts @ rot.T)
            continue
        half = np.array(mjcompat.row(model.geom_size, geom, 3))
        axes = [np.linspace(-h, h, max(2, round(2 * h / spacing_m) + 1)) for h in half]
        for fixed in range(3):
            others = [i for i in range(3) if i != fixed]
            u, v = np.meshgrid(axes[others[0]], axes[others[1]], indexing="ij")
            for sign in (-1.0, 1.0):
                local = np.zeros((u.size, 3))
                local[:, others[0]], local[:, others[1]] = u.ravel(), v.ravel()
                local[:, fixed] = sign * half[fixed]
                boxes.append(centre + local @ rot.T)
    surface = surface or boxes
    if not surface:
        raise ValueError(
            f"{robot.platform.display_name}: no box geometry on the jaws to calibrate from"
        )
    return np.concatenate(surface)


def jaw_underside(robot, arm: str) -> np.ndarray:
    """The centroid of the lowest `_UNDERSIDE_M` of the jaws, in the base
    frame: a first guess at what the camera's lowest arm pixels are."""
    points = jaw_surface(robot, arm)
    lowest = points[:, 2].min()
    return points[points[:, 2] < lowest + _UNDERSIDE_M].mean(axis=0)


def _refine(
    pose: np.ndarray, seen: list[np.ndarray], modelled: list[np.ndarray]
) -> tuple[np.ndarray, float]:
    """Iterative closest point: from a rough pose, carry every arm pixel the
    camera saw into the base frame, pair it with the nearest point on the
    twin's jaws at that spot, and re-solve. A camera looking down sees the
    tops and near sides of the jaws, never their underside, so a first guess
    from 'lowest points' is a centimetre off; this settles which surface the
    pixels actually are. Returns (pose, median gap in metres)."""
    from botcortex.camera import to_base

    residual = float("inf")
    for _ in range(12):
        cam_pts, base_pts, distances = [], [], []
        for pixels, surface in zip(seen, modelled, strict=True):
            carried = to_base(pose, pixels)
            gaps = np.linalg.norm(carried[:, None, :] - surface[None, :, :], axis=2)
            nearest = gaps.argmin(axis=1)
            closest = gaps[np.arange(len(pixels)), nearest]
            keep = closest < 0.03
            cam_pts.append(pixels[keep])
            base_pts.append(surface[nearest[keep]])
            distances.append(closest[keep])
        a, b = np.concatenate(cam_pts), np.concatenate(base_pts)
        if len(a) < 3:
            break
        pose, _ = vision.solve_pose(a, b)
        # The median gap, not the RMS: a few forearm pixels matched to the
        # nearest jaw, or a sensor's stray returns, must not fail a fit that
        # has the jaws themselves within a few millimetres.
        now = float(np.median(np.concatenate(distances)))
        if abs(residual - now) < 1e-5:
            residual = now
            break
        residual = now
    return pose, residual


def _arm_pixels(rest, frame, up, level: float, expected_low: float):
    """The arm in `frame`, as (points, heights above the bench), or None.

    What changed since `rest` and now stands nearer is the arm — and, on a
    real bench, also the person who leaned in, the paper the arm's draught
    lifted, and the floor beyond the far edge. So: only the bench band, split
    into connected pieces, and the piece whose lowest edge is where the twin
    says the jaws are (within `_AGREE_M`). A piece that low by chance is
    unlikely; a person is never that shape at that height.
    """
    import cv2

    cloud = frame.points_in_camera()
    height = cloud @ up - level
    moved = (
        (frame.depth > 0)
        & (frame.depth < 1.5)
        & (rest.depth > 0)
        & (frame.depth < rest.depth - _MOVED_M)
        & (height > -0.01)
        & (height < 0.25)
    )
    count, labels, stats, _ = cv2.connectedComponentsWithStats(
        moved.astype(np.uint8), connectivity=8
    )
    best, best_gap = None, _AGREE_M
    for label in range(1, count):
        if stats[label, 4] < _MIN_ARM_PIXELS:
            continue
        low = float(np.percentile(height[labels == label], 2))
        if abs(low - expected_low) < best_gap:
            best, best_gap = label, abs(low - expected_low)
    if best is None:
        return None
    chosen = labels == best
    return cloud[chosen], height[chosen]


def self_calibrate(robot, camera, say=print, wanted: int = 8) -> dict:
    """Calibrate with no target and no hands. Depth camera only. Returns what
    to save, exactly as `calibrate` does, or raises with the reason."""
    arm = robot.platform.arms[0]
    _open, closed = robot.platform.joint_limits[arm]["gripper"]
    robot.gripper(arm, closed)
    robot.park(arm)
    if getattr(robot, "link", None) is not None:
        wait_until_still(robot, arm)
        robot.sync()
    rest = camera.frame()
    if rest.depth is None:
        raise ValueError(
            "zero-shot calibration needs a depth camera; with a webcam, slide a block instead: "
            "botcortex camera calibrate <object> --execute --by-hand"
        )
    up = vision.bench_up(rest)
    level = vision.bench_level(rest, up)
    spots = spots_for(robot, arm, {"size_m": [0.04, 0.04, 0.04]}, wanted=wanted)
    if len(spots) < 3:
        raise RuntimeError("the arm can reach too few clear spots on the bench to calibrate from")

    in_view, in_base = [], []
    seen_clouds, jaw_models = [], []
    for i, spot in enumerate(spots, start=1):
        robot.move_to_point(arm, spot, 0.01)
        if getattr(robot, "link", None) is not None:
            wait_until_still(robot, arm)
            robot.sync()
        frame = camera.frame()
        jaws = jaw_surface(robot, arm)
        picked = _arm_pixels(rest, frame, up, level, expected_low=float(jaws[:, 2].min()))
        if picked is None:
            say(f"    spot {i} of {len(spots)}: the camera does not see the jaws there — skipping")
            continue
        pts, height = picked
        underside = pts[height < height.min() + _UNDERSIDE_M]
        in_view.append(underside.mean(axis=0))
        in_base.append(jaw_underside(robot, arm))
        # The jaws and hand only: the lowest 6 cm of what moved, thinned so
        # the fit below stays quick.
        low = pts[height < height.min() + 0.06]
        seen_clouds.append(low[:: max(1, len(low) // 400)])
        jaw_models.append(jaws)
        say(f"    spot {i} of {len(spots)}: the camera sees the jaws ({len(underside)} pixels)")
    robot.park(arm)
    if len(in_view) < 3:
        raise RuntimeError(
            "the camera saw the jaws at fewer than three spots. Aim it so the whole bench is in "
            "the picture, keep people and everything else still while it runs, then try again."
        )
    rough, _ = vision.solve_pose(np.array(in_view), np.array(in_base))
    pose, residual = _refine(rough, seen_clouds, jaw_models)
    if residual > ACCEPTABLE_RESIDUAL_M:
        raise RuntimeError(
            f"the spots disagree by {residual * 1000:.0f} mm, which is too much to grasp by. "
            "Nothing was saved. Usual causes: the camera moved during the routine, or something "
            "else on the bench moved with the arm."
        )
    return {"camera_to_base": pose.tolist(), "residual_m": residual, "zero_shot": True}
