"""How the CLI talks: one look, no dependency.

Colour and symbols only when someone is there to see them. A terminal gets
them; a pipe, a log file, `NO_COLOR=1` or a dumb terminal gets plain text with
the same words, so nothing a script greps for ever depends on an escape code.

Four kinds of line, and the rule for choosing between them:

    ok      it is fine, and here is the fact that shows it
    warn    it works, and something about it will bite later
    bad     it does not work — ALWAYS followed by `fix`, the command to run
    note    context, no judgement

A line that says something is wrong without saying what to do about it is the
failure this module exists to prevent.
"""

from __future__ import annotations

import os
import sys
import time

_CODES = {
    "bold": "1",
    "dim": "2",
    "red": "31",
    "green": "32",
    "yellow": "33",
    "blue": "34",
    "cyan": "36",
}


def fancy(stream=None) -> bool:
    stream = stream or sys.stdout
    if os.environ.get("NO_COLOR") or os.environ.get("TERM") == "dumb":
        return False
    return bool(getattr(stream, "isatty", lambda: False)())


def paint(text: str, *styles: str) -> str:
    if not fancy() or not styles:
        return text
    return f"\033[{';'.join(_CODES[s] for s in styles)}m{text}\033[0m"


def heading(text: str) -> None:
    print()
    print(paint(text, "bold"))


def ok(text: str) -> None:
    print(f"  {paint('✓', 'green')} {text}")


def warn(text: str, fix: str | None = None) -> None:
    print(f"  {paint('!', 'yellow')} {text}")
    _fix(fix)


def bad(text: str, fix: str | None = None) -> None:
    print(f"  {paint('✗', 'red')} {text}")
    _fix(fix)


def note(text: str) -> None:
    print(f"    {paint(text, 'dim')}")


def _fix(fix: str | None) -> None:
    if fix:
        print(f"      {paint('→', 'cyan')} {fix}")


def command(text: str) -> str:
    return paint(text, "cyan")


def table(rows: list[tuple], indent: int = 2) -> None:
    """Columns aligned on their widest cell; the last column is never padded."""
    if not rows:
        return
    widths = [max(len(str(r[i])) for r in rows) for i in range(len(rows[0]) - 1)]
    for row in rows:
        cells = [str(c).ljust(w) for c, w in zip(row[:-1], widths, strict=True)]
        print(" " * indent + "  ".join([*cells, str(row[-1])]))


def ask(prompt: str, default: str | None = None) -> str:
    hint = f" [{default}]" if default else ""
    try:
        answer = input(f"  {paint('?', 'cyan')} {prompt}{hint} ").strip()
    except EOFError:
        answer = ""
    return answer or (default or "")


def confirm(prompt: str, default: bool = True) -> bool:
    answer = ask(f"{prompt} ({'Y/n' if default else 'y/N'})").lower()
    return default if not answer else answer.startswith("y")


def choose(prompt: str, options: list[tuple[str, str]], default: int = 0) -> str:
    """Pick one of (value, description). Returns the value."""
    print(f"  {paint('?', 'cyan')} {prompt}")
    for i, (value, description) in enumerate(options, start=1):
        mark = paint("›", "cyan") if i - 1 == default else " "
        print(
            f"    {mark} {i}. {value.ljust(max(len(v) for v, _ in options))}  {paint(description, 'dim')}"
        )
    while True:
        answer = ask("number", str(default + 1))
        if answer.isdigit() and 1 <= int(answer) <= len(options):
            return options[int(answer) - 1][0]
        by_name = [v for v, _ in options if v == answer]
        if by_name:
            return by_name[0]
        print("      choose one of the numbers above")


class Progress:
    """A bar on a terminal, a line per tenth elsewhere."""

    def __init__(self, label: str, total: int):
        self.label, self.total, self._last, self._start = label, max(1, total), -1, time.monotonic()

    def __call__(self, done: int, total: int | None = None) -> None:
        if total:
            self.total = max(1, total)
        fraction = min(1.0, done / self.total)
        if fancy():
            filled = round(24 * fraction)
            bar = paint("█" * filled, "cyan") + paint("░" * (24 - filled), "dim")
            sys.stdout.write(f"\r  {self.label} {bar} {done}/{self.total}")
            sys.stdout.flush()
            if done >= self.total:
                sys.stdout.write("\n")
        elif int(fraction * 10) != self._last:
            self._last = int(fraction * 10)
            print(f"  {self.label} {done}/{self.total}")
