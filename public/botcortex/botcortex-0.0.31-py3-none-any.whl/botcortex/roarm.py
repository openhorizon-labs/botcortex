"""The RoArm-M2's wire: JSON lines over a serial port, and the unit mapping.

Everything here was read from Waveshare's own sources rather than remembered:

- commands and reply fields: `RoArm-M2_example/json_cmd.h` and
  `RoArm-M2_module.h` in github.com/waveshareteam/roarm_m2
- the mapping between URDF joint angles and the firmware's: `roarm_driver.py`
  in github.com/waveshareteam/roarm_ws_em0 (branch ros2-humble). Our MuJoCo
  model transcribes that URDF joint for joint (model/PROVENANCE.md), so the
  vendor's own signs apply to it unchanged.

Two things the firmware does that a caller must know:

`{"T":0}`, the firmware's "emergency stop", RELEASES ALL TORQUE FOR TEN
SECONDS. On a desk that is an arm falling onto whatever it was holding over.
So STOP here means "send nothing more": the servos hold their last target,
which is what a person pressing STOP expects. `limp()` exists for the case
where letting go is what is wanted, and it is never called by a guard.

`{"T":102,...,"spd":0}` moves at the servo's full speed. That is safe only
because the runtime streams one frame per control tick and `plan_move` has
already capped how far a frame may travel. The velocity cap lives there, once.

No pyserial import at module level: the package must import in a browser and
on a laptop with no arm attached.
"""

from __future__ import annotations

import json
import math
import time

BAUD = 115200
_FEEDBACK = 1051


class LinkError(RuntimeError):
    """The arm did not answer, or answered something unreadable."""


def to_wire(
    frame: dict[str, float], jaw_open_rad: float, gripper_limits: tuple[float, float]
) -> dict:
    """Our degrees -> the firmware's radians, for whichever joints `frame` has.

    base and shoulder are negated and the elbow is not, per the vendor driver.
    The hand runs from pi (closed) down by the jaw's opening, so a gripper at
    its open limit is pi - jaw_open_rad.
    """
    out: dict[str, float] = {}
    if "j1" in frame:
        out["base"] = -math.radians(frame["j1"])
    if "j2" in frame:
        out["shoulder"] = -math.radians(frame["j2"])
    if "j3" in frame:
        out["elbow"] = math.radians(frame["j3"])
    if "gripper" in frame:
        lo, hi = gripper_limits
        openness = (hi - frame["gripper"]) / (hi - lo)
        out["hand"] = math.pi - openness * jaw_open_rad
    return out


def from_wire(
    reply: dict, jaw_open_rad: float, gripper_limits: tuple[float, float]
) -> dict[str, float]:
    """A T=1051 feedback reply -> our degrees. The inverse of to_wire."""
    lo, hi = gripper_limits
    openness = (math.pi - float(reply["t"])) / jaw_open_rad
    return {
        "j1": -math.degrees(float(reply["b"])),
        "j2": -math.degrees(float(reply["s"])),
        "j3": math.degrees(float(reply["e"])),
        "gripper": hi - openness * (hi - lo),
    }


def _cannot_open(device: str, error: OSError) -> str:
    """Why a port would not open, in the words of what to do about it."""
    text = str(error).lower()
    if "permission" in text or "access is denied" in text:
        return (
            f"no permission to open {device}. On Linux: sudo usermod -aG dialout $USER, then log "
            "out and in. Or another program has the port open (a serial monitor, another botcortex)."
        )
    if "busy" in text or "resource" in text:
        return (
            f"{device} is in use by another program — close any serial monitor or other botcortex."
        )
    if "no such file" in text or "could not open" in text or "cannot find" in text:
        return f"there is no port {device}. Is the arm plugged in and powered? See: botcortex arm status"
    return f"could not open {device}: {error}"


class RoArmLink:
    """One open port. `port` is anything with write(bytes), readline() -> bytes
    and close(); `open_serial` builds the real one, tests pass a fake."""

    def __init__(self, port, reply_timeout: float = 0.5, reopen=None):
        self._port = port
        self._timeout = reply_timeout
        #: () -> a fresh port, for a link that can heal itself. A real serial
        #: link has one; a port handed in by a test does not.
        self._reopen = reopen
        self.reconnects = 0

    @classmethod
    def open_serial(cls, device: str) -> RoArmLink:
        try:
            import serial
        except ImportError as e:  # pragma: no cover
            raise ImportError(
                "a real RoArm needs pyserial — install the real extra: uv sync --extra real"
            ) from e

        def opened():
            try:
                port = serial.Serial(device, BAUD, timeout=0.2)
            except OSError as e:
                raise LinkError(_cannot_open(device, e)) from e
            # The ESP32 resets when the port opens and prints a boot banner.
            time.sleep(2.0)
            port.reset_input_buffer()
            return port

        return cls(opened(), reopen=opened)

    def _write(self, data: bytes) -> None:
        """Write, and if the port has gone — a nudged USB cable, a hub that
        napped — open it again ONCE and write again. A cable that stays out is
        an error worth stopping for; one that blinked is not."""
        try:
            self._port.write(data)
            return
        except OSError as lost:
            if self._reopen is None:
                raise LinkError(f"the connection to the arm was lost: {lost}") from lost
            try:
                self._port.close()
            except OSError:
                pass
        try:
            self._port = self._reopen()
            self.reconnects += 1
            self._port.write(data)
        except (OSError, LinkError) as gone:
            raise LinkError(
                "the arm's USB connection dropped and did not come back. The arm is holding "
                f"its last pose. Check the cable and power, then start again. ({gone})"
            ) from gone

    def send(self, command: dict) -> None:
        self._write((json.dumps(command) + "\n").encode("utf-8"))

    def joints(self, wire: dict[str, float]) -> None:
        """Command every joint at once. Joints missing from `wire` must be
        filled by the caller: T=102 has no 'leave this one alone'."""
        self.send({"T": 102, **{k: round(v, 5) for k, v in wire.items()}, "spd": 0, "acc": 0})

    def feedback(self) -> dict:
        """Ask where the arm is. Skips anything that is not the answer: the
        firmware interleaves echoes and info lines on the same port."""
        self.send({"T": 105})
        deadline = time.monotonic() + self._timeout
        while time.monotonic() < deadline:
            try:
                line = self._port.readline()
            except OSError as lost:
                raise LinkError(
                    f"the connection to the arm was lost while reading: {lost}"
                ) from lost
            if not line:
                continue
            try:
                reply = json.loads(line.decode("utf-8", "replace").strip())
            except ValueError:
                continue
            if isinstance(reply, dict) and reply.get("T") == _FEEDBACK:
                return reply
        raise LinkError("the arm did not report its position — is it powered and on this port?")

    def torque(self, enabled: bool) -> None:
        self.send({"T": 210, "cmd": 1 if enabled else 0})

    def limp(self) -> None:
        """Let go of every joint. The arm WILL fall. Never called by a guard."""
        self.torque(False)

    def close(self) -> None:
        self._port.close()
