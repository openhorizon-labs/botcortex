"""@beta_tool wrappers — the authoring agent's entire reach into the runtime.

The agent sees: primitives (bounded motion), the skill store, and episodic
memory. Nothing else. Tool bodies live on TeachSession (plain methods, unit
testable); this module only adapts them to the Claude tool-runner.

Motion here is TEACH-path motion: it runs on whatever robot the session holds
(mock in v0, dry-run twin on hardware). Deterministic replay of a saved skill —
the run path — never involves these tools.
"""

import json
from uuid import uuid4

from anthropic import beta_tool

from botcortex import config
from botcortex import session as session_mod

# The docstrings below are written for a two-armed robot with OpenArm's
# gripper degrees, because that is the body they were measured on. Before a
# docstring becomes a tool description it is rewritten for the body that
# actually loaded — its arm names, joint range and gripper limits — so an
# agent driving a one-armed RoArm is never offered "left" or "right".
_ARM_WORDS = " or ".join(f'"{arm}"' for arm in config.ARMS)
_JOINTS = config.PLATFORM.joints
_G_OPEN, _G_CLOSED = config.JOINT_LIMITS[config.ARMS[0]]["gripper"]


def _for_this_body(fn):
    fn.__doc__ = (
        (fn.__doc__ or "")
        .replace('"left" or "right"', _ARM_WORDS)
        .replace("j1..j7", f"{_JOINTS[0]}..{_JOINTS[-1]}")
        .replace(
            "(0 = closed/rest, -65 = fully open)",
            f"({_G_CLOSED:g} = closed/rest, {_G_OPEN:g} = fully open)",
        )
        .replace("within [-65, 0]", f"within [{_G_OPEN:g}, {_G_CLOSED:g}]")
        .replace('e.g. "wave_right_arm"', f'e.g. "wave_{config.ARMS[0]}_arm"')
    )
    return beta_tool(fn)


#: Results can be long — a joint dump, a whole skill listing. The wire carries
#: a preview for the operator to read; the robot keeps the real thing.
MAX_RESULT_CHARS = 500


def _traced(session, name: str, inputs: dict, run):
    """Run a tool, announcing what it is doing on the way in and out.

    Wrapped HERE, inside the closure, rather than around the BetaFunctionTool
    objects: those expose a writable `.func`, but `.call` — which the Anthropic
    tool runner uses — captures the original at decoration time and ignores it.
    Patching `.func` would have traced the OpenAI path and silently missed the
    other one.

    Inputs go out in full. `save_skill`'s code is the whole point of watching:
    seeing the program the agent wrote is what makes this legible.
    """
    call_id = uuid4().hex[:8]
    session.emit({"type": "tool", "id": call_id, "name": name, "input": inputs})
    try:
        result = run()
    except Exception as e:  # reported to the operator, then re-raised untouched
        session.emit(
            {
                "type": "tool_result",
                "id": call_id,
                "ok": False,
                "result": f"{type(e).__name__}: {e}",
            }
        )
        raise
    text = str(result)
    session.emit(
        {
            "type": "tool_result",
            "id": call_id,
            # The tool bodies report failure in the return value, not by
            # raising — session.failed owns that convention, and the contract
            # carries it so the browser classifies identically.
            "ok": not session_mod.failed(text),
            "result": text[:MAX_RESULT_CHARS],
        }
    )
    return result


def build_tools(session):
    """Return the tool list for one teach conversation, closed over `session`."""

    @_for_this_body
    def get_positions(arm: str) -> str:
        """Read the robot's current joint positions in degrees.

        Args:
            arm: Which arm to read, "left" or "right".
        """
        return _traced(
            session,
            "get_positions",
            {"arm": arm},
            lambda: json.dumps(session.tool_get_positions(arm)),
        )

    @_for_this_body
    def move_to(arm: str, targets_json: str, duration: float | None = None) -> str:
        """Move one arm's joints to target angles (degrees). The runtime clamps
        targets inside vendor limits, interpolates at 20 Hz with a velocity cap,
        and aborts between steps if the e-stop fires. Prefer saving a skill and
        running it over long chains of raw moves.

        Args:
            arm: "left" or "right".
            targets_json: JSON object of joint name to degrees, e.g. '{"j4": 60.0}'.
                Joints are j1..j7 and "gripper".
            duration: Optional seconds for the move; extended if the velocity cap needs more.
        """
        targets = json.loads(targets_json)
        return _traced(
            session,
            "move_to",
            {"arm": arm, "targets": targets, "duration": duration},
            lambda: session.tool_move_to(arm, targets, duration),
        )

    @_for_this_body
    def report(done: bool, summary: str) -> str:
        """Say whether the task is actually finished. Call this LAST, always.

        Judge it on what moved and where it ended up — run_skill tells you, in
        centimetres and by name. Not on whether your calls returned without
        error: a skill that runs perfectly and moves nothing has still failed.

        done=False is a good answer when it is the true one. An honest "I could
        not do this, and here is what went wrong" is worth far more than a
        claim that does not hold, and the runtime will not overrule it.

        Args:
            done: True only if the evidence shows the task achieved.
            summary: One or two plain sentences for the robot's owner.
        """
        return _traced(
            session,
            "report",
            {"done": done, "summary": summary},
            lambda: session.tool_report(done, summary),
        )

    @_for_this_body
    def can_reach(arm: str, point_json: str) -> str:
        """Ask whether an arm can put its gripper on a point, WITHOUT moving.

        Free, instant, and it changes nothing. Use it on every waypoint you
        intend to use before you save a skill: a point out of reach is far
        cheaper to discover here than inside a run.

        It answers REACHABILITY only — whether the arm can put its gripper
        there at all. It does not promise the way there is clear; a move
        between two reachable points can still sweep through the table, and the
        rehearsal is what catches that. Two different questions, both worth
        asking.

        When the answer is no it says what would work instead: the other arm,
        or a lower approach.

        Args:
            arm: "left" or "right".
            point_json: JSON array [x, y, z] in metres, e.g. '[0.32, -0.05, 0.34]'.
        """
        return _traced(
            session,
            "can_reach",
            {"arm": arm, "point": json.loads(point_json)},
            lambda: session.tool_can_reach(arm, json.loads(point_json)),
        )

    @_for_this_body
    def move_to_point(arm: str, point_json: str) -> str:
        """Put the gripper on a point in space, in the SAME metres describe_scene
        reports, with the jaws pointing down. Solved and clamped by the runtime.

        This is how you reach an object. describe_scene answers in metres and
        move_to takes degrees; nothing you can compute in a skill bridges the
        two, so guessing joint angles for a grasp does not work — it runs
        cleanly and moves nothing.

        Approach from ABOVE: go to a point ~12 cm over the target first, then
        down onto it. A move between two safe points is interpolated in JOINT
        space and can still sweep the arm through whatever lies between them.

        Refused, not approximated, when the point is out of reach.

        Args:
            arm: "left" or "right".
            point_json: JSON array [x, y, z] in metres, e.g. '[0.22, -0.16, 0.34]'.
        """
        point = json.loads(point_json)
        return _traced(
            session,
            "move_to_point",
            {"arm": arm, "point": point},
            lambda: session.tool_move_to_point(arm, point),
        )

    @_for_this_body
    def gripper(arm: str, position: float) -> str:
        """Set a gripper position in degrees (0 = closed/rest, -65 = fully open).

        Args:
            arm: "left" or "right".
            position: Target angle in degrees within [-65, 0].
        """
        return _traced(
            session,
            "gripper",
            {"arm": arm, "position": position},
            lambda: session.tool_gripper(arm, position),
        )

    @_for_this_body
    def describe_scene() -> str:
        """Look at the workspace: every object you can pick up, plus the fixtures
        around them, with positions in metres and full sizes.

        Call this FIRST for any task that mentions an object, a colour, a tray or
        a place. Positions move between attempts — a skill that hardcodes them
        works exactly once, so read the scene inside the skill rather than baking
        the numbers into it.
        """
        return _traced(session, "describe_scene", {}, session.tool_describe_scene)

    @_for_this_body
    def free_spot(fixture: str, carrying: str = "") -> str:
        """Ask where to SET SOMETHING DOWN inside a fixture, WITHOUT moving.

        The companion to can_reach: that one answers whether the arm can get
        somewhere, this one answers whether there is room once it does. Free,
        instant, changes nothing.

        Use it for every placement into a tray, bin or pocket, and use it
        again for each object — a tray that had room for the first one may not
        have room in the same place for the second. Putting two objects at the
        same point is not a routing problem and no amount of rerouting fixes
        it; the arm is refused for displacing the one already there.

        Args:
            fixture: the fixture to put something in, e.g. "tray_right".
            carrying: the object being placed, so its own position is not
                counted as something in the way. Optional.
        """
        return _traced(
            session,
            "free_spot",
            {"fixture": fixture, "carrying": carrying},
            lambda: session.tool_free_spot(fixture, carrying or None),
        )

    @_for_this_body
    def list_skills() -> str:
        """List the skills this robot has been SEEN TO RUN (name, description, params).

        Always check here before writing new code — reusing a skill that works
        costs nothing. Anything under `do_not_reuse` was saved but never ran
        successfully: it is a draft, not a skill, and running it or building on
        it inherits a failure that was already diagnosed once. Write that
        behaviour yourself and save over the name instead.
        """
        return _traced(session, "list_skills", {}, session.tool_list_skills)

    @_for_this_body
    def save_skill(name: str, code: str) -> str:
        """Save a new skill as a Python file the runtime executes deterministically.

        The file must define META = {"name": <name>, "description": str,
        "params": {<param>: <default>}} and run(ctx, **params). Inside run, the
        robot is reachable ONLY through ctx: ctx.move_to(arm, targets, duration),
        ctx.gripper(arm, position), ctx.get_positions(arm), ctx.set_torque,
        ctx.replay_trajectory, ctx.describe_scene(), ctx.free_spot(fixture),
        ctx.pick_up(arm, object), ctx.place_in(arm, fixture, object). Use
        pick_up for every grasp and place_in for every placement into a tray,
        bin or pocket instead of points you picked: pick_up squares the jaws to
        the object on arms that need it, and without place_in the second
        object is lowered onto the first. No imports (math is available as `math`), no
        filesystem, no network.

        Args:
            name: snake_case skill name, e.g. "wave_right_arm".
            code: The complete Python source of the skill file.
        """
        return _traced(
            session,
            "save_skill",
            {"name": name, "code": code},
            # as_agent: this wrapper IS the model's hand (see run_skill).
            lambda: session.tool_save_skill(name, code, as_agent=True),
        )

    @_for_this_body
    def run_skill(name: str, params_json: str = "{}") -> str:
        """Execute a saved skill on the robot and report the outcome. This is the
        same deterministic path the Run button uses — test your skill with it.

        Args:
            name: The skill to run.
            params_json: JSON object of parameter overrides, e.g. '{"repeats": 2}'.
        """
        params = json.loads(params_json)
        return _traced(
            session,
            "run_skill",
            {"name": name, "params": params},
            # as_agent: this wrapper IS the model's hand. The runtime refuses
            # to reuse a skill that has never run successfully from here, and
            # nowhere else.
            lambda: session.tool_run_skill(name, params, as_agent=True),
        )

    @_for_this_body
    def recall_episodes(query: str) -> str:
        """Search memory for a task. Returns {"episodes": past attempts and their
        lessons, "worked_examples": up to two skills that already WORK on this
        robot and are most like the task, with their code}. Check before
        authoring: start from a worked example when there is one, and apply the
        lessons.

        Args:
            query: Free-text description of the task, e.g. "fold towel both arms".
        """
        return _traced(
            session,
            "recall_episodes",
            {"query": query},
            lambda: session.tool_recall_episodes(query),
        )

    @_for_this_body
    def log_lesson(lesson: str) -> str:
        """Record what this attempt taught you, so the next authoring run recalls
        it. Call after failures especially — one concrete sentence.

        Args:
            lesson: The lesson, e.g. "j4 near 135 collides with the table; keep under 100".
        """
        return _traced(
            session,
            "log_lesson",
            {"lesson": lesson},
            lambda: session.tool_log_lesson(lesson),
        )

    # This list IS the registry — defining a @beta_tool above and forgetting it
    # here leaves a tool the agent can never call, and the contract test cannot
    # see the omission because it compares the contract against THIS list.
    # test_every_defined_tool_is_offered closes that.
    return [
        get_positions,
        move_to,
        can_reach,
        free_spot,
        move_to_point,
        report,
        gripper,
        describe_scene,
        list_skills,
        save_skill,
        run_skill,
        recall_episodes,
        log_lesson,
    ]
