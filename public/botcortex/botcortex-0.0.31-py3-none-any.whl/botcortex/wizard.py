"""`botcortex setup`: from a box on the desk to a robot that can be taught.

Everything here can also be done one command at a time, and the wizard says
which command each step was, so the second robot is quicker than the first.
What it adds is ORDER — body, software, arm, camera, account — because each
step only makes sense once the one before it is settled, and a person doing
this for the first time has no way to know that.

Nothing in it moves the arm without asking first, in those words.
"""

from __future__ import annotations

from botcortex import config, doctor, settings, ui


def _show(findings) -> bool:
    """Print findings; True when none of them is a blocker."""
    clear = True
    for f in findings:
        {"ok": ui.ok, "warn": ui.warn, "bad": ui.bad}.get(f.level, lambda t, fix=None: ui.note(t))(
            f.text, *([f.fix] if f.level in ("warn", "bad") else [])
        )
        if f.level == "note" and f.fix:
            ui.note(f"→ {f.fix}")
        clear = clear and f.level != "bad"
    return clear


def run(ask=ui.ask, confirm=ui.confirm, choose=ui.choose) -> int:
    from botcortex.platform import available_platforms, load_platform
    from botcortex.real import DRIVERS

    print()
    print(ui.paint("  BotCortex setup", "bold"))
    ui.note("Five short steps. Press Enter to accept what is in [brackets]. Ctrl-C leaves, and")
    ui.note("anything already answered stays saved.")

    # 1 — which body ---------------------------------------------------------
    ui.heading("1 of 5  Which robot is this?")
    names = available_platforms()
    options = [
        (
            n,
            ("real arm + simulation" if n in DRIVERS else "simulation only")
            + f" — {load_platform(n).display_name}",
        )
        for n in sorted(names, key=lambda n: (n not in DRIVERS, n))
    ]
    current = config.PLATFORM.name
    chosen = choose(
        "robot body",
        options,
        default=[v for v, _ in options].index(current) if current in names else 0,
    )
    if chosen != current or settings.source("platform") == "default":
        settings.put("platform", chosen)
        config.PLATFORM = load_platform(chosen)
    ui.ok(
        f"{config.PLATFORM.display_name}   {ui.paint('botcortex config set platform ' + chosen, 'dim')}"
    )
    real = chosen in DRIVERS

    # 2 — software -----------------------------------------------------------
    ui.heading("2 of 5  Is everything installed?")
    if not _show(doctor.check_install()):
        ui.note(
            "Install what is marked ✗, then run `botcortex setup` again. Nothing else will work until then."
        )
        return 1

    # 3 — the arm ------------------------------------------------------------
    ui.heading("3 of 5  The arm")
    if not real:
        ui.note(
            "This body runs in simulation only, so there is no arm to find. Try it: botcortex serve --sim"
        )
    else:
        ports = doctor.serial_ports()
        if not ports:
            ui.warn(
                "no USB serial device found",
                "plug in the arm's USB cable, switch on its power, and run setup again",
            )
            ui.note(
                "You can carry on without it: everything works in simulation (botcortex serve --sim)."
            )
        else:
            device = (
                ports[0]
                if len(ports) == 1
                else choose("which port is the arm?", [(p, "") for p in ports])
            )
            settings.put("device", device)
            ui.ok(f"{device}   {ui.paint('botcortex config set device ' + device, 'dim')}")
            if confirm(
                "Ask the arm where it is? (reads only, nothing moves; its controller restarts, which is normal)"
            ):
                _show(doctor.check_arm(probe_arm=True)[1:])
            ui.note(
                "Before the first task, check each joint turns the right way: botcortex arm check --execute"
            )

    # 4 — the camera ---------------------------------------------------------
    ui.heading("4 of 5  The camera")
    if not real:
        ui.note("The simulator knows where everything is; no camera needed.")
    elif confirm("Look for cameras now? (each one is switched on for a moment)"):
        from botcortex import camera as cameras

        found = cameras.list_cameras()
        if not found:
            ui.warn(
                "no camera found",
                "plug one in, or point at a phone/IP camera: botcortex camera use http://…",
            )
        else:
            labels = [
                ("realsense", c["name"] + " (depth)")
                if c["kind"] == "realsense"
                else (f"webcam {c['source']}", f"{c['size'][1]}x{c['size'][0]}")
                for c in found
            ]
            pick = choose("which camera looks at the bench?", labels)
            path = cameras.settings_path(config.DATA_DIR, config.PLATFORM.name)
            picked = (
                {"kind": "realsense"}
                if pick == "realsense"
                else {"kind": "opencv", "source": int(pick.split()[1])}
            )
            before = cameras.load_settings(path)
            if {k: before.get(k) for k in picked} != picked:
                path.unlink(missing_ok=True)  # another camera stands somewhere else
                cameras.save_settings(path, **picked)
            ui.ok(f"{pick}   {ui.paint('botcortex camera use ' + pick, 'dim')}")
            ui.note("Then, in this order, with the runtime running (botcortex serve --real):")
            ui.note(
                "  botcortex camera measure --add <name>    what is on the bench, sized by the camera"
            )
            ui.note(
                "  botcortex camera calibrate --execute     where the camera stands (the arm points)"
            )
            ui.note(
                "  botcortex camera colours                 what your objects look like in your light"
            )
    _show(doctor.check_camera()) if real else None

    # 5 — the account --------------------------------------------------------
    ui.heading("5 of 5  Your BotCortex account")
    from botcortex import cloud

    if not cloud.paired():
        ui.note("Pairing lets this robot teach with your BotCortex credit and appear in the app.")
        ui.note(f"When you are ready: {ui.command('botcortex login')}")
    else:
        _show(doctor.check_cloud()[:1])
        print()
        ui.note(
            "Sharing runs sends BotCortex what this robot did on each task: the sentence, joint"
        )
        ui.note(
            "positions, the outcome, the skill's code and — from a real arm — video from the bench"
        )
        ui.note("camera. It is how the product learns what fails on real robots. Off means all of")
        ui.note(
            "that stays on this machine. Change it any time: botcortex config set share_runs on|off"
        )
        settings.put(
            "share_runs",
            confirm("Share this robot's runs with BotCortex?", default=config.SHARE_RUNS),
        )
        ui.ok("shared" if settings.flag("share_runs", False) else "kept on this machine")

    ui.heading("Done. What is left, if anything:")
    todo = [
        f
        for _, findings in doctor.examine(online=False)
        for f in findings
        if f.level in ("bad", "warn") and f.fix
    ]
    if not todo:
        ui.ok(
            f"nothing. Start the robot: {ui.command('botcortex serve --real' if real else 'botcortex serve --sim')}"
        )
    for f in todo:
        ui.warn(f.text, f.fix)
    return 0
