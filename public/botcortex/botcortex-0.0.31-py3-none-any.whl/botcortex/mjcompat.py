"""Where the native MuJoCo binding and the WASM one disagree.

Two differences, and both are invisible from a Mac. Code written against the
native binding reads perfectly, passes every test, and then throws in a browser
— which is how `describe_scene` came to be broken in the browser sim while the
runtime's own suite stayed green.

  ENUMS. Native `mujoco.mjtObj.mjOBJ_BODY` is an IntEnum. The WASM build's is an
  embind object, `{value: 1}`, and passing it to mj_id2name raises
  `TypeError: Cannot convert "[object Object]" to int`. Comparing one to a
  number is worse than an error: `model.jnt_type[j] == mujoco.mjtJoint.mjJNT_FREE`
  is simply False for every joint, so every free body silently stops being an
  object and the workcell appears to contain nothing but fixtures.

  LAYOUT. Native `data.xpos[body]` is a 3-vector — the arrays are 2-D. In WASM
  they are FLAT Float64Array views, so the same expression returns one number,
  and `[float(v) for v in that]` fails. Measured on our own model: nbody=34 and
  len(xpos)=102, ngeom=36 and len(geom_size)=108.

Both are handled here rather than at each call site, for the same reason
`plan_move` and `JointMap` exist: a second copy of a rule is a rule that only
holds until someone edits one of them. It is also why the index arithmetic
below lives here and not in wasm.py, which is asserted to contain none.
"""

from __future__ import annotations


def enum_value(member) -> int:
    """A MuJoCo enum as an integer, whichever build produced it.

    Native IntEnums carry `.value` too, so this is one expression rather than a
    branch on which environment we are in — and something that never branches
    cannot take the wrong branch in the environment nobody is testing in.
    """
    return int(getattr(member, "value", member))


def row(array, index: int, width: int) -> list[float]:
    """One entry of a per-body/per-geom field, however this build stores it.

    Asks the array rather than being told which build it came from: a native
    row is iterable, a flat one yields a float and raises. The fallback is the
    flat slice.
    """
    try:
        return [float(value) for value in array[index]]
    except TypeError:
        start = index * width
        return [float(array[i]) for i in range(start, start + width)]


def is_flat(array) -> bool:
    """Whether this build stores per-body fields as one flat array. Asked once,
    at construction, so the solver's inner loop does not pay for an exception
    per read to find out again — `row` discovers it by raising, which is fine
    for a question asked once a frame and not for one asked 58,000 times a
    solve."""
    try:
        iter(array[0])
    except TypeError:
        return True
    return False


def flat_row(array, index: int, width: int) -> list[float]:
    """`row` for an array already known to be flat."""
    start = index * width
    return [float(array[i]) for i in range(start, start + width)]
