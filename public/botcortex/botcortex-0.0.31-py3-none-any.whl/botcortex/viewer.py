"""What the web app's 3D viewer needs to draw THIS body: the loaded model's
kinematic tree, its visible geometry, and how runtime degrees reach each
model joint.

The viewer carries a URDF for the OpenArm and nothing else, by design — a
body that is not an OpenArm must not be drawn as one. Every other body is
drawn from the tree its robot sends in the hello. The browser sim builds that
tree inside its worker (lib/robot/browser-sim/worker.ts); this is the same
description for a runtime with native MuJoCo, so a RoArm on a Raspberry Pi is
drawn from the very model it plans in.

Meshes travel as one binary blob (float32 vertices, uint32 faces, back to
back) that the entries in `meshes` index, never as JSON numbers: the Panda's
visual meshes are 1.6 million of them.
"""

from __future__ import annotations

import array

from botcortex import mjcompat, scene

#: MuJoCo geom types the viewer can draw, by mjtGeom value.
_GEOM = {2: "sphere", 3: "capsule", 5: "cylinder", 6: "box", 7: "mesh"}
#: Joint types, by mjtJoint value; anything else is drawn fixed.
_JOINT = {2: "slide", 3: "hinge"}


def describe(mujoco, model, platform, joints, arms, joint_limits) -> tuple[dict, bytes]:
    """(tree, mesh blob) for the viewer. `joints` is the robot's JointMap."""

    def name(kind: str, index: int) -> str:
        return (
            mujoco.mj_id2name(model, mjcompat.enum_value(getattr(mujoco.mjtObj, kind)), index) or ""
        )

    robot = scene.robot_bodies(mujoco, model, platform.sim)
    nbody = int(model.nbody)
    body_names = {i: name("mjOBJ_BODY", i) for i in range(nbody)}

    joints_by_body: dict[int, list[dict]] = {}
    qpos_joint: dict[int, str] = {}
    for j in range(int(model.njnt)):
        entry = {
            "name": name("mjOBJ_JOINT", j),
            "type": _JOINT.get(int(model.jnt_type[j]), "other"),
            "axis": mjcompat.row(model.jnt_axis, j, 3),
            "pos": mjcompat.row(model.jnt_pos, j, 3),
        }
        joints_by_body.setdefault(int(model.jnt_bodyid[j]), []).append(entry)
        qpos_joint[int(model.jnt_qposadr[j])] = entry["name"]

    geoms_by_body: dict[int, list[dict]] = {}
    meshes: dict[str, dict] = {}
    blob = bytearray()
    for g in range(int(model.ngeom)):
        kind = _GEOM.get(int(model.geom_type[g]))
        # Group 3 is physics-only (collision primitives under a visual mesh),
        # hidden exactly as MuJoCo's own viewer hides it.
        if kind is None or int(model.geom_group[g]) == 3:
            continue
        mat = int(model.geom_matid[g])
        entry = {
            "type": kind,
            "size": mjcompat.row(model.geom_size, g, 3),
            "pos": mjcompat.row(model.geom_pos, g, 3),
            "quat": mjcompat.row(model.geom_quat, g, 4),
            "rgba": mjcompat.row(model.mat_rgba, mat, 4)
            if mat >= 0
            else mjcompat.row(model.geom_rgba, g, 4),
        }
        if kind == "mesh":
            mid = int(model.geom_dataid[g])
            mesh_name = name("mjOBJ_MESH", mid)
            entry["mesh"] = mesh_name
            if mesh_name not in meshes:
                va, vn = int(model.mesh_vertadr[mid]), int(model.mesh_vertnum[mid])
                fa, fn = int(model.mesh_faceadr[mid]), int(model.mesh_facenum[mid])
                verts = array.array(
                    "f", (float(v) for v in model.mesh_vert[va : va + vn].reshape(-1))
                )
                faces = array.array(
                    "I", (int(v) for v in model.mesh_face[fa : fa + fn].reshape(-1))
                )
                meshes[mesh_name] = {
                    "vertexOffset": len(blob),
                    "vertexCount": len(verts),
                    "faceOffset": len(blob) + verts.itemsize * len(verts),
                    "faceCount": len(faces),
                }
                blob.extend(verts.tobytes())
                blob.extend(faces.tobytes())
        geoms_by_body.setdefault(int(model.geom_bodyid[g]), []).append(entry)

    bodies = [
        {
            "name": body_names[i],
            "parent": body_names[int(model.body_parentid[i])],
            "pos": mjcompat.row(model.body_pos, i, 3),
            "quat": mjcompat.row(model.body_quat, i, 4),
            "joints": joints_by_body.get(i, []),
            "geoms": geoms_by_body.get(i, []),
        }
        for i in range(1, nbody)
        if body_names[i] in robot
    ]

    # How a runtime degree reaches each model joint: qpos = a * deg + b, read
    # off two writes, so the viewer never re-implements the joint map.
    drive: dict[str, dict[str, list[dict]]] = {}
    for arm in arms:
        drive[arm] = {}
        for joint in joint_limits[arm]:
            at_zero, at_ten = (
                joints.qpos_writes(arm, joint, 0.0),
                joints.qpos_writes(arm, joint, 10.0),
            )
            drive[arm][joint] = [
                {"joint": qpos_joint.get(i0, ""), "a": (v1 - v0) / 10.0, "b": v0}
                for (i0, v0), (_i1, v1) in zip(at_zero, at_ten, strict=True)
            ]
    return {"bodies": bodies, "drive": drive, "meshes": meshes}, bytes(blob)


def for_robot(robot) -> tuple[dict, bytes] | None:
    """The description for a robot that has a MuJoCo model, else None (the
    mock has joints and no world, and the viewer draws it as an OpenArm)."""
    if not all(hasattr(robot, attr) for attr in ("_mujoco", "model", "joints", "platform")):
        return None
    body = robot.platform
    return describe(robot._mujoco, robot.model, body, robot.joints, body.arms, body.joint_limits)
