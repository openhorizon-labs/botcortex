# RoArm-M2 model provenance

Meshes (`meshes/*.STL`) and `roarm_description.urdf` are vendored verbatim from
Waveshare's ROS 2 package `roarm_description`:

- Repository: https://github.com/waveshareteam/roarm_ws_em0
- Branch `ros2-humble`, commit `f06b2ed6c1ddc5b7690975fdbba84aab626a2229`
  (vendored 15 September 2026)
- Path: `src/roarm_main/roarm_description/`
- Licence: the package declares `<license>MIT</license>` in its `package.xml`
  (copied here as the licence record; the repository carries no separate
  LICENSE file).

`roarm_m2.xml` is ours. Body frames, joint axes and limits, and each mesh's
placement are transcribed from MuJoCo's import of the URDF; the meshes are
visual-only, collision is primitives sized from the mesh extents, the clamp
gets contact pads, and position actuators with PLACEHOLDER gains stand in for
the ST3235 servos until the real controller is measured.
