"""Hard limits, paths, and control constants.

Safety values here are bounds, not preferences — user config may tune WITHIN them,
never beyond (see the runtime-architecture blueprint).
"""

import os
from pathlib import Path

# Keys and model choice live in a gitignored .env beside the package — on the
# robot, not in our cloud. BYO-model is a product promise, not a convenience.
#
# Optional because this module is also imported in the browser, where Pyodide
# runs the primitives and the skill executor against MuJoCo compiled to WASM.
# There is no .env there and never will be, so requiring python-dotenv would
# mean shipping a package across the network purely to no-op. Everything below
# falls back to os.environ, which is what dotenv populates anyway.
try:
    from dotenv import load_dotenv

    load_dotenv(Path(__file__).parent.parent / ".env")
except ModuleNotFoundError:  # pragma: no cover - only the browser lacks it
    pass

from botcortex import settings

CONTROL_HZ = 20
MAX_VEL_DEG_S = 30.0
SAFETY_MARGIN_DEG = 5.0
STOP_FILE = Path.home() / "openarm_agent_STOP"

# Where customer-owned artifacts live. Skills and episodes belong to the robot's
# owner and never leave the device (their sync is the paid cloud feature, later).
DATA_DIR = settings.data_dir()
SKILLS_DIR = DATA_DIR / "skills"
MEMORY_FILE = DATA_DIR / "memory" / "episodes.jsonl"
#: Runs kept tick by tick as training data (botcortex.episodes). Off unless
#: BOTCORTEX_RECORD is set: an episode with images is megabytes, and an owner
#: who only wants their robot to work should not find a disk full of them.
EPISODES_DIR = DATA_DIR / "episodes"
RECORD = settings.flag("record", False)
#: Runs waiting to reach the API, and their footage (botcortex.outbox).
OUTBOX_DIR = DATA_DIR / "outbox"
#: Also send them to the API's database (needs a paired robot). Separate from
#: RECORD, and off by default: the product's promise is that a robot's traces
#: stay on the robot unless its owner says otherwise.
SHARE_RUNS = settings.flag("share_runs", False)

# Authoring brain (teach path ONLY — never the control loop). BYO-model:
# swappable via env now, config.toml later.
# Matches botcortex-api's DEFAULT_MODEL. Cheap enough that a small credit
# grant buys plenty of teaching, current enough to write good skills. The app
# names a model per task anyway; this is only the fallback when nothing does.
MODEL = settings.get("model", "gpt-5.6-luna")

# BotCortex cloud. A robot key (minted in the web app, `bx_live_…`) routes
# model calls through our metered endpoint and spends the account's credits;
# leaving it unset keeps the vendor SDKs on the owner's own keys. Both paths
# are first-class — see botcortex/cloud.py.
API_URL = os.environ.get("BOTCORTEX_API_URL", "https://botcortex-api.vercel.app").rstrip("/")
API_KEY = os.environ.get("BOTCORTEX_API_KEY")


def provider_for(model: str) -> str:
    """Which SDK drives a given model name. The owner picks the model; the
    runtime picks the client."""
    name = model.lower()
    if name.startswith(("gpt", "o1", "o3", "o4", "chatgpt")):
        return "openai"
    return "anthropic"


PROVIDER = provider_for(MODEL)

# Static web app build (the Next.js out/ dir) served by the runtime, if present.
WEB_DIR = Path(os.environ.get("BOTCORTEX_WEB", DATA_DIR / "web"))

# The active platform descriptor supplies vendor joint limits (degrees), arm
# names, and the home pose. Limits are clamped a further SAFETY_MARGIN_DEG
# inside by the primitives (gripper excepted — a margin there would prevent
# full open/close). Home sits SAFETY_MARGIN_DEG off any joint whose vendor
# range starts/ends at 0 (OpenArm j4: 0..135 → home 5.0 — resting ON a hard
# stop is exactly what the margin exists to prevent).
from botcortex.platform import load_platform

PLATFORM = load_platform(settings.get("platform", "openarm_v1"))
JOINT_LIMITS = PLATFORM.joint_limits
ARMS = PLATFORM.arms
HOME_POSITION = PLATFORM.home_position
