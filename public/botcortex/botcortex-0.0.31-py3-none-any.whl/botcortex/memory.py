"""Episodic failure memory — the moat.

Every task attempt appends one JSON line; at authoring time the most relevant
episodes are recalled and injected into the agent's context before it writes
code. Failure-diagnostic feedback improves manipulation success by up to +35%
(RoboInspector, arXiv 2508.21378). Traces stay on-device — syncing them is the
paid cloud feature, later.
"""

import json
import re
from datetime import UTC, datetime
from pathlib import Path

STOPWORDS = frozenset(
    [
        "a",
        "an",
        "and",
        "are",
        "as",
        "at",
        "be",
        "by",
        "for",
        "from",
        "has",
        "i",
        "in",
        "is",
        "it",
        "of",
        "on",
        "or",
        "that",
        "the",
        "this",
        "to",
        "was",
        "with",
    ]
)


def _terms(text: str) -> set[str]:
    return {w for w in re.findall(r"[a-z0-9_]+", text.lower()) if w not in STOPWORDS}


class EpisodeMemory:
    def __init__(self, path: Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def log(
        self,
        task: str,
        skills_used: list[str],
        outcome: str,
        error: str | None = None,
        lesson: str | None = None,
    ) -> dict:
        episode = {
            "ts": datetime.now(UTC).isoformat(timespec="seconds"),
            "task": task,
            "skills_used": skills_used,
            "outcome": outcome,  # "ok" | "fail"
            "error": error,
            "lesson": lesson,
        }
        with self.path.open("a") as f:
            f.write(json.dumps(episode) + "\n")
        return episode

    def all(self) -> list[dict]:
        if not self.path.exists():
            return []
        episodes = []
        for line in self.path.read_text().splitlines():
            try:
                episodes.append(json.loads(line))
            except json.JSONDecodeError:
                continue
        return episodes

    def recall(self, task: str, limit: int = 5) -> list[dict]:
        """Keyword-overlap retrieval, v0. Embeddings can replace this wholesale
        later — the interface (task in, episodes out) is the stable part."""
        query = _terms(task)
        if not query:
            return []
        scored = []
        for i, ep in enumerate(self.all()):
            hay = _terms(f"{ep.get('task', '')} {ep.get('lesson') or ''} {ep.get('error') or ''}")
            score = len(query & hay)
            if score:
                scored.append((score, i, ep))
        scored.sort(key=lambda t: (-t[0], -t[1]))  # relevance, then recency
        return [ep for _, _, ep in scored[:limit]]

    def annotate_last(self, lesson: str) -> bool:
        """Attach a lesson to the most recent episode (the agent reflects after
        the attempt, and the attempt is already on disk)."""
        episodes = self.all()
        if not episodes:
            return False
        episodes[-1]["lesson"] = lesson
        with self.path.open("w") as f:
            for ep in episodes:
                f.write(json.dumps(ep) + "\n")
        return True

    # --- failures, filed by what went wrong ---------------------------------------
    #
    # A lesson is a sentence; a failure RECORD says what kind of thing went
    # wrong, in which primitive, on which robot, and — once the skill has been
    # seen to work again — what the agent said it changed. That last part is the
    # point: repair knowledge that WORKED, retrievable by the kind of failure,
    # on this robot or another. They live in the same file as episodes, so
    # `recall` finds them by keyword too.

    def log_failure(
        self, *, skill: str, kind: str, primitive: str | None, platform: str, error: str
    ) -> str:
        record_id = f"f{int(datetime.now(UTC).timestamp() * 1000)}-{skill}"
        record = {
            "ts": datetime.now(UTC).isoformat(timespec="seconds"),
            "task": "(failure)",
            "skills_used": [skill],
            "outcome": "fail",
            "error": error[:600],
            "lesson": None,
            "id": record_id,
            "kind": kind,
            "primitive": primitive,
            "platform": platform,
            "fixed": False,
        }
        with self.path.open("a") as f:
            f.write(json.dumps(record) + "\n")
        return record_id

    def _rewrite(self, change) -> bool:
        episodes = self.all()
        touched = False
        for episode in episodes:
            touched = change(episode) or touched
        if touched:
            with self.path.open("w") as f:
                for episode in episodes:
                    f.write(json.dumps(episode) + "\n")
        return touched

    def attach_fix(self, record_id: str, lesson: str) -> bool:
        """What the agent says it learned from this failure."""

        def change(episode: dict) -> bool:
            if episode.get("id") != record_id:
                return False
            episode["lesson"] = lesson
            return True

        return self._rewrite(change)

    def mark_fixed(self, record_ids: list[str]) -> bool:
        """The skill that failed this way has now been seen to work."""
        wanted = set(record_ids)

        def change(episode: dict) -> bool:
            if episode.get("id") not in wanted or episode.get("fixed"):
                return False
            episode["fixed"] = True
            return True

        return self._rewrite(change)

    def fixes_for(
        self, kind: str, platform: str, primitive: str | None, limit: int = 2
    ) -> list[dict]:
        """Failures of this KIND that ended in a working skill, with what the
        agent said it changed. This robot's first, then the same primitive on
        any robot, then the rest — a lost grasp on a Panda has something to say
        to a lost grasp on a ViperX, which is the whole thesis."""
        matches = [
            e
            for e in self.all()
            if e.get("kind") == kind and e.get("fixed") and (e.get("lesson") or "").strip()
        ]
        # Newest first, then (stably) this robot, then this primitive.
        matches.sort(key=lambda e: e.get("ts", ""), reverse=True)
        matches.sort(key=lambda e: (e.get("platform") != platform, e.get("primitive") != primitive))
        seen: set[str] = set()
        out = []
        for episode in matches:
            if episode["lesson"] in seen:
                continue
            seen.add(episode["lesson"])
            out.append(episode)
            if len(out) >= limit:
                break
        return out
