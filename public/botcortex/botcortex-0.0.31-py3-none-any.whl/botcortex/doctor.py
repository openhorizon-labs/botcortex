"""`botcortex doctor`: everything that can be wrong, checked, with the fix beside it.

Setting up a robot fails in a dozen small ways that each look like the robot
being broken: a Python package that was never installed, a serial port nobody
has permission to open, a camera that was never calibrated, a STOP file left
over from yesterday, a key that was revoked. Every one of them used to surface
as a traceback somewhere else. This asks them all at once and answers in the
words of what to do next.

Checks are data (`Finding`), so they can be tested and so `setup` can reuse
them. Nothing here moves the arm, and nothing opens the serial port unless
asked (`probe_arm`): opening it resets the RoArm's controller.
"""

from __future__ import annotations

import importlib.util
import json
import shutil
import sys
from dataclasses import dataclass
from pathlib import Path

from botcortex import config, settings


@dataclass(frozen=True)
class Finding:
    level: str  # "ok" | "warn" | "bad" | "note"
    text: str
    fix: str | None = None


def _has(module: str) -> bool:
    return importlib.util.find_spec(module) is not None


def serial_ports() -> list[str]:
    import glob

    patterns = (
        "/dev/cu.usbserial*",
        "/dev/cu.wchusbserial*",
        "/dev/cu.SLAB*",
        "/dev/ttyUSB*",
        "/dev/ttyACM*",
    )
    return sorted(path for pattern in patterns for path in glob.glob(pattern))


def check_install() -> list[Finding]:
    out = []
    version = sys.version_info
    if version >= (3, 12):
        out.append(Finding("ok", f"Python {version.major}.{version.minor}"))
    else:
        out.append(
            Finding(
                "bad",
                f"Python {version.major}.{version.minor} — BotCortex needs 3.12 or newer",
                "install Python 3.12, then reinstall botcortex",
            )
        )
    wanted = [
        (
            "mujoco",
            "the simulator, and the twin a real arm plans in",
            "bad",
            "pip install 'botcortex[real]'   (or: uv sync --extra real)",
        ),
        ("serial", "talking to the arm over USB", "bad", "pip install 'botcortex[real]'"),
        (
            "cv2",
            "webcams, and compact video of what the arm saw",
            "warn",
            "pip install 'botcortex[real]'",
        ),
        (
            "pyrealsense2",
            "an Intel RealSense depth camera (optional)",
            "note",
            "pip install 'botcortex[realsense]'",
        ),
        (
            "lerobot",
            "exporting datasets for training (optional)",
            "note",
            "pip install 'lerobot[dataset]'",
        ),
    ]
    for module, purpose, level, fix in wanted:
        if _has(module):
            out.append(Finding("ok", f"{module} — {purpose}"))
        else:
            out.append(Finding(level, f"{module} is not installed — {purpose}", fix))
    return out


def check_settings() -> list[Finding]:
    try:
        from botcortex.real import DRIVERS
    except ImportError:  # no numpy or mujoco yet — said by check_install
        DRIVERS = ("roarm_m2",)

    out = []
    path = settings.path()
    if path.exists():
        try:
            json.loads(path.read_text())
            out.append(Finding("ok", f"settings: {path}"))
        except ValueError:
            out.append(
                Finding(
                    "bad",
                    f"{path} is not valid JSON, so every setting in it is being ignored",
                    "fix or delete it, then: botcortex setup",
                )
            )
    else:
        out.append(
            Finding(
                "note",
                "no settings file yet — using defaults and environment variables",
                "botcortex setup",
            )
        )
    platform = config.PLATFORM
    where = settings.source("platform")
    if platform.name in DRIVERS:
        out.append(
            Finding("ok", f"robot: {platform.display_name} ({where}) — has a hardware driver")
        )
    else:
        out.append(
            Finding(
                "warn",
                f"robot: {platform.display_name} ({where}) — simulation only; real-arm drivers exist for: {', '.join(DRIVERS)}",
                "botcortex config set platform roarm_m2",
            )
        )
    try:
        config.DATA_DIR.mkdir(parents=True, exist_ok=True)
        probe = config.DATA_DIR / ".write-test"
        probe.write_text("ok")
        probe.unlink()
    except OSError as e:
        out.append(
            Finding(
                "bad",
                f"cannot write to {config.DATA_DIR}: {e}",
                "fix its permissions, or set BOTCORTEX_DATA to a folder you own",
            )
        )
    free = shutil.disk_usage(
        config.DATA_DIR if config.DATA_DIR.exists() else config.DATA_DIR.parent
    ).free
    if free < 1_000_000_000:
        out.append(
            Finding(
                "warn",
                f"only {free // 1_000_000} MB free where runs are kept — a filmed run is several MB",
                "free some space, or: botcortex config set record off",
            )
        )
    if config.STOP_FILE.exists():
        out.append(
            Finding(
                "bad",
                f"STOP is latched ({config.STOP_FILE}) — every motion will be refused",
                f"when the bench is safe: rm {config.STOP_FILE}",
            )
        )
    return out


def check_arm(probe_arm: bool = False) -> list[Finding]:
    out = []
    ports = serial_ports()
    chosen = settings.get("device")
    if chosen and chosen not in ports:
        out.append(
            Finding(
                "bad",
                f"the configured port {chosen} is not there — unplugged, unpowered, or renamed",
                "plug the arm in, or: botcortex setup",
            )
        )
    elif chosen:
        out.append(Finding("ok", f"arm port: {chosen}"))
    elif len(ports) == 1:
        out.append(Finding("ok", f"arm port: {ports[0]} (the only one plugged in)"))
    elif ports:
        out.append(
            Finding(
                "warn",
                f"{len(ports)} serial ports and none chosen: {', '.join(ports)}",
                "botcortex config set device <port>",
            )
        )
    else:
        out.append(
            Finding(
                "warn",
                "no USB serial device found — the arm is not plugged in (fine for simulation)",
                "plug in the arm's USB cable and switch its power on",
            )
        )
    device = chosen if chosen in ports else (ports[0] if len(ports) == 1 else None)
    if probe_arm and device and _has("serial"):
        from botcortex.roarm import LinkError, RoArmLink

        try:
            link = RoArmLink.open_serial(device)
            reply = link.feedback()
            link.close()
            out.append(
                Finding(
                    "ok",
                    f"the arm answers: base {reply['b']:.2f}, shoulder {reply['s']:.2f}, elbow {reply['e']:.2f} rad",
                )
            )
        except LinkError as e:
            out.append(
                Finding(
                    "bad",
                    f"the arm did not answer on {device}: {e}",
                    "check its 12 V power is on; then: botcortex arm status",
                )
            )
    return out


def check_camera() -> list[Finding]:
    from botcortex import camera as cameras

    found = cameras.load_settings(cameras.settings_path(config.DATA_DIR, config.PLATFORM.name))
    if not found.get("kind"):
        return [
            Finding(
                "warn",
                "no camera chosen — a real arm cannot see where anything is",
                "botcortex camera list, then: botcortex camera use webcam 0",
            )
        ]
    kind = "RealSense" if found["kind"] == "realsense" else f"webcam {found.get('source', 0)}"
    if "camera_to_base" not in found:
        return [
            Finding(
                "bad",
                f"{kind} is chosen but not calibrated",
                "botcortex camera calibrate --execute",
            )
        ]
    residual = float(found.get("residual_m", 0)) * 1000
    out = [
        Finding(
            "ok" if residual <= 5 else "warn",
            f"{kind}, calibrated to {residual:.1f} mm",
            None
            if residual <= 5
            else "recalibrate for a tighter fit: botcortex camera calibrate --execute",
        )
    ]
    taught = found.get("hues") or {}
    if taught:
        out.append(Finding("ok", f"colours taught for: {', '.join(sorted(taught))}"))
    else:
        out.append(
            Finding(
                "warn",
                "object colours come from the simulator's model, not your real blocks",
                "botcortex camera colours",
            )
        )
    return out


#: Intel's rules file: without it librealsense sees the camera and cannot
#: take it ("failed to set power state"), which reads like a broken camera.
REALSENSE_RULES = Path("/etc/udev/rules.d/99-realsense-libusb.rules")
REALSENSE_RULES_URL = "https://raw.githubusercontent.com/IntelRealSense/librealsense/master/config/99-realsense-libusb.rules"


def check_realsense_rules(found: dict | None = None) -> list[Finding]:
    """A RealSense on Linux needs Intel's udev rules before the depth library
    may open it. Only worth saying when a RealSense is the chosen camera."""
    from botcortex import camera as cameras

    if found is None:
        found = cameras.load_settings(cameras.settings_path(config.DATA_DIR, config.PLATFORM.name))
    if found.get("kind") != "realsense" or sys.platform != "linux":
        return []
    if REALSENSE_RULES.exists():
        return [Finding("ok", "RealSense udev rules installed")]
    return [
        Finding(
            "bad",
            "RealSense udev rules missing — the depth library cannot take the camera",
            f"sudo curl -sSL {REALSENSE_RULES_URL} -o {REALSENSE_RULES} && "
            "sudo udevadm control --reload-rules && sudo udevadm trigger",
        )
    ]


def check_bench() -> list[Finding]:
    """What the twin believes is on the bench: the scene's stock blocks, or
    what the owner measured onto it."""
    from botcortex import bench

    objects = bench.load(bench.path(config.DATA_DIR, config.PLATFORM.name))["objects"]
    if objects:
        named = ", ".join(
            f"{o['name']} ({'x'.join(f'{v * 100:.0f}' for v in o['size_m'])} cm)" for o in objects
        )
        return [Finding("ok", f"on this robot's bench: {named}")]
    return [
        Finding(
            "note",
            "the twin holds the scene's stock blocks; your bench may differ",
            "put what is really there in the twin: botcortex camera measure --add <name>",
        )
    ]


def check_runtime(port: int = 9090) -> list[Finding]:
    """Whether a runtime is serving on this machine, and which."""
    import json
    import urllib.request

    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/api/status", timeout=2) as r:
            answer = json.loads(r.read() or "{}")
    except (OSError, ValueError):
        return [
            Finding(
                "note",
                f"no runtime serving on port {port}",
                "botcortex serve --real   (or at boot: botcortex service install --real)",
            )
        ]
    return [
        Finding(
            "ok",
            f"serving on port {port} (pid {answer.get('pid', '?')}): {answer.get('name', '')}",
        )
    ]


def check_cloud(online: bool = True) -> list[Finding]:
    from botcortex import cloud
    from botcortex.outbox import Outbox

    out = []
    if cloud.half_paired():
        out.append(
            Finding(
                "bad",
                "points at BotCortex but has no robot key — teaching will be refused",
                "botcortex login",
            )
        )
    elif not cloud.paired():
        out.append(
            Finding(
                "note",
                "not paired — teaching uses your own model key, and nothing is shared",
                "botcortex login",
            )
        )
    elif online:
        who = cloud.whoami()
        if who:
            credit = (who.get("credit") or {}).get("display", "")
            out.append(
                Finding(
                    "ok",
                    f"paired with {(who.get('user') or {}).get('email', 'your account')}"
                    + (f" · {credit} credit" if credit else ""),
                )
            )
        else:
            out.append(
                Finding(
                    "warn",
                    f"paired, but {config.API_URL} did not answer — offline, or the key was revoked",
                    "check the network; if it persists: botcortex login",
                )
            )
    else:
        out.append(Finding("ok", "paired (not checked online)"))

    if cloud.sharing():
        out.append(
            Finding(
                "ok",
                "runs are shared with BotCortex (states, outcomes, and a real arm's footage)",
                "to stop: botcortex config set share_runs off",
            )
        )
    elif cloud.paired():
        out.append(
            Finding(
                "note",
                "runs stay on this machine",
                "to share them: botcortex config set share_runs on",
            )
        )
    box = Outbox(config.OUTBOX_DIR)
    waiting, refused = len(box.pending()), len(box.refused())
    if waiting:
        out.append(
            Finding("warn", f"{waiting} run events are waiting to be delivered", "botcortex sync")
        )
    if refused:
        out.append(
            Finding(
                "warn",
                f"{refused} run events were refused by the API; reasons are beside them in {box.rejected}",
            )
        )
    return out


def check_data() -> list[Finding]:
    from botcortex.skills import SkillStore

    out = []
    names = SkillStore(config.SKILLS_DIR).names() if config.SKILLS_DIR.exists() else []
    out.append(
        Finding(
            "ok" if names else "note",
            f"{len(names)} skills on this robot"
            + (f": {', '.join(names[:6])}" + ("…" if len(names) > 6 else "") if names else ""),
        )
    )
    if config.EPISODES_DIR.exists():
        files = list(config.EPISODES_DIR.iterdir())
        size = sum(f.stat().st_size for f in files if f.is_file())
        runs = sum(1 for f in files if f.suffix == ".json")
        out.append(
            Finding("ok", f"{runs} recorded runs, {size / 1e6:.0f} MB in {config.EPISODES_DIR}")
        )
    return out


SECTIONS = (
    ("Install", lambda **_: check_install()),
    ("This robot", lambda **_: check_settings()),
    ("Arm", lambda probe_arm=False, **_: check_arm(probe_arm)),
    ("Camera", lambda **_: [*check_camera(), *check_realsense_rules(), *check_bench()]),
    ("Runtime", lambda **_: check_runtime()),
    ("BotCortex account", lambda online=True, **_: check_cloud(online)),
    ("Skills and runs", lambda **_: check_data()),
)


def examine(probe_arm: bool = False, online: bool = True) -> list[tuple[str, list[Finding]]]:
    report = []
    for title, check in SECTIONS:
        try:
            report.append((title, check(probe_arm=probe_arm, online=online)))
        except Exception as e:  # noqa: BLE001 — a doctor that crashes is worse than no doctor
            report.append(
                (title, [Finding("bad", f"this check itself failed: {type(e).__name__}: {e}")])
            )
    return report
