"""The pose search, once, for every backend that has MuJoCo under it.

`solve_pose` answers "which joint angles put the grasp centre on this point?"
by walking a grid of candidate poses (kinematics.solve) and asking the backend
where the hand would be at each one. It lived in wasm.py and sim.py as two
copies, and the copies drifted: the browser's was made five times faster on
17 September (kinematics-only probes, remembered answers) and the native one
was not, so the native test suite and the benchmark kept paying 58,564 full
dynamics evaluations per point for numbers that are identical either way.

One definition now. A backend mixes this in and provides `_mujoco`, `model`,
`data`, `platform`, `tcp_error`, `_write_qpos`, `tip` and `rehearsal`.
"""

from __future__ import annotations

import time

from botcortex import kinematics, mjcompat
from botcortex.robot import clamp_target


class Pulse:
    """Calls something at most once per `interval` seconds, however often it
    is asked to. Lives here rather than in wasm.py because that file holds no
    arithmetic, by test, and "has half a second passed" is arithmetic."""

    def __init__(self, interval: float = 0.5):
        self._interval = interval
        self._last = 0.0

    def __call__(self, callback) -> None:
        if callback is None:
            return
        now = time.monotonic()
        if now - self._last >= self._interval:
            self._last = now
            callback()


class PoseSearch:
    """Mixin: `solve_pose`, and the probe it searches with."""

    #: Remembered answers, per robot — see solve_pose. Created on first use so
    #: a backend's __init__ does not have to know this mixin keeps state.
    _solved: dict | None = None

    def _alive(self) -> None:
        """Tell whoever is waiting that work is still happening. A backend
        with someone waiting overrides this — see WasmRobot."""

    def _probe(self, arm: str):
        """Hands kinematics.solve a way to try a pose without knowing MuJoCo."""

        # mj_kinematics, not mj_forward. The probe reads one thing — where the
        # hand body is — and mj_forward computes it by calling mj_kinematics
        # FIRST and then going on to collision detection, constraints and
        # dynamics nothing here looks at. Measured in a browser on the Panda:
        # 40 µs against 2.7 µs, inside a grid search that makes 58,564 probes
        # per point. The numbers that come back are the same numbers.
        forward = getattr(self._mujoco, "mj_kinematics", self._mujoco.mj_forward)

        def probe(pose):
            for joint, deg in pose.items():
                self._write_qpos(arm, joint, deg)
            forward(self.model, self.data)
            return self.tip(arm)

        if getattr(self, "probe_batch", None) is not None:
            probe.many = lambda held, axes: self._probe_many(arm, held, axes)
        return probe

    #: Set by a host that can run a whole grid of probes without coming back
    #: to Python between them: `probe_batch(held_adr, held_val, axis_adr,
    #: axis_val, axis_len, hand, offset, down_index, down_sign)` returning
    #: x, y, z, down per pose, flat, in kinematics._grid order. The browser
    #: worker provides one. Measured there: a pose search is 1.2 s of a
    #: 1.35 s checked move, nearly all of it the 58,564 crossings between
    #: Pyodide and MuJoCo, and a two-block skill makes twenty searches.
    probe_batch = None

    def _probe_many(self, arm: str, held: dict[str, float], axes: dict[str, list[float]]):
        """The grid, measured in one call. None when this body's joints cannot
        be expressed as one write each (then the caller probes one at a time).

        Everything that is a fact about the ROBOT is still computed here, by
        the same functions the one-at-a-time probe uses: which address a joint
        lives at and what a degree is in its units (JointMap), where the jaws
        close in the hand frame (calibrated_offset), which way is down
        (Platform). The host is handed numbers and enumerates the product.
        """
        held_writes = [
            w for joint, deg in held.items() for w in self.joints.qpos_writes(arm, joint, deg)
        ]
        axis_adr: list[int] = []
        axis_val: list[float] = []
        axis_len: list[int] = []
        for joint, values in axes.items():
            writes = [self.joints.qpos_writes(arm, joint, deg) for deg in values]
            if any(len(w) != 1 or w[0][0] != writes[0][0][0] for w in writes):
                return None
            axis_adr.append(writes[0][0][0])
            axis_len.append(len(values))
            axis_val.extend(w[0][1] for w in writes)
        p = self.platform
        offset = kinematics.calibrated_offset(p.grasp_offset, self.tcp_error)
        flat = self.probe_batch(
            [adr for adr, _ in held_writes],
            [value for _, value in held_writes],
            axis_adr,
            axis_val,
            axis_len,
            self._hand_id(arm),
            list(offset),
            6 + p.approach_axis,
            p.approach_sign,
        )
        # A Float64Array comes back as a proxy; one bulk copy into a list, not
        # 234,256 crossings to read it element by element.
        if hasattr(flat, "to_memoryview"):
            flat = flat.to_memoryview().tolist()
        elif hasattr(flat, "to_py"):
            flat = flat.to_py()
        return [((flat[i], flat[i + 1], flat[i + 2]), flat[i + 3]) for i in range(0, len(flat), 4)]

    def _hand_id(self, arm: str) -> int:
        mj = self._mujoco
        return int(
            mj.mj_name2id(
                self.model, mjcompat.enum_value(mj.mjtObj.mjOBJ_BODY), self.platform.hand_body(arm)
            )
        )

    def solve_pose(
        self, arm: str, point, *, pinned: dict[str, float] | None = None
    ) -> tuple[dict[str, float], float]:
        """Joint angles that put the grasp centre on `point`, and the error.

        Restores the arm afterwards: the search walks the joints through
        hundreds of poses, and leaving it wherever the last probe landed would
        teleport the robot as a side effect of asking a question.
        """
        # Remembered, because the answer is a function of the point and the
        # arm and nothing else — that is what pinning the neutral joints
        # bought (see kinematics.solve) — and the same points are asked for
        # over and over: every skill runs twice, once rehearsed and once for
        # real, and reach() re-solves its waypoints per route. In a browser a
        # solve is seconds; a skill that timed out at 600 s was mostly this.
        key = (
            arm,
            tuple(round(float(v), 6) for v in point),
            tuple(sorted((pinned or {}).items())),
            tuple(self.tcp_error),
        )
        self._alive()
        if self._solved is None:
            self._solved = {}
        known = self._solved.get(key)
        if known is not None:
            return dict(known[0]), known[1]
        solved = self._solve_pose(arm, point, pinned)
        self._solved[key] = (dict(solved[0]), solved[1])
        return solved

    def _solve_pose(self, arm: str, point, pinned) -> tuple[dict[str, float], float]:
        # Preserve independent finger positions and all integrator state, not
        # a lossy degree dictionary that writes one finger onto both jaws.
        with self.rehearsal():
            p = self.platform
            # `sim.product` overrides the search tuning for the owner's robot
            # and is ignored by the research benchmark, whose tables were
            # measured without it — see Platform.benchmark_world_path.
            tuning = dict(p.sim)
            if not getattr(self, "benchmark", False):
                tuning.update(
                    {k: v for k, v in p.sim.get("product", {}).items() if not k.startswith("_")}
                )
            # The search envelope: the vendor limits less the safety margin,
            # narrowed further where the descriptor says so (sim.ik_bounds).
            # A seven-joint arm with ±180° joints has elbow-over solutions
            # that put the grasp centre on the point and the forearm through
            # the neighbouring block; the envelope keeps the search on the
            # configurations the arm is meant to work in.
            narrowed = p.sim.get("ik_bounds", {})
            bounds = {}
            for joint in p.ik_joints:
                lo, hi = narrowed.get(joint, (-1e6, 1e6))
                bounds[joint] = (clamp_target(arm, joint, lo, p), clamp_target(arm, joint, hi, p))
            # The joints the search does not move are pinned to home, so the
            # answer depends on the point and the arm and nothing else. See
            # the note above kinematics.solve for the measurement that forced this.
            neutral = {joint: p.home_position[joint] for joint in p.neutral_joints}
            # `pinned` holds a neutral joint somewhere other than home, for a
            # caller that knows why — squaring the jaws to a cube the arm has
            # to reach sideways to. Default None keeps the answer a function
            # of the point and the arm alone, which every other caller needs.
            if pinned:
                neutral.update({j: float(v) for j, v in pinned.items() if j in neutral})
            return kinematics.solve(
                self._probe(arm),
                bounds,
                tuple(point),
                neutral=neutral,
                coarse=int(tuning.get("ik_coarse", 9)),
                refine=int(tuning.get("ik_refine", 2)),
                want_down=float(tuning.get("ik_want_down", kinematics._WANT_DOWN)),
                approach_weight=float(
                    tuning.get("ik_approach_weight", kinematics._APPROACH_WEIGHT)
                ),
            )
