"""From one skill to a dataset: many runs, pixels, and an export a trainer reads.

`episodes.py` keeps a run. This makes them by the hundred. A saved skill reads
the scene by name, so it does not care where the blocks are; scatter them, run
it, check where everything ended up against where the skill puts things when it
works, and that is a labelled demonstration nobody teleoperated. The ones that
fail are kept, labelled by what went wrong — a generator that throws its
failures away has thrown away the half of the data nobody else has.

None of this is a new idea (RoboTwin 2.0, MimicGen; see docs/research/
skills_to_vla_novelty.md). What it is for is the experiment that is: the same
tasks on several bodies, failures and their repairs included.

Native only: numpy, and a simulator to film in.
"""

from __future__ import annotations

import json
import random
from pathlib import Path

from botcortex import episodes, learning, scene
from botcortex.skills import SkillContext

#: Bench kept clear around each fixture and between objects when scattering.
_APART_M = 0.07
_OFF_FIXTURES_M = 0.04
_REACH_M = 0.02


def views_for(robot, names=("front", "side")) -> dict:
    """Simulated cameras aimed at this body's own bench, by view name. Two by
    default: from one view a gripper hides exactly the thing it is closing on."""
    from botcortex.camera import SimCamera

    bench = robot.describe_scene()["fixtures"]["table"]
    (x, y, z), (sx, sy, sz) = bench["position"], bench["size_m"]
    aim = {"lookat": (x, y, z + sz / 2), "distance": max(0.75, 1.1 * max(sx, sy))}
    angles = {"front": (180.0, -60.0), "side": (90.0, -35.0), "top": (180.0, -89.0)}
    return {
        name: SimCamera(robot, azimuth=angles[name][0], elevation=angles[name][1], **aim)
        for name in names
    }


class Wobble:
    """Disturb what the servos are told, so the data contains recoveries.

    A policy cloned from clean runs has never seen itself a centimetre off
    course, so the first time it is, it has nothing to go on and the error
    compounds. The standard cure (DART, Laskey et al. 2017) is to push the
    EXPERT off course while recording and keep its intended action as the
    label: the data then shows what to do from the places mistakes lead to.

    The push is a slow drift per joint (an Ornstein-Uhlenbeck walk), not
    jitter: a servo that shivers averages out within a tick, one that leans
    for half a second takes the hand somewhere else. The gripper is left
    alone — a jaw that wanders drops the block, and that is a different
    experiment. Only the recovery a skill already has is captured: the routed
    moves re-measure the tip on arrival and trim it, so that is what shows up.
    """

    def __init__(self, rng: random.Random, sigma_deg: float, hold_ticks: float = 10.0):
        self.rng, self.sigma, self.decay = rng, sigma_deg, 1.0 - 1.0 / hold_ticks
        self.lean: dict[tuple[str, str], float] = {}

    def __call__(self, arm: str, frame: dict[str, float]) -> dict[str, float]:
        kick = self.sigma * (1.0 - self.decay**2) ** 0.5
        out = {}
        for joint, degrees in frame.items():
            if joint == "gripper":
                out[joint] = degrees
                continue
            lean = self.lean.get((arm, joint), 0.0) * self.decay + self.rng.gauss(0.0, kick)
            self.lean[(arm, joint)] = lean
            out[joint] = degrees + lean
        return out


def scatter(robot, rng: random.Random, tries: int = 300) -> dict[str, list[float]]:
    """Put every object somewhere new on the bench: clear of each other and of
    the fixtures, and where an arm can reach. Returns what was placed; objects
    no spot was found for stay where they were."""
    described = robot.describe_scene()
    bench = described["fixtures"]["table"]
    (bx, by, _), (sx, sy, _) = bench["position"], bench["size_m"]
    blocked = [
        (b["position"], b["size_m"]) for n, b in described["fixtures"].items() if n != "table"
    ]
    poses = scene.object_poses(robot.data.qpos, robot._object_addr)
    placed: dict[str, list[float]] = {}
    for name in sorted(poses):
        z = poses[name][2]
        for _ in range(tries):
            x = bx + (rng.random() - 0.5) * (sx - 0.08)
            y = by + (rng.random() - 0.5) * (sy - 0.08)
            if any(
                abs(x - p[0]) < s[0] / 2 + _OFF_FIXTURES_M
                and abs(y - p[1]) < s[1] / 2 + _OFF_FIXTURES_M
                for p, s in blocked
            ):
                continue
            if any((x - q[0]) ** 2 + (y - q[1]) ** 2 < _APART_M**2 for q in placed.values()):
                continue
            pose = [x, y, z, 1.0, 0.0, 0.0, 0.0]
            if not any(_workable(robot, arm, name, pose) for arm in robot.platform.arms):
                continue
            placed[name] = [x, y, z, 1.0, 0.0, 0.0, 0.0]
            break
    scene.place_objects(robot.data.qpos, robot._object_addr, placed)
    robot.data.qvel[:] = 0.0
    robot._mujoco.mj_forward(robot.model, robot.data)
    robot.settle(0.3)
    return placed


def _workable(robot, arm: str, name: str, pose: list[float]) -> bool:
    """Can this arm come down over `name` if it stood at `pose`? Tried with the
    object actually there, not predicted.

    The pose solver says yes to anywhere the geometry closes. It knows nothing
    of servo droop, and nothing of the object: beyond about 40 cm the RoArm's
    fixed jaw comes down ON a 40 mm cube rather than beside it, which an empty
    bench does not show. A block scattered there is not a task the skill
    failed, it is a task nobody could set — and 9 of 20 generated RoArm runs
    were that. The solver is still asked first: it is cheap, and it refuses
    most of the bench.
    """
    x, y, z = pose[:3]
    if robot.solve_pose(arm, (x, y, z))[1] > _REACH_M:
        return False
    was = scene.object_poses(robot.data.qpos, robot._object_addr)[name]
    scene.place_objects(robot.data.qpos, robot._object_addr, {name: pose})
    robot._mujoco.mj_forward(robot.model, robot.data)
    opening, _closed = robot.platform.joint_limits[arm]["gripper"]
    try:
        with robot.rehearsal():
            robot.gripper(arm, opening)
            robot.move_to_point(arm, (x, y, z + 0.12), 0.02)
            robot.move_to_point(arm, (x, y, z), 0.02)
        return True
    except (ValueError, RuntimeError):
        return False
    finally:
        scene.place_objects(robot.data.qpos, robot._object_addr, {name: was})
        robot._mujoco.mj_forward(robot.model, robot.data)


def _ends(robot, names) -> dict[str, str | None]:
    described = robot.describe_scene()
    return {n: learning.holder_of(n, described, scene.resting_in) for n in names}


def _attempt(robot, recorder, store, skill: str, params: dict, expected, **told):
    """One recorded run. Returns where things ended when it worked, else None.

    It worked when the skill raised nothing AND, if `expected` is known, every
    object ended where the skill puts it when it works. The label is checked,
    not assumed.
    """
    before = robot.describe_scene()["objects"]
    recorder.begin(robot, depth=0, executed=True, skill=skill, params=params, **told)
    try:
        store.run(skill, SkillContext(robot), **params)
    except Exception as e:  # noqa: BLE001 — the skill is a model's code
        note = f"ERROR: {e}"
        recorder.end(
            robot,
            ok=False,
            note=note[:600],
            kind=learning.failure_kind(note),
            primitive=learning.primitive_of(note),
        )
        return None
    after = robot.describe_scene()["objects"]
    moved = [n for n in before if _far(before[n]["position"], after[n]["position"])]
    ends = _ends(robot, expected or moved)
    ok = expected is None or ends == expected
    extra = (
        {}
        if ok
        else {
            "note": f"NOT THE SAME RESULT: {ends} instead of {expected}",
            "kind": "wrong_result",
            "primitive": None,
        }
    )
    recorder.end(robot, ok=ok, **extra)
    return ends if ok else None


def generate(
    make_robot,
    store,
    skill: str,
    root: Path,
    count: int,
    *,
    instruction: str | None = None,
    params: dict | None = None,
    seed: int = 0,
    film: bool = True,
    wobble_deg: float = 0.0,
    say=lambda _line: None,
) -> dict:
    """Run `skill` `count` times over scattered scenes, keeping every run.

    `make_robot()` returns a fresh simulator. The first run is on the scene as
    shipped, undisturbed, and defines what "worked" means: which objects end up
    where. A scattered run succeeds when it raises nothing and ends the same
    way. `wobble_deg` above zero disturbs the servos during the scattered runs
    (see Wobble); the actions recorded are still the ones that were meant.
    """
    params = params or {}
    rng = random.Random(seed)
    robot = make_robot()
    start = scene.object_poses(robot.data.qpos, robot._object_addr)
    recorder = robot.recorder = episodes.Recorder(root, cameras=views_for(robot) if film else None)
    told = {"instruction": instruction, **episodes.code_of(store, skill)}

    expected = _attempt(robot, recorder, store, skill, params, None, phase="reference", **told)
    if not expected:
        raise RuntimeError(
            f"{skill} does not work on the scene as shipped, so there is nothing to vary"
        )
    made = {"ok": 1, "failed": 0}
    if wobble_deg > 0:
        robot.disturb = Wobble(rng, wobble_deg)
        told["wobble_deg"] = wobble_deg
    for i in range(1, count):
        _restore(robot, start)
        scatter(robot, rng)
        worked = _attempt(
            robot, recorder, store, skill, params, expected, phase="generated", **told
        )
        made["ok" if worked else "failed"] += 1
        if i % 10 == 0:
            say(f"  {i + 1}/{count}: {made['ok']} worked, {made['failed']} failed")
    robot.disturb = None
    return {**made, "expected": expected}


def replay_failures(make_robot, store, root: Path, skill: str, say=lambda _line: None) -> dict:
    """Give the skill as it is NOW every scene an older version of it failed on.

    This is where failure -> repair -> success triplets come from at scale. A
    failed episode kept the scene it started from and the code that failed. If
    the skill has since been rewritten, the same scene is set up again and the
    current code is run on it; when it works, the two episodes are linked. The
    pair then differs in exactly one thing — the code — which is the cleanest
    statement of "this change repaired that failure" there is.

    Failures of the CURRENT code are left alone: running it again on the scene
    it failed on is not a repair, it is a second opinion.
    """
    root = Path(root)
    robot = make_robot()
    now = episodes.code_of(store, skill)
    recorder = robot.recorder = episodes.Recorder(root, cameras=views_for(robot))
    waiting = [
        r
        for r in episodes.index(root)
        if r.get("skill") == skill
        and r["platform"] == robot.platform.name
        and not r["ok"]
        and r.get("repaired_by") is None
        and r.get("code_sha") != now["code_sha"]
    ]
    made = {"replayed": 0, "repaired": 0}
    for failed in waiting:
        first = episodes.load(root, failed["id"])["ticks"]["poses"]
        if not first:
            continue
        robot.reset()
        scene.place_objects(
            robot.data.qpos, robot._object_addr, dict(zip(failed["objects"], first[0], strict=True))
        )
        robot.data.qvel[:] = 0.0
        robot._mujoco.mj_forward(robot.model, robot.data)
        before = {r["id"] for r in episodes.index(root)}
        worked = _attempt(
            robot,
            recorder,
            store,
            skill,
            failed.get("params") or {},
            None,
            phase="replay",
            replays=failed["id"],
            instruction=failed.get("instruction"),
            **now,
        )
        made["replayed"] += 1
        if worked:
            [new] = [r["id"] for r in episodes.index(root) if r["id"] not in before]
            episodes.link_repair(root, new, [failed["id"]])
            made["repaired"] += 1
        say(f"  {failed['id']}: {'repaired' if worked else 'still fails'}")
    return made


def _far(a, b) -> bool:
    return sum((p - q) ** 2 for p, q in zip(a, b, strict=True)) ** 0.5 > 0.02


def _restore(robot, poses) -> None:
    """Arm home, blocks back, nothing moving. A simulator only."""
    robot.reset()
    scene.place_objects(robot.data.qpos, robot._object_addr, poses)
    robot._mujoco.mj_forward(robot.model, robot.data)


# --- pixels, afterwards -------------------------------------------------------


def render(root: Path, episode_id: str, make_robot, stride: int = 2) -> str:
    """Film an episode that was recorded without a camera: a browser tab, a
    rehearsal. In simulation the image is a function of the joints and the
    object poses, both of which every tick kept."""
    import numpy as np

    root = Path(root)
    record = episodes.load(root, episode_id)
    robot = make_robot()
    if robot.platform.name != record["platform"]:
        raise ValueError(
            f"{episode_id} was recorded on {record['platform']}, not {robot.platform.name}"
        )
    eyes = views_for(robot)
    names, frames = record["names"], {view: [] for view in eyes}
    for state, poses in zip(record["ticks"]["state"], record["ticks"]["poses"], strict=True):
        for name, degrees in zip(names, state, strict=True):
            arm, joint = name.split(".", 1)
            robot._write_qpos(arm, joint, degrees)
        scene.place_objects(
            robot.data.qpos, robot._object_addr, dict(zip(record["objects"], poses, strict=True))
        )
        robot._mujoco.mj_forward(robot.model, robot.data)
        for view, eye in eyes.items():
            frames[view].append(eye.rgb()[::stride, ::stride].copy())
    for eye in eyes.values():
        eye.close()
    np.savez_compressed(root / f"{episode_id}.npz", **{v: np.stack(f) for v, f in frames.items()})
    record["images"], record["views"], record["rendered"] = (
        f"{episode_id}.npz",
        sorted(frames),
        True,
    )
    (root / f"{episode_id}.json").write_text(json.dumps(record))
    return record["images"]


# --- out, in the format trainers read -----------------------------------------


def to_lerobot(
    root: Path, out: Path, repo_id: str, platform: str, *, only_ok: bool = False, writer=None
) -> dict:
    """Write one body's episodes as a LeRobot dataset, by calling LeRobot.

    The library writes its own format, so this stays right across its versions
    (v3.0 at lerobot 0.6.1; `finalize` is called when it exists). One body per
    dataset, because a state vector has one length. What LeRobot has no column
    for — success, failure kind, which episode repaired which — goes beside it
    in `botcortex_episodes.json`, keyed by LeRobot's episode index.
    """
    import numpy as np

    root = Path(root)
    chosen = [
        r for r in episodes.index(root) if r["platform"] == platform and (r["ok"] or not only_ok)
    ]
    if not chosen:
        raise ValueError(f"no episodes for {platform} under {root}")
    filmed = all(r.get("images") for r in chosen)
    names = chosen[0]["names"]
    features = {
        "observation.state": {"dtype": "float32", "shape": (len(names),), "names": names},
        "action": {"dtype": "float32", "shape": (len(names),), "names": names},
    }
    # Only the views every chosen episode has: a column cannot be half empty.
    views = sorted(set.intersection(*(set(r.get("views") or []) for r in chosen))) if filmed else []
    filmed = bool(views)
    for view in views:
        first = np.load(root / chosen[0]["images"])[view]
        features[f"observation.images.{view}"] = {
            "dtype": "video",
            "shape": tuple(first.shape[1:]),
            "names": ["height", "width", "channels"],
        }
    if writer is None:
        try:
            from lerobot.datasets.lerobot_dataset import LeRobotDataset
        except ImportError as newer:
            try:
                from lerobot.common.datasets.lerobot_dataset import LeRobotDataset
            except ImportError:
                # LeRobot's own message is the useful one: since 0.6 the writer
                # is an extra, and "pip install lerobot" alone does not bring it.
                raise ImportError(
                    f"exporting needs LeRobot's dataset writer: pip install 'lerobot[dataset]'  ({newer})"
                ) from newer
        writer = LeRobotDataset.create(
            repo_id=repo_id,
            fps=int(chosen[0]["fps"]),
            features=features,
            root=out,
            robot_type=platform,
            use_videos=filmed,
        )
    sidecar, index_of = [], {}
    for position, record in enumerate(chosen):
        ticks = episodes.load(root, record["id"])["ticks"]
        # Read each view ONCE: indexing an .npz decompresses the whole array,
        # and doing that per tick turned a two-episode export into gigabytes.
        images = {}
        if filmed:
            with np.load(root / record["images"]) as packed:
                images = {view: packed[view] for view in views}
        task = record.get("instruction") or record.get("skill") or "task"
        for t, (state, action) in enumerate(zip(ticks["state"], ticks["action"], strict=True)):
            frame = {
                "observation.state": np.asarray(state, dtype=np.float32),
                "action": np.asarray(action, dtype=np.float32),
                "task": task,
            }
            for view in views:
                frame[f"observation.images.{view}"] = images[view][t]
            writer.add_frame(frame)
        writer.save_episode()
        index_of[record["id"]] = position
        sidecar.append(
            {
                k: record.get(k)
                for k in (
                    "id",
                    "ok",
                    "phase",
                    "executed",
                    "kind",
                    "primitive",
                    "skill",
                    "code_sha",
                    "variation",
                    "repairs",
                    "repaired_by",
                )
            }
        )
    for entry in sidecar:
        entry["episode_index"] = index_of[entry["id"]]
        entry["repairs_index"] = [index_of[i] for i in entry["repairs"] or [] if i in index_of]
        entry["repaired_by_index"] = index_of.get(entry["repaired_by"])
    getattr(writer, "finalize", lambda: None)()
    Path(out).mkdir(parents=True, exist_ok=True)
    (Path(out) / "botcortex_episodes.json").write_text(json.dumps(sidecar, indent=1))
    return {
        "episodes": len(chosen),
        "frames": sum(r["length"] for r in chosen),
        "filmed": filmed,
        "views": views,
    }
