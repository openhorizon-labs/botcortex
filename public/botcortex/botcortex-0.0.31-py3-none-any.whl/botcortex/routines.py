"""Built-in demo routines composed only of primitives.

These power the CLI smoke test until the authoring agent lands (milestone 2);
agent-authored skills will replace them as the source of behavior.
"""


def wave(robot, arm: str | None = None, repeats: int = 3) -> int:
    """Raise the forearm and oscillate the wrist, then return home.

    Returns the number of interpolation steps executed.

    Written for the OpenArm (j4 lifts, j6 waves) and then asked to run on a
    RoArm, which has neither joint nor an arm called "right": the zero-API
    smoke test crashed on the first robot that was not the first robot. On any
    other body the last positioning joint waves and the one before it lifts,
    each about its own home, and the clamp keeps both inside their limits.
    """
    platform = getattr(robot, "platform", None)
    if platform is None:
        from botcortex import config

        platform = config.PLATFORM
    arm = arm if arm in platform.arms else platform.arms[0]
    home = platform.home_position
    joints = [j for j in platform.joint_limits[arm] if j != "gripper"]
    lift, wrist = ("j4", "j6") if {"j4", "j6"} <= set(joints) else (joints[-2], joints[-1])
    raised = 60.0 if lift == "j4" else home[lift] + 20.0
    swing = 25.0 if wrist == "j6" else 20.0

    steps_before = len(robot.motion_log)
    robot.move_to(arm, {lift: raised})
    for _ in range(repeats):
        robot.move_to(arm, {wrist: home[wrist] + swing if wrist != "j6" else swing})
        robot.move_to(arm, {wrist: home[wrist] - swing if wrist != "j6" else -swing})
    robot.move_to(arm, {wrist: home[wrist], lift: home[lift]})
    return len(robot.motion_log) - steps_before
