"""WasmRobot — the same primitives, driving MuJoCo compiled to WebAssembly.

This is what lets someone teach a robot with nothing installed: Pyodide runs
this package in the browser, `@mujoco/mujoco` (DeepMind's own WASM build of the
same engine, same version) runs the physics, and the account's credit pays for
the authoring. No runtime on their machine, and no second definition of how the
robot moves.

Read this class looking for arithmetic. There isn't any, and that is the point.
The trajectory comes from `plan_move`, the addresses and units from `JointMap`;
all that is left here is handing MuJoCo the numbers those two produced. A
browser backend that recomputed a velocity cap or a gripper conversion would
agree with the runtime on the day it was written and drift from then on, and
"the skill you taught in the browser runs on your arm" is the promise that pays
for all of this.

Measured parity against the native build, same model and command: 0.003° over a
40-tick move. Bitwise agreement is not achievable across architectures (libm and
FMA differ) and is not what matters — position-commanded, velocity-capped
motion converges on the command.

The JS side owns the module, model and data objects and passes them in; Pyodide
hands them over as JsProxy. Nothing here imports mujoco.
"""

from __future__ import annotations

import time
from collections.abc import Callable
from contextlib import contextmanager
from pathlib import Path

from botcortex import config, kinematics, mjcompat, safety, scene
from botcortex.jointmap import JointMap
from botcortex.platform import Platform
from botcortex.posesearch import PoseSearch, Pulse
from botcortex.robot import EStopTriggered, plan_move


class Trial:
    """A rehearsal in progress. `keep()` turns it into the run itself.

    See WasmRobot.rehearsal for when that is sound, which is only here.
    """

    def __init__(self) -> None:
        self.kept = False
        #: Set by the robot as the rehearsal ends: True only if the state and
        #: logs really were left in place. The caller reads THIS, not `kept` —
        #: asking is not the same as being granted.
        self.stood = False

    def keep(self) -> None:
        self.kept = True


class WasmRobot(PoseSearch):
    """Bimanual sim twin backed by the browser's MuJoCo.

    `mujoco`, `model` and `data` are the JS objects from @mujoco/mujoco.
    `sleep` is how a control tick waits: the default blocks, which is correct
    inside a Web Worker and wrong on the main thread — see the note on
    move_to().
    """

    def __init__(
        self,
        mujoco,
        model,
        data,
        platform: Platform | None = None,
        stop_file: Path | None = None,
        realtime: bool = False,
        sleep: Callable[[float], None] | None = None,
    ):
        self._mujoco = mujoco
        self.model = model
        self.data = data
        self.platform = platform or config.PLATFORM
        # A real path, in Pyodide's in-memory filesystem. Deliberately the same
        # mechanism as every other backend rather than a JS flag: the e-stop
        # check is the one line in this system that must never differ between
        # environments, and `stop_file.exists()` is that line everywhere.
        self.stop_file = stop_file if stop_file is not None else config.STOP_FILE
        self.realtime = realtime
        self._sleep = sleep or time.sleep
        self.motion_log: list[tuple[str, str, dict[str, float]]] = []
        #: Believed-TCP calibration error, metres in the hand frame. See tip().
        self.tcp_error: tuple[float, float, float] = (0.0, 0.0, 0.0)
        #: How far short of a point a move may land and still be treated as servo
        #: sag to trim out, rather than a route that failed (kinematics.reach).
        #: The ViperX droops 32 mm at the far blocks — 2 mm past the default —
        #: so the second block of "clear the table" was refused as unroutable.
        #: The benchmark keeps the default it was measured with.
        self.trimmable_m = (
            kinematics._TRIMMABLE
            if False
            else float(self.platform.sim.get("trimmable_m", kinematics._TRIMMABLE))
        )
        self.torque = {arm: True for arm in self.platform.arms}

        # The whole seam between this backend and the native one. Native
        # resolves through mj_name2id; here the embind accessors do it, because
        # the WASM build's enums are objects rather than ints and cannot be
        # passed to mj_name2id from Python.
        def qpos_adr(name: str) -> int:
            return int(model.jnt_qposadr[int(model.jnt(name).id)])

        def actuator_id(name: str) -> int:
            return int(data.actuator(name).id)

        self.joints = JointMap(self.platform, qpos_adr, actuator_id)

        # One control tick of sim time, however many physics steps that takes.
        self._substeps = max(1, round((1 / config.CONTROL_HZ) / float(model.opt.timestep)))
        #: Hand body id per arm, the flat-array question, and solved poses —
        #: each asked once instead of once per probe. See tip() and solve_pose().
        self._hand_ids: dict[str, int] = {}
        self._flat: bool | None = None  # asked on the first tip(), not before there is one

        #: What a structural link must never touch. Resolved on first need
        #: rather than at construction: a bare arm has no fixtures, and asking
        #: costs a full scene walk that most robots never need.
        self._fixture_names: set[str] | None = None

        #: Which bodies are the robot and which are its jaws, per the platform
        #: descriptor. Fixed at construction; used by every scene and
        #: collision query, which must not guess them from a name prefix.
        self._robot_bodies = scene.robot_bodies(mujoco, self.model, self.platform.sim)
        self._jaws = {
            body for arm in self.platform.arms for body in self.platform.finger_bodies(arm)
        }

        # Which bodies are objects, and where they start — reset puts the
        # workcell back, exactly as SimRobot does. Before this the browser's
        # reset snapped the arms home and left the blocks wherever the last
        # attempt dropped them: a different robot wearing the same name.
        self._object_addr = scene.free_joints(mujoco, model)
        self._object_home = scene.object_poses(data.qpos, self._object_addr)
        #: One entry per "step" in motion_log: where every object stood at
        #: that tick. The main thread plays these back in step with the arm
        #: frames — without them, playback showed the block teleporting to
        #: its destination and the arm setting off afterwards to fetch
        #: nothing. Rewound by rehearsal exactly as motion_log is.
        self.object_log: list[dict[str, list[float]]] = []
        #: botcortex.episodes.Recorder, when runs are kept as training data.
        #: A tab has no disk and no camera: it records states and hands them
        #: to a sink; pixels are rendered from them later (dataset.render).
        self.recorder = None

        #: Where rehearsals park the present moment — one mjData per nesting
        #: depth, built on first use and reused. A single shared spare would be
        #: clobbered by an inner rehearsal, and the outer restore would then put
        #: back the INNER snapshot: garbage, silently.
        self._spares: list = []
        self._depth = 0
        #: True while a rehearsal is running. Nothing real is happening, so
        #: the state feed holds its last frame rather than showing it — see
        #: the note in rehearsal().
        self.rehearsing = False
        #: Called, at most twice a second, while motion is being computed. The
        #: browser waits on a call that cannot be interrupted, and used to give
        #: every tool a flat ten minutes before deciding the thread had hung —
        #: so a genuinely hung skill took ten minutes to fail. With a pulse, a
        #: minute and a half of silence is a hang and a long skill is not.
        self.on_alive: Callable[[], None] | None = None
        self._pulse = Pulse()

        self.reset()

    # --- actuation (indices and units both come from JointMap) ---
    #
    # data.ctrl and data.qpos hand back a FRESH Float64Array view per property
    # access, onto the same WASM heap. Writes stick; identity does not hold, and
    # a view cached across a heap growth would detach. Fetched per tick, which
    # is both correct and cheap.

    def _write_target(self, arm: str, joint: str, deg: float) -> None:
        ctrl = self.data.ctrl
        for index, value in self.joints.ctrl_writes(arm, joint, deg):
            ctrl[index] = value

    def _write_qpos(self, arm: str, joint: str, deg: float) -> None:
        qpos = self.data.qpos
        for index, value in self.joints.qpos_writes(arm, joint, deg):
            qpos[index] = value

    def reset(self) -> None:
        """Snap back to home with no momentum.

        Velocities and accelerations are zeroed FIRST: writing qpos while qvel
        still carries momentum leaves the arm drifting away from the pose we
        just set, and mj_forward does not clear it.
        """
        qvel, qacc = self.data.qvel, self.data.qacc
        for i in range(len(qvel)):
            qvel[i] = 0.0
        for i in range(len(qacc)):
            qacc[i] = 0.0
        scene.place_objects(self.data.qpos, self._object_addr, self._object_home)
        for arm in self.platform.arms:
            for joint, value in self.platform.home_position.items():
                self._write_target(arm, joint, value)
                self._write_qpos(arm, joint, value)
        self._mujoco.mj_forward(self.model, self.data)

    def _alive(self) -> None:
        self._pulse(self.on_alive)

    # --- the primitive interface (mirrors MockRobot and SimRobot exactly) ---

    def get_positions(self, arm: str) -> dict[str, float]:
        return self.joints.positions(arm, self.data.qpos)

    def move_to(self, arm: str, targets: dict[str, float], duration: float | None = None) -> None:
        """One move, at the control rate, e-stop checked before every frame.

        On pacing: the default `sleep` BLOCKS, which is right in a Web Worker
        and wrong on the browser's main thread, where it would freeze the tab
        and — worse — stop the STOP button's message from ever being delivered.
        Whoever constructs this decides; the class does not assume. Passing a
        no-op sleep runs the move as fast as the CPU allows and leaves pacing to
        the caller, which is how the frames become animation.
        """
        frames = plan_move(arm, self.get_positions(arm), targets, duration, self.platform)
        tick = 1 / config.CONTROL_HZ
        for frame in frames:
            if self.stop_file.exists():
                raise EStopTriggered(f"stop file present: {self.stop_file}")
            self._alive()
            for joint, deg in frame.items():
                self._write_target(arm, joint, deg)
            for _ in range(self._substeps):
                self._mujoco.mj_step(self.model, self.data)
            self.motion_log.append(("step", arm, self.get_positions(arm)))
            self.object_log.append(scene.object_poses(self.data.qpos, self._object_addr))
            if self.recorder is not None:
                self.recorder.tick(self, arm, frame)
            # A link inside the furniture is a fault, and continuing to command
            # a servo that is already buried only pushes harder. Aborts like
            # the e-stop, and for the same reason.
            hits = self._collisions()
            if hits:
                raise safety.Collision(safety.describe(hits))
            if self.realtime:
                self._sleep(tick)

    def gripper(self, arm: str, position: float) -> None:
        self.move_to(arm, {"gripper": position})

    def set_torque(self, arm: str, enabled: bool) -> None:
        self.torque[arm] = enabled
        self.motion_log.append(("torque", arm, {"enabled": float(enabled)}))

    def clear_errors(self) -> None:
        self.motion_log.append(("clear_errors", "both", {}))

    def replay_trajectory(self, arm: str, waypoints: list[dict[str, float]]) -> None:
        for waypoint in waypoints:
            self.move_to(arm, waypoint)

    # --- Cartesian: the bridge between what describe_scene says and what
    # move_to accepts. See botcortex/kinematics.py for why it exists.

    def tip(self, arm: str) -> tuple[tuple[float, float, float], float]:
        """Read the actual grasp centre without writing any simulator state."""
        hand = self._hand_ids.get(arm)
        if hand is None:
            mj = self._mujoco
            hand = self._hand_ids[arm] = mj.mj_name2id(
                self.model, mjcompat.enum_value(mj.mjtObj.mjOBJ_BODY), self.platform.hand_body(arm)
            )
        if self._flat is None:
            self._flat = mjcompat.is_flat(self.data.xpos)
        read = mjcompat.flat_row if self._flat else mjcompat.row
        rot = read(self.data.xmat, hand, 9)
        base = read(self.data.xpos, hand, 3)
        # The CONTROLLER's idea of where the jaws close (kinematics.calibrated_offset);
        # the jaws themselves are where physics puts them.
        offset = kinematics.calibrated_offset(self.platform.grasp_offset, self.tcp_error)
        return (
            kinematics.tip_from(base, rot, offset),
            self.platform.downwardness(rot),
        )

    def pose_tip(
        self, arm: str, pose: dict[str, float]
    ) -> tuple[tuple[float, float, float], float]:
        """Where the grasp centre WOULD be at `pose`. A question, not a move —
        the arm is restored before returning."""
        with self.rehearsal():
            return self._probe(arm)(pose)

    def park(self, arm: str, observe=None) -> None:
        """Home, without sweeping through the furniture — kinematics.retreat."""
        kinematics.retreat(self, arm, dict(self.platform.home_position), observe)

    def move_to_point(
        self,
        arm: str,
        point,
        tolerance: float = 0.02,
        *,
        may_move: tuple[str, ...] = (),
        observe=None,
        pinned: dict[str, float] | None = None,
        carried: tuple[str, ...] = (),
    ) -> None:
        """Move the grasp centre to a point in metres, gripper pointing down.

        Routed, rehearsed and verified — one definition for every physics
        backend, in kinematics.reach. Refuses rather than approximating, both
        when the point is out of reach and when no transit arrives: a skill
        that closed its jaws wherever the arm happened to stop would report
        success having grasped nothing.
        """
        kinematics.reach(
            self,
            arm,
            point,
            tolerance,
            may_move=may_move,
            observe=observe,
            pinned=pinned,
            carried=carried,
        )

    def _fixtures(self) -> set[str]:
        if self._fixture_names is None:
            self._fixture_names = set(self.describe_scene()["fixtures"])
        return self._fixture_names

    def _collisions(self) -> set[tuple[str, str]]:
        """Arm links currently inside furniture. Empty is healthy.

        Cheap when nothing is touching anything, which is the overwhelmingly
        common case — no contacts means no possible collision, and the fixture
        list never has to be built.
        """
        if int(self.data.ncon) == 0:
            return set()
        return safety.link_collisions(
            self._mujoco, self.model, self.data, self._fixtures(), self._robot_bodies, self._jaws
        )

    def _spare_data(self):
        """A second mjData, asked for the way JS asks — `new mj.MjData(model)`.

        The one line of rehearsal that differs from the native backend.
        """
        return self._mujoco.MjData.new(self.model)

    @contextmanager
    def rehearsal(self):
        """Run motion for real, then leave no trace of it — unless it is kept.

        Identical to SimRobot.rehearsal — same MuJoCo call, same state mask
        (verified 16383 in both builds), same rewind of the motion log. The
        rationale and the measurements are in botcortex.safety.

        One thing is different here, and it is why a browser skill used to make
        the owner watch a still robot for twice as long as it needed: the
        outermost rehearsal can be KEPT. A rehearsal is the real motion, from
        the real present moment, in the only world this robot has — so when it
        comes back clean, running the same thing again computes the same
        trajectory a second time to the last bit (test_wasm pins that). Nothing
        in a browser is watching live either: the owner is shown the motion log
        afterwards, frame by frame. So a clean rehearsal IS the run, and
        `trial.keep()` says so: the state and the logs stay where the rehearsal
        left them.

        What does not change: nothing is shown, logged or kept until the WHOLE
        motion has rehearsed clean. A rehearsal that raises can never be kept,
        and neither can an inner one — those are questions ("would this
        orientation work?"), not runs.

        The native SimRobot must not do this. Its owner watches the robot LIVE,
        paced, and a kept rehearsal there would be a run nobody saw.
        """
        if len(self._spares) <= self._depth:
            self._spares.append(self._spare_data())
        spare = self._spares[self._depth]
        safety.hold_state(self._mujoco, self.model, spare, self.data)
        logged = len(self.motion_log)
        tracked = len(self.object_log)
        paced, self.realtime = self.realtime, False
        watched, self.rehearsing = self.rehearsing, True
        self._depth += 1
        trial = Trial()
        clean = False
        try:
            yield trial
            clean = True
        finally:
            self._depth -= 1
            self.realtime = paced
            self.rehearsing = watched
            trial.stood = clean and trial.kept and self._depth == 0
            if not trial.stood:
                del self.motion_log[logged:]
                del self.object_log[tracked:]
                safety.release_state(self._mujoco, self.model, spare, self.data)

    def describe_scene(self) -> dict[str, dict]:
        """What is on the table. One definition, in botcortex.scene — writing it
        per backend is how two backends start disagreeing."""
        return scene.describe(self._mujoco, self.model, self.data, self._robot_bodies)

    def settle(self, seconds: float = 0.5) -> None:
        """Advance physics with targets held — lets servos finish converging."""
        for _ in range(max(1, round(seconds / float(self.model.opt.timestep)))):
            self._mujoco.mj_step(self.model, self.data)
