"""The controlled fault catalog.

Four families now, matching four of the dossier's six benchmark classes:

- PROGRAM faults live in the program. They are source transforms applied to
  a skill before it runs — a wrong drop height, a skipped prerequisite, the
  wrong object — because that is what a program fault is: a bug in the
  code, not a knob on the robot. The verifier sees its consequences; the
  selector sees the failing program and its trace.

- PERCEPTION faults live in the observation layer (research.perception).
  The program is correct; what it was told was not.

- FRAME faults are calibration: the tool offset the controller believes
  (research.world.TcpOffset) or the camera-to-base transform the
  observation layer applies (perception.FrameOffset). Program and
  estimates are both right in their own frames; the frames disagree.

- TRACKING faults are the servos not doing what they were told
  (research.world.GainScale): the arm sags and arrives short.

The catalog is PER TASK. A fault is a transform on a program's text, and
a program without the line — a push has no drop height — cannot carry it;
`catalog(family)` keeps only the faults that apply, and says which.

Every injected fault comes with a `SealedLabel`: the ground truth of what
was injected, kept in a separate record from the episode the selector
reads. The selector must diagnose from evidence. The evaluation runner
opens the label afterwards to score the diagnosis — and to record whether
the fault actually caused a failure on that body, because an injected
setting that took no effect is not a failure case, it is a no-op, and
counting it as one would flatter every selector equally.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

from botcortex.research import perception, world

FAMILIES = ("program", "perception", "frame", "tracking")


@dataclass(frozen=True)
class Fault:
    """One entry in the catalog. `params` are the knobs; `kind` names the
    transform. `expected` is the verifier violation the fault is designed to
    produce, used to check that an injection took effect."""

    family: str
    kind: str
    params: dict = field(default_factory=dict)
    expected: str = ""

    @property
    def name(self) -> str:
        return f"{self.family}:{self.kind}"


@dataclass(frozen=True)
class SealedLabel:
    """What was injected, and whether it bit. Never in the episode packet."""

    fault: Fault | None
    took_effect: bool | None = None
    note: str = ""


class FaultError(ValueError):
    """The fault could not be applied to this program — the source lacks the
    line the transform edits, so injecting it would silently do nothing."""


# --- program faults: source transforms ---------------------------------------
#
# Written against the portable skill's shape (tests/fixtures/portable_pick_and_place.py):
# named `lift` and `drop` constants, an explicit open before the descent,
# and a `block` parameter. Each transform asserts it changed something.


def _sub(source: str, pattern: str, replacement: str, what: str) -> str:
    new, n = re.subn(pattern, replacement, source, count=1, flags=re.MULTILINE)
    if n == 0:
        raise FaultError(f"cannot inject {what}: the program has no `{pattern}`")
    return new


def drop_too_low(source: str, params: dict) -> str:
    """Releases the object INTO the tray floor instead of above it: the
    fingers wedge on the surface first, or the object is dropped from a
    pose the arm never reached."""
    depth = float(params.get("depth", -0.02))
    return _sub(source, r"^(\s*)drop = [0-9.]+", rf"\g<1>drop = {depth}", "drop_too_low")


def lift_too_low(source: str, params: dict) -> str:
    """Carries the object at a height that sweeps through neighbours or the
    tray walls: a planner that forgot what is between here and there."""
    height = float(params.get("height", 0.02))
    return _sub(source, r"^(\s*)lift = [0-9.]+", rf"\g<1>lift = {height}", "lift_too_low")


def skip_open(source: str, params: dict) -> str:
    """The prerequisite is missing: descends with the jaws closed, so the
    grasp closes on nothing (or the jaws land on the object)."""
    return _sub(
        source,
        r"^[ \t]*ctx\.gripper\(arm, open_deg\)[ \t]*\n(?=[ \t]*ctx\.move_to_point\(arm, \[here\[0\], here\[1\], here\[2\] \+ lift\]\))",
        "",
        "skip_open",
    )


def press_too_high(source: str, params: dict) -> str:
    """The push waypoint is above the block: the closed jaws sweep over it
    and nothing moves — a planner that took "at the block" to mean "over
    the block"."""
    height = float(params.get("height", 0.05))
    return _sub(source, r"^(\s*)press = [0-9.]+", rf"\g<1>press = {height}", "press_too_high")


def wrong_object(source: str, params: dict) -> str:
    """The relation names the wrong thing: the program picks `other` when
    the task said `block`."""
    other = params.get("other", "blue_block")
    return _sub(
        source,
        r'^(\s*)here = scene\["objects"\]\[block\]\["position"\]',
        rf'\g<1>here = scene["objects"]["{other}"]["position"]',
        "wrong_object",
    )


PROGRAM_TRANSFORMS = {
    "drop_too_low": drop_too_low,
    "lift_too_low": lift_too_low,
    "press_too_high": press_too_high,
    "skip_open": skip_open,
    "wrong_object": wrong_object,
}


def apply_program_fault(source: str, fault: Fault) -> str:
    if fault.family != "program":
        raise ValueError(f"{fault.name} is not a program fault")
    return PROGRAM_TRANSFORMS[fault.kind](source, fault.params)


# --- perception faults: observation transforms ---------------------------------


def perception_transform(fault: Fault) -> perception.Transform:
    if carrier(fault) != "perception":
        raise ValueError(f"{fault.name} is not injected through perception")
    p = fault.params
    if fault.kind == "pose_bias":
        return perception.PoseBias(tuple(p["objects"]), tuple(p["offset"]))
    if fault.kind == "stale_pose":
        return perception.StalePose(tuple(p["objects"]))
    if fault.kind == "identity_swap":
        return perception.IdentitySwap(p["a"], p["b"])
    if fault.kind == "occlusion":
        return perception.Occlusion(tuple(p["objects"]))
    if fault.kind == "base_offset":
        return perception.FrameOffset(tuple(p["offset"]))
    raise ValueError(f"unknown perception fault {fault.kind!r}")


# --- frame and tracking faults: patches on the robot -----------------------------


def world_patch(fault: Fault) -> world.Patch:
    p = fault.params
    if fault.name == "frame:tcp_offset":
        return world.TcpOffset(tuple(p["delta"]))
    if fault.name == "tracking:gain_low":
        return world.GainScale(float(p["factor"]))
    raise ValueError(f"{fault.name} is not a robot fault")


def carrier(fault: Fault) -> str:
    """Where a fault is injected: the program's text, the observation
    layer, or the robot itself."""
    if fault.family == "program":
        return "program"
    if fault.family == "perception" or fault.name == "frame:base_offset":
        return "perception"
    return "world"


# --- the catalog, per task family ---------------------------------------------


def _every(block: str, other: str) -> tuple[Fault, ...]:
    return (
        Fault("program", "drop_too_low", {"depth": -0.02}, expected="goal inside"),
        Fault("program", "lift_too_low", {"height": 0.02}, expected="invariant untouched"),
        Fault("program", "press_too_high", {"height": 0.05}, expected="goal near"),
        Fault("program", "skip_open", {}, expected="goal inside"),
        Fault("program", "wrong_object", {"other": other}, expected="goal"),
        Fault(
            "perception",
            "pose_bias",
            {"objects": [block], "offset": [0.03, 0.0, 0.0]},
            expected="goal",
        ),
        Fault("perception", "stale_pose", {"objects": [block]}, expected="goal"),
        Fault("perception", "identity_swap", {"a": block, "b": other}, expected="goal"),
        Fault("perception", "occlusion", {"objects": [block]}, expected="goal"),
        # The whole scene 30 mm off: as far as the block goes this is a pose
        # bias, but the tray and the pocket are off by the same amount, so
        # the drop lands off too — and a known fixture gives it away.
        Fault("frame", "base_offset", {"offset": [0.0, 0.03, 0.0]}, expected="goal"),
        # The controller thinks its jaws close 20 mm from where they do.
        Fault("frame", "tcp_offset", {"delta": [0.02, 0.0, 0.0]}, expected="goal"),
        # Servos at a fifth of their gain: the arm sags and lags, arrivals
        # fall short (measured: reach fails outright on the xArm7 and the
        # OpenArm at this factor, and the step-response probe reads it on
        # every body).
        Fault("tracking", "gain_low", {"factor": 0.2}, expected="goal"),
    )


def applies(fault: Fault, source: str) -> bool:
    """Whether this fault can be injected into this program at all — a
    program transform needs its line; the other carriers always apply."""
    if fault.family != "program":
        return True
    try:
        apply_program_fault(source, fault)
    except FaultError:
        return False
    return True


def catalog(
    family: str = "pick_and_place", block: str = "red_block", other: str = "blue_block"
) -> tuple[Fault, ...]:
    """The controlled faults for one task family: every fault in the
    benchmark that the family's program can carry.

    Parameters are the defaults the sim study starts from; the evaluation
    runner may sweep them. Each carries the violation it is expected to
    produce, so a run can report "injected but took no effect" honestly.
    """
    from botcortex.research import programs

    source = programs.source(family)
    return tuple(f for f in _every(block, other) if applies(f, source))
