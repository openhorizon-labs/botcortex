"""Repair memory: what was tried on which body, and whether it worked.

The product's episodic memory (botcortex.memory) holds task, outcome and a
lesson, keyed by keyword overlap. The research needs more from a record
and less from retrieval: every record carries the embodiment's identity
(platform name and capability hash), the program's hash before and after
the intervention, the failure in both representations (contract signature
and trace text), the repair chosen, and the VERIFIED outcome — a failed
repair is a record too, and the most useful kind.

Retrieval is switchable, because retrieval is the experiment:

  none              — the selector sees no memory at all.
  target_only       — records from the target body only.
  cross_body        — records from other bodies, matched by contract signature.
  cross_body_traces — records from other bodies, matched by keyword overlap
                      on the trace text (the H2 control).

Splits are enforced at retrieval, never by trusting the caller: a memory
opened for a held-out body refuses records from that body (and from any
embodiment declared to be its simulated variant), and a memory opened for
a training body refuses the held-out one's records too.
"""

from __future__ import annotations

import json
import re
from dataclasses import asdict, dataclass
from pathlib import Path

from botcortex.research.signature import signature_key

MODES = ("none", "target_only", "cross_body", "cross_body_traces")

_STOP = frozenset(
    [
        "a",
        "an",
        "and",
        "are",
        "as",
        "at",
        "be",
        "by",
        "for",
        "from",
        "has",
        "i",
        "in",
        "is",
        "it",
        "of",
        "on",
        "or",
        "that",
        "the",
        "this",
        "to",
        "was",
        "with",
    ]
)


def _terms(text: str) -> set[str]:
    return {w for w in re.findall(r"[a-z_]+", text.lower()) if w not in _STOP and len(w) > 2}


@dataclass(frozen=True)
class RepairRecord:
    platform: str
    capability_hash: str
    task: str
    skill_hash_before: str
    skill_hash_after: str
    signature: dict
    trace: str
    repair: str
    recovered: bool
    verdict_after: str
    split: str = "train"

    def to_json(self) -> str:
        return json.dumps(asdict(self), sort_keys=True)

    @staticmethod
    def from_json(line: str) -> RepairRecord:
        data = json.loads(line)
        sig = data["signature"]
        for key in ("violations", "moved_by_program_view"):
            sig[key] = tuple(sig[key])
        return RepairRecord(**data)


class RepairMemory:
    def __init__(self, path: Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def append(self, record: RepairRecord) -> None:
        with self.path.open("a") as f:
            f.write(record.to_json() + "\n")

    def all(self) -> list[RepairRecord]:
        if not self.path.exists():
            return []
        return [RepairRecord.from_json(line) for line in self.path.read_text().splitlines() if line]

    def retrieve(
        self,
        mode: str,
        *,
        target_platform: str,
        signature: dict,
        trace: str,
        excluded_platforms: tuple[str, ...] = (),
        task: str | None = None,
        limit: int = 50,
        probes: dict[str, bool | None] | None = None,
        min_score: float = 0.5,
    ) -> list[tuple[float, RepairRecord]]:
        """Records relevant to a failure on `target_platform`, scored.

        Score is 1.0 for an exact contract-signature match, a fraction for a
        partial match (cross_body and target_only), or the Jaccard overlap of
        trace terms (cross_body_traces). Records below `min_score` are not
        returned: at 1.0 the memory ABSTAINS on anything but an exact match,
        which is the fix the pilot's negative-transfer cases asked for — a
        partial match that recommends another fault's repair is worse than
        no memory at all. Records from excluded platforms — the held-out
        body's simulated variants — never come back, whatever the mode.
        """
        if mode not in MODES:
            raise ValueError(f"unknown retrieval mode {mode!r}; one of {MODES}")
        if mode == "none":
            return []
        records = [
            r
            for r in self.all()
            if r.platform not in excluded_platforms and (task is None or r.task == task)
        ]
        if mode == "target_only":
            records = [r for r in records if r.platform == target_platform]
        else:
            records = [r for r in records if r.platform != target_platform]
        # A probe the target has taken narrows memory to records whose own
        # probe agreed. Records that never took that probe are kept: absence
        # of a measurement is not evidence against.
        for probe, result in (probes or {}).items():
            records = [
                r
                for r in records
                if probe not in r.signature.get("probes", {})
                or r.signature["probes"][probe] == result
            ]

        scored: list[tuple[float, RepairRecord]] = []
        if mode == "cross_body_traces":
            query = _terms(trace)
            for r in records:
                hay = _terms(r.trace)
                if query and hay:
                    overlap = len(query & hay) / len(query | hay)
                    if overlap > 0:
                        scored.append((overlap, r))
        else:
            key = signature_key(signature)
            for r in records:
                other = signature_key(r.signature)
                matches = sum(a == b for a, b in zip(key, other, strict=True))
                score = matches / len(key)
                if key == other:
                    score = 1.0
                if score >= min_score:
                    scored.append((score, r))
        scored.sort(key=lambda t: -t[0])
        return scored[:limit]
