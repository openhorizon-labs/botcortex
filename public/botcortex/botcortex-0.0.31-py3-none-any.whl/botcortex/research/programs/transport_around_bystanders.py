META = {
    "name": "portable_transport",
    "description": "Carry a block to a tray past another block standing on the straight path between them.",
    "params": {"block": "red_block", "tray": "tray_right"},
}


def run(ctx, block="red_block", tray="tray_right"):
    # The same carry as pick-and-place. What makes it a different task is
    # the WORLD: a bystander sits on the line from block to tray, so the
    # carry height is what keeps the invariant, and a lift too low is the
    # fault that breaks it.
    arm = ctx.arms[0]
    open_deg, closed_deg = ctx.gripper_range(arm)

    scene = ctx.describe_scene()
    if block not in scene["objects"]:
        raise ValueError(f"no block called {block}")
    if tray not in scene["fixtures"]:
        raise ValueError(f"no tray called {tray}")

    here = scene["objects"][block]["position"]
    there = scene["fixtures"][tray]["position"]
    lift = 0.12  # above every block on the table, with margin
    drop = 0.06  # let go just above the tray floor, not into it

    ctx.gripper(arm, open_deg)
    ctx.move_to_point(arm, [here[0], here[1], here[2] + lift])
    ctx.move_to_point(arm, here)
    ctx.gripper(arm, closed_deg)
    ctx.move_to_point(arm, [here[0], here[1], here[2] + lift])
    ctx.move_to_point(arm, [there[0], there[1], there[2] + lift])
    ctx.move_to_point(arm, [there[0], there[1], there[2] + drop])
    ctx.gripper(arm, open_deg)
    ctx.move_to_point(arm, [there[0], there[1], there[2] + lift])
