META = {
    "name": "portable_push",
    "description": "Slide a block a set distance across the table with the closed gripper, without lifting it.",
    "params": {"block": "red_block", "dx": 0.0, "dy": -0.06},
}


def run(ctx, block="red_block", dx=0.0, dy=-0.06):
    # A push moves an object it never holds. The move that does the pushing
    # names the block in may_move, so the runtime's transit guard lets THAT
    # object move and still refuses to disturb any other.
    arm = ctx.arms[0]
    open_deg, closed_deg = ctx.gripper_range(arm)

    scene = ctx.describe_scene()
    if block not in scene["objects"]:
        raise ValueError(f"no block called {block}")

    here = scene["objects"][block]["position"]
    size = scene["objects"][block]["size_m"]
    lift = 0.12  # come in from above, clear of everything
    press = 0.0  # push at the block's own centre height, to begin with
    jaw = 0.012  # how far the closed jaws' face sits ahead of the grasp centre
    length = (dx * dx + dy * dy) ** 0.5
    if length == 0:
        raise ValueError("push needs a direction")
    ux, uy = dx / length, dy / length
    goal = [here[0] + ux * length, here[1] + uy * length]
    # Start behind the block: half its width plus room for the closed jaws.
    back = size[0] / 2 + 0.035

    def stroke(origin, distance, z):
        start = [origin[0] - ux * back, origin[1] - uy * back, z]
        # Stop with the jaws' face where the block's rear face must end, so
        # the block's centre travels `distance` and no further.
        travel = distance - size[0] / 2 - jaw
        end = [origin[0] + ux * travel, origin[1] + uy * travel, z]
        ctx.move_to_point(arm, [start[0], start[1], here[2] + lift])
        ctx.move_to_point(arm, start)
        ctx.move_to_point(arm, end, may_move=[block])
        ctx.move_to_point(arm, [end[0], end[1], here[2] + lift], may_move=[block])

    ctx.gripper(arm, closed_deg)
    stroke(here, length, here[2] + press)

    # Look, and push again if the block fell short — at most twice. Jaws
    # differ in how far they stand ahead of the grasp centre and a block
    # slips a little; a hand that tilts rides over the block instead of
    # moving it, and pushing lower fixes that.
    for _ in range(2):
        now = ctx.describe_scene()["objects"][block]["position"]
        left = (goal[0] - now[0]) * ux + (goal[1] - now[1]) * uy
        if left <= 0.015:
            break
        moved = ((now[0] - here[0]) ** 2 + (now[1] - here[1]) ** 2) ** 0.5
        if moved < 0.005:
            press = press - 0.008
        stroke(now, left, here[2] + press)
    ctx.gripper(arm, open_deg)
