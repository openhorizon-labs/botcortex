META = {
    "name": "portable_pick_and_place",
    "description": "Pick a block off the table and set it down in a tray, on whatever body runs it.",
    "params": {"block": "red_block", "tray": "tray_right"},
}


def run(ctx, block="red_block", tray="tray_right"):
    # Nothing about the body is hardcoded: which arm, or what "open" is.
    arm = ctx.arms[0]
    open_deg, closed_deg = ctx.gripper_range(arm)

    scene = ctx.describe_scene()
    if block not in scene["objects"]:
        raise ValueError(f"no block called {block}")
    if tray not in scene["fixtures"]:
        raise ValueError(f"no tray called {tray}")

    here = scene["objects"][block]["position"]
    there = scene["fixtures"][tray]["position"]
    lift = 0.12  # clear the tray walls and anything on the table
    drop = 0.06  # let go just above the tray floor, not into it

    ctx.gripper(arm, open_deg)
    ctx.move_to_point(arm, [here[0], here[1], here[2] + lift])
    ctx.move_to_point(arm, here)
    ctx.gripper(arm, closed_deg)
    ctx.move_to_point(arm, [here[0], here[1], here[2] + lift])
    ctx.move_to_point(arm, [there[0], there[1], there[2] + lift])
    ctx.move_to_point(arm, [there[0], there[1], there[2] + drop])
    ctx.gripper(arm, open_deg)
    ctx.move_to_point(arm, [there[0], there[1], there[2] + lift])
