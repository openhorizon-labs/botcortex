META = {
    "name": "portable_insertion",
    "description": "Set a block down inside a shallow pocket barely wider than the block.",
    "params": {"block": "red_block", "slot": "slot"},
}


def run(ctx, block="red_block", slot="slot"):
    # Contact-sensitive placement: the pocket leaves a centimetre a side,
    # so a placement that a tray forgives — a biased estimate, a
    # miscalibrated tool — lands on the pocket's wall here.
    arm = ctx.arms[0]
    open_deg, closed_deg = ctx.gripper_range(arm)

    scene = ctx.describe_scene()
    if block not in scene["objects"]:
        raise ValueError(f"no block called {block}")
    if slot not in scene["fixtures"]:
        raise ValueError(f"no slot called {slot}")

    here = scene["objects"][block]["position"]
    there = scene["fixtures"][slot]["position"]
    lift = 0.12  # clear everything on the table
    hover = 0.09  # line up precisely above the pocket before descending
    drop = 0.05  # release with the block's base just above the walls

    ctx.gripper(arm, open_deg)
    ctx.move_to_point(arm, [here[0], here[1], here[2] + lift])
    ctx.move_to_point(arm, here)
    ctx.gripper(arm, closed_deg)
    ctx.move_to_point(arm, [here[0], here[1], here[2] + lift])
    ctx.move_to_point(arm, [there[0], there[1], there[2] + lift])
    # A tight tolerance here: a carry waypoint may be sloppy, a descent into
    # a pocket with a centimetre a side may not. The arm trims its sag.
    ctx.move_to_point(arm, [there[0], there[1], there[2] + hover], 0.008)
    ctx.move_to_point(arm, [there[0], there[1], there[2] + drop], 0.008)
    ctx.gripper(arm, open_deg)
    ctx.move_to_point(arm, [there[0], there[1], there[2] + lift])
