"""The benchmark's task programs: one portable skill per task family.

Each is a plain BotCortex skill — META plus run(ctx, **params) — written
against the SkillContext alone, so the same source runs unchanged on every
body in the catalog. They are kept as source files, not imported: the
fault harness edits their TEXT (research.faults), and the store compiles
what it is given.

The programs share their idioms on purpose. Named `lift`, `drop` and
`press` heights, an explicit open before every descent, and `here =
scene["objects"][block]["position"]` are the lines the program faults
edit, so one fault catalog reaches every family where the line exists.
"""

from __future__ import annotations

from pathlib import Path

PROGRAMS_DIR = Path(__file__).parent

FAMILIES = ("pick_and_place", "transport_around_bystanders", "push", "insertion")


def path(family: str) -> Path:
    if family not in FAMILIES:
        raise ValueError(f"no benchmark program for task family {family!r}; one of {FAMILIES}")
    return PROGRAMS_DIR / f"{family}.py"


def source(family: str) -> str:
    return path(family).read_text()
