"""What a failure looks like, in two representations.

H1 says failure knowledge travels across bodies; H2 says it travels
BECAUSE failures are recorded as contract violations over object-centric
intent, not as joint traces. This module produces both forms from the same
episode, and nothing else in the harness gets to describe a failure.

The CONTRACT signature is structured: how the run ended, what class of
error if any, which contract predicates failed and where the target ended
up according to the independent verifier, which objects the PROGRAM saw
move, and whether the program's final observation disagrees with the
verifier's measurement. None of it mentions joints, arms, or the body.

The TRACE representation is what today's episodes.jsonl holds: the error
text, the primitive-call trace with its joint angles and coordinates, and a
one-line lesson — retrieved by keyword overlap, as memory.recall does. It
is the control arm: the same information, in the form a body leaves it.

Neither sees the sealed label. The verifier's verdict IS visible — a
diagnoser that could not learn the task had failed could not diagnose —
and the verdict's measured positions are treated as what they are on
hardware: an independent measurement the diagnoser may compare against the
controller's own estimate. That comparison is the single most informative
feature here, and it is a contract-level one.
"""

from __future__ import annotations

import re

from botcortex.research.evidence import Episode

#: How far the program's own final estimate may sit from the verifier's
#: measurement before the two are said to disagree. Settling and contact
#: compliance move a resting block a few millimetres; a biased estimator
#: moves it centimetres.
DISAGREEMENT_M = 0.015


def _error_class(error: str | None) -> str:
    if not error:
        return "none"
    text = error.lower()
    if "no block called" in text or "no object" in text or "keyerror" in text:
        return "missing_object"
    if "cannot reach" in text:
        return "unreachable"
    if "lost its grasp" in text:
        return "lost_grasp"
    if "unsafe transit" in text or "displaced" in text:
        return "unsafe_transit"
    if "no clear route" in text or "collision" in text:
        return "collision"
    return "other"


def _distance(a, b) -> float:
    return sum((x - y) ** 2 for x, y in zip(a, b, strict=True)) ** 0.5


def _moved(before: dict, after: dict | None, threshold: float = 0.02) -> tuple[str, ...]:
    if not after:
        return ()
    moved = []
    for name, body in before.get("objects", {}).items():
        end = after.get("objects", {}).get(name)
        if end and _distance(body["position"], end["position"]) > threshold:
            moved.append(name)
    return tuple(sorted(moved))


def _target_of(task: str) -> str | None:
    match = re.match(r"(?:put|carry|push) (\w+) ", task)
    return match.group(1) if match else None


def contract_signature(episode: Episode) -> dict:
    verdict = episode.verdict
    violations = verdict.get("violations", [])
    classes = tuple(sorted(v.split(":")[0].split("(")[0].strip() for v in violations))
    target = getattr(episode, "target", "") or _target_of(episode.task)
    landed = "unknown"
    for v in violations:
        # Any goal predicate about the target: inside(), near(), on_fixture().
        if target and re.match(rf"goal \w+\({re.escape(target)}[,)]", v):
            match = re.search(r"is (on \w+|off every fixture)", v)
            if match:
                landed = match.group(1)
            elif "held" in v:
                landed = "held above goal"
            elif "from its goal" in v:
                landed = "short of goal"
            else:
                landed = "elsewhere"
    if verdict.get("status") == "ok":
        landed = "at goal"

    disagreement = None
    measured = verdict.get("evidence", {}).get("objects_after", {})
    if episode.observed_after and measured:
        gaps = [
            _distance(body["position"], measured[name])
            for name, body in episode.observed_after.get("objects", {}).items()
            if name in measured
        ]
        disagreement = bool(gaps) and max(gaps) > DISAGREEMENT_M

    moved = _moved(episode.observed_before, episode.observed_after)
    # What the jaws held when the attempt ended, said relative to the task:
    # the target, another object, or nothing. Object-centric, body-free.
    held_all = sorted(
        {name for names in (getattr(episode, "held_at_stop", {}) or {}).values() for name in names}
    )
    holding = "target" if target in held_all else ("other" if held_all else "nothing")
    return {
        "outcome": episode.outcome,
        "error_class": _error_class(episode.error),
        "verdict": verdict.get("status"),
        "violations": classes,
        "target_landed": landed,
        "target_seen": bool(target and target in episode.observed_before.get("objects", {})),
        "moved_by_program_view": moved,
        "target_moved": bool(target and target in moved),
        "others_moved": any(name != target for name in moved),
        "perception_disagreement": disagreement,
        "holding": holding,
        # Filled in only when a probe was taken (research.probes); kept out
        # of signature_key so retrieval without probes is unchanged.
        "probes": {},
    }


def signature_key(sig: dict) -> tuple:
    """The exact-match key for retrieval: everything the contract signature
    holds, in a fixed order."""
    return (
        sig["outcome"],
        sig["error_class"],
        sig["verdict"],
        sig["violations"],
        sig["target_landed"],
        sig["target_seen"],
        sig["target_moved"],
        sig["others_moved"],
        sig["perception_disagreement"],
        # Absent on records written before the feature existed: those match
        # only each other on this field, never a record that measured it.
        sig.get("holding", "unmeasured"),
    )


def trace_text(episode: Episode) -> str:
    """The trace representation: the error text, the primitive trace with
    the body's own numbers, and whether the attempt passed or failed.

    Nothing from the contract: no predicate names, no "on table", no
    disagreement flag. An earlier version appended the verifier's violation
    text as the "lesson", which handed the control arm the contract
    representation by the back door and made H2 untestable. The lesson line
    the product's memory holds is the AGENT's, and the agent in this study
    is a fixed program that says nothing.
    """
    return " ".join(
        [episode.error or "", " ".join(episode.steps), episode.verdict.get("status", "")]
    )
