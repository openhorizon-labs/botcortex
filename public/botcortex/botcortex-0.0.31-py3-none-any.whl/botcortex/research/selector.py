"""Which repair to try next, from evidence — with or without memory.

Three kinds of selector, all sharing the same repair operators, so a
difference between them is a difference in DECISION, not in what a
decision can do:

- FixedStrategy: the dossier's fixed baselines. Always repair the program
  (cycle the program repairs), or always fix perception (cycle the
  perception repairs), or a fixed interleaving.
- RuleSelector: a hand-written diagnosis over the contract signature. No
  memory. This is the honest floor: if it already picks right every time,
  memory has nothing to add and the report says so.
- MemorySelector: ranks repairs by their verified success on retrieved
  records — retrieved under one of the four memory arms — and falls back
  to a fixed prior order for anything memory is silent on. The FOUR ARMS
  DIFFER ONLY IN RETRIEVAL. That is the experiment.

A selector proposes an ordered list of repairs it has not yet tried; the
recovery loop takes the first, runs it, verifies from truth, and asks
again. Attempts to verified recovery is what gets measured.
"""

from __future__ import annotations

import random
from collections import defaultdict
from dataclasses import dataclass, field

from botcortex.research import probes as probelib
from botcortex.research import repairs as repairlib
from botcortex.research.memory import RepairMemory

REPAIRS = repairlib.catalog()
BY_NAME = {r.name: r for r in REPAIRS}

#: The prior order any selector falls back to: the program first, because a
#: freshly authored program is the likeliest thing to be wrong, then the
#: perception pipeline. The same order for every body.
PRIOR_ORDER = tuple(r.name for r in REPAIRS)


class Selector:
    """`propose` ranks the untried repairs. `request_probe`, asked first on
    every round, may name a targeted measurement to take before proposing;
    its result lands in signature["probes"] and costs budget. The default
    never probes — every passive arm inherits that."""

    name = "selector"
    probing = "none"  # "none" | "rule" | "random"

    def propose(self, signature: dict, trace: str, tried: tuple[str, ...]) -> list[str]:
        raise NotImplementedError

    def request_probe(self, signature: dict, trace: str, tried: tuple[str, ...]) -> str | None:
        done = signature.get("probes", {})
        if self.probing == "rule":
            return probelib.choose_probe_by_rule(signature, done)
        if self.probing == "random":
            return probelib.choose_probe_at_random(signature, done, self._rng)
        return None

    def with_probing(self, probing: str, seed: int = 0):
        self.probing = probing
        self._rng = random.Random(seed)
        if probing != "none":
            self.name = f"{self.name}+{probing}_probe"
        return self


@dataclass
class FixedStrategy(Selector):
    order: tuple[str, ...]
    name: str = "fixed"

    def propose(self, signature, trace, tried):
        return [r for r in self.order if r not in tried]


def always_program() -> FixedStrategy:
    return FixedStrategy(
        tuple(r.name for r in REPAIRS if r.family == "program")
        + tuple(r.name for r in REPAIRS if r.family != "program"),
        "always_program",
    )


def always_perception() -> FixedStrategy:
    return FixedStrategy(
        tuple(r.name for r in REPAIRS if r.family == "perception")
        + tuple(r.name for r in REPAIRS if r.family != "perception"),
        "always_perception",
    )


def always_calibrate() -> FixedStrategy:
    """The dossier's second fixed baseline: always recalibrate or identify
    physical parameters first — frame and tracking repairs, then the rest."""
    return FixedStrategy(
        tuple(r.name for r in REPAIRS if r.family in ("frame", "tracking"))
        + tuple(r.name for r in REPAIRS if r.family not in ("frame", "tracking")),
        "always_calibrate",
    )


class RuleSelector(Selector):
    """Hand-written diagnosis from the contract signature, no memory.

    The rules are what a careful engineer would write after reading the
    fault catalog — which is the point: they are a ceiling for what
    evidence alone gives you on a body you know.
    """

    name = "rules"

    def propose(self, signature, trace, tried):
        ranked: list[str] = []
        sig = signature
        probes = sig.get("probes", {})
        # Measurements first: each probe, when taken, names its repair.
        if probes.get("check_tracking") is True:
            ranked.append("tracking:retune_gains")
        if probes.get("touch_reference") is True:
            ranked.append("frame:recalibrate_tcp")
        if probes.get("check_fixture") is True:
            ranked.append("frame:recalibrate_base")
        if sig["error_class"] == "missing_object" or not sig["target_seen"]:
            ranked.append("perception:change_viewpoint")
        if sig["perception_disagreement"]:
            tracked = probes.get("nudge")
            if tracked is False:
                ranked += ["perception:refresh_tracking", "perception:recalibrate"]
            else:
                ranked += [
                    "perception:recalibrate",
                    "frame:recalibrate_base",
                    "perception:refresh_tracking",
                ]
        if sig["outcome"] == "completed" and sig["others_moved"] and not sig["target_moved"]:
            ranked += ["program:retarget_named_object", "perception:reidentify"]
        if sig["outcome"] == "completed" and not sig["target_moved"] and not sig["others_moved"]:
            ranked += [
                "program:open_before_descent",
                "program:lower_press",
                "frame:recalibrate_tcp",
                "perception:refresh_tracking",
            ]
        if "invariant" in sig["violations"] or sig["error_class"] in (
            "unsafe_transit",
            "lost_grasp",
        ):
            ranked.append("program:raise_lift")
        holding = sig.get("holding", "unmeasured")
        if sig["error_class"] in ("collision", "unsafe_transit") and holding == "other":
            # The arm stopped with the WRONG block in its jaws: it picked the
            # wrong object, or was told the wrong name for it.
            ranked += ["program:retarget_named_object", "perception:reidentify"]
        if sig["error_class"] == "collision":
            # The arm hit the workcell. With the block held over the goal it
            # descended too far; with the block still on the table (or short
            # of a push goal) it swept into something on the way — a carry
            # too low. The servo probe, when taken, has already spoken above.
            if sig["target_landed"] == "held above goal":
                ranked += ["program:raise_drop", "program:raise_lift"]
            else:
                ranked += ["program:raise_lift", "program:raise_drop"]
        elif sig["target_landed"] in ("on table", "elsewhere", "held above goal"):
            ranked.append("program:raise_drop")
        if (
            sig["error_class"] in ("unreachable", "collision")
            or sig["target_landed"] == "short of goal"
        ):
            ranked += ["tracking:retune_gains", "program:lower_press"]
        ranked += list(PRIOR_ORDER)
        out: list[str] = []
        for r in ranked:
            if r not in tried and r not in out:
                out.append(r)
        return out


@dataclass
class MemorySelector(Selector):
    """Ranks repairs by verified success on retrieved records.

    `mode` is the memory arm. `target_platform` is the body the failure is
    on; `excluded_platforms` are its simulated variants, never retrieved.
    """

    memory: RepairMemory
    mode: str
    target_platform: str
    excluded_platforms: tuple[str, ...] = ()
    smoothing: float = 0.5
    #: Retrieval threshold. 0.5 (loose) is the pilot's setting; 1.0 makes
    #: the memory abstain on anything but an exact signature match and
    #: fall back to the prior order — no recommendation rather than a
    #: borrowed one. Named in the arm so the trade-off is visible.
    min_match: float = 0.5
    name: str = field(default="memory")

    def __post_init__(self):
        strictness = {1.0: "_exact", 0.8: "_strict"}.get(self.min_match, "")
        self.name = f"memory:{self.mode}{strictness}"

    def propose(self, signature, trace, tried):
        retrieved = self.memory.retrieve(
            self.mode,
            target_platform=self.target_platform,
            signature=signature,
            trace=trace,
            excluded_platforms=self.excluded_platforms,
            probes=signature.get("probes") or None,
            min_score=self.min_match,
        )
        wins: dict[str, float] = defaultdict(float)
        trials: dict[str, float] = defaultdict(float)
        for score, record in retrieved:
            # Symmetric evidence, weighted by how alike the two failures read.
            # An asymmetric variant (partial matches recommend, only exact
            # matches count against) was tried and reverted. Measured at FOUR
            # bodies, before the SO-101 and the ViperX: it rescued the low
            # carry (3 of 4 recovered) but cost more elsewhere (2.90 against
            # 2.75 mean attempts, 12 negative cases against 9). It has not
            # been re-measured at six, where (on the tables rebuilt after the
            # workcell layout fix) the baseline is 2.84 with 13 negative and
            # loose retrieval recovers 5 of 12 low carries —
            # and where the low carry turned out to be a signature ALIAS
            # (see benchmark_v2.md), which a reweighting cannot fix.
            trials[record.repair] += score
            if record.recovered:
                wins[record.repair] += score
        a = self.smoothing

        def estimate(name: str) -> float:
            return (wins[name] + a) / (trials[name] + 2 * a)

        prior = {name: i for i, name in enumerate(PRIOR_ORDER)}
        ranked = sorted(
            (name for name in PRIOR_ORDER if name not in tried),
            key=lambda name: (-estimate(name), -trials[name], prior[name]),
        )
        return ranked
