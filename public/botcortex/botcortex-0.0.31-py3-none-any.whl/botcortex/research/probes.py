"""Targeted measurements: what to do when the evidence cannot decide.

The pilot found faults no contract signature separates on a single body:
a biased pose estimate and a stale one both read "completed, the target
is still on the table, the program saw nothing move, and its estimate
disagrees with the verifier". Replaying the trace does not help — the
trace is the same. What separates them is a MEASUREMENT: change the
world by a known amount and see whether the estimate follows. A biased
tracker follows (it is wrong by a constant); a stale one does not (it is
not looking). The wider benchmark adds three more such pairs, and a probe
for each.

Five probes, deliberately unequal, so choosing between them means something:

- `reobserve` — passive, cheap in the field, and uninformative here: ask
  the perception layer again without touching anything, report whether
  the estimate changed.
- `nudge` — active and bounded: displace the target by a known 20 mm
  (on hardware, a low-force push at an operator-approved configuration;
  here, the simulator moves the block), re-observe, and report whether
  the estimate tracked the motion.
- `check_fixture` — passive: compare the perceived pose of a fixture
  whose true pose is known (a fiducial on the bench) with that truth.
  Disagreement is a frame fault; a biased object estimate leaves the
  fixture alone.
- `touch_reference` — active: put the tool on a reference point and
  measure where it really went. The controller's believed TCP against
  the measured one: a tool-offset fault, or not.
- `check_tracking` — active: command a small joint move, let it settle,
  measure the error. Servos that are not doing what they are told.

Every probe costs one budget unit, the same as a repair attempt. The
dossier is explicit that diagnostic actions are charged against the
hardware budget; a probe that is free would always be worth taking.

The choice of probe is a HAND-WRITTEN RULE — "when bias and stale pose
are the live hypotheses, nudge; when the estimate tracked, check a
fixture; when the jaws closed on nothing, touch off the tool; when the
arm fell short, check tracking" — and is labelled as such wherever it is
scored. It is not an expected-information policy and not learned. The
random-probe baseline fires on the same trigger and picks blindly, so the
rule's value over picking blindly is measured rather than assumed.
"""

from __future__ import annotations

import random
from contextlib import suppress
from dataclasses import dataclass

from botcortex.research import perception as perceptionlib

#: How far the estimate must move to count as having tracked the nudge.
TRACK_THRESHOLD_M = 0.010
NUDGE_M = (0.02, 0.0, 0.0)
#: A fixture reported further than this from where it is: the frame is off.
FIXTURE_THRESHOLD_M = 0.010
#: Believed and measured tool centre apart by more than this: the TCP is off.
TCP_THRESHOLD_M = 0.008
#: The step-response probe: how much of an 8 degree step a healthy servo
#: closes in 150 ms (measured 0.80-1.03 across the catalog) against a weak
#: one (0.31-0.54 at a third of the gain or less). The threshold sits between.
TRACKING_STEP_DEG = 8.0
TRACKING_WINDOW_S = 0.15
TRACKING_STEP_FRACTION = 0.65


@dataclass(frozen=True)
class Probe:
    name: str
    cost: float = 1.0
    active: bool = False


#: Default cost: a probe is charged like a full task attempt. On hardware a
#: re-observation takes seconds and a task attempt takes a minute plus a
#: reset, so the evaluation also reports a cheaper setting — the number
#: that decides whether a probe is worth taking is this ratio.
CATALOG = (
    Probe("reobserve", cost=1.0, active=False),
    Probe("nudge", cost=1.0, active=True),
    Probe("check_fixture", cost=1.0, active=False),
    Probe("touch_reference", cost=1.0, active=True),
    Probe("check_tracking", cost=1.0, active=True),
)
BY_NAME = {p.name: p for p in CATALOG}


def _distance(a, b) -> float:
    return sum((x - y) ** 2 for x, y in zip(a, b, strict=True)) ** 0.5


def run_probe(
    probe: Probe,
    robot,
    perception: perceptionlib.Perception,
    target: str,
    fixture: str = "tray_right",
) -> bool | None:
    """Execute one probe after a failed attempt, on the same world and the
    same (possibly faulty) perception. Returns the measurement, or None
    when what the probe needs cannot be observed at all."""
    if probe.name in ("reobserve", "nudge"):
        before = perception()
        seen_before = before["objects"].get(target)
        if seen_before is None:
            return None
        if probe.active:
            perceptionlib._nudge(robot, target, NUDGE_M)
            robot.settle(0.2)
        after = perception()
        seen_after = after["objects"].get(target)
        if seen_after is None:
            return None
        moved = _distance(seen_before["position"], seen_after["position"])
        return moved > TRACK_THRESHOLD_M
    if probe.name == "check_fixture":
        seen = perception()["fixtures"].get(fixture)
        true = robot.describe_scene()["fixtures"].get(fixture)
        if seen is None or true is None:
            return None
        return _distance(seen["position"], true["position"]) > FIXTURE_THRESHOLD_M
    if probe.name == "touch_reference":
        # The believed grasp centre against the measured one — on hardware a
        # touch-off against a reference; here the calibration error the
        # controller is carrying, which is exactly what a touch-off measures.
        error = getattr(robot, "tcp_error", (0.0, 0.0, 0.0))
        return _distance(error, (0.0, 0.0, 0.0)) > TCP_THRESHOLD_M
    if probe.name == "check_tracking":
        # Step response: hand a gravity-loaded joint a target a few degrees
        # away, straight to the servo (no interpolation), and read how much
        # of the step it closed in a fixed short time. Healthy gains close
        # most of it; weak ones a third. Measured inside a rehearsal, so the
        # world is left as it was. On hardware: the servo feedback (the
        # RoArm's T=105 report) a beat after a small command.
        arm = robot.platform.arms[0]
        joints = robot.platform.ik_joints
        joint = joints[1] if len(joints) > 1 else joints[0]
        lo, hi = robot.platform.joint_limits[arm][joint]
        with robot.rehearsal():
            # From a FREE pose. Measured on the Panda and the xArm7: a failed
            # attempt leaves the arm wedged against the workcell, and a step
            # commanded there is blocked by the contact, not by the servos —
            # the probe read "weak gains" on every collision. Retreat home
            # first (rehearsed, so nothing really moves); an arm that cannot
            # get home cleanly gives no measurement rather than a wrong one.
            if not _free_pose(robot, arm):
                return None
            start = robot.get_positions(arm)[joint]
            step = TRACKING_STEP_DEG if start + TRACKING_STEP_DEG < hi - 5 else -TRACKING_STEP_DEG
            if not (lo + 5 <= start + step <= hi - 5):
                return None
            robot._write_target(arm, joint, start + step)
            robot.settle(TRACKING_WINDOW_S)
            closed = (robot.get_positions(arm)[joint] - start) / step
        return closed < TRACKING_STEP_FRACTION
    raise ValueError(f"unknown probe {probe.name!r}")


def _free_pose(robot, arm: str) -> bool:
    """Get the arm clear of whatever it is touching, inside the caller's
    rehearsal. Home first; failing that (an arm still holding a block cannot
    retreat without the guard calling it a lost grasp), straight up 8 cm.
    False when neither works: no free pose, no measurement."""
    for clear in (lambda: robot.park(arm), lambda: _lift(robot, arm)):
        # A Collision or a refusal from one way out means trying the next.
        with suppress(Exception):
            clear()
            return True
    return False


def _lift(robot, arm: str) -> None:
    tip, _ = robot.tip(arm)
    robot.move_to_point(arm, (tip[0], tip[1], tip[2] + 0.08), may_move=())


def ambiguous(signature: dict) -> bool:
    """The live hypotheses are bias and stale pose: a completed run, the
    target still where it started by the program's own account, and an
    estimate the verifier disagrees with."""
    return (
        signature.get("outcome") == "completed"
        and signature.get("perception_disagreement") is True
        and not signature.get("target_moved")
    )


def closed_on_nothing(signature: dict) -> bool:
    """A completed run, nothing moved, and the estimates agree with the
    verifier: the jaws closed beside the block. Skipped open, or a tool
    offset — the trace cannot say which."""
    return (
        signature.get("outcome") == "completed"
        and not signature.get("target_moved")
        and not signature.get("others_moved")
        and signature.get("perception_disagreement") is False
    )


def fell_short(signature: dict) -> bool:
    """The arm could not get where it was sent, or the object landed short
    of the goal without any estimate being wrong: servos, or the program."""
    return signature.get("error_class") in ("unreachable", "collision") or (
        signature.get("outcome") == "completed"
        and signature.get("target_landed") in ("short of goal", "held above goal")
        and signature.get("perception_disagreement") is not True
    )


def probe_wanted(signature: dict, done: dict[str, bool | None]) -> list[str]:
    """Which probes the evidence cannot decide without, in the order the
    hand-written rule would take them. The trigger for BOTH probing
    policies; only the choice differs."""
    wanted: list[str] = []
    if ambiguous(signature):
        if "nudge" not in done:
            wanted.append("nudge")
        # The estimate tracked the nudge: a biased estimator, or the whole
        # frame. A fixture whose true pose is known separates those.
        elif done.get("nudge") is True and "check_fixture" not in done:
            wanted.append("check_fixture")
    if closed_on_nothing(signature) and "touch_reference" not in done:
        wanted.append("touch_reference")
    if fell_short(signature) and "check_tracking" not in done:
        wanted.append("check_tracking")
    return wanted


def choose_probe_by_rule(signature: dict, done: dict[str, bool | None]) -> str | None:
    wanted = probe_wanted(signature, done)
    return wanted[0] if wanted else None


def choose_probe_at_random(
    signature: dict, done: dict[str, bool | None], rng: random.Random
) -> str | None:
    """The same trigger as the rule, a blind pick among every probe not yet
    taken — so the rule's value over guessing is measured, not assumed."""
    if not probe_wanted(signature, done):
        return None
    left = [p.name for p in CATALOG if p.name not in done]
    return rng.choice(left) if left else None
