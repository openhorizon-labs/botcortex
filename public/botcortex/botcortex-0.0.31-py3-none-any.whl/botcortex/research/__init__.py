"""The research harness: what the dossier calls the thin slice.

Product code lives one level up and does not import from here. This package
adds what a transfer-failure study needs on top of the runtime:

- `contracts`   task contracts and the INDEPENDENT verifier, which reads the
                world directly and never the agent's or the controller's view.
- `perception`  the controller's observation layer, where perception faults
                are injected — so a corrupted estimate reaches the program
                and never the verifier.
- `faults`      the controlled fault catalog: program faults as source
                transforms, perception faults as observation transforms, each
                with a sealed label the selector never sees.
- `evidence`    the replayable episode packet, and `run_trial`, which puts
                the pieces together for one attempt.
"""
