"""The benchmark's task registry: what a body is asked to do, and where
everything starts.

A task is a family name, a portable program, a contract built from the
body's own workcell, a starting LAYOUT of the objects, and the object the
task is about. Layouts are expressed against the workcell — "the bystander
goes on the straight line from the block to the tray" — so the same task
means the same thing on a bench that is 30 cm deep and one that is 80.

A task is bindable on a body when the descriptor says so (Platform.binding)
AND the workcell has the fixtures it needs. Whether the body can actually
DO it is measured, not declared: the evaluation runs the clean program
first and reports a body that fails it as coverage, never as a fault case.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field

from botcortex.platform import Platform
from botcortex.research import contracts, programs
from botcortex.research import faults as faultlib

BLOCK, OTHER, THIRD = "red_block", "blue_block", "green_block"
TRAY, TABLE, SLOT = "tray_right", "table", "slot"

Scene = dict[str, dict]


@dataclass(frozen=True)
class Task:
    family: str
    #: Fixtures the workcell must have for the task to bind at all.
    needs: tuple[str, ...]
    #: Where the objects start, from the workcell's own geometry.
    layout: Callable[[Scene], dict[str, list[float]]]
    #: The contract, from the workcell's own geometry (after layout).
    contract: Callable[[Scene], contracts.TaskContract]
    target: str = BLOCK
    params: dict = field(default_factory=dict)

    @property
    def source(self) -> str:
        return programs.source(self.family)

    def faults(self) -> tuple[faultlib.Fault, ...]:
        return faultlib.catalog(self.family, self.target, OTHER)

    def bindable(self, platform: Platform, scene: Scene) -> tuple[bool, str]:
        binding = platform.binding(self.family)
        if not binding.bindable:
            return False, binding.reason
        missing = [f for f in self.needs if f not in scene["fixtures"]]
        if missing:
            return False, f"workcell has no {', '.join(missing)}"
        return True, binding.reason


def _midpoint(scene: Scene, a: str, b_fixture: str) -> list[float]:
    p, q = scene["objects"][a]["position"], scene["fixtures"][b_fixture]["position"]
    return [(p[0] + q[0]) / 2, (p[1] + q[1]) / 2, p[2]]


def _push_goal(scene: Scene, dx: float, dy: float) -> tuple[float, float]:
    here = scene["objects"][BLOCK]["position"]
    return (here[0] + dx, here[1] + dy)


PUSH = {"dx": 0.0, "dy": -0.06}

TASKS: tuple[Task, ...] = (
    Task(
        "pick_and_place",
        needs=(TRAY,),
        layout=lambda scene: {},
        contract=lambda scene: contracts.pick_and_place(BLOCK, TRAY, (OTHER, THIRD)),
    ),
    Task(
        "transport_around_bystanders",
        needs=(TRAY,),
        # The bystander stands halfway along the carry, on the line the
        # block travels. A carry at lift height clears it; one at 2 cm
        # sweeps it off the bench.
        layout=lambda scene: {OTHER: _midpoint(scene, BLOCK, TRAY)},
        contract=lambda scene: contracts.transport(BLOCK, TRAY, (OTHER, THIRD)),
    ),
    Task(
        "push",
        needs=(TABLE,),
        layout=lambda scene: {},
        contract=lambda scene: contracts.push(
            BLOCK, _push_goal(scene, PUSH["dx"], PUSH["dy"]), TABLE, (OTHER, THIRD)
        ),
        params=dict(PUSH),
    ),
    Task(
        "insertion",
        needs=(SLOT,),
        layout=lambda scene: {},
        contract=lambda scene: contracts.insertion(BLOCK, SLOT, (OTHER, THIRD)),
    ),
)
BY_FAMILY = {t.family: t for t in TASKS}


def task(family: str) -> Task:
    try:
        return BY_FAMILY[family]
    except KeyError as e:
        raise ValueError(f"unknown task family {family!r}; one of {list(BY_FAMILY)}") from e
