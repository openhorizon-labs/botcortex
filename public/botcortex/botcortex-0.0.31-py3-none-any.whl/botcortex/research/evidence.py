"""The replayable evidence packet, and one trial end to end.

An `Episode` is what a selector is allowed to see about an attempt: which
body, which program (by hash and by source), what the program observed,
what it did step by step, how it ended, and the verifier's verdict — with
the verdict produced independently of anything the program or an agent
said. What it must NOT contain is the injected fault: that lives in the
`SealedLabel` returned beside it, for the evaluation runner only.

`run_trial` is deliberately small. It is the loop every later experiment
arm repeats: bind the task on a body, inject at most one fault, run, verify
from truth, pack the evidence. Memory, repair, and selection come after it
in the slice and consume its output.
"""

from __future__ import annotations

import hashlib
import json
import re
from dataclasses import asdict, dataclass, field
from datetime import UTC, datetime
from pathlib import Path

from botcortex import safety
from botcortex import scene as scenelib
from botcortex.platform import Platform
from botcortex.research import faults as faultlib
from botcortex.research import repairs as repairlib
from botcortex.research import world as worldlib
from botcortex.research.contracts import TaskContract, Truth, Verdict
from botcortex.research.perception import Perception
from botcortex.skills import SkillContext, SkillStore


def sha(text: str) -> str:
    return hashlib.sha256(text.encode()).hexdigest()[:16]


def capability_hash(platform: Platform) -> str:
    """Identity of the body as the research sees it: the descriptor's
    capabilities, limits and task matrix. Two robots with the same hash are
    the same embodiment for retrieval purposes."""
    payload = {
        "name": platform.name,
        "arms": platform.arms,
        "joint_limits": platform.joint_limits,
        "capabilities": platform.capabilities,
        "tasks": platform.tasks,
    }
    return sha(json.dumps(payload, sort_keys=True, default=list))


@dataclass
class Episode:
    """One attempt, as evidence. No fault label anywhere in here."""

    ts: str
    platform: str
    capability_hash: str
    task: str
    #: The object the task is about (TaskContract.target) and the task
    #: family — what a probe nudges and what the signature reports on.
    target: str
    family: str
    skill_name: str
    skill_hash: str
    skill_source: str
    outcome: str  # "completed" | "error"
    error: str | None
    steps: list[str]
    observed_before: dict
    observed_after: dict | None
    verdict: dict
    #: Objects in the jaws when the attempt ended, per arm, measured from
    #: contact (safety.gripped_objects) — on hardware, gripper position and
    #: force plus a look at the hand. The one fact that separates "I hit
    #: something carrying low" from "I hit something carrying the wrong
    #: block": the trace and the verdict read the same for both.
    held_at_stop: dict[str, list[str]] = field(default_factory=dict)
    notes: dict = field(default_factory=dict)

    def to_json(self) -> str:
        return json.dumps(asdict(self), sort_keys=True)


@dataclass
class Trial:
    episode: Episode
    label: faultlib.SealedLabel
    verdict: Verdict
    #: The simulator and observation layer the attempt ran on, so a probe can
    #: be taken afterwards on the same world. Never serialised.
    robot: object = field(default=None, repr=False, compare=False)
    perception: object = field(default=None, repr=False, compare=False)


def prepare(
    skill_source: str, fault: faultlib.Fault | None, repair: repairlib.Repair | None
) -> tuple[str, tuple, tuple]:
    """The program text, observation transforms and robot patches a trial
    would run with.

    Exposed so the outcome cache can recognise two trials that would run
    byte-identical programs through identical pipelines on identical
    robots — a program repair applied to a perception fault, say — and
    record the second as the first's outcome instead of simulating it
    again. The simulation is deterministic, so that is the same
    measurement, not an approximation.
    """
    source = skill_source
    transforms: tuple = ()
    patches: tuple = ()
    if fault is not None:
        where = faultlib.carrier(fault)
        if where == "program":
            source = faultlib.apply_program_fault(source, fault)
        elif where == "perception":
            transforms = (faultlib.perception_transform(fault),)
        else:
            patches = (faultlib.world_patch(fault),)
    if repair is not None:
        source = repairlib.apply_to_source(source, repair)
        transforms = repairlib.apply_to_perception(transforms, repair)
        patches = repairlib.apply_to_world(patches, repair)
    return source, transforms, patches


def trial_identity(skill_source: str, fault, repair, layout: dict | None = None) -> str:
    source, transforms, patches = prepare(skill_source, fault, repair)
    return sha(
        source
        + "|"
        + repr(transforms)
        + "|"
        + repr(patches)
        + "|"
        + repr(sorted((layout or {}).items()))
    )


def place(robot, layout: dict[str, list[float]]) -> None:
    """Move objects to a task's starting layout before the trial: a
    bystander onto the carry path, say. Poses are [x, y, z] or the full
    7-float free-joint pose; the rest of the pose is kept."""
    if not layout:
        return
    poses = scenelib.object_poses(robot.data.qpos, robot._object_addr)
    for name, pose in layout.items():
        if name not in poses:
            raise ValueError(f"layout names {name!r}, which is not an object on this workcell")
        pose = list(pose)
        poses[name] = pose + poses[name][3:] if len(pose) == 3 else pose
    scenelib.place_objects(robot.data.qpos, robot._object_addr, poses)
    for i in range(len(robot.data.qvel)):
        robot.data.qvel[i] = 0.0
    robot._mujoco.mj_forward(robot.model, robot.data)
    robot.settle(0.3)


def run_trial(
    robot,
    skill_source: str,
    contract: TaskContract,
    fault: faultlib.Fault | None,
    workdir: Path,
    *,
    repair: repairlib.Repair | None = None,
    skill_name: str | None = None,
    settle: float = 1.0,
    layout: dict[str, list[float]] | None = None,
) -> Trial:
    """One attempt on one body with at most one injected fault, and at most
    one repair applied on top of it.

    The program sees the world through `Perception`; the verifier reads
    `Truth`. The two share a simulator and nothing else. A repair edits the
    faulty program (program repairs) or the observation pipeline
    (perception repairs) before the attempt; a repair that does not apply
    changes nothing, and the attempt is still spent.
    """
    platform: Platform = robot.platform
    truth = Truth(robot)
    source, transforms, patches = prepare(skill_source, fault, repair)
    place(robot, layout or {})
    worldlib.apply(robot, patches)

    # The store insists META["name"] matches the file name, so the trial is
    # saved under the program's own name unless told otherwise.
    if skill_name is None:
        match = re.search(r'"name":\s*"([a-z][a-z0-9_]*)"', source)
        skill_name = match.group(1) if match else "trial_skill"
    store = SkillStore(workdir / "skills")
    store.save(skill_name, source)
    perception = Perception(robot.describe_scene, transforms, world=robot)
    steps: list[str] = []
    ctx = SkillContext(robot, on_step=steps.append, perception=perception)

    before_truth = truth.snapshot()
    observed_before = perception()
    outcome, error = "completed", None
    try:
        store.run(skill_name, ctx)
    except Exception as e:  # noqa: BLE001 - the failure IS the data; nothing is rethrown
        outcome, error = "error", f"{type(e).__name__}: {e}"
    # Read BEFORE settling: what the jaws hold at the instant the attempt
    # ends is the evidence; a block that slips out during the settle was
    # still in the hand when the arm stopped.
    held_at_stop = {arm: sorted(safety.gripped_objects(robot, arm)) for arm in platform.arms}
    truth.settle(settle)
    after_truth = truth.snapshot()
    observed_after = perception() if outcome == "completed" else None

    verdict = contract.verify(before_truth, after_truth)
    episode = Episode(
        ts=datetime.now(UTC).isoformat(timespec="seconds"),
        platform=platform.name,
        capability_hash=capability_hash(platform),
        task=contract.task,
        target=contract.target,
        family=contract.family,
        skill_name=skill_name,
        skill_hash=sha(source),
        skill_source=source,
        outcome=outcome,
        error=error,
        steps=steps,
        observed_before=observed_before,
        observed_after=observed_after,
        verdict={
            "status": verdict.status,
            "violations": list(verdict.violations),
            "evidence": verdict.evidence,
        },
        held_at_stop=held_at_stop,
    )
    took_effect = None if fault is None else (verdict.ok is not True)
    label = faultlib.SealedLabel(
        fault=fault,
        took_effect=took_effect,
        note=""
        if fault is None
        else (
            f"expected `{fault.expected}`; got {verdict.status}: {'; '.join(verdict.violations) or '-'}"
        ),
    )
    return Trial(episode=episode, label=label, verdict=verdict, robot=robot, perception=perception)
