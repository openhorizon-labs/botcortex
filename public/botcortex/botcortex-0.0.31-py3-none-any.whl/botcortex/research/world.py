"""Faults that live in the ROBOT, not in its program or its perception.

Two more of the dossier's fault groups, each a bounded change to the
simulated body that the program and the verifier are both blind to:

- FRAME / TCP: the controller's calibration of where its jaws close is off
  by a known offset. `SimRobot.tip` reports the believed grasp centre; the
  jaws stay where physics puts them, so every reach lands the real jaws
  beside the target by exactly the offset. The verifier reads the objects,
  never the belief.

- TRACKING: the servos are weaker than the controller assumes — position
  gains scaled down — so the arm sags and arrives short of where it was
  sent. Injected into the model's actuator gains; whether it actually bit
  on a body is measured by the verifier like every other fault.

A patch is applied to a fresh robot before the trial and never reverted;
the trial owns its simulator. Repairs of these families remove the patch
(recalibrate the tool, re-identify the gains) — on hardware, the bounded
interventions those names describe.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class TcpOffset:
    """Believed TCP shifted by `delta` metres in the hand frame."""

    delta: tuple[float, float, float]

    def apply(self, robot) -> None:
        robot.tcp_error = tuple(float(v) for v in self.delta)


@dataclass(frozen=True)
class GainScale:
    """Every positioning servo's kp scaled by `factor` (the gripper's is
    left alone: a weak arm is the fault, not a weak grip)."""

    factor: float

    def apply(self, robot) -> None:
        # JointMap.ctrl_id holds the positioning actuators only; the gripper
        # drives through finger_ctrl and is untouched.
        for arm in robot.platform.arms:
            for index in robot.joints.ctrl_id[arm].values():
                _scale(robot.model, index, self.factor)


def _scale(model, actuator: int, factor: float) -> None:
    # A MuJoCo position servo: force = kp * (ctrl - q) - kv * qdot, stored as
    # gainprm[0] = kp, biasprm[1] = -kp, biasprm[2] = -kv. Scale kp on both
    # sides so the servo stays a position servo, only a weaker one.
    model.actuator_gainprm[actuator, 0] *= factor
    model.actuator_biasprm[actuator, 1] *= factor


Patch = TcpOffset | GainScale


def apply(robot, patches: tuple[Patch, ...]) -> None:
    for patch in patches:
        patch.apply(robot)
