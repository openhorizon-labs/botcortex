"""Task contracts, and the verifier that grades them from the world itself.

The runtime already has a gate on saying "done" (RobotSession.unverified):
an unrun skill, a refused run, a detected ejection or a latched stop can
never be reported as success. By its own docstring that gate is about
EVIDENCE, not the task — a completed run plus report(done=True) does not
establish that the requested object relation was achieved. This module is
the other half: a contract says what should be true of the objects when the
task is done, and a verifier checks it against a truth source the program
never touches.

Independence is the whole point. The verifier reads through `Truth`, a
handle on the simulator's own state; the program reads through a
`Perception` layer that the fault harness may corrupt. If both read the
same corrupted estimates, a perception fault would be graded by the very
numbers it corrupted, and "success" would mean nothing. On hardware the same
split holds with a fixture or a second measurement — see the dossier's
verifier section.

Verdicts are three-valued. `ok` is True, False, or None for "could not
observe" — a predicate about an object the truth source cannot see is not
false, it is unknown, and the two are kept apart because a selector that
treats unknown as failure learns the wrong lesson.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from botcortex import scene


@dataclass(frozen=True)
class Verdict:
    """What the verifier concluded, and from what.

    `ok`: True passed, False failed, None unobservable.
    `violations`: one line per failed predicate, in words a person can act on.
    `evidence`: the measurements the conclusion rests on, so a disputed
    verdict can be re-read without re-running anything.
    """

    ok: bool | None
    violations: tuple[str, ...] = ()
    evidence: dict = field(default_factory=dict)

    @property
    def status(self) -> str:
        return {True: "ok", False: "fail", None: "unknown"}[self.ok]


class Truth:
    """A read-only handle on the world as it is — the simulator's state.

    Bypasses everything the program sees through: no perception layer, no
    agent narration, no skill context. In simulation this is exact; the
    hardware equivalent is an independent measurement (fixture, fiducial,
    adjudicated video), and it is a different class.
    """

    def __init__(self, robot):
        self._robot = robot

    def snapshot(self) -> dict[str, dict]:
        r = self._robot
        return scene.describe(r._mujoco, r.model, r.data, r._robot_bodies)

    def settle(self, seconds: float = 0.5) -> None:
        """Let physics come to rest before reading — a block still falling
        into a tray is neither in it nor out of it."""
        self._robot.settle(seconds)


def _distance(a, b) -> float:
    return sum((x - y) ** 2 for x, y in zip(a, b, strict=True)) ** 0.5


# --- predicates ---------------------------------------------------------------
#
# Each takes the before and after snapshots and returns None (holds), a
# string (violated, and why), or Unobservable. They are deliberately small:
# the contract composes them, and a new task family adds a predicate, not a
# verifier.


class Unobservable(Exception):
    """The predicate's subject is not in the truth snapshot."""


def _body(snapshot: dict, kind: str, name: str) -> dict:
    try:
        return snapshot[kind][name]
    except KeyError as e:
        raise Unobservable(f"{name} is not visible to the verifier") from e


#: An object resting on a surface sits half its height above it, give or
#: take settling. Anything much higher inside the footprint is being HELD
#: over the fixture — and a block still in the jaws is not placed. The fault
#: sweep found exactly that: a refused descent left the block in the gripper
#: above the tray and the footprint-only check graded it as success.
_RESTING_TOLERANCE = 0.02


def inside(obj: str, fixture: str, resting_tolerance: float = _RESTING_TOLERANCE):
    """`obj` rests in or on `fixture` — the smallest containing footprint,
    and at resting height, not hovering in the gripper above it.

    `resting_tolerance` is how far above the floor the object may sit and
    still count as resting. A tray forgives settling; a pocket barely wider
    than the block must not forgive a block perched on its wall, so the
    insertion contract passes a tighter one."""

    def check(before: dict, after: dict) -> str | None:
        body = _body(after, "objects", obj)
        target = _body(after, "fixtures", fixture)
        holder = scene.resting_in(body["position"], after["fixtures"])
        where = [round(v, 3) for v in body["position"]]
        if holder != fixture:
            place = f"on {holder}" if holder else "off every fixture"
            return f"{obj} is {place}, not in {fixture} (at {where})"
        floor = target["position"][2] + target["size_m"][2] / 2
        resting = floor + body["size_m"][2] / 2
        if body["position"][2] > resting + resting_tolerance:
            height = (body["position"][2] - resting) * 1000
            return f"{obj} is held {height:.0f} mm above {fixture}, not resting in it (at {where})"
        return None

    check.__name__ = f"inside({obj}, {fixture})"
    return check


def near(obj: str, point, tolerance: float = 0.025):
    """`obj` ends within `tolerance` of `point` in the plane of the table —
    the goal of a push, which moves an object without ever holding it."""
    goal = (float(point[0]), float(point[1]))

    def check(before: dict, after: dict) -> str | None:
        body = _body(after, "objects", obj)
        miss = _distance(body["position"][:2], goal)
        if miss > tolerance:
            where = [round(v, 3) for v in body["position"]]
            return (
                f"{obj} is {miss * 1000:.0f} mm from its goal, more than "
                f"{tolerance * 1000:.0f} mm (at {where}, goal {[round(g, 3) for g in goal]})"
            )
        return None

    check.__name__ = f"near({obj})"
    return check


def on_fixture(obj: str, fixture: str):
    """`obj` is still sitting on `fixture` — a pushed block that left the
    table, or ended in the tray it was never meant for, fails here."""

    def check(before: dict, after: dict) -> str | None:
        body = _body(after, "objects", obj)
        holder = scene.resting_in(body["position"], after["fixtures"])
        if holder != fixture:
            place = f"on {holder}" if holder else "off every fixture"
            return f"{obj} is {place}, not on {fixture}"
        return None

    check.__name__ = f"on_fixture({obj}, {fixture})"
    return check


def beside(a: str, b: str, max_gap: float = 0.02, same_surface: bool = True):
    """`a` ends within `max_gap` of touching `b`, and on the same fixture."""

    def check(before: dict, after: dict) -> str | None:
        pa, pb = _body(after, "objects", a), _body(after, "objects", b)
        gap = (
            _distance(pa["position"][:2], pb["position"][:2])
            - (pa["size_m"][0] + pb["size_m"][0]) / 2
        )
        if gap > max_gap:
            return f"{a} is {gap * 1000:.0f} mm from {b}, more than {max_gap * 1000:.0f} mm"
        if same_surface:
            ha = scene.resting_in(pa["position"], after["fixtures"])
            hb = scene.resting_in(pb["position"], after["fixtures"])
            if ha != hb:
                return f"{a} rests on {ha} while {b} rests on {hb}"
        return None

    check.__name__ = f"beside({a}, {b})"
    return check


def untouched(objects: tuple[str, ...], tolerance: float = 0.015):
    """Bystanders stayed where they were, within settling tolerance."""

    def check(before: dict, after: dict) -> str | None:
        moved = []
        for name in objects:
            start = _body(before, "objects", name)["position"]
            end = _body(after, "objects", name)["position"]
            shift = _distance(start, end)
            if shift > tolerance:
                moved.append(f"{name} moved {shift * 1000:.0f} mm")
        return "; ".join(moved) or None

    check.__name__ = f"untouched{objects}"
    return check


# --- the contract ---------------------------------------------------------


@dataclass(frozen=True)
class TaskContract:
    """What must be true of the objects when the task is done.

    `goal` predicates must all hold; `invariants` are the bystander and
    surface conditions that must hold as well. The split matters for the
    research: a goal failure and an invariant failure are different failure
    classes with different likely repairs.

    `target` names the object the task is about — what a probe nudges and
    what the signature reports the landing of. `family` is the benchmark
    task family the contract belongs to.
    """

    task: str
    goal: tuple
    invariants: tuple = ()
    target: str = ""
    family: str = ""

    def verify(self, before: dict, after: dict) -> Verdict:
        violations: list[str] = []
        unknown: list[str] = []
        for group, predicates in (("goal", self.goal), ("invariant", self.invariants)):
            for predicate in predicates:
                try:
                    problem = predicate(before, after)
                except Unobservable as e:
                    unknown.append(f"{group} {predicate.__name__}: {e}")
                    continue
                if problem:
                    violations.append(f"{group} {predicate.__name__}: {problem}")
        evidence = {
            "objects_after": {
                name: [round(v, 4) for v in body["position"]]
                for name, body in after.get("objects", {}).items()
            },
            "unobservable": unknown,
        }
        if violations:
            return Verdict(False, tuple(violations), evidence)
        if unknown:
            return Verdict(None, tuple(unknown), evidence)
        return Verdict(True, (), evidence)


def pick_and_place(block: str, tray: str, bystanders: tuple[str, ...]) -> TaskContract:
    return TaskContract(
        task=f"put {block} in {tray}",
        goal=(inside(block, tray),),
        invariants=(untouched(bystanders),),
        target=block,
        family="pick_and_place",
    )


def transport(block: str, tray: str, bystanders: tuple[str, ...]) -> TaskContract:
    """Pick-and-place with a bystander in the way: the same goal, and the
    invariant is the point."""
    return TaskContract(
        task=f"carry {block} to {tray} past {', '.join(bystanders)}",
        goal=(inside(block, tray),),
        invariants=(untouched(bystanders),),
        target=block,
        family="transport_around_bystanders",
    )


def push(
    block: str, goal_xy, table: str, bystanders: tuple[str, ...], tolerance: float = 0.025
) -> TaskContract:
    """Slide `block` to `goal_xy` along the table without holding it."""
    return TaskContract(
        task=f"push {block} to {[round(float(v), 3) for v in goal_xy]}",
        goal=(near(block, goal_xy, tolerance), on_fixture(block, table)),
        invariants=(untouched(bystanders),),
        target=block,
        family="push",
    )


#: A pocket wall is 10 mm high; a block perched on it sits that much
#: higher than one resting on the floor, and must not pass.
_POCKET_TOLERANCE = 0.005


def insertion(block: str, slot: str, bystanders: tuple[str, ...]) -> TaskContract:
    return TaskContract(
        task=f"put {block} in {slot}",
        goal=(inside(block, slot, resting_tolerance=_POCKET_TOLERANCE),),
        invariants=(untouched(bystanders),),
        target=block,
        family="insertion",
    )


def place_beside(mover: str, anchor: str, bystanders: tuple[str, ...]) -> TaskContract:
    return TaskContract(
        task=f"put {mover} beside {anchor}",
        goal=(beside(mover, anchor),),
        invariants=(untouched((anchor, *bystanders)),),
        target=mover,
    )
