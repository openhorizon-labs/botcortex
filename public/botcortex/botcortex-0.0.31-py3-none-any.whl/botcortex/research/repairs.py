"""Repair operators: bounded, versioned, costed interventions.

The selector chooses one of these from evidence. Each is the honest inverse
of one entry in the fault catalog — a program edit that restores the drop
height, a perception fix that re-identifies objects — which makes the first
benchmark an eight-way diagnosis: the right repair recovers in one attempt,
a wrong one costs an attempt and recovers nothing. That is deliberately
simple. The research question is not whether these repairs work (they do,
by construction) but whether a body's failure evidence tells you WHICH one
to apply, and whether that knowledge travels to a body you have not seen.

Program repairs are source transforms on the failing program. Perception
repairs act on the observation pipeline: on hardware, recalibrating,
refreshing a tracker, re-identifying by appearance, or moving the camera;
in the simulated benchmark, removing the matching fault transform from the
Perception layer. A perception repair applied when the pipeline is fine
changes nothing — the attempt is spent and the failure stays.

Every repair has a cost in attempts (all 1 here) and a family, so the
evaluation can report wrong-family choices separately from wrong repairs.
"""

from __future__ import annotations

import re
from dataclasses import dataclass

from botcortex.research import perception, world
from botcortex.research.faults import FaultError


@dataclass(frozen=True)
class Repair:
    family: str  # "program" | "perception" | "frame" | "tracking"
    kind: str
    cost_attempts: int = 1

    @property
    def name(self) -> str:
        return f"{self.family}:{self.kind}"


def _sub(source: str, pattern: str, replacement: str, what: str) -> str:
    new, n = re.subn(pattern, replacement, source, count=1, flags=re.MULTILINE)
    if n == 0:
        raise FaultError(f"cannot apply {what}: the program has no `{pattern}`")
    return new


# --- program repairs ------------------------------------------------------------


def raise_drop(source: str) -> str:
    return _sub(source, r"^(\s*)drop = -?[0-9.]+", r"\g<1>drop = 0.06", "raise_drop")


def raise_lift(source: str) -> str:
    return _sub(source, r"^(\s*)lift = -?[0-9.]+", r"\g<1>lift = 0.12", "raise_lift")


def open_before_descent(source: str) -> str:
    """Insert an explicit open before the first descent unless one is already
    there. Idempotent: applying it to a correct program changes nothing."""
    pattern = r"^([ \t]*)ctx\.move_to_point\(arm, \[here\[0\], here\[1\], here\[2\] \+ lift\]\)"
    match = re.search(pattern, source, flags=re.MULTILINE)
    if match is None:
        raise FaultError("cannot apply open_before_descent: no descent to precede")
    preceding = (
        source[: match.start()].rstrip().splitlines()[-1] if source[: match.start()].strip() else ""
    )
    if "ctx.gripper(arm, open_deg)" in preceding:
        return source
    indent = match.group(1)
    return (
        source[: match.start()] + f"{indent}ctx.gripper(arm, open_deg)\n" + source[match.start() :]
    )


def lower_press(source: str) -> str:
    return _sub(source, r"^(\s*)press = -?[0-9.]+", r"\g<1>press = 0.0", "lower_press")


def retarget_named_object(source: str) -> str:
    return _sub(
        source,
        r'^(\s*)here = scene\["objects"\]\["[a-z_]+"\]\["position"\]',
        r'\g<1>here = scene["objects"][block]["position"]',
        "retarget_named_object",
    )


PROGRAM_REPAIRS = {
    "raise_drop": raise_drop,
    "raise_lift": raise_lift,
    "lower_press": lower_press,
    "open_before_descent": open_before_descent,
    "retarget_named_object": retarget_named_object,
}

# --- perception repairs: which fault transform each one clears --------------------

PERCEPTION_REPAIRS = {
    "recalibrate": perception.PoseBias,
    "refresh_tracking": perception.StalePose,
    "reidentify": perception.IdentitySwap,
    "change_viewpoint": perception.Occlusion,
}

# --- frame and tracking repairs: which robot patch (or frame transform) each clears --

FRAME_REPAIRS = {
    # Re-measure the camera-to-base transform against a known fixture.
    "recalibrate_base": perception.FrameOffset,
    # Touch off the tool against a reference and correct the TCP.
    "recalibrate_tcp": world.TcpOffset,
}
TRACKING_REPAIRS = {
    # Re-identify the servo gains and retune the controller to them.
    "retune_gains": world.GainScale,
}


def catalog() -> tuple[Repair, ...]:
    return (
        tuple(Repair("program", k) for k in PROGRAM_REPAIRS)
        + tuple(Repair("perception", k) for k in PERCEPTION_REPAIRS)
        + tuple(Repair("frame", k) for k in FRAME_REPAIRS)
        + tuple(Repair("tracking", k) for k in TRACKING_REPAIRS)
    )


def apply_to_source(source: str, repair: Repair) -> str:
    if repair.family != "program":
        return source
    try:
        return PROGRAM_REPAIRS[repair.kind](source)
    except FaultError:
        # Nothing to edit: the repair does not apply to this program. The
        # attempt is still spent — that is what a wrong repair costs.
        return source


def apply_to_perception(transforms: tuple, repair: Repair) -> tuple:
    cleared = (
        PERCEPTION_REPAIRS.get(repair.kind)
        if repair.family == "perception"
        else (FRAME_REPAIRS.get(repair.kind) if repair.family == "frame" else None)
    )
    if cleared is None or not issubclass(
        cleared,
        perception.FrameOffset
        | perception.PoseBias
        | perception.StalePose
        | perception.IdentitySwap
        | perception.Occlusion,
    ):
        return transforms
    return tuple(t for t in transforms if not isinstance(t, cleared))


def apply_to_world(patches: tuple, repair: Repair) -> tuple:
    cleared = (
        FRAME_REPAIRS
        if repair.family == "frame"
        else TRACKING_REPAIRS
        if repair.family == "tracking"
        else {}
    ).get(repair.kind)
    if cleared is None or not issubclass(cleared, world.TcpOffset | world.GainScale):
        return patches
    return tuple(p for p in patches if not isinstance(p, cleared))
