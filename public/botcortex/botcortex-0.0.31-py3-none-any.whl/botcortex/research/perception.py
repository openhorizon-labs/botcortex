"""What the program sees — and how that can be made wrong on purpose.

`describe_scene` is privileged perception: the simulator hands the skill
the object poses. That is the product's contract with a camera and a pose
estimator on hardware, and it is exactly where perception faults happen in
the field: a biased pose, a stale one, a swapped identity, an occluded
object. So the research harness puts an observation layer between the
robot and the skill (SkillContext's `perception` hook) and corrupts it
there, while the verifier (research.contracts.Truth) keeps reading the
simulator directly.

KNOWN LIMIT: the runtime's own safety checks — transit height and the
object-motion guard inside kinematics.reach — read the robot's describe_scene,
not this layer. A perception fault therefore reaches the PROGRAM's decisions
(where it aims) and not the runtime's collision guard. On hardware the guard
would be perception-based too; that is a fidelity gap of the simulated
benchmark and is recorded as such, not hidden.
"""

from __future__ import annotations

import copy
from collections.abc import Callable
from dataclasses import dataclass

Scene = dict[str, dict]
Transform = Callable[[Scene, int], Scene]


@dataclass(frozen=True)
class PoseBias:
    """Every listed object is reported `offset` metres from where it is."""

    objects: tuple[str, ...]
    offset: tuple[float, float, float]

    def __call__(self, observed: Scene, call: int) -> Scene:
        for name in self.objects:
            body = observed["objects"].get(name)
            if body:
                body["position"] = [
                    p + d for p, d in zip(body["position"], self.offset, strict=True)
                ]
        return observed


@dataclass(frozen=True)
class StalePose:
    """The listed objects are reported where they were on the first look —
    and the world moves on after that look.

    A stale estimate is only a fault if something changed: on hardware, a
    bumped block, a tray slid over, an object placed by someone else. So on
    the first observation this fault also nudges the real object by
    `displacement` (through the Perception layer's world hook), and keeps
    reporting the pre-nudge pose forever after. The program looked, the
    world changed, the tracker did not notice.
    """

    objects: tuple[str, ...]
    displacement: tuple[float, float, float] = (0.04, 0.0, 0.0)
    needs_world = True

    def __call__(self, observed: Scene, call: int, world=None) -> Scene:
        cache = _stale_cache.setdefault(id(self), {})
        for name in self.objects:
            body = observed["objects"].get(name)
            if body is None:
                continue
            if name not in cache:
                cache[name] = list(body["position"])
                if world is not None:
                    _nudge(world, name, self.displacement)
            body["position"] = list(cache[name])
        return observed


_stale_cache: dict[int, dict[str, list[float]]] = {}


def _nudge(robot, name: str, displacement) -> None:
    """Move an object in the simulator without touching the arm."""
    from botcortex import scene  # local: the layer is otherwise physics-free

    poses = scene.object_poses(robot.data.qpos, robot._object_addr)
    pose = poses[name]
    pose[:3] = [p + d for p, d in zip(pose[:3], displacement, strict=True)]
    scene.place_objects(robot.data.qpos, robot._object_addr, {name: pose})
    robot._mujoco.mj_forward(robot.model, robot.data)


@dataclass(frozen=True)
class FrameOffset:
    """The camera-to-base transform is wrong: EVERYTHING the program sees —
    objects and fixtures alike — is reported `offset` metres from where it
    is. Unlike PoseBias, which is one estimator's error on named objects,
    this is a frame fault: the tray is as wrong as the block, and a fixture
    whose true pose is known (a fiducial on the bench) exposes it."""

    offset: tuple[float, float, float]

    def __call__(self, observed: Scene, call: int) -> Scene:
        for group in ("objects", "fixtures"):
            for body in observed.get(group, {}).values():
                body["position"] = [
                    p + d for p, d in zip(body["position"], self.offset, strict=True)
                ]
        return observed


@dataclass(frozen=True)
class IdentitySwap:
    """Two objects' names are exchanged — the estimator labelled them wrong."""

    a: str
    b: str

    def __call__(self, observed: Scene, call: int) -> Scene:
        objects = observed["objects"]
        if self.a in objects and self.b in objects:
            objects[self.a], objects[self.b] = objects[self.b], objects[self.a]
        return observed


@dataclass(frozen=True)
class Occlusion:
    """The listed objects are not reported at all."""

    objects: tuple[str, ...]

    def __call__(self, observed: Scene, call: int) -> Scene:
        for name in self.objects:
            observed["objects"].pop(name, None)
        return observed


class Perception:
    """The observation layer: truth in, what the program sees out.

    Callable, so it slots straight into SkillContext(perception=...). Keeps a
    log of every observation it handed out — the evidence packet needs what
    the program was told, not only what was true.
    """

    def __init__(self, truth: Callable[[], Scene], faults: tuple[Transform, ...] = (), world=None):
        self._truth = truth
        self.faults = tuple(faults)
        #: The simulator, for faults that must also change the world (a
        #: stale estimate of an object that has since moved). Never read
        #: by the program; only faults that declare `needs_world` get it.
        self.world = world
        self.calls = 0
        self.log: list[Scene] = []

    def __call__(self) -> Scene:
        observed = copy.deepcopy(self._truth())
        for fault in self.faults:
            if getattr(fault, "needs_world", False):
                observed = fault(observed, self.calls, self.world)
            else:
                observed = fault(observed, self.calls)
        self.calls += 1
        self.log.append(copy.deepcopy(observed))
        return observed
