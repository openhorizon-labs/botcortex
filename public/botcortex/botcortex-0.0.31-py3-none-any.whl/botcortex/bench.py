"""What is on THIS robot's bench, when it is not the stock workcell.

The platform's scene.xml is shared by every body of its kind and by the
browser sim, and it holds three 40 mm blocks and a tray. A real bench holds
whatever the owner put there — a stapler, say — and the twin has to hold the
same, or the arm plans around blocks that are not there and cannot see the
thing that is.

So a bench file, per robot and per body, under ~/.openhorizon: the objects
on the bench, each a box with a size, a colour and a resting place. When it
exists it REPLACES the scene's own objects (the furniture stays), and the
world the twin loads is written from it beside the scene, where MuJoCo can
still find the model and its meshes. Nothing here touches the shared scene
file or the browser sim.
"""

from __future__ import annotations

import hashlib
import json
import xml.etree.ElementTree as ET
from pathlib import Path


def path(data_dir: Path, platform_name: str) -> Path:
    return data_dir / f"bench_{platform_name}.json"


def load(bench_path: Path) -> dict:
    return json.loads(bench_path.read_text()) if bench_path.exists() else {"objects": []}


def save(bench_path: Path, bench: dict) -> None:
    bench_path.parent.mkdir(parents=True, exist_ok=True)
    bench_path.write_text(json.dumps(bench, indent=2) + "\n")


def add(
    bench_path: Path,
    name: str,
    size_m: tuple[float, float, float],
    rgba: list[float],
    position: tuple[float, float] | None = None,
) -> dict:
    """Put an object on the bench, replacing one of the same name."""
    if not name.replace("_", "").isalnum() or not name[0].isalpha():
        raise ValueError("an object's name is snake_case ascii, e.g. stapler or red_mug")
    if min(size_m) <= 0 or max(size_m) > 0.5:
        raise ValueError("an object is between a millimetre and half a metre on each side")
    bench = load(bench_path)
    bench["objects"] = [o for o in bench["objects"] if o["name"] != name]
    bench["objects"].append(
        {
            "name": name,
            "size_m": [round(float(v), 4) for v in size_m],
            "rgba": [round(float(v), 3) for v in rgba[:3]] + [1.0],
            "position": None if position is None else [round(float(v), 4) for v in position],
        }
    )
    save(bench_path, bench)
    return bench


def remove(bench_path: Path, name: str) -> bool:
    bench = load(bench_path)
    kept = [o for o in bench["objects"] if o["name"] != name]
    if len(kept) == len(bench["objects"]):
        return False
    bench["objects"] = kept
    save(bench_path, bench)
    return True


def world_for(platform, bench_path: Path) -> Path | None:
    """The scene to load: the platform's own when there is no bench file,
    else one written beside it with the bench's objects in place of the
    scene's. Beside it, because MuJoCo resolves `<include>` and mesh
    directories relative to the file it was asked to load."""
    bench = load(bench_path)
    scene_path = platform.world_path
    if not bench["objects"] or scene_path is None:
        return scene_path
    tree = ET.parse(scene_path)
    root = tree.getroot()
    world = root.find("worldbody")
    if world is None:
        raise ValueError(f"{scene_path} has no <worldbody> to put a bench in")
    # The scene's own objects are the bodies that move freely. The furniture
    # has no joint and stays.
    for body in [b for b in world.findall("body") if b.find("freejoint") is not None]:
        world.remove(body)
    top = _table_top(world)
    across = _table_span(world)
    for i, obj in enumerate(bench["objects"]):
        length, width, height = obj["size_m"]
        x, y = obj.get("position") or _default_spot(i, len(bench["objects"]), across)
        body = ET.SubElement(
            world, "body", name=obj["name"], pos=f"{x:.4f} {y:.4f} {top + height / 2:.4f}"
        )
        ET.SubElement(body, "freejoint", name=f"{obj['name']}_free")
        ET.SubElement(
            body,
            "geom",
            name=f"{obj['name']}_geom",
            **{"class": "payload"},
            size=f"{length / 2:.4f} {width / 2:.4f} {height / 2:.4f}",
            rgba=" ".join(f"{v:.3f}" for v in obj["rgba"]),
        )
    stamp = hashlib.sha256(json.dumps(bench, sort_keys=True).encode()).hexdigest()[:10]
    out = scene_path.with_name(f"bench_{stamp}.xml")
    if not out.exists():
        for stale in scene_path.parent.glob("bench_*.xml"):
            stale.unlink(missing_ok=True)
        tree.write(out, encoding="unicode")
    return out


def _table_top(world) -> float:
    """Where things rest: the table body's z plus its first geom's half height."""
    table = next((b for b in world.findall("body") if b.get("name") == "table"), None)
    if table is None:
        return 0.0
    z = float(table.get("pos", "0 0 0").split()[2])
    geom = table.find("geom")
    half = (
        float(geom.get("size", "0 0 0").split()[2])
        if geom is not None and geom.get("size")
        else 0.0
    )
    return z + half


def _table_span(world) -> tuple[float, float, float]:
    """(centre x, centre y, half width in y) of the table, for default spots."""
    table = next((b for b in world.findall("body") if b.get("name") == "table"), None)
    if table is None:
        return 0.3, 0.0, 0.15
    x, y, _ = (float(v) for v in table.get("pos", "0 0 0").split())
    geom = table.find("geom")
    half_y = (
        float(geom.get("size", "0 0 0").split()[1])
        if geom is not None and geom.get("size")
        else 0.15
    )
    return x, y, half_y


def _default_spot(index: int, count: int, span) -> tuple[float, float]:
    """In front of the arm, spread across the table, when nobody measured where."""
    cx, cy, half_y = span
    if count == 1:
        return cx, cy
    step = min(0.1, (2 * half_y * 0.6) / max(count - 1, 1))
    return cx, cy + (index - (count - 1) / 2) * step
