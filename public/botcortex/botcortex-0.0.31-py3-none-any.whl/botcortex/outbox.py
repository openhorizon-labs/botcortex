"""Runs on their way to the API, kept on disk until they have arrived.

The first uploader was a queue in memory: a full queue dropped the event, an
API that was down lost it, and a restart forgot everything. That is fine for a
progress bar and wrong for data. A robot on a bench is offline for an afternoon,
gets unplugged, gets restarted — and the runs it made in between are exactly
the ones worth having.

So every event is a file first. `Outbox.put` writes it (atomically: a reader
never sees half an event) and returns; that is all a run ever waits for. A
`Courier` delivers them oldest first, and a file is deleted only when the API
has said yes:

    delivered     gone
    refused       moved to rejected/, with the reason beside it — a payload the
                  API will never accept must not block everything behind it
    unreachable   left where it is, and the pass stops there. Order matters: a
                  tag or a link means nothing before its episode, so nothing
                  overtakes a run that has not landed yet

Footage is an event too (`blob`): a pointer to the file the recorder wrote. It
is compacted to MP4 when OpenCV is here — a real camera's frames barely shrink
under zlib, and a minute of them is tens of megabytes — and sent in parts,
because the API sits behind a 4.5 MB request limit.
"""

from __future__ import annotations

import json
import threading
import time
from pathlib import Path

PART_BYTES = 3_000_000
#: Seconds between delivery attempts when the last one could not reach the API.
BACKOFF_S = (5, 15, 60, 300)


class Refused(Exception):
    """The API understood and said no. Retrying will not help."""


class Unreachable(Exception):
    """The API could not be asked, or asked us to wait. Try again later."""


class Outbox:
    def __init__(self, root: Path):
        self.root = Path(root)
        self.rejected = self.root / "rejected"
        self._lock = threading.Lock()
        self._last = 0
        self.arrived = threading.Event()

    def put(self, event: dict) -> Path:
        """Keep one event. Called from inside a run, so it only writes a file."""
        with self._lock:
            self._last = max(time.time_ns(), self._last + 1)
            stamp = self._last
        self.root.mkdir(parents=True, exist_ok=True)
        target = self.root / f"{stamp:020d}-{event.get('event', 'event')}.json"
        scratch = target.with_suffix(".tmp")
        scratch.write_text(json.dumps(event))
        scratch.replace(target)
        self.arrived.set()
        return target

    __call__ = put  # so an Outbox IS a recorder sink

    def pending(self) -> list[Path]:
        return sorted(self.root.glob("*.json")) if self.root.exists() else []

    def refused(self) -> list[Path]:
        return sorted(self.rejected.glob("*.json")) if self.rejected.exists() else []

    def reject(self, item: Path, reason: str) -> None:
        self.rejected.mkdir(parents=True, exist_ok=True)
        item.replace(self.rejected / item.name)
        (self.rejected / f"{item.stem}.why.txt").write_text(reason + "\n")


def footage(archive: Path) -> list[tuple[str, Path]]:
    """The files to send for one episode's images: an MP4 per view when OpenCV
    is here, else the archive as it is. Encoded once and kept beside the
    archive, so a retry after a dropped connection does not encode again."""
    try:
        import cv2
        import numpy as np
    except ImportError:
        return [("images.npz", archive)]
    out = []
    with np.load(archive) as views:
        for view in views.files:
            target = archive.with_name(f"{archive.stem}.{view}.mp4")
            if not target.exists():
                frames = views[view]
                height, width = frames.shape[1:3]
                scratch = target.with_suffix(".part.mp4")
                writer = cv2.VideoWriter(
                    str(scratch), cv2.VideoWriter_fourcc(*"mp4v"), 20, (width, height)
                )
                if not writer.isOpened():
                    return [("images.npz", archive)]
                for frame in frames:
                    writer.write(cv2.cvtColor(frame, cv2.COLOR_RGB2BGR))
                writer.release()
                scratch.replace(target)
            out.append((f"{view}.mp4", target))
    return out


class Courier:
    """Delivers an Outbox. `post(event)` and `put_part(episode_id, name, part,
    parts, data)` do the talking and raise Refused or Unreachable."""

    def __init__(self, outbox: Outbox, post, put_part, compact=footage):
        self.outbox, self._post, self._put_part, self._compact = outbox, post, put_part, compact
        self._thread: threading.Thread | None = None
        self.last_error: str | None = None

    def deliver(self, progress=None) -> dict:
        """One pass, oldest first. Stops at the first event that cannot be
        delivered YET, so nothing overtakes it."""
        tally = {"delivered": 0, "refused": 0, "waiting": 0}
        items = self.outbox.pending()
        for position, item in enumerate(items):
            try:
                event = json.loads(item.read_text())
            except (OSError, ValueError):
                self.outbox.reject(item, "unreadable: not JSON")
                tally["refused"] += 1
                continue
            try:
                if event.get("event") == "blob":
                    self._send_footage(event)
                else:
                    self._post(event)
            except Refused as no:
                self.outbox.reject(item, str(no))
                tally["refused"] += 1
            except Unreachable as later:
                self.last_error = str(later)
                tally["waiting"] = len(items) - position
                return tally
            else:
                item.unlink(missing_ok=True)
                tally["delivered"] += 1
                self.last_error = None
            if progress:
                progress(position + 1, len(items))
        return tally

    def _send_footage(self, event: dict) -> None:
        archive = Path(event.get("path", ""))
        if not archive.exists():
            raise Refused(f"the footage file is gone: {archive}")
        for name, source in self._compact(archive):
            data = source.read_bytes()
            parts = max(1, -(-len(data) // PART_BYTES))
            for part in range(parts):
                self._put_part(
                    event["id"],
                    name,
                    part,
                    parts,
                    data[part * PART_BYTES : (part + 1) * PART_BYTES],
                )

    def start(self) -> None:
        """Deliver in the background for as long as the process lives."""
        if self._thread is None:
            self._thread = threading.Thread(target=self._run, daemon=True, name="outbox-courier")
            self._thread.start()

    def _run(self) -> None:
        failures = 0
        while True:
            self.outbox.arrived.clear()
            try:
                waiting = self.deliver()["waiting"]
            except Exception as e:  # noqa: BLE001 — a courier that dies silently loses data
                self.last_error, waiting = f"{type(e).__name__}: {e}", 1
            failures = failures + 1 if waiting else 0
            # Sleep until something new is put, or until it is time to try the
            # API again: whichever comes first.
            pause = BACKOFF_S[min(failures, len(BACKOFF_S)) - 1] if waiting else None
            self.outbox.arrived.wait(pause)
