"""What is standing on the bench, measured by the depth camera.

An owner should not have to type an object's length, width and height: a
depth camera looking at the bench can read them. The bench is fitted as a
plane (vision.bench_up), everything that stands more than a few millimetres
above it is split into connected pieces, and each piece gets the smallest
rectangle around its footprint and its height above the bench.

What this cannot do, stated rather than hidden: the arm itself stands on the
bench too, so anything taller than an object could be (`max_height_m`) or
touching the edge of the picture is set aside, with the reason. A webcam
without depth cannot measure at all; `botcortex bench add` takes the numbers
by hand in that case.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from botcortex import vision
from botcortex.camera import Frame


@dataclass
class Found:
    #: Length, width, height in metres; length >= width. Half a millimetre of
    #: depth noise is normal; the numbers are rounded to the millimetre.
    size_m: tuple[float, float, float]
    #: The centre of the object (half way up) in the CAMERA frame.
    centre_camera: np.ndarray
    #: Median colour of its pixels, 0..1, and the hue the runtime would look for.
    rgba: list[float]
    hue: float
    pixels: int

    @property
    def size_cm(self) -> tuple[float, float, float]:
        return tuple(round(v * 100, 1) for v in self.size_m)


@dataclass
class Ignored:
    why: str
    pixels: int
    height_m: float


def measure(
    frame: Frame,
    *,
    min_height_m: float = 0.006,
    max_height_m: float = 0.15,
    min_pixels: int = 150,
    max_range_m: float = 1.5,
) -> tuple[list[Found], list[Ignored]]:
    """(objects on the bench, largest first; what was set aside and why).

    Only what is within `max_range_m` counts as the bench. A camera set low
    sees the room behind the bench, and a plane fitted to the whole picture
    is then the far wall or the floor: the bench is the near surface.
    """
    if frame.depth is None:
        raise ValueError(
            "measuring needs a depth camera; this one sees colour only. Measure by hand and: "
            "botcortex bench add <name> <length_cm> <width_cm> <height_cm>"
        )
    import cv2

    near = Frame(
        frame.rgb,
        np.where(frame.depth < max_range_m, frame.depth, 0.0),
        frame.fx,
        frame.fy,
        frame.cx,
        frame.cy,
        frame.pose,
    )
    up, on_bench = vision.bench_plane(near)
    cloud = near.points_in_camera()
    valid = near.depth > 0
    along = cloud @ up
    # The plane bench_plane chose — the nearest big flat surface — not the
    # median of everything in range, which a floor beyond the table wins.
    level = float(on_bench @ up)
    height = along - level
    standing = valid & (height > min_height_m)

    h, w = frame.depth.shape
    count, labels, stats, _ = cv2.connectedComponentsWithStats(
        standing.astype(np.uint8), connectivity=8
    )
    # Plane axes: the camera's x projected onto the bench (its z when the
    # bench happens to face the lens square on), and the one across it.
    e1 = np.array([1.0, 0.0, 0.0]) - up[0] * up
    if np.linalg.norm(e1) < 1e-3:
        e1 = np.array([0.0, 0.0, 1.0]) - up[2] * up
    e1 /= np.linalg.norm(e1)
    e2 = np.cross(up, e1)

    found, ignored = [], []
    for label in range(1, count):
        x0, y0, bw, bh, pixels = stats[label]
        if pixels < min_pixels:
            continue
        mask = labels == label
        tall = float(np.percentile(height[mask], 95))
        if tall > max_height_m:
            ignored.append(
                Ignored(
                    f"{tall * 100:.0f} cm tall — the arm, or something no gripper takes",
                    int(pixels),
                    tall,
                )
            )
            continue
        if x0 == 0 or y0 == 0 or x0 + bw >= w or y0 + bh >= h:
            ignored.append(Ignored("cut off by the edge of the picture", int(pixels), tall))
            continue
        pts = cloud[mask]
        flat = np.stack((pts @ e1, pts @ e2), axis=-1).astype(np.float32)
        (cx, cy), (a, b), _angle = cv2.minAreaRect(flat)
        length, width = (max(a, b), min(a, b))
        centre = cx * e1 + cy * e2 + up * (level + tall / 2)
        rgb = np.median(frame.rgb[mask], axis=0) / 255.0
        found.append(
            Found(
                size_m=(round(float(length), 3), round(float(width), 3), round(tall, 3)),
                centre_camera=centre,
                rgba=[round(float(v), 3) for v in rgb] + [1.0],
                hue=round(vision._hue_of(rgb), 1),
                pixels=int(pixels),
            )
        )
    found.sort(key=lambda f: f.pixels, reverse=True)
    return found, ignored


def measure_by_colour(
    frame: Frame, table_top_m: float, height_m: float = 0.0, *, min_pixels: int = 150
) -> list[Found]:
    """A colour-only camera, once calibrated: each coloured thing's footprint,
    by casting its outline onto the bench. Height is not in the picture —
    `probe_height` reads it with the arm — and until it is known every
    `size_m` here carries height 0 and a footprint that is too long by the
    height's shadow: at a 60 degree slant a 40 mm cube reads 63 mm.

    Given the height, the outline is cast twice: onto the bench, where its
    NEAR edge (the object's bottom) is true and its far edge over-reads by
    the height's shadow, and onto the plane at the object's top, where the
    FAR edge (the object's top) is true and the near edge over-reads. Where
    the two casts overlap is the footprint. Call once for the outline,
    probe, call again for the size.
    """
    if frame.pose is None:
        raise ValueError(
            "a colour camera can only measure once it knows where it stands: "
            "botcortex camera calibrate --execute"
        )
    import cv2

    _hue, coloured = vision._coloured(frame)
    count, labels, stats, _ = cv2.connectedComponentsWithStats(
        coloured.astype(np.uint8), connectivity=8
    )
    rotation, origin = frame.pose[:3, :3], frame.pose[:3, 3]
    found = []
    for label in range(1, count):
        pixels = int(stats[label][4])
        if pixels < min_pixels:
            continue
        mask = labels == label
        v, u = np.nonzero(mask)
        rays = frame.rays_in_camera(np.stack((u, v), axis=-1).astype(float)) @ rotation.T
        down = rays[:, 2]
        going = down < -1e-6  # toward the bench, not the sky
        if going.sum() < min_pixels:
            continue
        aimed, slope = rays[going], down[going]
        on_bench = _cast(origin, aimed, slope, table_top_m)
        footprint = cv2.convexHull(on_bench)
        if height_m > 0:
            on_top = cv2.convexHull(_cast(origin, aimed, slope, table_top_m + height_m))
            _area, overlap = cv2.intersectConvexConvex(footprint, on_top)
            if overlap is not None and len(overlap) >= 3:
                footprint = overlap
        (cx, cy), (a, b), _angle = cv2.minAreaRect(footprint.reshape(-1, 2))
        rgb = np.median(frame.rgb[mask], axis=0) / 255.0
        centre_base = np.array([cx, cy, table_top_m + height_m / 2])
        # Back into the camera frame, for the same shape as a depth measurement.
        centre_camera = rotation.T @ (centre_base - origin)
        found.append(
            Found(
                size_m=(round(float(max(a, b)), 3), round(float(min(a, b)), 3), round(height_m, 3)),
                centre_camera=centre_camera,
                rgba=[round(float(c), 3) for c in rgb] + [1.0],
                hue=round(vision._hue_of(rgb), 1),
                pixels=pixels,
            )
        )
    found.sort(key=lambda f: f.pixels, reverse=True)
    return found


def _cast(origin: np.ndarray, rays: np.ndarray, slope: np.ndarray, plane: float) -> np.ndarray:
    """Where rays from `origin` meet the horizontal plane at `plane`, in xy."""
    t = (plane - origin[2]) / slope
    return (origin + rays * t[:, None])[:, :2].astype(np.float32)


def probe_height(
    robot,
    arm: str,
    xy: tuple[float, float],
    table_top_m: float,
    *,
    start_m: float = 0.10,
    step_m: float = 0.005,
) -> float:
    """How tall the thing at `xy` is, by touch: the closed gripper comes down
    over it in small steps until the servos report they are held back. The
    height is where the tip stopped. Real motion — the caller holds the
    --execute decision — and the arm is left just above where it touched.
    """
    from botcortex.real import FollowingError

    _open, closed = robot.platform.joint_limits[arm]["gripper"]
    robot.gripper(arm, closed)
    z = table_top_m + start_m
    robot.move_to_point(arm, (xy[0], xy[1], z))
    while z > table_top_m + 0.003:
        z -= step_m
        try:
            robot.move_to_point(arm, (xy[0], xy[1], z))
        except FollowingError:
            robot.sync()
            (_x, _y, touched), _ = robot.tip(arm)
            robot.move_to_point(arm, (xy[0], xy[1], touched + 0.03))
            return round(max(touched - table_top_m, 0.0), 3)
    return 0.0
