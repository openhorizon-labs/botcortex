"""Where the blocks are, from a colour-and-depth frame. No model, no tokens.

This is the hardware answer to `scene.describe`'s privileged positions, and it
is deliberately the dullest thing that works: a block is found by its colour,
and its centre is read off its TOP FACE.

Why the top face. The pixels a camera sees of a cube are its near surfaces, so
their centroid sits up to half a cube closer to the lens than the cube's
centre — 15 mm on a 40 mm block, which is a missed grasp. The top face of a
block lying flat is centred exactly over the block, the camera sees all of it,
and half the block's height below it is the centre. "Up" is the bench's own
normal, fitted from the frame, so none of this needs to know where the camera
stands — which is what lets the same routine CALIBRATE the camera.

WITHOUT DEPTH — a plain webcam — a pixel is only a direction. What pins the
block down then is that it rests on something whose height is known: the
bench, a tray floor, another block. A cube's outline is symmetric about its
centre, so the middle of its coloured blob is where the centre projects, and
the ray through that pixel is cut at the centre's height above its support.
Which support is not visible in one colour image, so the one that agrees best
with where the twin already believes the block is wins. The price, said
plainly: a block put somewhere new AND at a new height by a person, between
two looks, can be misplaced by about its height times the camera's slant. A
depth camera has no such case.

What neither path does, stated rather than hidden: neither estimates
orientation, neither can tell two blocks of one colour apart, and a block
tumbled onto an edge is reported where its highest face is. A block the arm
is hiding part of is refused rather than reported where its visible half is.
Each refusal comes back as unseen-with-a-reason, never as a confident wrong
position.
"""

from __future__ import annotations

import colorsys

import numpy as np

from botcortex.camera import Frame, to_base

#: Hue distance, in degrees, inside which a pixel is the object's colour.
_HUE_WINDOW = 20.0
#: Two objects closer in hue than this cannot be told apart by colour.
_HUE_AMBIGUOUS = 30.0
_MIN_SATURATION = 0.30
_MIN_VALUE = 0.12
_MIN_PIXELS = 60
#: How far away the bench can be. Beyond this is the room, never the bench.
BENCH_RANGE_M = 1.5
#: How far below its highest point a pixel may be and still count as the top
#: face. A RealSense is good to about 2 mm at bench range.
_TOP_BAND_M = 0.005
#: Less of its outline than this showing, and an object is reported hidden:
#: what is visible of a half-covered block is not centred on the block.
_VISIBLE = 0.5
#: How far past the table's edge an object may still be over the bench.
_BENCH_MARGIN_M = 0.05
#: The height band, around the table's top, in which a depth point may belong
#: to an object on the bench. Below: sensor noise on a dark or shiny surface.
#: Above: the tallest object, plus the same allowance.
_BAND_BELOW_M = 0.03
_BAND_ABOVE_M = 0.05
#: Colour only: how near its believed place a blob must point for the belief
#: to stand. The same 3 cm at which RealRobot lets reality overrule physics.
_AGREES_M = 0.03
_HIDDEN = "partly hidden (the arm or another object is in front of it)"


def _hue_saturation(rgb: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    c = rgb.astype(np.float32) / 255.0
    hi, lo = c.max(axis=-1), c.min(axis=-1)
    span = hi - lo
    safe = np.where(span == 0, 1.0, span)
    r, g, b = c[..., 0], c[..., 1], c[..., 2]
    hue = np.where(
        hi == r, ((g - b) / safe) % 6, np.where(hi == g, (b - r) / safe + 2, (r - g) / safe + 4)
    )
    return hue * 60.0, np.where(hi == 0, 0.0, span / np.where(hi == 0, 1.0, hi))


def _coloured(frame: Frame) -> tuple[np.ndarray, np.ndarray]:
    """(hue, which pixels have a hue worth reading).

    Saturation alone is not enough. A nearly black pixel — the arm's dark
    plastic in shadow, (5, 8, 5) — has a saturation of 0.4 and a hue of pure
    green, and enough of them once carried the green block's estimate 12 cm up
    onto the forearm. Hue means nothing without light, so dark pixels are out.
    """
    hue, saturation = _hue_saturation(frame.rgb)
    value = frame.rgb.max(axis=-1) / 255.0
    return hue, (saturation > _MIN_SATURATION) & (value > _MIN_VALUE)


def _one_blob(points: np.ndarray, reach: float) -> np.ndarray:
    """Which of `points` belong to the main blob: within `reach` of the median,
    twice over. Stray pixels of the right colour elsewhere in the frame — a
    reflection, a sleeve — must not pull the estimate, and the median of a
    blob with a few strays is still inside the blob."""
    keep = np.ones(len(points), dtype=bool)
    for _ in range(2):
        middle = np.median(points[keep], axis=0)
        keep = np.linalg.norm(points - middle, axis=1) < reach
        if not keep.any():
            break
    return keep


def _hue_for(body: dict) -> float:
    """The hue to look for. A TAUGHT one wins (`hue`, from `botcortex camera
    colours`): the simulator's red is a number somebody typed, and a real red
    block under a desk lamp is whatever the camera says it is."""
    taught = body.get("hue")
    return float(taught) if taught is not None else _hue_of(body["colour"])


def dominant_hue(frame: Frame) -> tuple[float, int] | None:
    """The one strong colour in view, as (hue in degrees, pixels of it), or None
    when nothing colourful is there. For teaching: put ONE object on the bench.

    A histogram peak, then the circular mean of what is near it — a mean over
    everything would put a red block at magenta the moment a blue pen is in
    shot, and red itself straddles 0/360.
    """
    hue, coloured = _coloured(frame)
    found = hue[coloured]
    if found.size < _MIN_PIXELS:
        return None
    counts, edges = np.histogram(found, bins=36, range=(0.0, 360.0))
    peak = float(edges[int(counts.argmax())]) + 5.0
    near = found[_hue_gap(found, peak) < _HUE_WINDOW]
    if near.size < _MIN_PIXELS:
        return None
    angle = np.radians(near)
    mean = float(np.degrees(np.arctan2(np.sin(angle).mean(), np.cos(angle).mean())) % 360.0)
    return round(mean, 1), int(near.size)


def _hue_of(rgba) -> float:
    return colorsys.rgb_to_hsv(*rgba[:3])[0] * 360.0


def _hue_gap(a, b):
    return np.abs((a - b + 180.0) % 360.0 - 180.0)


def bench_up(frame: Frame) -> np.ndarray:
    """The bench's normal in the camera frame, pointing toward the lens."""
    return bench_plane(frame)[0]


def bench_level(frame: Frame, up: np.ndarray) -> float:
    """Where the bench is along `up`, for heights above it: the SAME plane
    `bench_up` chose, measured at its centre. It used to be the median of
    everything in range, which the floor beyond a black table wins — so the
    normal came from the bench and the height from the floor, 79 cm apart."""
    return float(bench_plane(frame)[1] @ up)


def bench_plane(frame: Frame) -> tuple[np.ndarray, np.ndarray]:
    """(normal toward the lens, a point on the bench), in the camera frame."""
    # Within arm's reach only. A bench camera set low sees the room behind
    # the bench, and a floor or a wall two metres away can out-vote the bench
    # in the consensus below — which put a cap a metre off the table.
    pts = frame.points_in_camera()[(frame.depth > 0) & (frame.depth < BENCH_RANGE_M)]
    pts = pts[:: max(1, len(pts) // 20000)]
    # Consensus, not a first guess tightened: a least-squares plane through
    # everything is dragged by the arm, the trays, and on a real sensor by
    # whatever else is in range (a chair leg, the far edge of the table), and
    # rounds of refitting on a thinner slab around a wrong plane keep the
    # wrong points. Measured on a RealSense over a paper-covered bench: the
    # first fit had 4% of the bench within 5 mm, and the rounds recovered
    # only sometimes. So: many small samples, each proposing a plane, and the
    # plane most of the points agree with wins. Then one refit on its inliers.
    rng = np.random.default_rng(0)
    planes: list[tuple[int, float, np.ndarray, np.ndarray]] = []  # (count, distance, a, normal)
    for _ in range(300):
        a, b, c = pts[rng.choice(len(pts), 3, replace=False)]
        normal = np.cross(b - a, c - a)
        length = np.linalg.norm(normal)
        if length < 1e-9:
            continue
        normal /= length
        gaps = np.abs((pts - a) @ normal)
        count = int((gaps < 0.004).sum())
        if count < 200:
            continue
        # One entry per distinct plane: a new hypothesis of a plane already
        # seen (same tilt, same offset) only keeps the better count.
        offset = float(a @ normal)
        for i, (had, _d, a0, n0) in enumerate(planes):
            if (
                abs(n0 @ normal) > 0.98
                and abs(float(a0 @ n0) - offset * np.sign(n0 @ normal)) < 0.05
            ):
                if count > had:
                    planes[i] = (
                        count,
                        float(np.median(np.linalg.norm(pts[gaps < 0.004], axis=1))),
                        a,
                        normal,
                    )
                break
        else:
            planes.append(
                (count, float(np.median(np.linalg.norm(pts[gaps < 0.004], axis=1))), a, normal)
            )
    if not planes:
        raise ValueError(
            "no flat surface in view within reach — is the camera looking at the bench?"
        )
    # The bench is the NEAREST of the big flat surfaces, not the biggest. A
    # bench camera sits above the bench, and the floor beyond the far edge is
    # below it and farther; on a black table that returns no depth, the floor
    # had more points than the paper and was taken for the bench, 79 cm down.
    biggest = max(count for count, *_ in planes)
    count, _distance, a, normal = min(
        (plane for plane in planes if plane[0] >= 0.3 * biggest), key=lambda plane: plane[1]
    )
    inliers = pts[np.abs((pts - a) @ normal) < 0.004]
    for slab in (0.004, 0.002):
        centre = inliers.mean(axis=0)
        normal = np.linalg.svd(inliers - centre, full_matrices=False)[2][-1]
        inliers = pts[np.abs((pts - centre) @ normal) < slab]
    centre = inliers.mean(axis=0)
    normal = np.linalg.svd(inliers - centre, full_matrices=False)[2][-1]
    # Toward the lens: the camera is at the origin of its own frame.
    return (normal if normal @ (-centre) > 0 else -normal), centre


def locate_in_camera(
    frame: Frame,
    objects: dict[str, dict],
    up: np.ndarray,
    counts: dict | None = None,
    keep: np.ndarray | None = None,
    trace: dict | None = None,
) -> tuple[dict[str, np.ndarray], dict[str, str]]:
    """Each object's centre in the CAMERA frame, plus why any was not found.

    `objects` is the `objects` half of a scene description: this reads each
    one's `colour` and `size_m` and nothing else. `keep` is a pixel mask of
    where objects may be at all — over the bench — from whoever knows where
    the bench is (see `locate`).
    """
    hue, coloured = _coloured(frame)
    cloud = frame.points_in_camera()
    usable = (frame.depth > 0) & coloured
    # Only what stands ON the bench is a candidate: from a little below its
    # surface to the tallest object plus a margin. Measured on a real bench:
    # an orange carpet stripe two metres behind it was the golden cap's hue,
    # and whenever the cap was far from the middle of all cap-coloured pixels
    # the blob picked the carpet, and a calibration disagreed by a metre.
    if keep is not None:
        # Whoever passed `keep` knows where the bench is (its height and its
        # footprint from the calibration and the scene); that beats guessing
        # the bench's level from the median of whatever is within reach,
        # which a person at the far edge or the floor beyond it pulls down.
        band = keep
    else:
        along = cloud @ up
        level = bench_level(frame, up)
        tallest = max((float(body["size_m"][2]) for body in objects.values()), default=0.1)
        band = (along - level > -0.02) & (along - level < tallest + 0.05)
    usable &= band
    hues = {name: _hue_for(body) for name, body in objects.items()}
    seen: dict[str, np.ndarray] = {}
    unseen: dict[str, str] = {}
    counts = counts if counts is not None else {}
    for name, body in objects.items():
        twins = [o for o in hues if o != name and _hue_gap(hues[o], hues[name]) < _HUE_AMBIGUOUS]
        if twins:
            unseen[name] = (
                f"same colour as {', '.join(sorted(twins))}; colour alone cannot tell them apart"
            )
            continue
        matching = _hue_gap(hue, hues[name]) < _HUE_WINDOW
        pts = cloud[usable & matching]
        if trace is not None:
            # Where the pixels went, for `camera check`: how many had the
            # colour at all, how many of those had depth, stood on the bench
            # and were over the table, and how many the blob kept.
            trace[name] = {
                "coloured": int((coloured & matching).sum()),
                "with_depth": int((coloured & matching & (frame.depth > 0)).sum()),
                "on_bench": int((coloured & matching & (frame.depth > 0) & band).sum()),
                "over_table": len(pts),
            }
        if len(pts) < _MIN_PIXELS:
            unseen[name] = "not in view (hidden, out of frame, or the lighting changed its colour)"
            continue
        pts = pts[_one_blob(pts, float(np.linalg.norm(body["size_m"])))]
        if trace is not None:
            trace[name]["blob"] = len(pts)
        if len(pts) < _MIN_PIXELS:
            unseen[name] = "not in view (hidden, out of frame, or the lighting changed its colour)"
            continue
        height = pts @ up
        # Nothing of a block is more than its own height above its middle
        # pixel. What is, is the edge of whatever is in front of it — a jaw
        # closing on the block shares pixels with it, red by colour and 3 cm
        # higher by depth, and once lifted the estimate by exactly that.
        under = height < np.median(height) + 0.5 * float(body["size_m"][2])
        pts, height = pts[under], height[under]
        top = pts[height > np.percentile(height, 98) - _TOP_BAND_M]
        seen[name] = top.mean(axis=0) - up * (float(body["size_m"][2]) / 2)
        counts[name] = len(pts)
    return seen, unseen


def locate(
    frame: Frame,
    objects: dict[str, dict],
    fixtures: dict[str, dict] | None = None,
    trace: dict | None = None,
) -> tuple[dict[str, list[float]], dict[str, str]]:
    """Each object's centre in the robot's BASE frame. Needs a calibrated frame.

    `fixtures` matters only without depth: they are the surfaces a block may
    be resting on.
    """
    if frame.pose is None:
        raise ValueError("this camera has not been calibrated — run: botcortex camera calibrate")
    if frame.depth is None:
        return _locate_by_ray(frame, objects, fixtures or {})
    up = frame.pose[:3, :3].T @ np.array([0.0, 0.0, 1.0])
    counts: dict[str, int] = {}
    # Only over the bench. Everything an object could be confused with that
    # is NOT on the bench — a hand at the far edge, a wooden chair leg a metre
    # behind it, the carpet — is off the table's footprint, and the footprint
    # is known: the calibration says where the camera stands and the scene
    # says where the table is. A golden cap was read at a chair 1.3 m away
    # for want of this, and then held there as "partly hidden" for good.
    keep = None
    table = (fixtures or {}).get("table")
    if table is not None:
        (tx, ty, tz), (sx, sy, sz) = table["position"], table["size_m"]
        top = tz + sz / 2
        tallest = max((float(body["size_m"][2]) for body in objects.values()), default=0.1)
        in_base = to_base(frame.pose, frame.points_in_camera())
        keep = (
            (np.abs(in_base[..., 0] - tx) < sx / 2 + _BENCH_MARGIN_M)
            & (np.abs(in_base[..., 1] - ty) < sy / 2 + _BENCH_MARGIN_M)
            & (in_base[..., 2] > top - _BAND_BELOW_M)
            & (in_base[..., 2] < top + tallest + _BAND_ABOVE_M)
        )
    in_camera, unseen = locate_in_camera(frame, objects, up, counts, keep=keep, trace=trace)
    if trace is not None:
        for name in in_camera:
            trace.setdefault(name, {})["used"] = counts[name]
    seen: dict[str, list[float]] = {}
    for name, point in in_camera.items():
        centre = to_base(frame.pose, point)
        body = objects[name]
        if body.get("seen_px") and body.get("seen_at_m"):
            # How it looked when it was measured, scaled to this distance: the
            # pixels the camera actually gets from THIS object's colour, not
            # the outline of a box it may not fill.
            distance = max(float(np.linalg.norm(point)), 0.05)
            expected = float(body["seen_px"]) * (float(body["seen_at_m"]) / distance) ** 2
        else:
            expected = _outline(frame, centre, body["size_m"])[0]
        if counts[name] < _VISIBLE * expected:
            unseen[name] = _HIDDEN
            continue
        seen[name] = [round(float(v), 4) for v in centre]
    return seen, unseen


# --- colour only: a ray, and the surface the block rests on ----------------


def blobs(frame: Frame, objects: dict[str, dict]) -> tuple[dict[str, tuple], dict[str, str]]:
    """Each object's blob as (centre pixel, pixel count). No geometry at all,
    which is why calibration can use it before there is any."""
    hue, usable = _coloured(frame)
    hues = {name: _hue_for(body) for name, body in objects.items()}
    seen: dict[str, tuple] = {}
    unseen: dict[str, str] = {}
    for name in objects:
        twins = [o for o in hues if o != name and _hue_gap(hues[o], hues[name]) < _HUE_AMBIGUOUS]
        if twins:
            unseen[name] = (
                f"same colour as {', '.join(sorted(twins))}; colour alone cannot tell them apart"
            )
            continue
        v, u = np.nonzero(usable & (_hue_gap(hue, hues[name]) < _HUE_WINDOW))
        if len(u) < _MIN_PIXELS:
            unseen[name] = "not in view (hidden, out of frame, or the lighting changed its colour)"
            continue
        pixels = np.stack((u, v), axis=1).astype(float)
        # A disc of the blob's own area has radius sqrt(n / pi); a blob's
        # pixels lie within about twice that of its middle, strays do not.
        pixels = pixels[_one_blob(pixels, 2.2 * float(np.sqrt(len(pixels) / np.pi)))]
        if len(pixels) < _MIN_PIXELS:
            unseen[name] = "not in view (hidden, out of frame, or the lighting changed its colour)"
            continue
        seen[name] = (pixels.mean(axis=0), len(pixels))
    return seen, unseen


def _on_plane(frame: Frame, pixel: np.ndarray, height: float) -> np.ndarray:
    """Where the ray through `pixel` crosses the horizontal plane z = height."""
    origin = frame.pose[:3, 3]
    direction = frame.pose[:3, :3] @ frame.rays_in_camera(pixel)
    return origin + direction * ((height - origin[2]) / direction[2])


def _turn(a, b, c) -> float:
    """Positive when a -> b -> c turns left. numpy 2 dropped 2-D np.cross."""
    return float((b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0]))


def _outline(frame: Frame, centre: np.ndarray, size) -> tuple[float, np.ndarray]:
    """What an upright box of `size` at `centre` should look like: the area in
    pixels of its outline, and how far the outline's middle sits from where
    the box's CENTRE projects.

    That second number is the perspective the symmetry argument ignores: the
    near faces are drawn larger than the far ones, so the blob's middle is
    pulled a few pixels toward the lens. It is small, it is systematic, and
    the box's known shape predicts it — so it is subtracted, not tolerated.
    """
    half = np.array(size) / 2
    corners = centre + half * np.array(
        [[x, y, z] for x in (-1, 1) for y in (-1, 1) for z in (-1, 1)], dtype=float
    )

    def project(points):
        cam = (points - frame.pose[:3, 3]) @ frame.pose[:3, :3]
        return np.stack(
            (cam[:, 0] / cam[:, 2] * frame.fx, cam[:, 1] / cam[:, 2] * frame.fy), axis=1
        )

    pts = project(corners)
    pts = pts[np.lexsort((pts[:, 1], pts[:, 0]))]

    def chain(points):
        out: list = []
        for p in points:
            while len(out) >= 2 and _turn(out[-2], out[-1], p) <= 0:
                out.pop()
            out.append(p)
        return out[:-1]

    hull = np.array(chain(pts) + chain(pts[::-1]))
    x, y = hull[:, 0], hull[:, 1]
    xn, yn = np.roll(x, -1), np.roll(y, -1)
    wedge = x * yn - xn * y
    area = float(wedge.sum()) / 2
    middle = np.array([((x + xn) * wedge).sum(), ((y + yn) * wedge).sum()]) / (6 * area)
    return abs(area), middle - project(centre[None, :])[0]


def _supports(name: str, objects: dict[str, dict], fixtures: dict[str, dict]):
    """(top surface height, footprint test) for everything `name` could rest on."""
    yield 0.0, lambda xy: True  # the bench
    for other, body in {**fixtures, **{o: b for o, b in objects.items() if o != name}}.items():
        if other == "table":
            continue
        (x, y, z), (sx, sy, sz) = body["position"], body["size_m"]
        yield (
            z + sz / 2,
            (
                lambda xy, x=x, y=y, sx=sx, sy=sy: (
                    abs(xy[0] - x) < sx / 2 and abs(xy[1] - y) < sy / 2
                )
            ),
        )


def _locate_by_ray(frame, objects, fixtures):
    """Colour only. The image is first asked whether it CONTRADICTS the twin.

    A block in the jaws ten centimetres up has no support to be found on, and
    cutting its ray at bench height put it 6 cm away on the bench — the camera
    then "corrected" the twin by taking the block out of the gripper. So the
    first hypothesis is the twin's own: the block is at the height believed.
    If the blob sits where that predicts and is the size that predicts, the
    belief stands and only its x and y are refined. Only when the image
    disagrees is the block looked for on the surfaces it could be resting on,
    and there apparent size — a block 12 cm nearer the lens covers a third more
    pixels — chooses between heights before nearness to the belief does.
    """
    found, unseen = blobs(frame, objects)
    seen: dict[str, list[float]] = {}
    for name, (pixel, count) in found.items():
        body = objects[name]
        size = body["size_m"]
        half = float(size[2]) / 2
        believed = np.array(body["position"], dtype=float)

        as_believed = _on_plane(frame, pixel, float(believed[2]))
        expected, pull = _outline(frame, as_believed, size)
        where_believed = float(np.linalg.norm(as_believed - believed)) < _AGREES_M
        consistent = where_believed and _VISIBLE * expected <= count <= expected / _VISIBLE
        if where_believed and count < _VISIBLE * expected:
            # It points where the twin says, and less of it shows than should:
            # something is in front of it — usually the jaws carrying it. That
            # is "hidden", not "somewhere else". Looking for it on the bench
            # instead found a carried block 12 cm away and called it dropped.
            unseen[name] = _HIDDEN
            continue
        if consistent:
            centre = _on_plane(frame, pixel - pull, float(believed[2]))
        else:
            options = []
            for top, covers in _supports(name, objects, fixtures):
                candidate = _on_plane(frame, pixel, top + half)
                if covers(candidate):
                    area, pull = _outline(frame, candidate, size)
                    options.append((abs(float(np.log(count / area))), candidate, area, pull))
            best = min(o[0] for o in options)
            _, centre, expected, pull = min(
                (o for o in options if o[0] < best + 0.08),
                key=lambda o: float(np.linalg.norm(o[1] - believed)),
            )
            if count < _VISIBLE * expected:
                unseen[name] = _HIDDEN
                continue
            centre = _on_plane(frame, pixel - pull, float(centre[2]))
        seen[name] = [round(float(v), 4) for v in centre]
    return seen, unseen


def solve_pose_from_pixels(
    pixels: np.ndarray,
    on_bench: np.ndarray,
    height: float,
    centre: tuple[float, float],
    width: int,
    size=None,
) -> tuple[np.ndarray, float, float]:
    """A webcam's pose AND focal length, from a block seen at known bench spots.

    `pixels` are blob centres, `on_bench` the (x, y) the block's centre stood
    at, all at one `height`; `size` is the block's, and buys a second pass
    with the perspective pull on each blob removed. Four or more spots fix the homography between
    the image and that plane; the two facts that a rotation's columns are
    perpendicular and equally long then give the focal length (Zhang's
    method, with square pixels and the principal point taken as the image
    centre), and the homography's columns the pose.

    Returns (camera-to-base, focal in pixels, RMS error on the bench in metres).
    A camera looking STRAIGHT down leaves the focal length unobservable; it is
    then guessed, which only costs accuracy at heights other than `height`.
    """
    px = np.asarray(pixels, float) - np.array(centre)
    xy = np.asarray(on_bench, float)
    if len(px) < 4:
        raise ValueError("a camera without depth needs at least four calibration spots")
    rows = []
    for (u, v), (x, y) in zip(px, xy, strict=True):
        rows.append([x, y, 1, 0, 0, 0, -u * x, -u * y, -u])
        rows.append([0, 0, 0, x, y, 1, -v * x, -v * y, -v])
    _, singular, vt = np.linalg.svd(np.array(rows))
    if singular[-2] < 1e-9:
        raise ValueError("the calibration spots are in a line — spread them over the bench")
    h = vt[-1].reshape(3, 3)
    h1, h2 = h[:, 0], h[:, 1]
    num = np.array(
        [h1[0] * h2[0] + h1[1] * h2[1], h1[0] ** 2 + h1[1] ** 2 - h2[0] ** 2 - h2[1] ** 2]
    )
    den = np.array([h1[2] * h2[2], h1[2] ** 2 - h2[2] ** 2])
    scale = np.linalg.norm(h[2, :2]) ** 2
    f2 = -float(num @ den) / float(den @ den) if float(den @ den) > 1e-6 * scale**2 else -1.0
    focal = float(np.sqrt(f2)) if f2 > 0 else float(width) / (2 * np.tan(np.radians(30)))
    k_inv = np.diag([1 / focal, 1 / focal, 1.0])
    m = k_inv @ h
    m /= (np.linalg.norm(m[:, 0]) + np.linalg.norm(m[:, 1])) / 2
    if m[2, 2] < 0:  # the bench is in front of the lens
        m = -m
    u, _, vt2 = np.linalg.svd(np.column_stack((m[:, 0], m[:, 1], np.cross(m[:, 0], m[:, 1]))))
    rotation = u @ np.diag([1.0, 1.0, np.linalg.det(u @ vt2)]) @ vt2  # base -> camera
    translation = m[:, 2] - rotation @ np.array([0.0, 0.0, height])
    pose = np.eye(4)
    pose[:3, :3] = rotation.T
    pose[:3, 3] = -rotation.T @ translation
    probe = Frame(np.zeros((1, 1, 3), np.uint8), None, focal, focal, *centre, pose)
    if size is not None:
        # Second pass: now that the camera is roughly known, the block's shape
        # says how far each blob's middle was pulled toward the lens. Remove
        # that and solve again on what the centres really projected to.
        pulls = np.array([_outline(probe, np.array([x, y, height]), size)[1] for x, y in xy])
        return solve_pose_from_pixels(px + np.array(centre) - pulls, xy, height, centre, width)
    back = np.array([_on_plane(probe, p + np.array(centre), height)[:2] for p in px])
    return pose, focal, float(np.sqrt(np.mean(np.sum((back - xy) ** 2, axis=1))))


def solve_pose(in_camera: np.ndarray, in_base: np.ndarray) -> tuple[np.ndarray, float]:
    """The camera-to-base transform that best carries one point set onto the
    other (Kabsch), and the RMS distance it leaves, in metres.

    Needs at least three points that are not in a line. The residual is the
    honest number to show the person calibrating: a few millimetres is a
    camera that can be trusted with a 40 mm block, a centimetre is not.
    """
    a, b = np.asarray(in_camera, float), np.asarray(in_base, float)
    if len(a) < 3:
        raise ValueError("calibration needs at least three spots")
    ca, cb = a.mean(axis=0), b.mean(axis=0)
    u, s, vt = np.linalg.svd((a - ca).T @ (b - cb))
    if s[1] < 1e-6:
        raise ValueError("the calibration spots are in a line — spread them over the bench")
    flip = np.diag([1.0, 1.0, np.sign(np.linalg.det(vt.T @ u.T))])
    rotation = vt.T @ flip @ u.T
    pose = np.eye(4)
    pose[:3, :3] = rotation
    pose[:3, 3] = cb - rotation @ ca
    residual = float(np.sqrt(np.mean(np.sum((to_base(pose, a) - b) ** 2, axis=1))))
    return pose, residual
