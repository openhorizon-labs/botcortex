"""A real arm, driven through its own simulation.

RealRobot IS a SimRobot. The simulation is the arm's model of the world — the
digital twin — and hardware is attached to it at exactly two points:

- OUT: every control frame the twin steps without hitting anything is sent to
  the servos (`_actuate`). Rehearsals send nothing, by construction: they run
  inside the twin and are rewound. So "rehearsed clean before it moved" means
  on a desk what it means in a browser tab, and pose search, routing, the
  object-motion guard and the evidence report all work unchanged.
- IN: the camera corrects where the twin believes the objects are
  (`describe_scene`), and servo feedback checks the arm is where the twin
  thinks it is (the following guard).

What is deliberately absent: `reset`. A simulator may snap home; an arm that
did would be flung there. The server only offers reset where the attribute
exists, so here it does not.

With `link=None` nothing is ever sent: a dry run with the real camera. That is
the default everywhere above this file; opening the port takes --execute.
"""

from __future__ import annotations

import json
import math
import time

from botcortex import config, scene, vision
from botcortex.roarm import from_wire, to_wire
from botcortex.sim import SimRobot

#: How far a joint may lag its command before the move is abandoned, and for
#: how many consecutive ticks. One tick of lag is normal servo behaviour; a
#: quarter of a second of 12 degrees is an arm pressing on something.
FOLLOW_LIMIT_DEG = 12.0
FOLLOW_TICKS = 5
#: Camera corrections smaller than this are sensor noise, and applying them
#: would wake resting physics for nothing.
_SEE_DEADBAND_M = 0.003
#: At the jaws — open or closed — the camera sees a block half hidden by the
#: clamp, and its estimate is biased. There, physics is believed unless the two
#: disagree by more than this — which is a dropped or missed block, and reality
#: wins. Open jaws count: measured, a block being closed on was reported 25 mm
#: too high from the jaw's own pixels at its edge.
_HELD_NEAR_M = 0.06
#: Seconds given to the bench after the jaws move.
_AFTER_JAWS_S = 0.4
PLACEMENT_SLACK_M = 0.004
_HELD_DISAGREE_M = 0.03


class FollowingError(RuntimeError):
    """The arm is not where it was told to be: it is blocked, stalled or unpowered."""


class RealRobot(SimRobot):
    def __init__(
        self,
        platform=None,
        link=None,
        camera=None,
        stop_file=None,
        realtime=True,
        signs=None,
        world=None,
    ):
        super().__init__(platform, stop_file=stop_file, realtime=realtime, world=world)
        #: Joints this unit drives backwards relative to the vendor's mapping
        #: (`botcortex arm check`). Applied on the wire and nowhere else, so
        #: the twin, the skills and the recorded data stay in one convention.
        self.signs: dict[str, int] = dict(signs or {})
        self.link = link
        self.camera = camera
        #: A camera chosen but not yet calibrated: the arm cannot see with it,
        #: the owner can watch through it (the server's /camera.mjpg).
        self.feed = None
        #: Added to every placement's room-beside-a-wall (SkillContext._wall_margin).
        #: What the arm believes and what is on the bench differ by the camera's
        #: error plus how the block sat in the jaws. Measured in the loopback
        #: rig: a second block into the RoArm's tray landed 6 mm nearer the wall
        #: than planned, came to rest leaning on it, and every later move was
        #: refused for "displacing" a block the twin's physics could not hold.
        #: 4 mm, not 6: at 6 the tray's spots close up past the room fingers
        #: need between blocks and it holds one block instead of three
        #: (kinematics.free_spots). At 4, both camera kinds place all three flat.
        self.placement_slack_m = PLACEMENT_SLACK_M
        #: Object name -> hue in degrees, as THIS camera sees THESE objects
        #: (`botcortex camera colours`). Empty means the model's colours.
        self.hues: dict[str, float] = {}
        #: How each object looked when the camera measured it, {name: (pixels,
        #: distance in metres)} — the bench file's seen_px / seen_at_m.
        self.looks: dict[str, tuple[int, float]] = {}
        #: Where each object's pixels went on the last look (vision.locate trace).
        self.trace: dict[str, dict] = {}
        self._lagging = 0
        self._measured_now: dict[str, float] | None = None
        #: The last complete command sent, per arm. A frame that names only
        #: some joints is completed from HERE, not from the twin's measured
        #: pose: that one sags a fraction of a degree under load, and feeding
        #: it back as a command would walk the arm downhill tick by tick.
        self._commanded = {arm: dict(self.platform.home_position) for arm in self.platform.arms}
        #: What the last look could not find, and why — shown to the owner.
        self.unseen: dict[str, str] = {}
        sim = self.platform.sim
        self._jaw_open = float(sim["gripper"]["qpos_open"])
        self._arm = self.platform.arms[0]
        self._gripper_limits = tuple(self.platform.joint_limits[self._arm]["gripper"])
        if link is not None:
            self.sync()

    @property
    def reset(self):
        raise AttributeError("a real arm cannot be snapped home — use park()")

    # --- out: frames to servos -------------------------------------------

    def _actuate(self, arm: str, frame: dict[str, float]) -> None:
        if self.link is None or self.rehearsing:
            return
        # T=102 has no "leave this joint alone": a missing joint is driven to
        # zero. So every frame is completed from where the twin holds the rest.
        full = self._commanded[arm] = {**self._commanded[arm], **frame}
        self.link.joints(to_wire(self._flipped(full), self._jaw_open, self._gripper_limits))
        self._follow(arm, full)

    def _follow(self, arm: str, commanded: dict[str, float]) -> None:
        actual = self._measured_now = self.measured(arm)
        predicted = self.get_positions(arm)
        # Far from BOTH the command and the twin's prediction. A healthy servo
        # trails its command, by an amount the twin also predicts, so either
        # alone cries wolf: the command test on a soft servo mid-swing, the
        # twin test wherever the twin's placeholder gains are softer than the
        # real ST3235. A blocked arm is left behind by both.
        # The gripper is excluded on purpose: closed on a block it stalls short
        # of its command, and that is a grasp, not a fault.
        lag = max(
            min(abs(actual[j] - commanded[j]), abs(actual[j] - predicted[j]))
            for j in commanded
            if j != "gripper"
        )
        self._lagging = self._lagging + 1 if lag > FOLLOW_LIMIT_DEG else 0
        if self._lagging >= FOLLOW_TICKS:
            self._lagging = 0
            # Sending nothing more IS the stop: the servos hold. The twin is
            # then put where the arm really is, so the next plan starts there.
            self.sync()
            raise FollowingError(
                f"the arm is {lag:.0f} degrees behind its command — blocked or stalled. "
                "It is holding where it stopped."
            )

    def settle(self, seconds: float = 0.5) -> None:
        """The twin settles, and so must the bench: real seconds have to pass
        before the next look, or the camera catches a block still sliding and
        the motion guard — correctly — reports the arm disturbed it."""
        super().settle(seconds)
        if self.link is None or self.rehearsing:
            return
        for _ in range(max(1, round(seconds * config.CONTROL_HZ))):
            # One poll per control tick keeps the following guard's view fresh,
            # and is the only clock a loopback world has.
            self.link.feedback()
            if self.realtime:
                time.sleep(1 / config.CONTROL_HZ)

    def gripper(self, arm: str, position: float) -> None:
        """Jaws move, then everything is given a moment: a released block drops
        its last centimetre and rocks before it rests. In the rehearsal too, so
        the two stay the same sequence."""
        super().gripper(arm, position)
        self.settle(_AFTER_JAWS_S)

    def observed_positions(self, arm: str) -> dict[str, float]:
        """What a recording should call the state: the servos' own reading when
        there are servos, because a policy trained on this will be fed exactly
        that — not the twin's belief about it."""
        if self.link is None or self.rehearsing or self._measured_now is None:
            return self.get_positions(arm)
        return dict(self._measured_now)

    def measured(self, arm: str) -> dict[str, float]:
        """Where the servos say the arm is, in our degrees."""
        return self._flipped(from_wire(self.link.feedback(), self._jaw_open, self._gripper_limits))

    def _flipped(self, pose: dict[str, float]) -> dict[str, float]:
        """Its own inverse: a reversed joint is negated going out and coming back."""
        if not self.signs:
            return pose
        return {j: (-v if self.signs.get(j) == -1 else v) for j, v in pose.items()}

    def sync(self) -> None:
        """Put the twin where the arm actually is. Done at start-up — an arm is
        wherever it was left, not at home — and after a following error."""
        actual = self.measured(self._arm)
        self._commanded[self._arm] = dict(actual)
        for joint, deg in actual.items():
            self._write_target(self._arm, joint, deg)
            self._write_qpos(self._arm, joint, deg)
        self.data.qvel[:] = 0.0
        self._mujoco.mj_forward(self.model, self.data)

    def holding_by_feel(self, arm: str) -> bool:
        """True when the jaws stopped short of where they were sent: something
        is between them. The blueprint's camera-free grasp check."""
        wanted = self.get_positions(arm)["gripper"]
        return abs(self.measured(arm)["gripper"] - wanted) > 4.0

    # --- in: the camera corrects the twin ----------------------------------

    def describe_scene(self) -> dict[str, dict]:
        if self.camera is not None and not self.rehearsing:
            self.see()
        return super().describe_scene()

    def see(self) -> dict[str, str]:
        """Look, and move the twin's objects to where they really are."""
        twin = scene.describe(self._mujoco, self.model, self.data, self._robot_bodies)
        believed = twin["objects"]
        for name, hue in self.hues.items():
            if name in believed:
                believed[name]["hue"] = hue
        for name, (pixels, at_m) in self.looks.items():
            if name in believed:
                believed[name]["seen_px"], believed[name]["seen_at_m"] = pixels, at_m
        self.trace = {}
        found, self.unseen = vision.locate(
            self.camera.frame(), believed, twin["fixtures"], trace=self.trace
        )
        grasp, _ = self.tip(self._arm)
        poses = scene.object_poses(self.data.qpos, self._object_addr)
        moved = {}
        for name, where in found.items():
            # Height is the camera's least reliable coordinate — a depth
            # camera read the golden cap 1 to 5 cm low — and a body placed
            # inside the table is thrown a metre by the physics on the next
            # step, which the app showed as the cap vanishing. Nothing the
            # camera sees rests below what it rests on.
            where = _rested(where, believed[name]["size_m"][2], twin["fixtures"])
            was = believed[name]["position"]
            off = math.dist(where, was)
            if off < _SEE_DEADBAND_M:
                continue
            if math.dist(was, grasp) < _HELD_NEAR_M and off < _HELD_DISAGREE_M:
                continue
            moved[name] = [*where, *poses[name][3:]]
        if moved:
            scene.place_objects(self.data.qpos, self._object_addr, moved)
            self.data.qvel[:] = 0.0
            self._mujoco.mj_forward(self.model, self.data)
        return self.unseen

    def close(self) -> None:
        for part in (self.link, self.camera, self.feed):
            if part is not None:
                part.close()


def _rested(where, height_m: float, fixtures: dict[str, dict]) -> list[float]:
    """`where`, lifted if need be so the object sits ON the bench, or on the
    floor of the tray it is over — never inside either. Only ever raises: an
    object the camera sees above a surface (held, or stacked) stays there."""
    table = fixtures.get("table")
    top = table["position"][2] + table["size_m"][2] / 2 if table else 0.0
    for name, body in fixtures.items():
        if name == "table":
            continue
        (x, y, z), (sx, sy, _sz) = body["position"], body["size_m"]
        if abs(where[0] - x) < sx / 2 and abs(where[1] - y) < sy / 2:
            top = max(top, z + body["size_m"][2] / 2)
    return [float(where[0]), float(where[1]), max(float(where[2]), top + height_m / 2)]


def wait_until_still(robot: RealRobot, arm: str, seconds: float = 2.0) -> None:
    """Block until the servos stop moving, or `seconds` pass."""
    last, deadline = None, time.monotonic() + seconds
    while time.monotonic() < deadline:
        now = robot.measured(arm)
        if last and max(abs(now[j] - last[j]) for j in now) < 0.3:
            return
        last = now
        if robot.realtime:
            time.sleep(0.05)


# --- opening one -------------------------------------------------------------

#: Bodies with a hardware driver. One so far; a second is a wire module and a line here.
DRIVERS = ("roarm_m2",)


def find_device() -> str | None:
    """The arm's serial port, when exactly one candidate is plugged in."""
    import glob

    found = [
        path
        for pattern in (
            "/dev/cu.usbserial*",
            "/dev/cu.wchusbserial*",
            "/dev/cu.SLAB*",
            "/dev/ttyUSB*",
            "/dev/ttyACM*",
        )
        for path in glob.glob(pattern)
    ]
    return found[0] if len(found) == 1 else None


def open_real(
    platform,
    *,
    execute: bool,
    device: str | None = None,
    loopback: bool = False,
    camera: bool = True,
    view: bool = False,
):
    """The robot `--real` serves. Returns (robot, one line saying what it is).

    execute=False is a dry run: the real camera, the twin, and no port opened.
    loopback=True needs no hardware at all — see botcortex.loopback.
    camera=False serves without vision. view=True opens a camera that is
    chosen but not calibrated anyway, as `robot.feed`, to be watched.
    """
    from botcortex import camera as cameras
    from botcortex.roarm import RoArmLink

    if platform.name not in DRIVERS:
        raise ValueError(
            f"{platform.display_name} has no hardware driver yet (have: {', '.join(DRIVERS)}). "
            "Set BOTCORTEX_PLATFORM to one that does."
        )
    if loopback:
        from botcortex.loopback import LoopbackPort

        world = SimRobot(platform, realtime=False)
        robot = RealRobot(
            platform, link=RoArmLink(LoopbackPort(world)), camera=cameras.SimCamera(world)
        )
        return robot, "loopback — a simulated arm and camera behind the real wire protocol"
    from botcortex import settings as chosen

    eye, hues, feed = None, {}, None
    found = cameras.load_settings(cameras.settings_path(config.DATA_DIR, platform.name))
    if view and "kind" in found and (not camera or "camera_to_base" not in found):
        feed = cameras.open_camera(found)
    if camera:
        if "camera_to_base" not in found:
            if feed is not None:
                feed.close()
            raise ValueError(
                "the camera is not set up. Three commands, in order:\n"
                "  botcortex camera list\n"
                "  botcortex camera use webcam 0        (or: realsense)\n"
                "  botcortex camera calibrate --execute\n"
                "Or serve blind for now: botcortex serve --real --no-camera"
            )
        eye = cameras.open_camera(found)
        hues = found.get("hues") or {}
    signs = wire_signs(chosen.get("wire_signs"))
    # This robot's bench, when the owner has described one: what is really
    # there in place of the scene's stock blocks. See botcortex.bench.
    from botcortex import bench

    bench_path = bench.path(config.DATA_DIR, platform.name)
    world = bench.world_for(platform, bench_path)
    looks = {
        o["name"]: (int(o["seen_px"]), float(o["seen_at_m"]))
        for o in bench.load(bench_path)["objects"]
        if o.get("seen_px") and o.get("seen_at_m")
    }
    if not execute:
        robot = RealRobot(platform, link=None, camera=eye, signs=signs, world=world)
        robot.hues = dict(hues)
        robot.looks = looks
        robot.feed = feed
        return robot, "DRY RUN — no motion (add --execute to move the arm)"
    device = device or chosen.get("device") or find_device()
    if device is None:
        raise ValueError(
            "could not tell which serial port is the arm. See what is plugged in with "
            "`botcortex arm status`, then: botcortex config set device /dev/…"
        )
    robot = RealRobot(
        platform, link=RoArmLink.open_serial(device), camera=eye, signs=signs, world=world
    )
    robot.hues = dict(hues)
    robot.looks = looks
    robot.feed = feed
    return robot, f"LIVE on {device}"


def wire_signs(value) -> dict[str, int]:
    """Joints whose direction is reversed on this unit: {"j1": -1}. Written by
    `botcortex arm check`; read from settings, where it may be JSON text."""
    if isinstance(value, str):
        try:
            value = json.loads(value)
        except ValueError:
            return {}
    return {str(j): -1 for j, v in (value or {}).items() if v in (-1, "-1")}
