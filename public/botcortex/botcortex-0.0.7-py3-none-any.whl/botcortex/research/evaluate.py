"""The evaluation runner: leave-one-embodiment-out, on a frozen outcome table.

Every attempt the selectors could make is a deterministic simulation —
one body, one task, one injected fault, one repair — so the honest way to
compare selectors is to run each such attempt ONCE, cache its verified
outcome, and score every selector against the same table. No arm gets
luckier physics than another, and the whole comparison reruns in seconds.

    python -m botcortex.research.evaluate cache roarm_m2            # every task
    python -m botcortex.research.evaluate cache roarm_m2 push       # one task
    python -m botcortex.research.evaluate run                       # score the arms

The cache holds, per (platform, task, fault, repair): the episode's
contract signature and trace text, and whether the verifier passed it.
Faults that took no effect on a body (the verdict was already ok) are not
failure cases and are reported separately, not scored — an injection that
did nothing would flatter every selector equally. A task whose CLEAN run
fails on a body is coverage, not a failure case either: the body cannot
do the task, and the cache says so instead of injecting faults into a
program that was never going to pass.

Scoring, per held-out body, task and effective fault, for each arm:
  attempts to verified recovery, censored at `budget`.
Memory for the target is built from the OTHER bodies' records — every
(task, fault, repair, recovered) they observed, on every task — with the
target's declared simulated variants excluded. `target_only` memory is
leave-one-fault-out on the target's own records, so a fault is never
diagnosed from its own trial.
"""

from __future__ import annotations

import json
import statistics
import sys
import tempfile
from collections import defaultdict
from dataclasses import asdict, dataclass, field
from pathlib import Path

from botcortex.platform import MODELS_DIR, available_platforms, load_platform
from botcortex.research import benchmark
from botcortex.research import probes as probelib
from botcortex.research import repairs as repairlib
from botcortex.research import selector as selectorlib
from botcortex.research.evidence import run_trial, trial_identity
from botcortex.research.memory import MODES, RepairMemory, RepairRecord
from botcortex.research.signature import contract_signature, trace_text

#: v2: rows carry the task family and the robot patches; the first slice's
#: single-task tables live beside it untouched.
CACHE_DIR = Path(MODELS_DIR).parent / "research" / "v2"
BUDGET = 8

#: Embodiments that are simulated variants of a physical body and must not
#: be a memory source for it: the OpenArm sim IS the OpenArm rig's twin.
#: Grows as hardware anchors arrive (the RoArm sim vs the RoArm-M2-Pro).
VARIANTS: dict[str, tuple[str, ...]] = {}


@dataclass
class Outcome:
    platform: str
    task: str
    fault: str  # "clean" or Fault.name
    repair: str  # "none" or Repair.name
    outcome: str
    error: str | None
    verdict: str
    violations: list[str]
    signature: dict
    trace: str
    recovered: bool
    identity: str = ""
    derived_from: str = ""
    #: Probe results measured after the unrepaired failure, keyed by probe
    #: name. Only rows with repair == "none" carry them. A selector pays to
    #: look; the table just remembers what it would have seen.
    probes: dict = field(default_factory=dict)
    #: Why a task was not run on this body, on its "clean" row: the binding
    #: reason, or "" when it ran.
    note: str = ""


Key = tuple[str, str, str]  # (task, fault, repair)


# --- filling the table --------------------------------------------------------


def cache_path(platform: str) -> Path:
    return CACHE_DIR / f"outcomes_{platform}.jsonl"


def _fresh(platform, work: Path):
    from botcortex.sim import SimRobot

    return SimRobot(platform=platform, stop_file=work / "STOP", realtime=False)


def build_cache(platform_name: str, families: list[str] | None = None) -> Path:
    platform = load_platform(platform_name)
    if not platform.model_available:
        raise SystemExit(f"{platform_name}: model not available (scripts/fetch_models.py)")
    path = cache_path(platform_name)
    path.parent.mkdir(parents=True, exist_ok=True)
    existing = load_cache(platform_name)
    done = {(o.task, o.fault, o.repair) for o in existing}
    simulated: dict[str, Outcome] = {o.identity: o for o in existing if o.identity}
    tasks = [benchmark.task(f) for f in families] if families else list(benchmark.TASKS)

    with path.open("a") as out:

        def record(row: Outcome) -> None:
            out.write(json.dumps(asdict(row), sort_keys=True) + "\n")
            out.flush()
            tag = f"= {row.derived_from}" if row.derived_from else (row.note and f"({row.note})")
            print(
                f"{platform_name:11s} {row.task:28s} {row.fault:24s} {row.repair:30s} {row.verdict} {tag}",
                flush=True,
            )

        for task in tasks:
            probe_robot = _fresh(platform, Path(tempfile.mkdtemp(prefix="bx_scene_")))
            scene = probe_robot.describe_scene()
            bindable, why = task.bindable(platform, scene)
            layout = task.layout(scene) if bindable else {}
            contract = task.contract(scene) if bindable else None
            source = task.source

            if (task.family, "clean", "none") not in done:
                if not bindable:
                    record(
                        Outcome(
                            platform_name,
                            task.family,
                            "clean",
                            "none",
                            "unbound",
                            None,
                            "unknown",
                            [],
                            {},
                            "",
                            False,
                            note=why,
                        )
                    )
                    done.add((task.family, "clean", "none"))
                    continue
                work = Path(tempfile.mkdtemp(prefix="bx_trial_"))
                trial = run_trial(
                    _fresh(platform, work), source, contract, None, work, layout=layout
                )
                row = _row(
                    platform_name,
                    task.family,
                    "clean",
                    "none",
                    trial,
                    trial_identity(source, None, None, layout),
                )
                simulated[row.identity] = row
                record(row)
                done.add((task.family, "clean", "none"))
            clean = next(
                (
                    o
                    for o in load_cache(platform_name)
                    if o.task == task.family and o.fault == "clean"
                ),
                None,
            )
            if clean is None or not clean.recovered:
                # The body cannot do this task as written: coverage, not a
                # failure case. Nothing to inject into.
                continue

            grid: list[tuple] = [(f, None) for f in task.faults()] + [
                (f, r) for f in task.faults() for r in repairlib.catalog()
            ]
            # A repair that changes neither the program, the observation
            # pipeline nor the robot runs the SAME trial as the unrepaired
            # fault, and the simulation is deterministic. Simulate each
            # distinct trial once and record the rest as its outcome.
            for fault, repair in grid:
                key = (task.family, fault.name, repair.name if repair else "none")
                if key in done:
                    continue
                identity = trial_identity(source, fault, repair, layout)
                if identity in simulated:
                    twin = simulated[identity]
                    row = Outcome(
                        **{
                            **asdict(twin),
                            "task": key[0],
                            "fault": key[1],
                            "repair": key[2],
                            "derived_from": f"{twin.task}/{twin.fault}/{twin.repair}",
                        }
                    )
                else:
                    work = Path(tempfile.mkdtemp(prefix="bx_trial_"))
                    trial = run_trial(
                        _fresh(platform, work),
                        source,
                        contract,
                        fault,
                        work,
                        repair=repair,
                        layout=layout,
                    )
                    probes: dict = {}
                    if repair is None and trial.verdict.ok is not True:
                        for probe in probelib.CATALOG:
                            try:
                                probes[probe.name] = probelib.run_probe(
                                    probe, trial.robot, trial.perception, task.target
                                )
                            except Exception as e:  # noqa: BLE001 - a probe that cannot run is a None measurement
                                probes[probe.name] = None
                                print(f"  probe {probe.name} failed: {e}", flush=True)
                    row = _row(platform_name, *key, trial, identity, probes)
                    simulated[identity] = row
                record(row)
                done.add(key)
    return path


def _row(
    platform: str,
    task: str,
    fault: str,
    repair: str,
    trial,
    identity: str,
    probes: dict | None = None,
) -> Outcome:
    return Outcome(
        platform=platform,
        task=task,
        fault=fault,
        repair=repair,
        outcome=trial.episode.outcome,
        error=trial.episode.error,
        verdict=trial.verdict.status,
        violations=list(trial.verdict.violations),
        signature=contract_signature(trial.episode),
        trace=trace_text(trial.episode),
        recovered=trial.verdict.ok is True,
        identity=identity,
        probes=probes or {},
    )


def load_cache(platform_name: str) -> list[Outcome]:
    path = cache_path(platform_name)
    if not path.exists():
        return []
    out = []
    for line in path.read_text().splitlines():
        if not line:
            continue
        data = json.loads(line)
        sig = data["signature"]
        for key in ("violations", "moved_by_program_view"):
            if key in sig:
                sig[key] = tuple(sig[key])
        out.append(Outcome(**data))
    return out


# --- scoring ---------------------------------------------------------------------


def _table(platforms: list[str]) -> dict[str, dict[Key, Outcome]]:
    return {p: {(o.task, o.fault, o.repair): o for o in load_cache(p)} for p in platforms}


def tasks_in(table: dict[Key, Outcome]) -> list[str]:
    return sorted({task for (task, _f, _r) in table})


def coverage(table: dict[Key, Outcome]) -> dict[str, str]:
    """Per task: "ok" when the clean run passed, else why not."""
    out = {}
    for task in tasks_in(table):
        clean = table.get((task, "clean", "none"))
        if clean is None:
            out[task] = "no clean run cached"
        elif clean.outcome == "unbound":
            out[task] = f"unbound: {clean.note}"
        elif not clean.recovered:
            out[task] = (
                f"clean run failed: {'; '.join(clean.violations) or clean.error or clean.verdict}"
            )
        else:
            out[task] = "ok"
    return out


def effective_faults(table: dict[Key, Outcome], task: str) -> list[str]:
    """Faults whose unrepaired trial failed on this body, for this task."""
    if coverage(table).get(task) != "ok":
        return []
    return sorted(
        fault
        for (t, fault, repair), o in table.items()
        if t == task and repair == "none" and fault != "clean" and not o.recovered
    )


def _records_for(
    platform: str, table: dict[Key, Outcome], split: str
) -> list[tuple[str, str, RepairRecord]]:
    """What a body remembers after exploring its own failures: one record per
    (task, fault, repair) it tried, keyed by the failure's signature. The
    task and fault names ride beside each record for the RUNNER's
    bookkeeping only — the fault is the sealed label, and it never enters
    the memory the selector reads."""
    records = []
    for task in tasks_in(table):
        for fault in effective_faults(table, task):
            failed = table[(task, fault, "none")]
            signature = {**failed.signature, "probes": dict(failed.probes)}
            for repair in repairlib.catalog():
                after = table.get((task, fault, repair.name))
                if after is None:
                    continue
                records.append(
                    (
                        task,
                        fault,
                        RepairRecord(
                            platform=platform,
                            capability_hash="",
                            task=task,
                            skill_hash_before="",
                            skill_hash_after="",
                            signature=signature,
                            trace=failed.trace,
                            repair=repair.name,
                            recovered=after.recovered,
                            verdict_after=after.verdict,
                            split=split,
                        ),
                    )
                )
    return records


def attempts_to_recovery(
    selector: selectorlib.Selector,
    table: dict[Key, Outcome],
    task: str,
    fault: str,
    budget: int = BUDGET,
    probe_cost: float | None = None,
) -> tuple[float | None, list[str]]:
    """How many budget units the selector spends before the verifier passes:
    one per repair attempt and one per probe. None when the budget runs
    out. Also the sequence it tried, probes marked `probe:<name>`."""
    failed = table[(task, fault, "none")]
    signature = {**failed.signature, "probes": dict(failed.signature.get("probes", {}))}
    tried: list[str] = []
    spent = 0.0
    while spent < budget:
        repairs_tried = tuple(t for t in tried if not t.startswith("probe:"))
        probe = selector.request_probe(signature, failed.trace, repairs_tried)
        if probe is not None and probe in failed.probes:
            signature["probes"][probe] = failed.probes[probe]
            tried.append(f"probe:{probe}")
            spent += probelib.BY_NAME[probe].cost if probe_cost is None else probe_cost
            continue
        proposals = selector.propose(signature, failed.trace, repairs_tried)
        if not proposals:
            break
        choice = proposals[0]
        tried.append(choice)
        spent += 1
        after = table.get((task, fault, choice))
        if after is not None and after.recovered:
            return spent if spent != int(spent) else int(spent), tried
    return None, tried


@dataclass
class ArmResult:
    target: str
    task: str
    fault: str
    arm: str
    attempts: float | None
    tried: list[str]
    first_choice_family_right: bool
    probes: int = 0


def _arms(target, memory, target_records, task, fault, excluded, seed):
    def mem(mode, min_match=0.5):
        return _memory_selector(
            mode, target, memory, target_records, task, fault, excluded, min_match
        )

    return (
        [
            ("always_program", selectorlib.always_program()),
            ("always_perception", selectorlib.always_perception()),
            ("always_calibrate", selectorlib.always_calibrate()),
            ("rules", selectorlib.RuleSelector()),
            ("rules+rule_probe", selectorlib.RuleSelector().with_probing("rule")),
            ("rules+random_probe", selectorlib.RuleSelector().with_probing("random", seed)),
        ]
        + [(f"memory:{mode}", mem(mode)) for mode in MODES]
        + [
            (f"memory:{mode}{tag}", mem(mode, m))
            for mode in ("target_only", "cross_body")
            for m, tag in ((0.8, "_strict"), (1.0, "_exact"))
        ]
        + [
            ("memory:cross_body_exact+rule_probe", mem("cross_body", 1.0).with_probing("rule")),
            (
                "memory:cross_body_exact+random_probe",
                mem("cross_body", 1.0).with_probing("random", seed),
            ),
            ("memory:cross_body+rule_probe", mem("cross_body").with_probing("rule")),
        ]
    )


def evaluate(
    platforms: list[str] | None = None,
    budget: int = BUDGET,
    probe_cost: float | None = None,
    families: list[str] | None = None,
) -> dict:
    """Leave-one-embodiment-out over every cached body and task. `probe_cost`
    overrides every probe's cost, to show how the value of measuring
    depends on what measuring costs relative to a task attempt."""
    platforms = platforms or [p for p in available_platforms() if cache_path(p).exists()]
    tables = _table(platforms)
    results: list[ArmResult] = []
    skipped: dict[str, dict[str, list[str]]] = {}
    covered: dict[str, dict[str, str]] = {}
    for target in platforms:
        table = tables[target]
        covered[target] = coverage(table)
        skipped[target] = {}
        excluded = VARIANTS.get(target, ())
        with tempfile.TemporaryDirectory() as tmp:
            memory = RepairMemory(Path(tmp) / "repairs.jsonl")
            for source in platforms:
                if source == target or source in excluded:
                    continue
                for _task, _fault, record in _records_for(source, tables[source], "train"):
                    memory.append(record)
            target_records = _records_for(target, table, "target")
            for task in tasks_in(table):
                if families and task not in families:
                    continue
                faults = effective_faults(table, task)
                skipped[target][task] = sorted(
                    f
                    for (t, f, r) in table
                    if t == task and r == "none" and f != "clean" and f not in faults
                )
                for fault in faults:
                    fault_family = fault.split(":")[0]
                    seed = hash((target, task, fault)) & 0xFFFF
                    for arm_name, selector in _arms(
                        target, memory, target_records, task, fault, excluded, seed
                    ):
                        attempts, tried = attempts_to_recovery(
                            selector, table, task, fault, budget, probe_cost
                        )
                        repairs_only = [t for t in tried if not t.startswith("probe:")]
                        results.append(
                            ArmResult(
                                target,
                                task,
                                fault,
                                arm_name,
                                attempts,
                                tried,
                                bool(repairs_only)
                                and repairs_only[0].split(":")[0] == fault_family,
                                probes=len(tried) - len(repairs_only),
                            )
                        )
    return {
        "results": [asdict(r) for r in results],
        "skipped": skipped,
        "coverage": covered,
        "budget": budget,
        "probe_cost": probe_cost,
    }


def _memory_selector(mode, target, memory, target_records, task, fault, excluded, min_match=0.5):
    if mode == "target_only":
        # Leave-one-fault-out on the target's own records: the body has
        # explored its other failures, never this one on this task. The
        # runner uses the sealed names to leave it out; the selector still
        # sees only signatures and repairs.
        own = RepairMemory(Path(tempfile.mkdtemp(prefix="bx_own_")) / "own.jsonl")
        for recorded_task, recorded_fault, record in target_records:
            if not (recorded_task == task and recorded_fault == fault):
                own.append(record)
        return selectorlib.MemorySelector(own, mode, target, excluded, min_match=min_match)
    return selectorlib.MemorySelector(memory, mode, target, excluded, min_match=min_match)


def summarize(evaluation: dict) -> str:
    results = evaluation["results"]
    budget = evaluation["budget"]
    by_arm: dict[str, list] = defaultdict(list)
    by_target_arm: dict[tuple[str, str], list] = defaultdict(list)
    by_task_arm: dict[tuple[str, str], list] = defaultdict(list)
    family_right: dict[str, list[bool]] = defaultdict(list)
    for r in results:
        by_arm[r["arm"]].append(r["attempts"])
        by_target_arm[(r["target"], r["arm"])].append(r["attempts"])
        by_task_arm[(r["task"], r["arm"])].append(r["attempts"])
        family_right[r["arm"]].append(r["first_choice_family_right"])

    def cell(values: list) -> str:
        if not values:
            return "-"
        solved = [v for v in values if v is not None]
        censored = len(values) - len(solved)
        mean = statistics.mean(solved) if solved else float("nan")
        return (
            f"{mean:.2f} ({len(solved)}/{len(values)} within {budget})"
            if censored
            else f"{mean:.2f}"
        )

    targets = sorted({r["target"] for r in results})
    tasks = sorted({r["task"] for r in results})
    arms = list(by_arm)
    baseline = {
        (r["target"], r["task"], r["fault"]): r["attempts"]
        for r in results
        if r["arm"] == "memory:none"
    }
    lines = [
        f"Cases: {len({(r['target'], r['task'], r['fault']) for r in results})} (body, task, fault) triples.",
        "",
        "### By body",
        "",
        "| arm | "
        + " | ".join(targets)
        + " | all (repairs + probes) | probes | saved vs no memory | worse than no memory | first pick in right family |",
        "|---" * (len(targets) + 6) + "|",
    ]
    for arm in arms:
        cells = [cell(by_target_arm[(t, arm)]) for t in targets]
        right = family_right[arm]
        rows = [r for r in results if r["arm"] == arm]
        saved = [
            (baseline[(r["target"], r["task"], r["fault"])] or budget) - (r["attempts"] or budget)
            for r in rows
        ]
        worse = sum(1 for s in saved if s < 0)
        probes = sum(r.get("probes", 0) for r in rows)
        lines.append(
            f"| {arm} | " + " | ".join(cells) + f" | {cell(by_arm[arm])} | {probes} | "
            f"{statistics.mean(saved):+.2f} | {worse}/{len(rows)} | {sum(right)}/{len(right)} |"
        )
    lines += [
        "",
        "### By task",
        "",
        "| arm | " + " | ".join(tasks) + " |",
        "|---" * (len(tasks) + 1) + "|",
    ]
    for arm in arms:
        lines.append(f"| {arm} | " + " | ".join(cell(by_task_arm[(t, arm)]) for t in tasks) + " |")
    lines.append("")
    lines.append("Coverage (clean run per body and task):")
    for target, per_task in evaluation.get("coverage", {}).items():
        lines.append(
            f"- {target}: " + "; ".join(f"{task} {status}" for task, status in per_task.items())
        )
    lines.append("")
    lines.append("Skipped (fault took no effect on that body and task, so not a failure case):")
    for target, per_task in evaluation["skipped"].items():
        for task, faults in per_task.items():
            if faults:
                lines.append(f"- {target}/{task}: {', '.join(faults)}")
    return "\n".join(lines)


def main(argv: list[str]) -> None:
    if not argv:
        raise SystemExit(__doc__)
    if argv[0] == "cache":
        names = [a for a in argv[1:] if a in available_platforms()] or available_platforms()
        families = [a for a in argv[1:] if a in benchmark.BY_FAMILY] or None
        for name in names:
            build_cache(name, families)
    elif argv[0] == "run":
        platforms = [a for a in argv[1:] if a in available_platforms()] or None
        evaluation = evaluate(platforms)
        CACHE_DIR.mkdir(parents=True, exist_ok=True)
        out = CACHE_DIR / "evaluation.json"
        out.write_text(json.dumps(evaluation, indent=1))
        print("## probes charged as a full attempt (cost 1.0)\n")
        print(summarize(evaluation))
        cheap = evaluate(platforms, probe_cost=0.25)
        (CACHE_DIR / "evaluation_probe_cost_0.25.json").write_text(json.dumps(cheap, indent=1))
        print("\n## probes charged at a quarter of an attempt (cost 0.25)\n")
        print(summarize(cheap))
        print(f"\nwrote {out}")
    else:
        raise SystemExit(__doc__)


if __name__ == "__main__":
    main(sys.argv[1:])
