"""The optional link between this robot and BotCortex cloud.

The agent stays HERE, on the robot, holding the primitives, the skill store,
and the memory. All this module does is let the robot reach a model through
our metered endpoint instead of paying a vendor directly, and push a copy of
each authored skill up for the registry.

Two modes, decided by whether a robot key is present:

  BOTCORTEX_API_KEY set  → model calls go to BotCortex, billed to credits.
  unset                  → the vendor SDKs use their own keys, exactly as
                           before. This is the BYO-model path and it must
                           stay byte-identical, because "bring your own key"
                           is a promise, not a fallback.

There is a third state, and it is a bug rather than a mode: BOTCORTEX_API_URL
naming our cloud with no key to reach it. See half_paired().
"""

from __future__ import annotations

import json
import os
import socket
import time
import urllib.error
import urllib.request
from pathlib import Path

from botcortex import config

#: The gitignored file config.py loads on import, and reload() re-reads.
ENV_PATH = Path(__file__).parent.parent / ".env"

#: Sync is a courtesy, never a dependency. A robot with a flaky uplink still
#: teaches at full speed; the copy just arrives late or not at all.
SYNC_TIMEOUT_S = 3.0


def reload() -> None:
    """Re-read .env so a key swapped on disk takes effect on the next teach.

    Config is read once at import, which meant pairing a robot — or rotating
    its key — left the process authenticating as whatever it started with
    until someone restarted it. Nothing in the UI said so; the teach just
    failed with a 401 about a key the owner had already replaced.

    Deliberately NOT called from module import or from cloud helpers: tests
    monkeypatch config.API_KEY directly, and a reload underneath them would
    quietly undo it.

    Reads the file into a dict rather than load_dotenv(override=True), which
    re-applies EVERY key in .env over the process environment — so a var set
    deliberately at launch (`OPENAI_API_KEY=... botcortex serve`) was silently
    replaced by the file on the first teach. Only the two settings this
    function owns are touched; the file wins for those, since `botcortex
    login` writes there, and the environment fills in when it is absent.
    """
    from dotenv import dotenv_values

    values = dotenv_values(ENV_PATH) if ENV_PATH.exists() else {}
    config.API_KEY = values.get("BOTCORTEX_API_KEY") or os.environ.get("BOTCORTEX_API_KEY")
    url = values.get("BOTCORTEX_API_URL") or os.environ.get("BOTCORTEX_API_URL")
    if url:
        config.API_URL = url.rstrip("/")


def enabled() -> bool:
    return bool(config.API_KEY)


def _configured(name: str) -> str | None:
    """What .env or the environment says about a setting, read fresh.

    Deliberately does NOT touch `config` — that is reload()'s job, scoped to
    the teach path. Anything that merely REPORTS the robot's wiring (the
    startup banner, the app's hello) reads through here, so asking a question
    can never mutate the process being asked about.
    """
    from dotenv import dotenv_values

    values = dotenv_values(ENV_PATH) if ENV_PATH.exists() else {}
    return values.get(name) or os.environ.get(name)


def paired() -> bool:
    """Whether a robot key is configured right now.

    Read fresh rather than from config, so a robot paired since launch answers
    honestly without a restart — the same reason teach() calls reload().
    """
    return bool(_configured("BOTCORTEX_API_KEY"))


def half_paired() -> bool:
    """Pointed at BotCortex, with no key to reach it.

    A BROKEN configuration, not the BYO-model path. BYO means no
    BOTCORTEX_API_URL at all: the vendor SDKs use the owner's own keys and our
    cloud is not involved. Naming our API and then omitting the key means
    someone meant to pair and did not finish — and the old behaviour was to
    fall through to the vendor key in silence. Teaching kept working, so
    nothing looked wrong, while the web app showed a credit balance that could
    never move: the owner was paying OpenAI directly with no way to tell.

    Callers refuse this state rather than degrade into it.
    """
    return bool(_configured("BOTCORTEX_API_URL")) and not paired()


def openai_kwargs() -> dict:
    """Client kwargs for the OpenAI SDK, which appends /chat/completions to
    whatever base_url it is given — so ours must already end in /v1."""
    if not enabled():
        return {}
    return {"api_key": config.API_KEY, "base_url": f"{config.API_URL}/v1"}


def anthropic_kwargs() -> dict:
    """Client kwargs for the Anthropic SDK, which appends /v1/messages — so
    ours must be the bare root. The asymmetry with OpenAI is the SDKs', not
    ours; both land on the same two proxy routes."""
    if not enabled():
        return {}
    return {"api_key": config.API_KEY, "base_url": config.API_URL}


def _post(path: str, payload: dict) -> dict | None:
    request = urllib.request.Request(
        f"{config.API_URL}{path}",
        data=json.dumps(payload).encode(),
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {config.API_KEY}",
        },
        method="POST",
    )
    with urllib.request.urlopen(request, timeout=SYNC_TIMEOUT_S) as response:
        return json.loads(response.read() or "null")


def sync_skill(name: str, description: str, code: str) -> bool:
    """Push a copy of an authored skill to the registry. Returns whether it
    landed. Never raises: a teach must not fail because our API is down."""
    if not enabled():
        return False
    try:
        _post(
            "/v1/skills",
            {
                "name": name,
                "description": description,
                "code": code,
                "platform": config.PLATFORM.name,
            },
        )
        return True
    except (urllib.error.URLError, OSError, ValueError):
        return False


def rank_skills(query: str, candidates: list[dict]) -> list[str] | None:
    """Working skills ordered by how like the task they MEAN, best first — or
    None when the api cannot say (not paired, no credit, down), and the runtime
    falls back to counting shared words. Never raises."""
    if not enabled() or not candidates:
        return None
    try:
        answer = _post("/v1/similar", {"query": query, "candidates": candidates})
    except (urllib.error.URLError, OSError, ValueError):
        return None
    ranked = (answer or {}).get("ranked")
    return [row["name"] for row in ranked] if isinstance(ranked, list) else None


def forget(name: str) -> str:
    """Remove the registry's copy of a skill; the robot's own file is the
    caller's job. Returns what happened rather than a bool, because a human
    typed this command and "done" must not cover three different outcomes:

      "deleted"      the registry copy is gone
      "absent"       the registry never had one (or it was already gone)
      "refused"      the key was rejected — re-pair
      "unreachable"  our API did not answer; the copy, if any, survives
    """
    if not enabled():
        return "absent"
    try:
        status, _body = _call(
            f"{config.API_URL}/v1/skills/{name}", token=config.API_KEY, method="DELETE"
        )
    except (urllib.error.URLError, OSError, ValueError):
        return "unreachable"
    if status == 200:
        return "deleted"
    if status == 404:
        return "absent"
    if status == 401:
        return "refused"
    return "unreachable"


#: The client id botcortex-api's validateClient allows.
CLI_CLIENT_ID = "botcortex-cli"

#: Poll/handshake calls are interactive — a human is watching a spinner.
PAIR_TIMEOUT_S = 15.0


def _call(
    url: str, payload: dict | None = None, token: str | None = None, method: str = "POST"
) -> tuple[int, dict]:
    """HTTP without raising on 4xx — the device flow signals with status codes
    and error bodies, so treating those as exceptions would fight the protocol."""
    headers = {"Content-Type": "application/json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    request = urllib.request.Request(
        url,
        data=json.dumps(payload).encode() if payload is not None else None,
        headers=headers,
        method=method,
    )
    try:
        with urllib.request.urlopen(request, timeout=PAIR_TIMEOUT_S) as response:
            return response.status, json.loads(response.read() or "null")
    except urllib.error.HTTPError as e:
        body = e.read()
        try:
            return e.code, json.loads(body or "null")
        except ValueError:
            return e.code, {"error": body.decode(errors="replace")[:200]}


def start_pairing() -> dict:
    """Ask for a device code and the short code a human will type."""
    status, body = _call(
        f"{config.API_URL}/api/auth/device/code",
        {"client_id": CLI_CLIENT_ID, "scope": "teach"},
    )
    if status != 200:
        raise RuntimeError(body.get("error_description") or body.get("error") or "pairing refused")
    return body


def describe(device_code: str, name: str, platform: str, arms: int) -> bool:
    """Tell the approval screen what it is approving. Authenticated by the
    SECRET device code, so nobody can plant a name on someone else's pairing."""
    status, _ = _call(
        f"{config.API_URL}/v1/device/describe",
        {"device_code": device_code, "name": name, "platform": platform, "arms": arms},
    )
    return status == 200


def poll_for_approval(device_code: str, interval: int, expires_in: int) -> str:
    """Block until a human approves, then return the session token.

    Backs off on slow_down as RFC 8628 requires — polling tighter than the
    server's interval earns errors that look like a broken flow.
    """
    deadline = time.monotonic() + expires_in
    wait = max(1, interval)
    while time.monotonic() < deadline:
        time.sleep(wait)
        status, body = _call(
            f"{config.API_URL}/api/auth/device/token",
            {
                "grant_type": "urn:ietf:params:oauth:grant-type:device_code",
                "device_code": device_code,
                "client_id": CLI_CLIENT_ID,
            },
        )
        token = body.get("access_token")
        if status == 200 and token:
            return token
        error = body.get("error")
        if error == "authorization_pending":
            continue
        if error == "slow_down":
            wait += 5
            continue
        raise RuntimeError(
            {
                "access_denied": "Pairing was denied in the browser.",
                "expired_token": "The code expired — run `botcortex login` again.",
            }.get(error, body.get("error_description") or error or "pairing failed")
        )
    raise RuntimeError("The code expired — run `botcortex login` again.")


def exchange_for_key(access_token: str, name: str) -> dict:
    """Trade the short-lived device session for the durable key the robot runs
    on. This is the step that needs the server's bearer plugin."""
    status, body = _call(f"{config.API_URL}/v1/keys/exchange", {"name": name}, token=access_token)
    if status != 201:
        raise RuntimeError(body.get("error") or "could not mint a robot key")
    return body


def register(key: str, device_code: str, name: str, platform: str, arms: int, address: str) -> bool:
    """Claim the described row and publish the LAN address the web app dials."""
    status, _ = _call(
        f"{config.API_URL}/v1/robots/register",
        {
            "device_code": device_code,
            "name": name,
            "platform": platform,
            "arms": arms,
            "address": address,
        },
        token=key,
    )
    return status == 200


def lan_address(port: int = 9090) -> str:
    """This machine's address on the local network. Opening a UDP socket to a
    public IP sends nothing — it just makes the OS pick the outbound interface,
    which is the only reliable way to learn which of several NICs a browser on
    the same LAN would reach us on."""
    probe = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        probe.connect(("8.8.8.8", 80))
        host = probe.getsockname()[0]
    except OSError:
        host = "localhost"
    finally:
        probe.close()
    return f"{host}:{port}"


def save_key(key: str, env_path: Path | None = None) -> Path:
    """Write the key into the same gitignored .env config.py already reads.

    Replaces any existing BOTCORTEX_API_KEY rather than appending, so re-pairing
    a robot doesn't leave a stale key that dotenv might load instead.

    Deliberately NOT a config.toml parser — the blueprint wants one eventually,
    but inventing a config format is its own decision, and .env is what the
    runtime loads today.
    """
    path = env_path or ENV_PATH
    lines = path.read_text().splitlines() if path.exists() else []
    lines = [ln for ln in lines if not ln.startswith("BOTCORTEX_API_KEY=")]
    lines.append(f"BOTCORTEX_API_KEY={key}")
    path.write_text("\n".join(lines) + "\n")
    path.chmod(0o600)
    return path


def whoami() -> dict | None:
    """Who this robot's key belongs to, and what credit is left. Used by
    `botcortex login` to prove a key works before it is written to disk."""
    if not enabled():
        return None
    request = urllib.request.Request(
        f"{config.API_URL}/v1/me",
        headers={"Authorization": f"Bearer {config.API_KEY}"},
    )
    try:
        with urllib.request.urlopen(request, timeout=SYNC_TIMEOUT_S) as response:
            return json.loads(response.read())
    except (urllib.error.URLError, OSError, ValueError):
        return None
