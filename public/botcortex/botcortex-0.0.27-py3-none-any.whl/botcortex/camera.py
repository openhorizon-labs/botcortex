"""A camera, as the runtime is handed one: colour, depth, and where it stands.

Three sources answer the same `frame()` call, and nothing above this file
knows which one it has:

- `SimCamera` renders a MuJoCo world, which is what lets every line of the
  vision path be tested on a laptop with no sensor attached.
- `RealSenseCamera` reads an Intel RealSense with depth aligned to colour.
- `OpenCVCamera` reads anything OpenCV can open: a USB webcam, a laptop's own
  camera, a phone or IP camera by URL. Colour only — `Frame.depth` is None —
  and `vision` then places objects by where their ray meets the surface they
  rest on. That is enough for a bench; what it costs is said in vision.py.

The camera frame is the computer-vision one: x right, y down, z out of the
lens. `Frame.pose` is camera-to-base, 4x4, in metres. A RealSense does not
know where it is bolted; that comes from `vision.calibrate` and lives in a
file beside the user's config, one per body.

Native only. Nothing the browser imports may import this: numpy is here at
module level on purpose, and the tab has no camera to read.
"""

from __future__ import annotations

import json
import math
import time
from dataclasses import dataclass
from pathlib import Path

import numpy as np


@dataclass(frozen=True)
class Frame:
    rgb: np.ndarray  #: H x W x 3, uint8
    depth: (
        np.ndarray | None
    )  #: H x W metres along the optical axis, 0 = unknown; None = colour only
    fx: float
    fy: float
    cx: float
    cy: float
    pose: np.ndarray | None  #: camera-to-base, or None before calibration

    def points_in_camera(self) -> np.ndarray:
        """H x W x 3: where each pixel's surface is, in the camera frame."""
        h, w = self.depth.shape
        u, v = np.meshgrid(np.arange(w), np.arange(h))
        z = self.depth
        return np.stack(((u - self.cx) / self.fx * z, (v - self.cy) / self.fy * z, z), axis=-1)

    def rays_in_camera(self, pixels: np.ndarray) -> np.ndarray:
        """Unit-depth directions (..., 3) through pixel coordinates (..., 2)."""
        u, v = pixels[..., 0], pixels[..., 1]
        return np.stack(
            ((u - self.cx) / self.fx, (v - self.cy) / self.fy, np.ones_like(u)), axis=-1
        )


def to_base(pose: np.ndarray, points: np.ndarray) -> np.ndarray:
    """Camera-frame points (..., 3) into the robot's base frame."""
    return points @ pose[:3, :3].T + pose[:3, 3]


class SimCamera:
    """A camera looking at a MuJoCo world: `world` is anything with `.model`,
    `.data` and `._mujoco` (a SimRobot). Aimed like MuJoCo's free camera."""

    def __init__(
        self,
        world,
        lookat=(0.30, 0.0, 0.0),
        distance: float = 0.75,
        azimuth: float = 180.0,
        elevation: float = -60.0,
        size: tuple[int, int] = (480, 640),
        depth: bool = True,
        calibrated: bool = True,
    ):
        """depth=False plays a plain webcam. calibrated=False withholds the
        pose and the focal length, as a camera fresh out of its box would."""
        mujoco = world._mujoco
        self._world = world
        self._renderer = mujoco.Renderer(world.model, size[0], size[1])
        self._cam = mujoco.MjvCamera()
        self._cam.type = mujoco.mjtCamera.mjCAMERA_FREE
        self._cam.lookat[:] = lookat
        self._cam.distance = distance
        self._cam.azimuth = azimuth
        self._cam.elevation = elevation
        h, w = size
        self._f = (h / 2) / math.tan(math.radians(float(world.model.vis.global_.fovy)) / 2)
        self._centre = (w / 2, h / 2)
        self._depth = depth
        #: Set by calibration, exactly as on a physical camera.
        self.pose: np.ndarray | None = None
        self.focal: float | None = None
        self._calibrated = calibrated

    def frame(self) -> Frame:
        r, world = self._renderer, self._world
        r.update_scene(world.data, self._cam)
        rgb = r.render().copy()
        depth = None
        if self._depth:
            r.enable_depth_rendering()
            r.update_scene(world.data, self._cam)
            depth = r.render().copy()
            r.disable_depth_rendering()
            # The far plane reads as tens of metres; nothing on a bench is there.
            depth[depth > 5.0] = 0.0
        if self._calibrated:
            return Frame(rgb, depth, self._f, self._f, *self._centre, self._pose())
        # A depth camera ships knowing its own lens; a webcam has to be measured.
        f = self._f if self._depth else (self.focal or guessed_focal(rgb.shape[1]))
        return Frame(rgb, depth, f, f, *self._centre, self.pose)

    def rgb(self) -> np.ndarray:
        """Colour only, for filming a run: no depth pass, no pose."""
        self._renderer.update_scene(self._world.data, self._cam)
        return self._renderer.render().copy()

    @property
    def true_pose(self) -> np.ndarray:
        self.frame()
        return self._pose()

    @property
    def true_focal(self) -> float:
        return self._f

    def _pose(self) -> np.ndarray:
        """Where the renderer actually put the lens. Read back from the scene
        rather than recomputed from azimuth and elevation: one definition."""
        eyes = self._renderer.scene.camera
        position = (np.array(eyes[0].pos) + np.array(eyes[1].pos)) / 2
        forward = np.array(eyes[0].forward)
        up = np.array(eyes[0].up)
        pose = np.eye(4)
        pose[:3, 0] = np.cross(forward, up)  # x: right
        pose[:3, 1] = -up  # y: down
        pose[:3, 2] = forward  # z: out of the lens
        pose[:3, 3] = position
        return pose

    def close(self) -> None:
        self._renderer.close()


class RealSenseCamera:
    """An Intel RealSense, depth aligned to colour."""

    def __init__(self, size: tuple[int, int] = (480, 640)):
        try:
            import pyrealsense2 as rs
        except ImportError as e:  # pragma: no cover
            raise ImportError(
                "a RealSense needs pyrealsense2 — install it: uv sync --extra realsense"
            ) from e
        h, w = size
        self.pose: np.ndarray | None = None
        self._pipeline = rs.pipeline()
        cfg = rs.config()
        cfg.enable_stream(rs.stream.depth, w, h, rs.format.z16, 30)
        cfg.enable_stream(rs.stream.color, w, h, rs.format.rgb8, 30)
        profile = self._pipeline.start(cfg)
        self._scale = profile.get_device().first_depth_sensor().get_depth_scale()
        self._align = rs.align(rs.stream.color)
        k = profile.get_stream(rs.stream.color).as_video_stream_profile().get_intrinsics()
        self._k = (k.fx, k.fy, k.ppx, k.ppy)
        # Auto-exposure needs a second to settle; the first frames are dark.
        for _ in range(30):
            self._pipeline.wait_for_frames()

    def frame(self) -> Frame:  # pragma: no cover - needs the sensor
        frames = self._align.process(self._pipeline.wait_for_frames())
        depth = np.asanyarray(frames.get_depth_frame().get_data()).astype(np.float32) * self._scale
        rgb = np.asanyarray(frames.get_color_frame().get_data()).copy()
        return Frame(rgb, depth, *self._k, self.pose)

    def rgb(self) -> np.ndarray:  # pragma: no cover - needs the sensor
        return np.asanyarray(self._pipeline.wait_for_frames().get_color_frame().get_data()).copy()

    def close(self) -> None:  # pragma: no cover
        self._pipeline.stop()


def guessed_focal(width: int) -> float:
    """A webcam's focal length in pixels before anyone has measured it: a 60
    degree horizontal field of view, which is what most of them have."""
    return width / (2 * math.tan(math.radians(30)))


class SharedCamera:
    """One camera, two readers: the arm (vision.locate, on the teach thread)
    and the live feed the web app shows (the server, on its own). Neither
    OpenCV's capture nor RealSense's pipeline may be read from two threads at
    once, so every read goes through one lock, and the last frame is kept:
    the feed shows what the arm last saw rather than stealing a read from it.
    """

    def __init__(self, camera, keep_s: float = 0.25):
        import threading

        self._camera = camera
        self._lock = threading.Lock()
        self._keep_s = keep_s
        self._latest: tuple[float, Frame] | None = None

    def __getattr__(self, name: str):
        # pose, focal, and whatever else a camera kind carries: the arm sets
        # them on calibration and reads them back through the same name.
        return getattr(self._camera, name)

    def __setattr__(self, name: str, value) -> None:
        if name.startswith("_"):
            object.__setattr__(self, name, value)
        else:
            setattr(self._camera, name, value)

    def frame(self) -> Frame:
        with self._lock:
            frame = self._camera.frame()
            self._latest = (time.monotonic(), frame)
            return frame

    def latest(self) -> Frame:
        """A frame no older than `keep_s`, without taking a read from the arm
        if it just took one."""
        held = self._latest
        if held is not None and time.monotonic() - held[0] < self._keep_s:
            return held[1]
        return self.frame()

    def close(self) -> None:
        with self._lock:
            close = getattr(self._camera, "close", None)
            if close is not None:
                close()


class OpenCVCamera:
    """Anything OpenCV can open. `source` is a device index (0 is usually the
    built-in camera, 1 the first USB one) or a stream URL. Colour only."""

    def __init__(self, source: int | str = 0, size: tuple[int, int] = (480, 640)):
        try:
            import cv2
        except ImportError as e:  # pragma: no cover
            raise ImportError(
                "a webcam needs OpenCV — install the real extra: uv sync --extra real"
            ) from e
        self._cv2 = cv2
        self._capture = cv2.VideoCapture(source)
        if not self._capture.isOpened():
            raise RuntimeError(f"no camera at {source!r} — see: botcortex camera list")
        self._capture.set(cv2.CAP_PROP_FRAME_WIDTH, size[1])
        self._capture.set(cv2.CAP_PROP_FRAME_HEIGHT, size[0])
        self.pose: np.ndarray | None = None
        self.focal: float | None = None
        # Auto-exposure and white balance take a second to settle.
        for _ in range(15):
            self._capture.read()

    def frame(self) -> Frame:  # pragma: no cover - needs a camera
        # Drain: a capture queues frames, and the oldest is from before the arm moved.
        for _ in range(4):
            self._capture.grab()
        ok, bgr = self._capture.read()
        if not ok:
            raise RuntimeError("the camera stopped answering")
        rgb = self._cv2.cvtColor(bgr, self._cv2.COLOR_BGR2RGB)
        h, w = rgb.shape[:2]
        f = self.focal or guessed_focal(w)
        return Frame(rgb, None, f, f, w / 2, h / 2, self.pose)

    def rgb(self) -> np.ndarray:  # pragma: no cover - needs a camera
        """One read, not frame()'s drain of four: filming runs once per control
        tick, and a frame one tick old is what a policy will be given anyway."""
        ok, bgr = self._capture.read()
        if not ok:
            raise RuntimeError("the camera stopped answering")
        return self._cv2.cvtColor(bgr, self._cv2.COLOR_BGR2RGB)

    def close(self) -> None:  # pragma: no cover
        self._capture.release()


# --- one file per body: which camera, and where it stands ------------------


def settings_path(data_dir: Path, platform_name: str) -> Path:
    return data_dir / f"camera_{platform_name}.json"


def load_settings(path: Path) -> dict:
    return json.loads(path.read_text()) if path.exists() else {}


def save_settings(path: Path, **changes) -> dict:
    settings = {**load_settings(path), **changes}
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(settings, indent=2))
    return settings


def open_camera(settings: dict):
    """The camera the settings file describes, calibration applied."""
    kind = settings.get("kind")
    if kind == "realsense":
        cam = RealSenseCamera()
    elif kind == "opencv":
        cam = OpenCVCamera(settings.get("source", 0))
    else:
        raise ValueError("no camera chosen yet — run: botcortex camera use <webcam|realsense>")
    if "camera_to_base" in settings:
        cam.pose = np.array(settings["camera_to_base"], dtype=float)
    if "focal_px" in settings and hasattr(cam, "focal"):
        cam.focal = float(settings["focal_px"])
    return cam


def list_cameras(max_index: int = 5) -> list[dict]:  # pragma: no cover - probes hardware
    """What is plugged in. Probing an index that does not exist is how OpenCV
    is asked, so its warnings are silenced for the duration."""
    found: list[dict] = []
    try:
        import cv2

        # OpenCV 5 moved this under cv2.utils.logging; 4.x has both.
        (getattr(cv2, "setLogLevel", None) or cv2.utils.logging.setLogLevel)(0)
        for index in range(max_index):
            capture = cv2.VideoCapture(index)
            if capture.isOpened():
                ok, image = capture.read()
                if ok:
                    found.append({"kind": "opencv", "source": index, "size": list(image.shape[:2])})
            capture.release()
    except ImportError:
        pass
    try:
        import pyrealsense2 as rs

        for device in rs.context().query_devices():
            found.append({"kind": "realsense", "name": device.get_info(rs.camera_info.name)})
    except ImportError:
        pass
    return found


def write_png(path: Path, rgb: np.ndarray) -> None:
    """A PNG with nothing but the standard library, so `camera show` needs no
    imaging package on a machine that only has a RealSense."""
    import struct
    import zlib

    h, w = rgb.shape[:2]
    raw = b"".join(b"\x00" + rgb[y].astype(np.uint8).tobytes() for y in range(h))

    def chunk(kind: bytes, data: bytes) -> bytes:
        body = kind + data
        return struct.pack(">I", len(data)) + body + struct.pack(">I", zlib.crc32(body))

    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(
        b"\x89PNG\r\n\x1a\n"
        + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0))
        + chunk(b"IDAT", zlib.compress(raw, 6))
        + chunk(b"IEND", b"")
    )
