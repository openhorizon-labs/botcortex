"""What is on the table, as the agent and its skills are told it.

One definition, called by every MuJoCo backend. Writing it twice was caught
immediately by `test_it_contains_no_arithmetic` — the half-extent-to-full-size
conversion is arithmetic, and arithmetic living in two backends is how they
start disagreeing. The same lesson `plan_move` and `JointMap` already carry.

PRIVILEGED perception, deliberately. The blueprint's position is that the LLM
is the authoring brain and not the perception system, so the agent is handed
geometry rather than made to infer it from pixels. On hardware the same call is
answered by a camera and a pose estimator; the SHAPE below is the contract, so
a skill written against it keeps working when the answer stops coming from a
simulator.
"""

from __future__ import annotations

from botcortex.mjcompat import enum_value, row


def robot_bodies(mujoco, model, sim: dict) -> set[str]:
    """Every body name that belongs to the robot, per the platform descriptor.

    `sim["root_bodies"]` names the roots of the robot's kinematic tree and
    the whole subtree is the robot; `sim["robot_prefix"]` matches by name
    prefix instead (OpenArm's vendored model prefixes everything). "world"
    is always the robot's, in the sense that it is never an object.

    Declared rather than guessed, because a Panda's bodies are link0..link7,
    hand, left_finger — no prefix in common with each other, let alone with
    a RoArm's.
    """
    body = enum_value(mujoco.mjtObj.mjOBJ_BODY)
    names = {i: mujoco.mj_id2name(model, body, i) or "" for i in range(model.nbody)}
    out = {"world"}
    prefix = sim.get("robot_prefix")
    if prefix:
        out |= {n for n in names.values() if n.startswith(prefix)}
    roots = set(sim.get("root_bodies", ()))
    if roots:
        root_ids = {i for i, n in names.items() if n in roots}
        for i in range(model.nbody):
            j = i
            while j > 0:
                if j in root_ids:
                    out.add(names[i])
                    break
                j = int(model.body_parentid[j])
    return out


def describe(mujoco, model, data, robot: set[str] | None = None) -> dict[str, dict]:
    """Manipulable objects and immovable fixtures, keyed by name.

    Objects are bodies with a free joint — the things that can be picked up.
    Fixtures are everything else in the world: the table, the trays. Keeping
    them apart matters, because an agent told the table is an "object" will
    eventually try to pick it up.

    `mujoco` is the module (native) or the WASM module (browser). Both expose
    the same names, which is the whole reason this can be shared. `robot` is
    the body set from robot_bodies(); without it, only "world" is excluded.
    """
    robot = robot if robot is not None else {"world"}
    objects: dict[str, dict] = {}
    fixtures: dict[str, dict] = {}

    movable_bodies = {
        int(model.jnt_bodyid[j])
        for j in range(model.njnt)
        if int(model.jnt_type[j]) == enum_value(mujoco.mjtJoint.mjJNT_FREE)
    }

    for body in range(model.nbody):
        name = mujoco.mj_id2name(model, enum_value(mujoco.mjtObj.mjOBJ_BODY), body)
        if not name or name in robot:
            continue
        entry = {
            "position": [round(v, 4) for v in row(data.xpos, body, 3)],
            # Blocks tumble. Without orientation the viewer draws every one
            # axis-aligned, so a block knocked on its corner still looks
            # perfectly square — the one visual cue that something went wrong.
            "orientation": [round(v, 4) for v in row(data.xquat, body, 4)],
            "size_m": _size_of(model, body),
            "colour": _colour_of(model, body),
        }
        (objects if body in movable_bodies else fixtures)[name] = entry

    return {"objects": objects, "fixtures": fixtures}


def _size_of(model, body: int) -> list[float]:
    """Full extents of a body's first geom, in metres.

    MuJoCo stores HALF-extents; an agent asked to grasp a "0.02 m" block when
    it is really 40 mm across would plan a grip narrower than the object.
    """
    for geom in range(model.ngeom):
        if int(model.geom_bodyid[geom]) == body:
            return [round(v * 2, 4) for v in row(model.geom_size, geom, 3)]
    return [0.0, 0.0, 0.0]


def _colour_of(model, body: int) -> list[float]:
    """The body's first geom rgba, so the viewer draws a red block red.

    Taken from the model rather than named in the client: the scene already
    says what colour a thing is, and a second list of names-to-colours in
    TypeScript would be one more thing to keep in step.
    """
    for geom in range(model.ngeom):
        if int(model.geom_bodyid[geom]) == body:
            material = int(model.geom_matid[geom])
            source = (
                row(model.mat_rgba, material, 4)
                if material >= 0
                else row(model.geom_rgba, geom, 4)
            )
            return [round(v, 3) for v in source]
    return [0.6, 0.6, 0.6, 1.0]


def free_joints(mujoco, model) -> dict[str, int]:
    """qpos address of every free-jointed body, keyed by body name.

    The objects, in other words — everything that can be picked up. One
    definition for both backends: the browser records object motion frame by
    frame from these addresses, and a second copy of "which joints are free"
    would drift exactly the way describe() would have.
    """
    body = enum_value(mujoco.mjtObj.mjOBJ_BODY)
    out: dict[str, int] = {}
    for j in range(model.njnt):
        if int(model.jnt_type[j]) != enum_value(mujoco.mjtJoint.mjJNT_FREE):
            continue
        name = mujoco.mj_id2name(model, body, int(model.jnt_bodyid[j]))
        if name:
            out[name] = int(model.jnt_qposadr[j])
    return out


def object_poses(qpos, addresses: dict[str, int]) -> dict[str, list[float]]:
    """Where every object is right now: [x, y, z, qw, qx, qy, qz] per name.

    The 7 floats a free joint stores, read straight out of qpos. Recorded per
    control tick so a browser can REPLAY object motion in step with the arm —
    without this, playback showed the block teleporting to its destination
    and the arm setting off afterwards to fetch nothing.
    """
    return {
        name: [float(qpos[adr + i]) for i in range(7)] for name, adr in addresses.items()
    }


def place_objects(qpos, addresses: dict[str, int], poses: dict[str, list[float]]) -> None:
    """Write object poses back into qpos — reset() restoring the workcell."""
    for name, pose in poses.items():
        adr = addresses[name]
        for i, value in enumerate(pose):
            qpos[adr + i] = value


def resting_in(position, fixtures: dict[str, dict]) -> str | None:
    """Which fixture an object is sitting in or on, or None if it is nowhere.

    "Moved 32 cm to [0.315, -0.461, 0.22]" is a true sentence that an agent
    reads as "placed". Those coordinates ARE the answer to "did it land in the
    tray", but only after arithmetic against a footprint the model has to
    remember to do — and when it did not, it reported a block lying on the
    table as a successful placement.

    So the runtime does the arithmetic. It is the only mechanism that can:
    a rehearsal catches a bad APPROACH, because a link in the furniture is a
    fault, but it cannot catch a bad PLACE — the payload touching a fixture is
    manipulation working, deliberately not a fault (see botcortex.safety).

    The SMALLEST containing footprint wins. The trays sit on the table, so a
    block in a tray is inside both, and "on the table" would be technically
    true and useless.
    """
    matches = []
    for name, body in fixtures.items():
        size = body.get("size_m") or [0.0, 0.0, 0.0]
        centre = body["position"]
        if len(size) < 3 or len(centre) < 3:
            continue
        within = (
            abs(position[0] - centre[0]) <= size[0] / 2
            and abs(position[1] - centre[1]) <= size[1] / 2
            and position[2] >= centre[2]
        )
        if within:
            matches.append((size[0] * size[1], name))
    return min(matches)[1] if matches else None
