"""Where each joint lives in the MuJoCo arrays, and what its degrees mean there.

`plan_move` (robot.py) decides the trajectory in degrees. This decides what
physics actually receives: which `ctrl` and `qpos` indices to write, and the
conversion to radians — or, for the gripper, to whatever the model's gripper
mechanism is driven in.

It exists as its own layer for the same reason plan_move does. Two MuJoCo
backends exist — native Python and the browser's WASM build — and they
differ only in how a name resolves to an index. Everything else, especially the
gripper mapping, is arithmetic that must not be written twice: a sign error
there yields a perfectly correct trajectory and a jaw that closes when it was
told to open. A backend using this class contains no arithmetic at all.

The two resolvers are the entire seam. Native passes lookups built on
mj_name2id; the browser passes ones built on the embind accessors, whose enums
are objects rather than ints. Addresses are plain integers on both sides, so
every write below is backend-agnostic.

Which joints exist, and how the gripper is built, come from the platform
descriptor. This class used to fix seven joints per arm and two finger sliders
in metres — true of OpenArm and of nothing else in the catalog.
"""

from __future__ import annotations

import math
from collections.abc import Callable, Sequence

from botcortex.platform import Platform


class JointMap:
    """Address resolution and unit mapping for one loaded model.

    qpos_adr(name) -> the index into data.qpos for that joint
    actuator_id(name) -> the index into data.ctrl for that actuator

    Both are resolved once, at construction, so nothing does a string lookup
    inside a control loop.
    """

    def __init__(
        self,
        platform: Platform,
        qpos_adr: Callable[[str], int],
        actuator_id: Callable[[str], int],
    ):
        self.platform = platform
        sim = platform.sim
        self.gripper = platform.gripper
        self.meters_open = self.gripper.meters_open

        self.qpos_adr: dict[str, dict[str, int]] = {}
        self.ctrl_id: dict[str, dict[str, int]] = {}
        #: Gripper readback and drive addresses per arm. For "fingers_m" one
        #: entry per finger; for "linear" exactly one of each.
        self.finger_qpos: dict[str, list[int]] = {}
        self.finger_ctrl: dict[str, list[int]] = {}

        for side in platform.arms:
            self.qpos_adr[side] = {}
            self.ctrl_id[side] = {}
            for joint in platform.joints:
                n = int(joint[1:]) if joint[1:].isdigit() else joint
                self.qpos_adr[side][joint] = qpos_adr(sim["joint_fmt"].format(side=side, n=n))
                self.ctrl_id[side][joint] = actuator_id(
                    sim["actuator_fmt"].format(side=side, n=n)
                )
            g = self.gripper
            if g.kind == "fingers_m":
                self.finger_qpos[side] = [
                    qpos_adr(g.finger_joint_fmt.format(side=side, i=i))
                    for i in range(1, g.fingers + 1)
                ]
                self.finger_ctrl[side] = [
                    actuator_id(g.finger_actuator_fmt.format(side=side, i=i))
                    for i in range(1, g.fingers + 1)
                ]
            elif g.kind == "linear":
                self.finger_qpos[side] = [qpos_adr(g.joint.format(side=side))]
                self.finger_ctrl[side] = [actuator_id(g.actuator.format(side=side))]
            else:
                raise ValueError(f"{platform.name}: unknown gripper kind {g.kind!r}")

    # --- gripper: degrees of jaw opening <-> the model's drive units ---
    #
    # The platform's gripper limit is (lo, hi) with lo fully OPEN and hi fully
    # CLOSED. OpenArm: -65..0 — the inversion is real, not a mistake: the
    # vendor range runs negative-open to zero-closed, and every platform after
    # it declares its limits in the same orientation.

    def _openness(self, arm: str, deg: float) -> float:
        """0 at fully closed, 1 at fully open."""
        lo, hi = self.platform.joint_limits[arm]["gripper"]
        return (hi - deg) / (hi - lo)

    def _deg_from_openness(self, arm: str, openness: float) -> float:
        lo, hi = self.platform.joint_limits[arm]["gripper"]
        return hi - openness * (hi - lo)

    def gripper_deg_to_m(self, arm: str, deg: float) -> float:
        """Finger travel in metres — 0 m is jaws together (fingers_m only)."""
        return self._openness(arm, deg) * self.meters_open

    def gripper_m_to_deg(self, arm: str, meters: float) -> float:
        return self._deg_from_openness(arm, meters / self.meters_open)

    def gripper_deg_to_ctrl(self, arm: str, deg: float) -> float:
        g = self.gripper
        if g.kind == "fingers_m":
            return self.gripper_deg_to_m(arm, deg)
        t = self._openness(arm, deg)
        return g.ctrl_closed + t * (g.ctrl_open - g.ctrl_closed)

    def gripper_deg_to_qpos(self, arm: str, deg: float) -> float:
        g = self.gripper
        if g.kind == "fingers_m":
            return self.gripper_deg_to_m(arm, deg)
        t = self._openness(arm, deg)
        return g.qpos_closed + t * (g.qpos_open - g.qpos_closed)

    def gripper_qpos_to_deg(self, arm: str, value: float) -> float:
        g = self.gripper
        if g.kind == "fingers_m":
            return self.gripper_m_to_deg(arm, value)
        span = g.qpos_open - g.qpos_closed
        t = (value - g.qpos_closed) / span if span else 0.0
        return self._deg_from_openness(arm, t)

    # --- what to write, as (index, value) pairs ---
    #
    # Pairs rather than direct writes so a backend needs no knowledge of units
    # or addressing: it loops and assigns. One gripper command yields one pair
    # per finger actuator, which is why these return sequences rather than
    # scalars.

    def ctrl_writes(self, arm: str, joint: str, deg: float) -> list[tuple[int, float]]:
        """Actuator targets for one joint at one control tick."""
        if joint == "gripper":
            value = self.gripper_deg_to_ctrl(arm, deg)
            return [(cid, value) for cid in self.finger_ctrl[arm]]
        return [(self.ctrl_id[arm][joint], math.radians(deg))]

    def qpos_writes(self, arm: str, joint: str, deg: float) -> list[tuple[int, float]]:
        """Direct state writes — teleporting home, never mid-motion."""
        if joint == "gripper":
            value = self.gripper_deg_to_qpos(arm, deg)
            return [(adr, value) for adr in self.finger_qpos[arm]]
        return [(self.qpos_adr[arm][joint], math.radians(deg))]

    def read_deg(self, arm: str, joint: str, qpos: Sequence[float]) -> float:
        """One joint's angle in degrees, read out of a qpos array.

        Indexable is the only requirement, which numpy arrays and the WASM
        build's Float64Array views both satisfy.
        """
        if joint == "gripper":
            return self.gripper_qpos_to_deg(arm, float(qpos[self.finger_qpos[arm][0]]))
        return math.degrees(float(qpos[self.qpos_adr[arm][joint]]))

    def positions(self, arm: str, qpos: Sequence[float]) -> dict[str, float]:
        return {
            joint: self.read_deg(arm, joint, qpos)
            for joint in self.platform.joint_limits[arm]
        }
