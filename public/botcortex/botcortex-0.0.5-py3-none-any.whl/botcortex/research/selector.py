"""Which repair to try next, from evidence — with or without memory.

Three kinds of selector, all sharing the same repair operators, so a
difference between them is a difference in DECISION, not in what a
decision can do:

- FixedStrategy: the dossier's fixed baselines. Always repair the program
  (cycle the program repairs), or always fix perception (cycle the
  perception repairs), or a fixed interleaving.
- RuleSelector: a hand-written diagnosis over the contract signature. No
  memory. This is the honest floor: if it already picks right every time,
  memory has nothing to add and the report says so.
- MemorySelector: ranks repairs by their verified success on retrieved
  records — retrieved under one of the four memory arms — and falls back
  to a fixed prior order for anything memory is silent on. The FOUR ARMS
  DIFFER ONLY IN RETRIEVAL. That is the experiment.

A selector proposes an ordered list of repairs it has not yet tried; the
recovery loop takes the first, runs it, verifies from truth, and asks
again. Attempts to verified recovery is what gets measured.
"""

from __future__ import annotations

import random
from collections import defaultdict
from dataclasses import dataclass, field

from botcortex.research import probes as probelib
from botcortex.research import repairs as repairlib
from botcortex.research.memory import RepairMemory

REPAIRS = repairlib.catalog()
BY_NAME = {r.name: r for r in REPAIRS}

#: The prior order any selector falls back to: the program first, because a
#: freshly authored program is the likeliest thing to be wrong, then the
#: perception pipeline. The same order for every body.
PRIOR_ORDER = tuple(r.name for r in REPAIRS)


class Selector:
    """`propose` ranks the untried repairs. `request_probe`, asked first on
    every round, may name a targeted measurement to take before proposing;
    its result lands in signature["probes"] and costs budget. The default
    never probes — every passive arm inherits that."""

    name = "selector"
    probing = "none"  # "none" | "rule" | "random"

    def propose(self, signature: dict, trace: str, tried: tuple[str, ...]) -> list[str]:
        raise NotImplementedError

    def request_probe(self, signature: dict, trace: str, tried: tuple[str, ...]) -> str | None:
        done = signature.get("probes", {})
        if self.probing == "rule":
            return probelib.choose_probe_by_rule(signature, done)
        if self.probing == "random":
            return probelib.choose_probe_at_random(signature, done, self._rng)
        return None

    def with_probing(self, probing: str, seed: int = 0):
        self.probing = probing
        self._rng = random.Random(seed)
        if probing != "none":
            self.name = f"{self.name}+{probing}_probe"
        return self


@dataclass
class FixedStrategy(Selector):
    order: tuple[str, ...]
    name: str = "fixed"

    def propose(self, signature, trace, tried):
        return [r for r in self.order if r not in tried]


def always_program() -> FixedStrategy:
    return FixedStrategy(tuple(r.name for r in REPAIRS if r.family == "program")
                         + tuple(r.name for r in REPAIRS if r.family == "perception"), "always_program")


def always_perception() -> FixedStrategy:
    return FixedStrategy(tuple(r.name for r in REPAIRS if r.family == "perception")
                         + tuple(r.name for r in REPAIRS if r.family == "program"), "always_perception")


class RuleSelector(Selector):
    """Hand-written diagnosis from the contract signature, no memory.

    The rules are what a careful engineer would write after reading the
    fault catalog — which is the point: they are a ceiling for what
    evidence alone gives you on a body you know.
    """

    name = "rules"

    def propose(self, signature, trace, tried):
        ranked: list[str] = []
        sig = signature
        if sig["error_class"] == "missing_object" or not sig["target_seen"]:
            ranked.append("perception:change_viewpoint")
        if sig["perception_disagreement"]:
            tracked = sig.get("probes", {}).get("nudge")
            if tracked is False:
                ranked += ["perception:refresh_tracking", "perception:recalibrate"]
            else:
                ranked += ["perception:recalibrate", "perception:refresh_tracking"]
        if sig["outcome"] == "completed" and sig["others_moved"] and not sig["target_moved"]:
            ranked += ["program:retarget_named_object", "perception:reidentify"]
        if sig["outcome"] == "completed" and not sig["target_moved"] and not sig["others_moved"]:
            ranked += ["program:open_before_descent", "perception:refresh_tracking"]
        if "invariant" in sig["violations"] or sig["error_class"] in ("unsafe_transit", "lost_grasp"):
            ranked.append("program:raise_lift")
        if sig["error_class"] == "collision" or sig["target_landed"] in ("on table", "elsewhere"):
            ranked.append("program:raise_drop")
        ranked += list(PRIOR_ORDER)
        out: list[str] = []
        for r in ranked:
            if r not in tried and r not in out:
                out.append(r)
        return out


@dataclass
class MemorySelector(Selector):
    """Ranks repairs by verified success on retrieved records.

    `mode` is the memory arm. `target_platform` is the body the failure is
    on; `excluded_platforms` are its simulated variants, never retrieved.
    """

    memory: RepairMemory
    mode: str
    target_platform: str
    excluded_platforms: tuple[str, ...] = ()
    smoothing: float = 0.5
    #: Retrieval threshold. 0.5 (loose) is the pilot's setting; 1.0 makes
    #: the memory abstain on anything but an exact signature match and
    #: fall back to the prior order — no recommendation rather than a
    #: borrowed one. Named in the arm so the trade-off is visible.
    min_match: float = 0.5
    name: str = field(default="memory")

    def __post_init__(self):
        strictness = {1.0: "_exact", 0.8: "_strict"}.get(self.min_match, "")
        self.name = f"memory:{self.mode}{strictness}"

    def propose(self, signature, trace, tried):
        retrieved = self.memory.retrieve(
            self.mode,
            target_platform=self.target_platform,
            signature=signature,
            trace=trace,
            excluded_platforms=self.excluded_platforms,
            probes=signature.get("probes") or None,
            min_score=self.min_match,
        )
        wins: dict[str, float] = defaultdict(float)
        trials: dict[str, float] = defaultdict(float)
        for score, record in retrieved:
            trials[record.repair] += score
            if record.recovered:
                wins[record.repair] += score
        a = self.smoothing

        def estimate(name: str) -> float:
            return (wins[name] + a) / (trials[name] + 2 * a)

        prior = {name: i for i, name in enumerate(PRIOR_ORDER)}
        ranked = sorted(
            (name for name in PRIOR_ORDER if name not in tried),
            key=lambda name: (-estimate(name), -trials[name], prior[name]),
        )
        return ranked
