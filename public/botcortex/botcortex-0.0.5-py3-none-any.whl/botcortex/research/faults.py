"""The controlled fault catalog.

Two families in this slice, matching the dossier's first benchmark classes:

- PROGRAM faults live in the program. They are source transforms applied to
  a skill before it runs — a wrong drop height, a skipped prerequisite, the
  wrong object — because that is what a program fault is: a bug in the
  code, not a knob on the robot. The verifier sees its consequences; the
  selector sees the failing program and its trace.

- PERCEPTION faults live in the observation layer (research.perception).
  The program is correct; what it was told was not.

Every injected fault comes with a `SealedLabel`: the ground truth of what
was injected, kept in a separate record from the episode the selector
reads. The selector must diagnose from evidence. The evaluation runner
opens the label afterwards to score the diagnosis — and to record whether
the fault actually caused a failure on that body, because an injected
setting that took no effect is not a failure case, it is a no-op, and
counting it as one would flatter every selector equally.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

from botcortex.research import perception

FAMILIES = ("program", "perception")


@dataclass(frozen=True)
class Fault:
    """One entry in the catalog. `params` are the knobs; `kind` names the
    transform. `expected` is the verifier violation the fault is designed to
    produce, used to check that an injection took effect."""

    family: str
    kind: str
    params: dict = field(default_factory=dict)
    expected: str = ""

    @property
    def name(self) -> str:
        return f"{self.family}:{self.kind}"


@dataclass(frozen=True)
class SealedLabel:
    """What was injected, and whether it bit. Never in the episode packet."""

    fault: Fault | None
    took_effect: bool | None = None
    note: str = ""


class FaultError(ValueError):
    """The fault could not be applied to this program — the source lacks the
    line the transform edits, so injecting it would silently do nothing."""


# --- program faults: source transforms ---------------------------------------
#
# Written against the portable skill's shape (tests/fixtures/portable_pick_and_place.py):
# named `lift` and `drop` constants, an explicit open before the descent,
# and a `block` parameter. Each transform asserts it changed something.


def _sub(source: str, pattern: str, replacement: str, what: str) -> str:
    new, n = re.subn(pattern, replacement, source, count=1, flags=re.MULTILINE)
    if n == 0:
        raise FaultError(f"cannot inject {what}: the program has no `{pattern}`")
    return new


def drop_too_low(source: str, params: dict) -> str:
    """Releases the object INTO the tray floor instead of above it: the
    fingers wedge on the surface first, or the object is dropped from a
    pose the arm never reached."""
    depth = float(params.get("depth", -0.02))
    return _sub(source, r"^(\s*)drop = [0-9.]+", rf"\g<1>drop = {depth}", "drop_too_low")


def lift_too_low(source: str, params: dict) -> str:
    """Carries the object at a height that sweeps through neighbours or the
    tray walls: a planner that forgot what is between here and there."""
    height = float(params.get("height", 0.02))
    return _sub(source, r"^(\s*)lift = [0-9.]+", rf"\g<1>lift = {height}", "lift_too_low")


def skip_open(source: str, params: dict) -> str:
    """The prerequisite is missing: descends with the jaws closed, so the
    grasp closes on nothing (or the jaws land on the object)."""
    return _sub(
        source,
        r"^[ \t]*ctx\.gripper\(arm, open_deg\)[ \t]*\n(?=[ \t]*ctx\.move_to_point\(arm, \[here\[0\], here\[1\], here\[2\] \+ lift\]\))",
        "",
        "skip_open",
    )


def wrong_object(source: str, params: dict) -> str:
    """The relation names the wrong thing: the program picks `other` when
    the task said `block`."""
    other = params.get("other", "blue_block")
    return _sub(
        source,
        r'^(\s*)here = scene\["objects"\]\[block\]\["position"\]',
        rf'\g<1>here = scene["objects"]["{other}"]["position"]',
        "wrong_object",
    )


PROGRAM_TRANSFORMS = {
    "drop_too_low": drop_too_low,
    "lift_too_low": lift_too_low,
    "skip_open": skip_open,
    "wrong_object": wrong_object,
}


def apply_program_fault(source: str, fault: Fault) -> str:
    if fault.family != "program":
        raise ValueError(f"{fault.name} is not a program fault")
    return PROGRAM_TRANSFORMS[fault.kind](source, fault.params)


# --- perception faults: observation transforms ---------------------------------


def perception_transform(fault: Fault) -> perception.Transform:
    if fault.family != "perception":
        raise ValueError(f"{fault.name} is not a perception fault")
    p = fault.params
    if fault.kind == "pose_bias":
        return perception.PoseBias(tuple(p["objects"]), tuple(p["offset"]))
    if fault.kind == "stale_pose":
        return perception.StalePose(tuple(p["objects"]))
    if fault.kind == "identity_swap":
        return perception.IdentitySwap(p["a"], p["b"])
    if fault.kind == "occlusion":
        return perception.Occlusion(tuple(p["objects"]))
    raise ValueError(f"unknown perception fault {fault.kind!r}")


# --- the catalog for the pick-and-place family ---------------------------------


def catalog(block: str = "red_block", other: str = "blue_block") -> tuple[Fault, ...]:
    """The controlled faults of the first benchmark, for one task family.

    Parameters are the defaults the sim study starts from; the evaluation
    runner may sweep them. Each carries the violation it is expected to
    produce, so a run can report "injected but took no effect" honestly.
    """
    return (
        Fault("program", "drop_too_low", {"depth": -0.02}, expected="goal inside"),
        Fault("program", "lift_too_low", {"height": 0.02}, expected="invariant untouched"),
        Fault("program", "skip_open", {}, expected="goal inside"),
        Fault("program", "wrong_object", {"other": other}, expected="goal inside"),
        Fault(
            "perception",
            "pose_bias",
            {"objects": [block], "offset": [0.03, 0.0, 0.0]},
            expected="goal inside",
        ),
        Fault("perception", "stale_pose", {"objects": [block]}, expected="goal inside"),
        Fault("perception", "identity_swap", {"a": block, "b": other}, expected="goal inside"),
        Fault("perception", "occlusion", {"objects": [block]}, expected="goal inside"),
    )
