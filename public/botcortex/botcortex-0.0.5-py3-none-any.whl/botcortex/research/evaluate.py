"""The evaluation runner: leave-one-embodiment-out, on a frozen outcome table.

Every attempt the selectors could make is a deterministic simulation —
one body, one injected fault, one repair — so the honest way to compare
selectors is to run each such attempt ONCE, cache its verified outcome,
and score every selector against the same table. No arm gets luckier
physics than another, and the whole comparison reruns in seconds.

    python -m botcortex.research.evaluate cache roarm_m2      # fill the table
    python -m botcortex.research.evaluate run                 # score the arms

The cache holds, per (platform, fault, repair): the episode's contract
signature and trace text, and whether the verifier passed it. Faults that
took no effect on a body (the clean-run verdict was already ok) are not
failure cases and are reported separately, not scored — an injection that
did nothing would flatter every selector equally.

Scoring, per held-out body and effective fault, for each arm:
  attempts to verified recovery, censored at `budget`.
Memory for the target is built from the OTHER bodies' records — every
(fault, repair, recovered) pair they observed, which is what a body that
had explored its own failures would remember — with the target's declared
simulated variants excluded. `target_only` memory is leave-one-fault-out on
the target's own records, so a fault is never diagnosed from its own trial.
"""

from __future__ import annotations

import json
import statistics
import sys
import tempfile
from collections import defaultdict
from dataclasses import asdict, dataclass, field
from pathlib import Path

from botcortex.platform import MODELS_DIR, available_platforms, load_platform
from botcortex.research import contracts
from botcortex.research import faults as faultlib
from botcortex.research import probes as probelib
from botcortex.research import repairs as repairlib
from botcortex.research import selector as selectorlib
from botcortex.research.evidence import run_trial, trial_identity
from botcortex.research.memory import MODES, RepairMemory, RepairRecord
from botcortex.research.signature import contract_signature, trace_text

CACHE_DIR = Path(MODELS_DIR).parent / "research"
PORTABLE = Path(__file__).parent.parent.parent / "tests" / "fixtures" / "portable_pick_and_place.py"
BUDGET = 8

#: Embodiments that are simulated variants of a physical body and must not
#: be a memory source for it: the OpenArm sim IS the OpenArm rig's twin.
#: Grows as hardware anchors arrive (the RoArm sim vs the RoArm-M2-Pro).
VARIANTS: dict[str, tuple[str, ...]] = {}


@dataclass
class Outcome:
    platform: str
    fault: str  # "clean" or Fault.name
    repair: str  # "none" or Repair.name
    outcome: str
    error: str | None
    verdict: str
    violations: list[str]
    signature: dict
    trace: str
    recovered: bool
    identity: str = ""
    derived_from: str = ""
    #: Probe results measured after the unrepaired failure, keyed by probe
    #: name. Only rows with repair == "none" carry them. A selector pays to
    #: look; the table just remembers what it would have seen.
    probes: dict = field(default_factory=dict)


# --- filling the table --------------------------------------------------------


def cache_path(platform: str) -> Path:
    return CACHE_DIR / f"outcomes_{platform}.jsonl"


def build_cache(platform_name: str, contract_block: str = "red_block") -> Path:
    from botcortex.sim import SimRobot

    platform = load_platform(platform_name)
    if not platform.model_available:
        raise SystemExit(f"{platform_name}: model not available (scripts/fetch_models.py)")
    source = PORTABLE.read_text()
    contract = contracts.pick_and_place(contract_block, "tray_right", ("blue_block", "green_block"))
    path = cache_path(platform_name)
    path.parent.mkdir(parents=True, exist_ok=True)
    done = {(o.fault, o.repair) for o in load_cache(platform_name)}
    grid = [(None, None)] + [(f, None) for f in faultlib.catalog()] + [
        (f, r) for f in faultlib.catalog() for r in repairlib.catalog()
    ]
    # A repair that changes neither the program nor the observation pipeline
    # — a program edit against a perception fault, a tracker refresh against
    # a bad drop height — runs the SAME trial as the unrepaired fault, and
    # the simulation is deterministic. Simulate each distinct trial once and
    # record the rest as its outcome, marked as such.
    simulated: dict[str, Outcome] = {o.identity: o for o in load_cache(platform_name) if o.identity}
    with path.open("a") as out:
        for fault, repair in grid:
            key = (fault.name if fault else "clean", repair.name if repair else "none")
            if key in done:
                continue
            identity = trial_identity(source, fault, repair)
            if identity in simulated:
                twin = simulated[identity]
                record = Outcome(**{**asdict(twin), "fault": key[0], "repair": key[1], "derived_from": f"{twin.fault}/{twin.repair}"})
            else:
                work = Path(tempfile.mkdtemp(prefix="bx_trial_"))
                robot = SimRobot(platform=platform, stop_file=work / "STOP", realtime=False)
                trial = run_trial(robot, source, contract, fault, work, repair=repair)
                probes: dict = {}
                if fault is not None and repair is None and trial.verdict.ok is not True:
                    for probe in probelib.CATALOG:
                        probes[probe.name] = probelib.run_probe(
                            probe, trial.robot, trial.perception, contract_block
                        )
                record = Outcome(
                    platform=platform_name,
                    fault=key[0],
                    repair=key[1],
                    outcome=trial.episode.outcome,
                    error=trial.episode.error,
                    verdict=trial.verdict.status,
                    violations=list(trial.verdict.violations),
                    signature=contract_signature(trial.episode),
                    trace=trace_text(trial.episode),
                    recovered=trial.verdict.ok is True,
                    identity=identity,
                    probes=probes,
                )
                simulated[identity] = record
            out.write(json.dumps(asdict(record), sort_keys=True) + "\n")
            out.flush()
            tag = f"= {record.derived_from}" if record.derived_from else ""
            print(f"{platform_name:11s} {key[0]:24s} {key[1]:30s} {record.verdict} {tag}", flush=True)
    return path


def load_cache(platform_name: str) -> list[Outcome]:
    path = cache_path(platform_name)
    if not path.exists():
        return []
    out = []
    for line in path.read_text().splitlines():
        if not line:
            continue
        data = json.loads(line)
        sig = data["signature"]
        for key in ("violations", "moved_by_program_view"):
            sig[key] = tuple(sig[key])
        out.append(Outcome(**data))
    return out


# --- scoring ---------------------------------------------------------------------


def _table(platforms: list[str]) -> dict[str, dict[tuple[str, str], Outcome]]:
    return {p: {(o.fault, o.repair): o for o in load_cache(p)} for p in platforms}


def effective_faults(table: dict[tuple[str, str], Outcome]) -> list[str]:
    """Faults whose unrepaired trial failed on this body."""
    return sorted(
        fault for (fault, repair), o in table.items() if repair == "none" and fault != "clean" and not o.recovered
    )


def _records_for(
    platform: str, table: dict[tuple[str, str], Outcome], split: str
) -> list[tuple[str, RepairRecord]]:
    """What a body remembers after exploring its own failures: one record per
    (fault, repair) it tried, keyed by the failure's signature. The fault
    name rides beside each record for the RUNNER's bookkeeping only — it is
    the sealed label, and it never enters the memory the selector reads."""
    records = []
    for fault in effective_faults(table):
        failed = table[(fault, "none")]
        # A body that explored its failures also took the probes; its
        # records remember what they showed, so a target that pays for the
        # same probe can match on the result.
        signature = {**failed.signature, "probes": dict(failed.probes)}
        for repair in repairlib.catalog():
            after = table.get((fault, repair.name))
            if after is None:
                continue
            records.append((
                fault,
                RepairRecord(
                    platform=platform,
                    capability_hash="",
                    task="pick_and_place",
                    skill_hash_before="",
                    skill_hash_after="",
                    signature=signature,
                    trace=failed.trace,
                    repair=repair.name,
                    recovered=after.recovered,
                    verdict_after=after.verdict,
                    split=split,
                ),
            ))
    return records


def attempts_to_recovery(
    selector: selectorlib.Selector,
    table: dict[tuple[str, str], Outcome],
    fault: str,
    budget: int = BUDGET,
    probe_cost: float | None = None,
) -> tuple[float | None, list[str]]:
    """How many budget units the selector spends before the verifier passes:
    one per repair attempt and one per probe. None when the budget runs
    out. Also the sequence it tried, probes marked `probe:<name>`."""
    failed = table[(fault, "none")]
    signature = {**failed.signature, "probes": dict(failed.signature.get("probes", {}))}
    tried: list[str] = []
    spent = 0.0
    while spent < budget:
        repairs_tried = tuple(t for t in tried if not t.startswith("probe:"))
        probe = selector.request_probe(signature, failed.trace, repairs_tried)
        if probe is not None and probe in failed.probes:
            signature["probes"][probe] = failed.probes[probe]
            tried.append(f"probe:{probe}")
            spent += probelib.BY_NAME[probe].cost if probe_cost is None else probe_cost
            continue
        proposals = selector.propose(signature, failed.trace, repairs_tried)
        if not proposals:
            break
        choice = proposals[0]
        tried.append(choice)
        spent += 1
        after = table.get((fault, choice))
        if after is not None and after.recovered:
            return spent if spent != int(spent) else int(spent), tried
    return None, tried


@dataclass
class ArmResult:
    target: str
    fault: str
    arm: str
    attempts: float | None
    tried: list[str]
    first_choice_family_right: bool
    probes: int = 0


def evaluate(
    platforms: list[str] | None = None,
    budget: int = BUDGET,
    k_target: int | None = None,
    probe_cost: float | None = None,
) -> dict:
    """Leave-one-embodiment-out over every cached body. `probe_cost`
    overrides every probe's cost, to show how the value of measuring
    depends on what measuring costs relative to a task attempt."""
    platforms = platforms or [p for p in available_platforms() if cache_path(p).exists()]
    tables = _table(platforms)
    results: list[ArmResult] = []
    skipped: dict[str, list[str]] = {}
    for target in platforms:
        table = tables[target]
        faults = effective_faults(table)
        skipped[target] = sorted(
            f.name for f in faultlib.catalog() if f.name not in faults and (f.name, "none") in table
        )
        excluded = VARIANTS.get(target, ())
        with tempfile.TemporaryDirectory() as tmp:
            memory = RepairMemory(Path(tmp) / "repairs.jsonl")
            for source in platforms:
                if source == target or source in excluded:
                    continue
                for _fault, record in _records_for(source, tables[source], "train"):
                    memory.append(record)
            target_records = _records_for(target, table, "target")
            for fault in faults:
                fault_family = fault.split(":")[0]
                seed = hash((target, fault)) & 0xFFFF
                arms: list[tuple[str, selectorlib.Selector]] = [
                    ("always_program", selectorlib.always_program()),
                    ("always_perception", selectorlib.always_perception()),
                    ("rules", selectorlib.RuleSelector()),
                    ("rules+rule_probe", selectorlib.RuleSelector().with_probing("rule")),
                    ("rules+random_probe", selectorlib.RuleSelector().with_probing("random", seed)),
                ] + [
                    (f"memory:{mode}", _memory_selector(mode, target, memory, target_records, fault, excluded))
                    for mode in MODES
                ] + [
                    (
                        f"memory:{mode}{tag}",
                        _memory_selector(mode, target, memory, target_records, fault, excluded, min_match=m),
                    )
                    for mode in ("target_only", "cross_body")
                    for m, tag in ((0.8, "_strict"), (1.0, "_exact"))
                ] + [
                    (
                        "memory:cross_body_exact+rule_probe",
                        _memory_selector("cross_body", target, memory, target_records, fault, excluded, min_match=1.0)
                        .with_probing("rule"),
                    ),
                    (
                        "memory:cross_body+rule_probe",
                        _memory_selector("cross_body", target, memory, target_records, fault, excluded)
                        .with_probing("rule"),
                    ),
                    (
                        "memory:cross_body+random_probe",
                        _memory_selector("cross_body", target, memory, target_records, fault, excluded)
                        .with_probing("random", seed),
                    ),
                ]
                for arm_name, selector in arms:
                    attempts, tried = attempts_to_recovery(selector, table, fault, budget, probe_cost)
                    repairs_only = [t for t in tried if not t.startswith("probe:")]
                    results.append(
                        ArmResult(
                            target,
                            fault,
                            arm_name,
                            attempts,
                            tried,
                            bool(repairs_only) and repairs_only[0].split(":")[0] == fault_family,
                            probes=len(tried) - len(repairs_only),
                        )
                    )
    return {"results": [asdict(r) for r in results], "skipped": skipped, "budget": budget, "probe_cost": probe_cost}


def _memory_selector(mode, target, memory, target_records, fault, excluded, min_match=0.5):
    if mode == "target_only":
        # Leave-one-fault-out on the target's own records: the body has
        # explored its other failures, never this one. The runner uses the
        # sealed fault name to leave it out; the selector still sees only
        # signatures and repairs.
        own = RepairMemory(Path(tempfile.mkdtemp(prefix="bx_own_")) / "own.jsonl")
        for recorded_fault, record in target_records:
            if recorded_fault != fault:
                own.append(record)
        return selectorlib.MemorySelector(own, mode, target, excluded, min_match=min_match)
    return selectorlib.MemorySelector(memory, mode, target, excluded, min_match=min_match)


def summarize(evaluation: dict) -> str:
    results = evaluation["results"]
    budget = evaluation["budget"]
    by_arm: dict[str, list[int | None]] = defaultdict(list)
    by_target_arm: dict[tuple[str, str], list[int | None]] = defaultdict(list)
    family_right: dict[str, list[bool]] = defaultdict(list)
    for r in results:
        by_arm[r["arm"]].append(r["attempts"])
        by_target_arm[(r["target"], r["arm"])].append(r["attempts"])
        family_right[r["arm"]].append(r["first_choice_family_right"])

    def cell(values: list[int | None]) -> str:
        if not values:
            return "-"
        solved = [v for v in values if v is not None]
        censored = len(values) - len(solved)
        mean = statistics.mean(solved) if solved else float("nan")
        return f"{mean:.2f} ({len(solved)}/{len(values)} within {budget})" if censored else f"{mean:.2f}"

    targets = sorted({r["target"] for r in results})
    arms = list(by_arm)
    baseline = {(r["target"], r["fault"]): r["attempts"] for r in results if r["arm"] == "memory:none"}
    lines = [
        "| arm | " + " | ".join(targets)
        + " | all (repairs + probes) | probes | saved vs no memory | worse than no memory | first pick in right family |",
        "|---" * (len(targets) + 6) + "|",
    ]
    for arm in arms:
        cells = [cell(by_target_arm[(t, arm)]) for t in targets]
        right = family_right[arm]
        rows = [r for r in results if r["arm"] == arm]
        saved = [
            (baseline[(r["target"], r["fault"])] or budget) - (r["attempts"] or budget) for r in rows
        ]
        worse = sum(1 for s in saved if s < 0)
        probes = sum(r.get("probes", 0) for r in rows)
        lines.append(
            f"| {arm} | " + " | ".join(cells) + f" | {cell(by_arm[arm])} | {probes} | "
            f"{statistics.mean(saved):+.2f} | {worse}/{len(rows)} | {sum(right)}/{len(right)} |"
        )
    lines.append("")
    lines.append("Skipped (fault took no effect on that body, so not a failure case):")
    for target, faults in evaluation["skipped"].items():
        lines.append(f"- {target}: {', '.join(faults) or 'none'}")
    return "\n".join(lines)


def main(argv: list[str]) -> None:
    if not argv:
        raise SystemExit(__doc__)
    if argv[0] == "cache":
        for name in argv[1:] or available_platforms():
            build_cache(name)
    elif argv[0] == "run":
        evaluation = evaluate(argv[1:] or None)
        out = CACHE_DIR / "evaluation.json"
        out.write_text(json.dumps(evaluation, indent=1))
        print("## probes charged as a full attempt (cost 1.0)\n")
        print(summarize(evaluation))
        cheap = evaluate(argv[1:] or None, probe_cost=0.25)
        (CACHE_DIR / "evaluation_probe_cost_0.25.json").write_text(json.dumps(cheap, indent=1))
        print("\n## probes charged at a quarter of an attempt (cost 0.25)\n")
        print(summarize(cheap))
        print(f"\nwrote {out}")
    else:
        raise SystemExit(__doc__)


if __name__ == "__main__":
    main(sys.argv[1:])
