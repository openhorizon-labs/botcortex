"""Targeted measurements: what to do when the evidence cannot decide.

The pilot found two faults no contract signature separates on a single
body: a biased pose estimate and a stale one both read "completed, the
target is still on the table, the program saw nothing move, and its
estimate disagrees with the verifier". Replaying the trace does not help —
the trace is the same. What separates them is a MEASUREMENT: change the
world by a known amount and see whether the estimate follows. A biased
tracker follows (it is wrong by a constant); a stale one does not (it is
not looking).

Two probes, deliberately unequal, so choosing between them means something:

- `reobserve` — passive, cheap in the field, and uninformative here: ask
  the perception layer again without touching anything, report whether
  the estimate changed.
- `nudge` — active and bounded: displace the target by a known 20 mm
  (on hardware, a low-force push at an operator-approved configuration;
  here, the simulator moves the block), re-observe, and report whether the
  estimate tracked the motion.

Every probe costs one budget unit, the same as a repair attempt. The
dossier is explicit that diagnostic actions are charged against the
hardware budget; a probe that is free would always be worth taking.

The choice of probe in this slice is a HAND-WRITTEN RULE — "when bias and
stale pose are the live hypotheses, nudge" — and is labelled as such
wherever it is scored. It is not an expected-information policy and not
learned. The random-probe baseline exists so that the rule's value over
picking blindly is measured rather than assumed.
"""

from __future__ import annotations

import random
from dataclasses import dataclass

from botcortex.research import perception as perceptionlib

#: How far the estimate must move to count as having tracked the nudge.
TRACK_THRESHOLD_M = 0.010
NUDGE_M = (0.02, 0.0, 0.0)


@dataclass(frozen=True)
class Probe:
    name: str
    cost: float = 1.0
    active: bool = False


#: Default cost: a probe is charged like a full task attempt. On hardware a
#: re-observation takes seconds and a task attempt takes a minute plus a
#: reset, so the evaluation also reports a cheaper setting — the number
#: that decides whether a probe is worth taking is this ratio.
CATALOG = (Probe("reobserve", cost=1.0, active=False), Probe("nudge", cost=1.0, active=True))
BY_NAME = {p.name: p for p in CATALOG}


def _distance(a, b) -> float:
    return sum((x - y) ** 2 for x, y in zip(a, b, strict=True)) ** 0.5


def run_probe(probe: Probe, robot, perception: perceptionlib.Perception, target: str) -> bool | None:
    """Execute one probe after a failed attempt, on the same world and the
    same (possibly faulty) perception. Returns the measurement, or None
    when the target cannot be observed at all."""
    before = perception()
    seen_before = before["objects"].get(target)
    if seen_before is None:
        return None
    if probe.active:
        perceptionlib._nudge(robot, target, NUDGE_M)
        robot.settle(0.2)
    after = perception()
    seen_after = after["objects"].get(target)
    if seen_after is None:
        return None
    moved = _distance(seen_before["position"], seen_after["position"])
    return moved > TRACK_THRESHOLD_M


def ambiguous(signature: dict) -> bool:
    """The live hypotheses are bias and stale pose: a completed run, the
    target still where it started by the program's own account, and an
    estimate the verifier disagrees with."""
    return (
        signature.get("outcome") == "completed"
        and signature.get("perception_disagreement") is True
        and not signature.get("target_moved")
    )


def choose_probe_by_rule(signature: dict, done: dict[str, bool | None]) -> str | None:
    if ambiguous(signature) and "nudge" not in done:
        return "nudge"
    return None


def choose_probe_at_random(signature: dict, done: dict[str, bool | None], rng: random.Random) -> str | None:
    if not ambiguous(signature):
        return None
    left = [p.name for p in CATALOG if p.name not in done]
    return rng.choice(left) if left else None
