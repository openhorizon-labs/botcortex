"""Agent-authored skills: parametrized Python files the runtime owns and executes.

A skill is a single .py file with `META = {"name", "description", "params"}` and
`run(ctx, **params)`. Skills can only touch the robot through the SkillContext —
the exec namespace has no imports, no filesystem, and a whitelisted builtins set.
That restriction is a guardrail against accidental misuse (an agent-written `open()`
or `os.system`), not a hardened security boundary; marketplace-grade sandboxing
comes with the hub.
"""

from __future__ import annotations

import math
import re
from pathlib import Path

from botcortex import config
from botcortex.safety import Collision

NAME_RE = re.compile(r"^[a-z][a-z0-9_]{1,63}$")

# Enough for motion math; nothing that reaches the interpreter's edges.
SAFE_BUILTINS = {
    name: __builtins__[name] if isinstance(__builtins__, dict) else getattr(__builtins__, name)
    for name in (
        "abs", "all", "any", "bool", "dict", "enumerate", "float", "int", "len",
        "list", "max", "min", "range", "round", "sorted", "reversed", "str", "sum",
        "tuple", "zip", "True", "False", "None", "ValueError", "RuntimeError",
        "TypeError", "KeyError", "Exception", "isinstance",
    )
    if (isinstance(__builtins__, dict) and name in __builtins__)
    or (not isinstance(__builtins__, dict) and hasattr(__builtins__, name))
}


class SkillError(ValueError):
    """The skill code failed validation or execution."""


class SkillContext:
    """The only handle a skill gets. Wraps the primitives; nothing else exists.

    on_step, when set, receives (label,) before each primitive call — the server
    uses it to stream live progress to the plan view.
    """

    def __init__(self, robot, on_step=None, perception=None):
        self._robot = robot
        self.platform = getattr(robot, "platform", config.PLATFORM)
        self._on_step = on_step
        #: What the skill SEES, when it is not the simulator's own truth. The
        #: research harness puts its perception layer here so that faults in
        #: observation reach the program while the verifier keeps reading the
        #: world directly — see botcortex.research.perception. None means the
        #: robot's describe_scene, which is the product path.
        self._perception = perception
        self.math = math
        self.last_step: str | None = None

    def _step(self, label: str) -> None:
        self.last_step = label
        if self._on_step:
            self._on_step(label)

    def get_positions(self, arm: str) -> dict[str, float]:
        return self._robot.get_positions(arm)

    @property
    def arms(self) -> tuple[str, ...]:
        """The arms this robot has — ("right", "left") on OpenArm, ("arm",)
        on a single manipulator. A skill that hardcodes "right" is written
        for one body; one that reads this runs on the next."""
        return self.platform.arms

    def gripper_range(self, arm: str) -> tuple[float, float]:
        """(fully open, fully closed) in gripper degrees for this body.

        Every platform's gripper limit is declared open-to-closed, so a skill
        can open and close without knowing whether the jaws are two sliding
        fingers, a tendon, or one hinged clamp."""
        lo, hi = self.platform.joint_limits[arm]["gripper"]
        return (lo, hi)

    def describe_scene(self) -> dict:
        """Where the objects are, right now.

        Skills need this as much as the agent does. Without it an authored
        skill can only hold the coordinates it was written with, so "pick up
        the red block" works exactly once — the next time the block is
        anywhere else, the arm closes on air. A skill that reads the scene at
        run time is the difference between a recording and a program.
        """
        if self._perception is not None:
            return self._perception()
        return self._robot.describe_scene()

    def move_to(self, arm: str, targets: dict[str, float], duration: float | None = None) -> None:
        self._step(f"move_to {arm} {targets}")
        self._robot.move_to(arm, targets, duration)

    def go_home(self) -> None:
        """Every arm to the pose the robot rests in.

        Sequential, because v0 has no concurrency primitive — the same reason
        the system prompt tells the agent two-arm coordination is sequential.

        Through park() rather than a raw move: home is LOW, so from over the
        tray a single joint-space move sweeps the hand down through the table
        edge. The backend routes and rehearses its way there — see
        kinematics.retreat.
        """
        for arm in getattr(self._robot, "platform", config.PLATFORM).arms:
            self._step(f"home {arm}")
            self._robot.park(arm)

    def move_to_point(self, arm: str, point, tolerance: float = 0.02) -> None:
        """Put the grasp centre at a point in metres, gripper pointing down.

        The bridge from describe_scene (metres) to the arm (degrees). Without
        it a skill can see exactly where a block is and has no way to go there,
        which is what issue #16 discovered.
        """
        self._step(f"move_to_point {arm} {[round(float(v), 3) for v in point]}")
        self._robot.move_to_point(arm, point, tolerance)

    def gripper(self, arm: str, position: float) -> None:
        self._step(f"gripper {arm} -> {position}")
        self._robot.gripper(arm, position)

    def set_torque(self, arm: str, enabled: bool) -> None:
        self._step(f"set_torque {arm} {enabled}")
        self._robot.set_torque(arm, enabled)

    def clear_errors(self) -> None:
        self._robot.clear_errors()

    def replay_trajectory(self, arm: str, waypoints: list[dict[str, float]]) -> None:
        self._step(f"replay_trajectory {arm} ({len(waypoints)} waypoints)")
        self._robot.replay_trajectory(arm, waypoints)


class SkillStore:
    """Loads, validates, saves, and runs skills from a directory of .py files."""

    def __init__(self, directory: Path):
        self.directory = Path(directory)
        self.directory.mkdir(parents=True, exist_ok=True)

    def _compile(self, name: str, code: str):
        """Exec the skill in the restricted namespace; return (meta, run)."""
        namespace = {"__builtins__": dict(SAFE_BUILTINS), "math": math}
        try:
            # exec IS the skill runtime — the restricted namespace above is the guardrail.
            exec(compile(code, f"<skill:{name}>", "exec"), namespace)  # noqa: S102
        except ImportError as e:
            raise SkillError(
                f"skills cannot import ({e}); everything a skill needs is on ctx"
            ) from e
        except SyntaxError as e:
            raise SkillError(f"syntax error in skill: {e}") from e
        meta = namespace.get("META")
        run = namespace.get("run")
        if not isinstance(meta, dict) or "name" not in meta or "description" not in meta:
            raise SkillError('skill must define META = {"name", "description", "params"}')
        if not callable(run):
            raise SkillError("skill must define run(ctx, **params)")
        meta.setdefault("params", {})
        return meta, run

    def save(self, name: str, code: str) -> dict:
        if not NAME_RE.match(name):
            raise SkillError("skill name must be snake_case ascii, e.g. wave_right_arm")
        meta, _ = self._compile(name, code)
        if meta["name"] != name:
            raise SkillError(f'META["name"] ({meta["name"]!r}) must match the save name ({name!r})')
        (self.directory / f"{name}.py").write_text(code)
        # New code is unproven code. Saving over a skill that HAD run drops the
        # mark, because what ran was the old version — otherwise the third
        # rewrite of a broken skill inherits the first one's good name.
        self._proof(name).unlink(missing_ok=True)
        return meta

    def delete(self, name: str) -> bool:
        """Remove a skill and its proof mark. True if there was one to remove.

        The proof goes too: a `.ran` file surviving its skill would crown the
        NEXT skill saved under this name with a run it never had.
        """
        path = self.directory / f"{name}.py"
        existed = path.exists()
        path.unlink(missing_ok=True)
        self._proof(name).unlink(missing_ok=True)
        return existed

    # --- which of these has ever actually worked -----------------------------
    #
    # The sidebar's promise is "your robot knows these". A skill the agent wrote
    # and never got to run — or ran and watched fail — is not something the
    # robot knows, and listing it beside the ones that work is the same lie as
    # reporting a failed teach as done. So a run that completes leaves a mark
    # next to the file, and everything that lists skills can say which is which.
    #
    # A file rather than an in-memory flag: the claim has to survive a restart,
    # and it is worth being able to see it on disk.

    def _proof(self, name: str) -> Path:
        return self.directory / f"{name}.ran"

    def mark_ran(self, name: str) -> None:
        """This exact code ran to completion at least once."""
        self._proof(name).touch()

    def has_run(self, name: str) -> bool:
        return self._proof(name).exists()

    def unproven(self) -> list[str]:
        """Saved, but never seen to run. Named for the UI to mark."""
        return [name for name in self.names() if not self.has_run(name)]

    def list(self) -> list[dict]:
        metas = []
        for path in sorted(self.directory.glob("*.py")):
            try:
                meta, _ = self._compile(path.stem, path.read_text())
                metas.append(meta)
            except SkillError:
                continue  # a broken file must not take the whole store down
        return metas

    def names(self) -> list[str]:
        return [m["name"] for m in self.list()]

    def run(self, name: str, ctx: SkillContext, *, home: bool = True, **params):
        """Execute a skill, from home and back to home.

        Bracketing every skill with a move to HOME_POSITION is the runtime's
        job rather than the agent's, for the same reason clamping and the
        e-stop are: a rule that only holds when a model remembers to write it
        does not hold. An agent that forgot the return leaves the arm extended
        over the workcell for whatever runs next.

        It also makes a skill REPRODUCIBLE. Two runs from different starting
        poses take different paths and can reach different outcomes, which
        would put a confound straight into the success rate the eval suite
        exists to measure.

        A real move, never `robot.reset()`: reset teleports, which is why it
        exists only on backends with no physical arm to fling. This goes home
        the way any other motion does — interpolated, velocity-capped, e-stop
        checked between frames.

        On FAILURE the arm stays where it stopped. Homing afterwards would
        overwrite the evidence, and moving an arm right after an unexplained
        failure is the wrong instinct on hardware. `home=False` skips both ends
        for a caller that is composing skills and does not want the round trip.

        THE BRACKET IS NOT THE SKILL, and the failure has to say which broke.
        Measured on a real attempt: an agent wrote a correct pick-and-place,
        the body ran to completion, and the closing go_home swept the hand
        through the table on its way back from over the tray. The collision was
        reported as the skill's, so the agent concluded its grasp descent was
        too low and raised it — three times, each time breaking the grasp a
        little more, each time getting the same collision from the same
        bracket. It was debugging a sentence about someone else's move.
        """
        path = self.directory / f"{name}.py"
        if not path.exists():
            raise SkillError(f"no skill named {name!r}; known: {self.names()}")
        meta, run = self._compile(name, path.read_text())
        merged = {**meta.get("params", {}), **params}

        if home:
            self._home(ctx, opening=True)
        result = run(ctx, **merged)
        if home:
            self._home(ctx, opening=False)
        return result

    @staticmethod
    def _home(ctx: SkillContext, *, opening: bool) -> None:
        """The runtime's own move to the rest pose, owning its own failures."""
        try:
            ctx.go_home()
        except Collision as e:
            raise Collision(
                (
                    f"{e}\n\nTHIS WAS NOT YOUR SKILL. The runtime moves both arms to the "
                    "rest pose before every skill, and the arm could not get there from "
                    "where it was already standing. Reset the sim, or move the arm clear "
                    "by hand, before running anything."
                )
                if opening
                else (
                    f"{e}\n\nTHIS WAS NOT YOUR SKILL — the skill body ran all the way "
                    "through. The runtime then moves both arms back to the rest pose, "
                    "and THAT move crashed. Do not change your grasp or your waypoints "
                    "to fix this: change where the skill LEAVES the arm. Finish lower "
                    "and closer in rather than high and extended over the workcell."
                )
            ) from e
