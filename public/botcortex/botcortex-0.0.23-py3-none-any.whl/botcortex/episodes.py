"""Every run, kept as something a policy can be trained on.

`memory.py` remembers WHAT WENT WRONG, in words, for the agent that writes the
next skill. This keeps what HAPPENED, tick by tick, for a model that learns to
move: the sentence that was asked, where every joint was and what it was told,
where every object was, what the camera saw, and whether it worked — checked by
the runtime, not labelled by a person.

Two things make it more than a log.

FAILURES ARE KEPT, AND TIED TO THEIR REPAIR. A run that fails is an episode. When
the same skill is next seen to work, the working episode names the failures it
repairs and each of them names it back, and both carry the skill's source — so
the pair is a failure, the fix, and the success, on the same task. That triplet
is the training signal nobody else was found collecting (docs/research/
skills_to_vla_novelty.md); successes alone are what every generator keeps.

STATES ARE RECORDED; PIXELS CAN WAIT. In simulation an image is a pure function
of the joints and the object poses, so an episode recorded with no camera — in
a browser tab, or in a rehearsal nobody watched — can be rendered afterwards
(`render`). On a real arm the camera frame is taken as it happens, because
reality cannot be re-rendered.

What counts as the trajectory is decided by DEPTH. A run is full of rehearsals:
every `move_to_point` tries routes inside one before it commits. Those are the
robot thinking, not moving. So a recording names the rehearsal depth it is
following — 0 for the real run, 1 for a skill being rehearsed whole — and ticks
at any other depth are ignored.

The index and the ticks are plain JSON so that nothing here needs numpy; only
images do, and only when there are images.
"""

from __future__ import annotations

import hashlib
import json
from datetime import UTC, datetime
from pathlib import Path

from botcortex import config, scene

VERSION = 1


def joint_names(platform) -> list[str]:
    """The order every state and action vector is in: arm by arm, joint by joint."""
    return [f"{arm}.{joint}" for arm in platform.arms for joint in platform.joint_limits[arm]]


class Recorder:
    """Attach with `robot.recorder = Recorder(...)`. The robot calls `tick` once
    per control tick; the session brackets each run with `begin` and `end`."""

    def __init__(
        self,
        root: Path | None,
        cameras: dict | None = None,
        image_stride: int = 2,
        sink=None,
    ):
        """`root` keeps episodes as files; `sink` is handed each one as an
        event, for whoever keeps them somewhere else — the API's database, from
        a robot (cloud.EpisodeUploader) or from a browser tab that has no disk
        (root=None). Either, or both. A sink must not raise and must not block:
        it is called from inside a run."""
        self.root = Path(root) if root is not None else None
        self.sink = sink
        #: For a simulator, cameras to film with as it happens, by view name
        #: ("front", "side"). A RealRobot's own camera is used without being
        #: named here, as "front".
        self.cameras = dict(cameras or {})
        #: Keep every n-th pixel each way: policies train at 224 to 320 wide,
        #: and a full-size episode is a fifth of a gigabyte.
        self.image_stride = image_stride
        self._open: dict | None = None
        self._last_stamp = 0

    @property
    def recording(self) -> bool:
        return self._open is not None

    def begin(self, robot, *, depth: int, **meta) -> None:
        """Start an episode following rehearsal depth `depth`. A recording
        already open is dropped: it never reached `end`, so nothing is known
        about how it went."""
        platform = robot.platform
        commanded = {arm: robot.get_positions(arm) for arm in platform.arms}
        self._open = {
            "depth": depth,
            "commanded": commanded,
            "meta": {
                "version": VERSION,
                "ts": datetime.now(UTC).isoformat(timespec="seconds"),
                "platform": platform.name,
                "backend": type(robot).__name__,
                "fps": config.CONTROL_HZ,
                "names": joint_names(platform),
                "objects": sorted(getattr(robot, "_object_addr", {})),
                "scene_before": _positions(robot),
                **meta,
            },
            "state": [],
            "action": [],
            "poses": [],
            "images": {},
        }

    def tick(self, robot, arm: str, frame: dict[str, float]) -> None:
        episode = self._open
        if episode is None or getattr(robot, "_depth", 0) != episode["depth"]:
            return
        episode["commanded"][arm].update(frame)
        arms = robot.platform.arms
        observed = getattr(robot, "observed_positions", robot.get_positions)
        episode["state"].append([round(v, 3) for a in arms for v in observed(a).values()])
        episode["action"].append(
            [round(v, 3) for a in arms for v in episode["commanded"][a].values()]
        )
        addresses = getattr(robot, "_object_addr", None)
        if addresses:
            poses = scene.object_poses(robot.data.qpos, addresses)
            episode["poses"].append(
                [[round(v, 4) for v in poses[n]] for n in episode["meta"]["objects"]]
            )
        eyes = self.cameras
        if not eyes and episode["depth"] == 0 and getattr(robot, "camera", None) is not None:
            eyes = {"front": robot.camera}
        s = self.image_stride
        for view, eye in eyes.items():
            episode["images"].setdefault(view, []).append(eye.rgb()[::s, ::s].copy())

    def end(self, robot, *, ok: bool, **outcome) -> str | None:
        """Close the episode and write it. Returns its id, or None when nothing
        moved — a refusal before the first tick is not a trajectory."""
        episode, self._open = self._open, None
        if episode is None or not episode["state"]:
            return None
        meta = episode["meta"]
        stamp = max(int(datetime.now(UTC).timestamp() * 1000), self._last_stamp + 1)
        self._last_stamp = stamp  # two in one millisecond still get two ids
        episode_id = f"e{stamp}-{meta.get('skill', 'run')}"
        if self.root is not None:
            self.root.mkdir(parents=True, exist_ok=True)
        record = {
            "id": episode_id,
            **meta,
            "ok": ok,
            **outcome,
            "scene_after": _positions(robot),
            "repairs": [],
            "repaired_by": None,
            "length": len(episode["state"]),
            "images": None,
            "ticks": {
                "state": episode["state"],
                "action": episode["action"],
                "poses": episode["poses"],
            },
        }
        if episode["images"] and self.root is not None:
            import numpy as np

            # One array per view, keyed by its name. Images stay on disk: they
            # are megabytes, and in simulation `dataset.render` can remake them
            # from the ticks a sink was given.
            np.savez_compressed(
                self.root / f"{episode_id}.npz",
                **{view: np.stack(frames) for view, frames in episode["images"].items()},
            )
            record["images"] = f"{episode_id}.npz"
            record["views"] = sorted(episode["images"])
        if self.root is not None:
            (self.root / f"{episode_id}.json").write_text(json.dumps(record))
        self._send({"event": "episode", "episode": record})
        return episode_id

    def link(self, success_id: str, failed_ids: list[str]) -> None:
        """`success_id` repaired `failed_ids`. Said to the files and to the sink."""
        if not failed_ids:
            return
        if self.root is not None:
            link_repair(self.root, success_id, failed_ids)
        self._send({"event": "link", "success": success_id, "failed": list(failed_ids)})

    def tag(self, episode_id: str, **fields) -> None:
        """Add facts learned after an episode closed, such as its memory record."""
        if self.root is not None and (self.root / f"{episode_id}.json").exists():
            record = load(self.root, episode_id)
            record.update(fields)
            (self.root / f"{episode_id}.json").write_text(json.dumps(record))
        self._send({"event": "tag", "id": episode_id, "fields": fields})

    def _send(self, event: dict) -> None:
        if self.sink is None:
            return
        try:
            self.sink(event)
        except Exception:  # noqa: BLE001, S110 — keeping data must never break a run
            pass

    def discard(self) -> None:
        self._open = None


def _positions(robot) -> dict[str, list[float]]:
    addresses = getattr(robot, "_object_addr", None)
    if not addresses:
        return {}
    return {
        n: [round(v, 4) for v in p[:3]]
        for n, p in scene.object_poses(robot.data.qpos, addresses).items()
    }


def code_of(store, name: str) -> dict:
    """The skill as it stood when it ran. A repair IS a change to this text, so
    a failure and its fix are only comparable if both kept their own copy."""
    try:
        source = (store.directory / f"{name}.py").read_text()
    except OSError:
        return {"code": None, "code_sha": None}
    return {"code": source, "code_sha": hashlib.sha256(source.encode()).hexdigest()[:16]}


# --- reading them back ------------------------------------------------------


def load(root: Path, episode_id: str) -> dict:
    return json.loads((Path(root) / f"{episode_id}.json").read_text())


def index(root: Path) -> list[dict]:
    """Every episode, oldest first, without its ticks."""
    out = []
    for path in sorted(Path(root).glob("e*.json")):
        record = json.loads(path.read_text())
        record.pop("ticks", None)
        record.pop("code", None)
        out.append(record)
    return out


def link_repair(root: Path, success_id: str, failed_ids: list[str]) -> None:
    """`success_id` is the run that finally worked; `failed_ids` the attempts at
    the same skill that did not. Written on both sides so either can be found
    from the other."""
    root = Path(root)
    failed_ids = [f for f in failed_ids if (root / f"{f}.json").exists()]
    if not failed_ids or not (root / f"{success_id}.json").exists():
        return
    success = load(root, success_id)
    success["repairs"] = sorted({*success.get("repairs", []), *failed_ids})
    (root / f"{success_id}.json").write_text(json.dumps(success))
    for failed_id in failed_ids:
        failed = load(root, failed_id)
        if failed.get("repaired_by") is None:
            failed["repaired_by"] = success_id
            (root / f"{failed_id}.json").write_text(json.dumps(failed))


def triplets(root: Path) -> list[dict]:
    """failure -> repair -> success, one entry per failed episode that was later
    repaired. `changed` says whether the skill's code differs between the two:
    when it does not, the world changed and the code did not, which is a
    different kind of repair and should not be trained on as the same thing."""
    records = {r["id"]: r for r in index(root)}
    out = []
    for record in records.values():
        fixed_by = records.get(record.get("repaired_by") or "")
        if record["ok"] or fixed_by is None:
            continue
        out.append(
            {
                "failure": record["id"],
                "success": fixed_by["id"],
                "skill": record.get("skill"),
                "platform": record.get("platform"),
                "kind": record.get("kind"),
                "changed": record.get("code_sha") != fixed_by.get("code_sha"),
            }
        )
    return out


def summary(root: Path) -> dict:
    records = index(root)
    by_kind: dict[str, int] = {}
    for r in records:
        if not r["ok"]:
            by_kind[r.get("kind") or "unknown"] = by_kind.get(r.get("kind") or "unknown", 0) + 1
    return {
        "episodes": len(records),
        "succeeded": sum(r["ok"] for r in records),
        "failed": sum(not r["ok"] for r in records),
        "with_images": sum(bool(r.get("images")) for r in records),
        "ticks": sum(r["length"] for r in records),
        "platforms": sorted({r["platform"] for r in records}),
        "skills": sorted({r.get("skill") or "?" for r in records}),
        "failure_kinds": by_kind,
        "triplets": len(triplets(root)),
    }
