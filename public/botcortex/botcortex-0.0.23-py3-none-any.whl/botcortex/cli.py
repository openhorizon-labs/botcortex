"""BotCortex CLI — `botcortex "task"` (alias `bx`).

Dry-run is the default; real motion requires --execute AND an operator present.
The hardware path lands at milestone 3 — v0 is mock-first by design.
"""

import argparse
import os
import socket
import sys
from pathlib import Path

from botcortex import __version__, config, routines
from botcortex.robot import EStopTriggered, MockRobot


def _robot_identity(name: str | None = None) -> tuple[str, str, int]:
    """What this robot calls itself on the approval screen and in the app.

    The hostname is only a default. Two arms plugged into one machine would
    otherwise pair under the same name and collide on the account's
    (owner, name) index — the second registration silently updating the
    first's row instead of creating its own. --name, or BOTCORTEX_ROBOT_NAME
    in .env for something that survives reboots, settles it.
    """
    chosen = (name or os.environ.get("BOTCORTEX_ROBOT_NAME") or "").strip()
    if not chosen:
        chosen = socket.gethostname().split(".")[0].lower() or "robot"
    return chosen, config.PLATFORM.name, len(config.ARMS)


def _login(port: int, key: str | None = None, name: str | None = None) -> None:
    """Pair this robot with a BotCortex account (RFC 8628 device flow).

    The human never types a secret and the robot never handles a password:
    they approve a short code in a browser where their session already lives,
    and the durable key travels back over TLS.
    """
    from botcortex import cloud

    name, platform, arms = _robot_identity(name)

    # Escape hatch for machines with no browser anywhere near them.
    if key:
        path = cloud.save_key(key)
        print(f"✓ Key saved to {path}")
        return

    try:
        pairing = cloud.start_pairing()
    except (OSError, RuntimeError) as e:
        sys.exit(f"Could not reach BotCortex at {config.API_URL}: {e}")

    cloud.describe(pairing["device_code"], name, platform, arms)

    print()
    print(f"  Open  {pairing['verification_uri']}")
    print(f"  Code  {pairing['user_code']}")
    print()
    print(f'  Approving as "{name}" ({platform}, {arms} arms)')
    print("  Waiting for approval…", flush=True)

    try:
        token = cloud.poll_for_approval(
            pairing["device_code"], pairing["interval"], pairing["expires_in"]
        )
        minted = cloud.exchange_for_key(token, name)
    except (OSError, RuntimeError) as e:
        sys.exit(f"\n✗ {e}")
    except KeyboardInterrupt:
        sys.exit("\n  Cancelled.")

    address = cloud.lan_address(port)
    cloud.register(minted["key"], pairing["device_code"], name, platform, arms, address)
    path = cloud.save_key(minted["key"])

    # Read back through the key itself — proves it works before we claim it does.
    config.API_KEY = minted["key"]
    who = cloud.whoami()
    owner = (who or {}).get("user", {}).get("email", "your account")
    credit = (who or {}).get("credit", {}).get("display", "")

    print(f"\n  ✓ Paired with {owner}" + (f" · {credit} credit" if credit else ""))
    print(f"    Key saved to {path}")
    print(f"    Reachable at {address} — it will appear in the app's robot list.")


def _forget(name: str | None) -> None:
    """Delete a skill from this robot and from the account registry, saying
    plainly what happened to each copy — a human asked, so neither half may
    fail silent the way best-effort sync is allowed to."""
    if not name:
        sys.exit("Which skill? Usage: botcortex forget <name>")

    from botcortex import cloud
    from botcortex.skills import SkillStore

    store = SkillStore(config.SKILLS_DIR)
    known = store.names()
    if store.delete(name):
        print(f"✓ Deleted {name} from this robot")
    else:
        listed = f" Known: {', '.join(known)}." if known else " No skills saved yet."
        print(f"  No local skill named {name!r}.{listed}")

    if not cloud.paired():
        return  # BYO robots have no registry copy to chase.
    print(
        {
            "deleted": "✓ Removed the account registry copy",
            "absent": "  The account registry had no copy",
            "refused": "  ! BotCortex rejected this robot's key — run `botcortex login`, "
            "then `botcortex forget` again to clear the registry copy.",
            "unreachable": "  ! Could not reach BotCortex — the registry copy, if any, "
            "is still there. Re-run this when the robot is back online.",
        }[cloud.forget(name)]
    )


def _camera(args) -> None:
    """`botcortex camera list | use | show | calibrate | check` — everything a
    camera needs, from the terminal, for whichever body BOTCORTEX_PLATFORM names."""
    from botcortex import camera as cameras
    from botcortex import config

    path = cameras.settings_path(config.DATA_DIR, config.PLATFORM.name)
    action = args.extra or "help"
    try:
        if action == "list":
            found = cameras.list_cameras()
            for c in found:
                if c["kind"] == "opencv":
                    print(
                        f"  webcam {c['source']}  {c['size'][1]}x{c['size'][0]}   ->  botcortex camera use webcam {c['source']}"
                    )
                else:
                    print(f"  {c['name']} (depth)   ->  botcortex camera use realsense")
            if not found:
                print(
                    "  no camera found. Plug one in, or name a stream: botcortex camera use http://…"
                )
        elif action == "use":
            kind = args.more[0] if args.more else ""
            if kind == "realsense":
                chosen = {"kind": "realsense"}
            elif kind == "webcam" or kind.startswith(("http", "rtsp")):
                source = (args.more[1] if len(args.more) > 1 else "0") if kind == "webcam" else kind
                chosen = {"kind": "opencv", "source": int(source) if source.isdigit() else source}
            else:
                sys.exit("usage: botcortex camera use webcam [index] | realsense | <stream url>")
            cameras.open_camera(chosen).close()  # fail now, not at the first task
            # A different camera stands somewhere else: the old calibration goes.
            path.unlink(missing_ok=True)
            cameras.save_settings(path, **chosen)
            print(
                f"  using {chosen}. Next: botcortex camera show, then botcortex camera calibrate --execute"
            )
        elif action == "show":
            eye = cameras.open_camera(cameras.load_settings(path))
            out = config.DATA_DIR / "camera_view.png"
            cameras.write_png(out, eye.frame().rgb)
            eye.close()
            print(f"  wrote {out} — the whole bench and all the blocks should be in it")
        elif action == "calibrate":
            _calibrate_camera(args, path)
        elif action == "check":
            from botcortex.real import open_real

            robot, _ = open_real(config.PLATFORM, execute=False, loopback=args.loopback)
            scene = robot.describe_scene()["objects"]
            for name, body in scene.items():
                why = robot.unseen.get(name)
                where = ", ".join(f"{v:.3f}" for v in body["position"])
                print(f"  {name:<14} " + (f"NOT SEEN — {why}" if why else f"at ({where}) m"))
            robot.close()
        else:
            print(
                "botcortex camera list | use <webcam [n] | realsense | url> | show | calibrate --execute | check"
            )
    except (ValueError, ImportError, RuntimeError) as e:
        sys.exit(str(e))


def _dataset(args) -> None:
    """`botcortex dataset summary | generate | repair | render | export` — see docs/DATASETS.md.

    Runs are kept as episodes when BOTCORTEX_RECORD=1; `generate` makes them by
    the hundred from one saved skill, in simulation, for whichever body
    BOTCORTEX_PLATFORM names.
    """
    from botcortex import config, episodes

    root, action = config.EPISODES_DIR, args.extra or "help"

    def simulator():
        from botcortex.sim import SimRobot

        return SimRobot(config.PLATFORM, realtime=False)

    try:
        if action == "summary":
            for key, value in episodes.summary(root).items():
                print(f"  {key:<14} {value}")
            print(
                f"  in {root}"
                + ("" if config.RECORD else "   (recording is OFF: set BOTCORTEX_RECORD=1)")
            )
        elif action == "generate":
            from botcortex import dataset
            from botcortex.skills import SkillStore

            if not args.more:
                sys.exit("usage: botcortex dataset generate <skill> [count] [wobble_degrees]")
            skill = args.more[0]
            count = int(args.more[1]) if len(args.more) > 1 else 50
            wobble = float(args.more[2]) if len(args.more) > 2 else 0.0
            store = SkillStore(config.SKILLS_DIR)
            if skill not in store.names():
                sys.exit(
                    f"no skill called {skill!r}; this robot knows: {', '.join(store.names()) or 'none'}"
                )
            described = next((s["description"] for s in store.list() if s["name"] == skill), skill)
            print(
                f"  {count} runs of {skill} on {config.PLATFORM.display_name}, blocks scattered each time …"
            )
            made = dataset.generate(
                simulator,
                store,
                skill,
                root,
                count,
                instruction=described,
                wobble_deg=wobble,
                say=print,
            )
            print(
                f"  done: {made['ok']} worked, {made['failed']} failed (kept, with why). botcortex dataset summary"
            )
        elif action == "repair":
            from botcortex import dataset
            from botcortex.skills import SkillStore

            if not args.more:
                sys.exit("usage: botcortex dataset repair <skill>")
            made = dataset.replay_failures(
                simulator, SkillStore(config.SKILLS_DIR), root, args.more[0], say=print
            )
            print(
                f"  {made['replayed']} old failures replayed with the skill as it is now; {made['repaired']} repaired and linked"
            )
        elif action == "render":
            from botcortex import dataset

            blind = [
                r
                for r in episodes.index(root)
                if not r.get("images") and r["platform"] == config.PLATFORM.name
            ]
            for record in blind:
                dataset.render(root, record["id"], simulator)
            print(f"  filmed {len(blind)} episodes that were recorded without a camera")
        elif action == "export":
            from botcortex import dataset

            if not args.more:
                sys.exit("usage: botcortex dataset export <dir> [repo_id]")
            repo_id = (
                args.more[1] if len(args.more) > 1 else f"local/botcortex_{config.PLATFORM.name}"
            )
            out = dataset.to_lerobot(
                root, Path(args.more[0]).expanduser(), repo_id, config.PLATFORM.name
            )
            print(
                f"  wrote {out['episodes']} episodes, {out['frames']} frames"
                + ("" if out["filmed"] else " (no images: run `botcortex dataset render` first)")
            )
        else:
            print(
                "botcortex dataset summary | generate <skill> [count] | render | export <dir> [repo_id]"
            )
    except (ValueError, ImportError, RuntimeError) as e:
        sys.exit(str(e))


def _calibrate_camera(args, path) -> None:
    from botcortex import calibrate, config
    from botcortex import camera as cameras
    from botcortex.real import open_real

    if not args.execute and not args.loopback:
        sys.exit(
            "calibration moves the arm to six spots over the bench. Clear the bench except ONE block,\n"
            "be within reach of the power switch, then: botcortex camera calibrate --execute"
        )
    robot, label = open_real(
        config.PLATFORM, execute=True, device=args.device, loopback=args.loopback, camera=False
    )
    eye = cameras.open_camera(cameras.load_settings(path)) if not args.loopback else None
    if eye is None:
        sys.exit("--loopback has no camera to calibrate: its simulated one is already exact.")
    blocks = robot.describe_scene()["objects"]
    block = args.more[0] if args.more else min(blocks)
    print(f"  {label}. Calibrating on {block}: keep only that block on the bench.")
    found = calibrate.calibrate(robot, eye, block, ask=input)
    cameras.save_settings(path, **found)
    robot.close()
    print(
        f"  saved. The spots agree to {found['residual_m'] * 1000:.1f} mm. Check it: botcortex camera check"
    )


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="botcortex", description="Teach your robot new tasks by typing."
    )
    parser.add_argument(
        "task",
        nargs="?",
        help='what to do, e.g. "wave right arm" — or "login" / "serve" / "forget <skill>"',
    )
    parser.add_argument(
        "extra",
        nargs="?",
        help="argument for the command before it, e.g. the skill name for forget",
    )
    parser.add_argument("more", nargs="*", help="further arguments, e.g. `camera use webcam 1`")
    parser.add_argument("--mock", action="store_true", help="run against the in-memory mock robot")
    parser.add_argument(
        "--execute",
        action="store_true",
        help="allow REAL motion, with `serve --real` and `camera calibrate`. Be at the arm.",
    )
    parser.add_argument(
        "--real", action="store_true", help="serve the physical arm (dry run without --execute)"
    )
    parser.add_argument("--device", help="the arm's serial port, e.g. /dev/cu.usbserial-110")
    parser.add_argument(
        "--loopback",
        action="store_true",
        help="with --real: a simulated arm and camera behind the real wire protocol — no hardware needed",
    )
    parser.add_argument("--port", type=int, default=9090, help="port for `botcortex serve`")
    parser.add_argument(
        "--sim",
        action="store_true",
        help="serve MuJoCo physics instead of the mock (needs [sim] extra)",
    )
    parser.add_argument("--version", action="store_true", help="print version and exit")
    parser.add_argument(
        "--key",
        help="paste an existing bx_live_ key instead of pairing (headless installs, CI, fleets)",
    )
    parser.add_argument(
        "--name",
        help="what to call this robot in the app (default: hostname, or $BOTCORTEX_ROBOT_NAME)",
    )
    args = parser.parse_args()

    if args.version:
        print(f"botcortex {__version__}")
        return
    if args.execute and not (args.real or args.task == "camera"):
        sys.exit(
            "--execute moves a physical arm: use it with `serve --real` or `camera calibrate`."
        )
    if not args.task:
        parser.print_help()
        return

    if args.task == "login":
        _login(port=args.port, key=args.key, name=args.name)
        return

    if args.task == "forget":
        _forget(args.extra)
        return

    if args.task == "camera":
        _camera(args)
        return

    if args.task == "dataset":
        _dataset(args)
        return

    if args.task == "serve":
        from botcortex import cloud, server

        robot, label = None, ""
        if args.real:
            from botcortex import config
            from botcortex.real import open_real

            try:
                robot, label = open_real(
                    config.PLATFORM,
                    execute=args.execute,
                    device=args.device,
                    loopback=args.loopback,
                )
            except (ValueError, ImportError, RuntimeError) as e:
                sys.exit(str(e))
        backend = label if robot is not None else "MuJoCo sim" if args.sim else "mock robot"
        # flush: uvicorn logs to stderr while this goes to a block-buffered
        # stdout, so under nohup/systemd the banner sat in the buffer and the
        # NOT PAIRED warning never reached the one place someone would look.
        print(
            f"botcortex serving on http://localhost:{args.port} ({backend}, ws at /ws)",
            flush=True,
        )
        # Say which wallet teaching spends from, every time. The half-paired
        # case is the one that used to be invisible, so it gets a warning and
        # the command that fixes it rather than a quiet status line.
        if cloud.half_paired():
            print(
                "  ! NOT PAIRED — points at BotCortex but has no robot key.\n"
                "    Teaching is refused rather than billed to your own model provider.\n"
                "    Run `botcortex login` to pair it.",
                flush=True,
            )
        elif cloud.paired():
            print("  · paired — teaching spends BotCortex credit", flush=True)
        else:
            print(
                "  · bring-your-own-key — teaching spends your model provider directly",
                flush=True,
            )
        server.serve(port=args.port, sim=args.sim, robot=robot, label=label.split(" ")[0].lower())
        return

    if not args.mock:
        sys.exit('v0 supports --mock only. Try: botcortex --mock "wave right arm"')

    task = args.task.lower()
    if task.startswith("wave"):
        # Deterministic built-in — the zero-API smoke test.
        arm = "left" if "left" in task else "right"
        robot = MockRobot()
        try:
            steps = routines.wave(robot, arm=arm)
        except EStopTriggered as e:
            sys.exit(f"E-STOP: {e}")
        print(
            f"[mock] waved the {arm} arm: {steps} interpolation steps at 20 Hz, "
            "velocity-capped, e-stop checked every step. Final pose: home."
        )
        return

    # Anything else goes through the authoring agent (needs Anthropic credentials).
    import anthropic

    from botcortex.agent import TeachSession

    session = TeachSession(MockRobot())
    print(f"[mock] teaching: {args.task!r} (model {config.MODEL})")
    try:
        result = session.teach(args.task)
    except anthropic.AuthenticationError:
        sys.exit(
            "No Anthropic credentials. Set ANTHROPIC_API_KEY (or `ant auth login`) — "
            "BotCortex is BYO-key and never resells inference."
        )
    except anthropic.APIConnectionError as e:
        sys.exit(f"Could not reach the model API: {e}")

    print(result.text or "(no reply)")
    marker = "✓" if result.outcome == "ok" else "✗"
    print(
        f"[{marker}] outcome={result.outcome} skills_used={result.skills_used or '[]'} "
        f"— episode logged to {config.MEMORY_FILE}"
    )
